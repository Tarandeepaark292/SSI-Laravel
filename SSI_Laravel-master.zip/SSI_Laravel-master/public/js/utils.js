var Utils = {

	isLoading: false,

	showLoading: function (msg) {
		this.isLoading = true;
		$.blockUI({
			message: '<div style="padding:10px;font-size: 2em;text-align: center;font-family:\'Ostrich Sans regular\';display:block;color:#black;background: ##f7f6f3;">' +
				'<div style="display:inline-block;font-size:1em;text-transform:uppercase;">' + msg + '</div></div>',
			css: {
				cursor: 'default',
				top: '40%',
				border: 'solid 2px #007bff'
			}
		});
	},
	hideLoading: function () {
		this.isLoading = false;
		$.unblockUI();
    }
}