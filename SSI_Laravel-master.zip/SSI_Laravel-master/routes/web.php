<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', 'MiscController@home');
Route::get('/testpdf','MiscController@testpdf');

Route::get('/testpay', 'PaymentController@testpay');
Route::post('/confirm', 'PaymentController@Postconfirmation');
Route::post('/js/confirm', 'PaymentController@jsPostconfirmation');

Route::get('/about', 'MiscController@about');

Route::get('/recruiters', 'RecruiterController@allrecruiters');
// Route::get('/recruiters', function () {
//     return view('recruiters');
// });
Route::get('/post-job-ad', function () {
    return view('post-job-ad');
});
Route::get('/bulk-job-posting', function () {
    return view('bulk-job-posting');
});

Route::get('/advertise-us','MiscController@advertiseWithUs');

Route::get('/email-us',function(){
    return view('email_us');
});
// Route::get('/resumes', function () {
//     return view('resumes');
// });

// Route::get('/jobseekers', function () {
//     return view('jobseekers');
// });
// Route::get('/broadcast-resume', function () {
//     return view('broadcast-resume');
// });
// Route::get('/all-jobs', function () {
//     return view('all-jobs');
// });

Route::get('/all-jobs','MiscController@alljobs');
// Route::get('/my-acccount', function () {
//     return view('my-acccount');
// });

Route::get('/employees', function () {
    return view('employees');
});

// Route::get('/corporate-social-funding', function () {
//     return view('corporate-social-funding');
// });

Route::get('/corporate-social-funding', 'MiscController@getCSRfunding');

// Route::get('/all-csr-ads', function () {
//     return view('all-csr-ads');
// });

// Route::get('/register-grants', function () {
//     return view('register-grants');
// });
Route::get('/events', function () {
    return view('events');
});
// Route::get('/all-event-ads', function () {
//     return view('all-event-ads');
// });



// Route::get('/recruiters', function () {
//     return view('recruiters');
// });
Route::get('/rfp', function () {
    return view('rfp');
});
Route::get('/fellowshipads', function () {
    return view('fellowshipads');
});
Route::get('/financial-services', function () {
    return view('financial-services');
});
Route::get('/contact', 'MiscController@contact');
// Route::get('/contact', function () {
//     return view('contact');
// });
Route::get('/our-reach', function () {
    return view('our-reach');
});
// Route::get('/faq', function () {
//     return view('faq');
// });
Route::get('/faq', 'MiscController@faq');
// Route::get('/privacy-policy', function () {
//     return view('privacy-policy');
// });
Route::get('/privacy-policy', 'MiscController@privacypolicy');
Route::get('/terms-condition', 'MiscController@termscondition');
// Route::get('/terms-condition', function () {
//     return view('terms-condition');
// });
// Route::get('/post-proposal', function () {
//     return view('post-proposal');
// });
// Route::get('/all-ads', function () {
//     return view('all-ads');
// });

Route::get('/post-fellowship', function () {
    return view('post-fellowship');
});
// Route::get('/all-fellowship', function () {
//     return view('all-fellowship');
// });
Route::get('/accounting', 'MiscController@accountingview');
// Route::get('/accounting', function () {
//     return view('accounting');
// });
// Route::get('/auditing', function () {
//     return view('auditing');
// });
// Route::get('/tax-compliance', function () {
//     return view('tax-compliance');
// });
// Route::get('/fcra-services', function () {
//     return view('fcra-services');
// });
Route::get('/fcra-services', 'MiscController@fcraservices');
Route::get('/tax-compliance', 'MiscController@taxcompilance');
Route::get('/auditing', 'MiscController@auditing');

Route::get('/costing-list', function () {
    return view('costing-list');
});
Route::get('/statutory', function () {
    return view('statutory');
});

Route::get('/org-sector-wise', 'MiscController@orgSectorwise');
// Route::get('/org-sector-wise', function () {
//     return view('org-sector-wise');
// });
Route::get('/state-ut','MiscController@stateUt');
// Route::get('/state-ut', function () {
//     return view('state-ut');
// });
// Route::get('/post-funding', function () {
//     return view('post-funding');
// });

Route::get('/csr-funders', 'CsrfunderController@csrfundlist');
Route::get('/fcra-funders', 'FcraController@fcrafundlist');

Route::get('/csr-funder','CsrfunderController@categorycsr');

// Route::get('/csr-fundersaa','CsrfunderController@csrsearchblade');
Route::post('/csr-ajax', 'CsrfunderController@ajaxcsrfunders')->name('ajaxcsrfunder.post');

// Route::get('/csr-funders','CsrfunderController@ajaxcsr');




// Route::get('/search_all','CsrfunderController@search_list');

Route::post('/fcra-ajax','FcraController@ajaxfcrafunders')->name('ajaxfcrafunder.post');

// Route::get('/fcra-funders', 'FcraController@categoryfcra');
// Route::get('/post-event', function () {
//     return view('post-event');
// });

Route::get('/login', function () {
    return view('login');
});

Route::get('/register', function () {
    return view('register');
});
Route::get('adm_csr_list', function () {
    return view('adm_csr_list');
});


Route::get('/organizer-services', function () {
    return view('services');
});

//admin Views
Route::get('/admin/post-fc',"AdminController@adm_post_fc_grant");
Route::post('/post-fc/submit', "AdminController@adm_submit_fc_grant");

//csr admin//
Route::get('/admin/post-csr',"AdminController@adm_post_csr");
Route::post('/post-csr/submit', "AdminController@adm_submit_csr");

//fellowship
Route::get('/admin/post-fellowship',"AdminController@adm_post_fellowship");
Route::post('/post-fellowship/submit', "AdminController@adm_submit_fellowship");

//scholarship
Route::get('/admin/post-scholarship',"AdminController@adm_post_scholarship");
Route::post('/post-scholarship/submit', "AdminController@adm_submit_scholarship");
//Admission
Route::get('/admin/post-admission',"AdminController@adm_post_admission");
Route::post('/post-admission/submit', "AdminController@adm_submit_admission");

//Award
Route::get('/admin/post-award',"AdminController@adm_post_award");
Route::post('/post-award/submit', "AdminController@adm_submit_award");

//Callpaper
Route::get('/admin/post-callpaper',"AdminController@adm_post_callpaper");
Route::post('/post-callpaper/submit', "AdminController@adm_submit_callpaper");

//Events
Route::get('/admin/post-events',"AdminController@adm_post_events");
Route::post('/post-events/submit', "AdminController@adm_submit_events");

//Publication
Route::get('/admin/post-publication',"AdminController@adm_post_publication");
Route::post('/post-publication/submit', "AdminController@adm_submit_publication");

//Jobpost
Route::get('/admin/post-jobpost',"AdminController@adm_post_jobpost");
Route::post('/post-jobpost/submit', "AdminController@adm_submit_jobpost");

//Online Course
Route::get('/admin/post-onlinecourse',"AdminController@adm_post_onlinecourse");
Route::post('/post-onlinecourse/submit', "AdminController@adm_submit_onlinecourse");

//Organization
Route::get('/admin/organisation/register','AdminController@admin_organisation_register');
Route::post('/admin/organisation/submit', "AdminController@adm_organisation_submit");

//Recruiters Views
Route::get('/recruiter/resumes',"RecruiterController@resumes_list");
Route::get('/recruiter/applicantlist',"RecruiterController@jobapp_list");
Route::get('/recruiter/dashboard', "RecruiterController@loadDashboard");
Route::get('/recruiter/change-password', "RecruiterController@show_change_password");
Route::get('/recruiter/profile', "RecruiterController@show_edit_info");

Route::post('/recruiter/rec_password/update/{recid}','RecruiterController@updatePassword');
Route::post('/recruiter/profile/update/{recid}','RecruiterController@updateProfile');

Route::get('/recruiter/csr-list', "RecruiterController@csr_list");
Route::get('/recruiter/event-list', "RecruiterController@evt_list");
Route::get('/recruiter/award-list', "RecruiterController@awd_list");

Route::get('/recruiter/fell-list', "RecruiterController@fell_list");
Route::get('/recruiter/sc-list', "RecruiterController@sc_list");
Route::get('/recruiter/pub-list', "RecruiterController@pub_list");
Route::get('/recruiter/onlinecourse-list', "RecruiterController@online_courselist");
Route::get('/recruiter/admission-list', "RecruiterController@rec_admission_list");

Route::get('/recruiter/rfp-list', "RecruiterController@rfp_list");
Route::get('/recruiter/call-list', "CallpaperController@reccallpaperlist");

Route::get('/recruiter/reg-list', "RecruiterController@rgrant_list");
Route::get('/recruiter/job-post-list', "RecruiterController@job_post_list");
Route::get('/recruiter/purchase-list', "RecruiterController@purchaseList");
Route::get('/recruiter/payment-list', 'RecruiterController@paymentList');
Route::get('/recruiter/post-csr', 'RecruiterController@post_csr');
Route::get('/recruiter/post-event', 'RecruiterController@post_event');
Route::get('/recruiter/post-fellowship', 'RecruiterController@post_fellowship');
Route::get('/recruiter/post-grant', 'RecruiterController@post_reg_grant');
Route::get('/recruiter/post-rfp', 'RecruiterController@post_RFP');
Route::get('/recruiter/post-job-post', 'RecruiterController@post_JobPost');
Route::get('/recruiter/items', 'RecruiterController@purchasableitems');
// Route::get('/recruiter/post-donate','RecruiterController@post_donate');
Route::get('/recruiter/post_award', 'RecruiterController@post_award');
Route::get('/recruiter/post_scholarship', 'RecruiterController@post_scholarship');
Route::get('/recruiter/post-online-course', 'RecruiterController@post_onlinecourse');
Route::get('/recruiter/post-publication', 'RecruiterController@post_publication');
Route::get('/recruiter/post-admission', 'RecruiterController@post_admission');
Route::get('/recruiter/post-callpaper', 'RecruiterController@post_callpaper');
Route::get('/recruiter/shop-resume', 'RecruiterController@shop_resume_view');
Route::get('/recruiter/purchased_resume', 'RecruiterController@purchased_resume_view');


Route::get('/organization/login', 'LoginController@organization_login');
Route::get('/organization/register', 'LoginController@organization_register');
Route::get('/organization/forgot-password', 'LoginController@organization_forgotpwd');
Route::post('/organization/resetpwd','LoginController@resetpwd');


Route::get('/recruiter/logout', "RecruiterController@logout");

Route::post('/js/register', "JobseekerController@register");

// Route::get('/preview/jobseeker/{url}','PreviewController@js1_preview');
Route::get('/js/forgot-password', 'LoginController@js_forgotpwd');
Route::post('/js/resetpwd','LoginController@jsresetpwd');
Route::get('/js/change-password','JobseekerController@show_change_password');
Route::get('/js/shortlist-jobs','JobseekerController@show_shortlist_jobs');
Route::get('/js/messages','JobseekerController@show_rece_msgs');

Route::post('/js/js_password/update/{jspid}','JobseekerController@updatePassword');

Route::get('/js/logout', "JobseekerController@logout");

Route::post('/recruiter/register', "RecruiterController@register");
Route::post('/csr/submit', "MiscController@submitCSR");
Route::post('/event/submit', "MiscController@submitEVENT");
Route::post('/employees/submit', "JobseekerController@jobseekerSubmit");
Route::post('/userlogin', "LoginController@userlogin");
Route::post('/onlinecourse/submit', "OnlineCourseController@submitonlinecourse");
Route::post('/publication/submit', "PublicationController@submitpublication");
Route::post('/admission/submit', "AdmissionController@submitAdmission");
Route::post('/callpaper/submit', "CallpaperController@submitCallPaper");


Route::get('/all-admissions', 'AdmissionController@admissionads');
Route::post('/alladmissions', 'AdmissionController@ajax_search_admission')->name('ajax_search_admission.post');
Route::get('/all-callpaper','CallpaperController@callpaperads');    
Route::post('/all-call','CallpaperController@ajax_search_callpaper')->name('ajax_search_callpaper.post');  //Search page
Route::post('/allonline', 'OnlineCourseController@ajaxonlinecourse')->name('ajaxonline.post');
Route::get('/all-online-course', 'OnlineCourseController@searchonline');
Route::get('/all-publication', 'PublicationController@searchpublication');
Route::post('/allpublication', 'PublicationController@ajaxpublication')->name('ajaxpublication.post');
Route::get('/all-grants', 'MiscController@searchregistergrants');
Route::get('/ngo-dir', 'NgoDirectoryController@NgoDirectory_list');
Route::post('/ngo-dir', 'NgoDirectoryController@ajaxNgoDirectory_list')->name('ajaxNgoDirectory.post');

// Jobseeker Payment 
Route::get('/jobseeker/payment-list', 'JobseekerController@paymentList');
Route::get('/jobseeker/purchase-list', 'JobseekerController@purchaseList');
Route::post('/searchjobseeker-ajax', 'RecruiterController@ajaxfilterjobseeker')->name('ajaxfilterjobseeker.post');

Route::post('/alljobs-ajax', 'MiscController@ajaxjob')->name('ajaxjob.post');



//Employer Panel
Route::get('/employee/csr-list1', "EmployeeController@csr_list1");
Route::get('/employee/event-list1', "EmployeeController@evt_list1");
Route::get('/employee/fell-list1', "EmployeeController@fell_list1");
Route::get('/employee/rfp-list1', "EmployeeController@rfp_list1");
Route::get('/employee/reg-list1', "EmployeeController@rgrant_list1");
Route::get('/employee/job-post-list1', "EmployeeController@job_post_list1");



Route::get('/userlogout', "LoginController@userlogout");
Route::get('/testadmin', function () {
    return view('testadmin');
});

// Route::get('/rfp','RfpController@getRFP');
// Route::post('/rfp/submit',"RfpController@submitRFP");

Route::get('/post-rfp', 'RfpController@getRFP1');
Route::post('/post-proposal/submit', "RfpController@submitRFP1");


Route::get('/fellowship', 'FellowshipController@getFellowship');
Route::post('/fellowship/submit', "FellowshipController@submitFellowship");

Route::get('/register-grants', 'RegistergrantsController@getGrants');
Route::post('/register-grants/submit', "RegistergrantsController@submitGrants");

Route::post('/recruiters/submit', "JobpostController@submitJB");

Route::get('/preview/csr/{url}', 'PreviewController@rec_csr_preview');
Route::get('/preview/rfp/{url}', 'PreviewController@rfp_preview');
Route::get('/preview/fell/{url}', 'PreviewController@fell_preview');
Route::get('/preview/sc/{url}', 'PreviewController@scholarship_preview');
Route::get('/preview/grant/{url}', 'PreviewController@grant_preview');
Route::get('/preview/evt/{url}', 'PreviewController@evt_preview');
Route::get('/preview/award/{url}', 'PreviewController@awd_preview');
Route::get('/preview/job-post/{url}', 'PreviewController@rec_jobpost_preview');
Route::get('/preview/job-seeker/{url}', 'PreviewController@js_preview');

Route::get('/csr/{url}', 'SeoController@rec_csr_SEO');
Route::get('/rfp/{url}', 'SeoController@rfp_SEO');
Route::get('/fell/{url}', 'SeoController@fell_SEO');
Route::get('/scholarship/{url}', 'SeoController@sc_SEO');
Route::get('/grant/{url}', 'SeoController@grant_SEO');
Route::get('/evt/{url}', 'SeoController@evt_SEO');
Route::get('/award/{url}', 'SeoController@awd_SEO');
Route::get('/job-post/{url}', 'SeoController@rec_jobpost_SEO');
Route::get('/admission/{url}', 'SeoController@admission_SEO');
Route::get('/online-course/{url}', 'SeoController@onlinecourse_SEO');
Route::get('/call-paper/{url}', 'SeoController@callpaper_SEO');
Route::get('/publication_seo/{url}', 'SeoController@publication_SEO');

Route::get('/news/{url}', 'SeoController@news_detail_seo');
Route::get('/donate/{url}', 'SeoController@donation_detail_seo');
Route::get('/jobseeker/{url}', 'SeoController@js_SEO');
Route::get('/jobseeker/enc/{url}', 'SeoController@js_enc_SEO');
Route::get('/csr-funder/{url}', 'SeoController@csr_funder_seo');
Route::get('/fcra-funder/{url}', 'SeoController@fcra_funder_seo');
Route::get('/ngo-dir/{url}', 'SeoController@NgoDirectory_seo');


Route::get('/show', 'PaymentController@showcart');
Route::get('/organizer/showcart', 'PaymentController@showorganizercart');

Route::get('/js/showcart', 'PaymentController@showjscart');
Route::get('/js/broadcastResume','JobseekerController@broadcastResume');
//MISCPages
Route::get('/success', function () {
    return view('success');
});
// Route::get('/successpage/{message?}', function () {
//     return view('successpage');
// });
Route::get('/organizer/successpage/{message?}', 'MiscController@successPage')->name('sp');
Route::get('/error-page', function () {
    return view('error');
});
Route::get('/error/{message?}', 'MiscController@errorPage')->name('ep');
Route::get('/testredirect', function () {
    return redirect()->route('sp', ['CSR']);
});

Route::get('/confirmation/{purchaseid}/{encs}', 'PaymentController@confirmation');
Route::get('/js/confirmation/{purchaseid}/{encs}', 'PaymentController@js_confirmation');

//AJAX ROUTES

//ADMIN ROUTES

Route::get('/admin/post-ngodirectory','NgoDirectoryController@post_ngodirectory');
Route::post('/admin/post-ngodirectory/submit','NgoDirectoryController@submit_ngodirectory');
Route::get('/admin/ngodirectorylist','NgoDirectoryController@showngodirectory');
Route::get('/admin/ngo-directory-detail/{ngo_id}','NgoDirectoryController@showngodirectorydetail');
Route::post('/admin/edit-ngodirectory/{ngo_id}','NgoDirectoryController@updategodirectorydetail');

Route::get('/admin/adminlogin', function () {
    return view('adminlogin');
});
Route::get('/admin/logout','AdminLoginController@adminlogout');
Route::post('/admin/adminlogin/check', "AdminLoginController@adminlogin");



Route::post('/js/apply', 'JobseekerController@applyjob')->name('ajaxapplyjob.post');
Route::post('/admin/csr_enable', 'AdminController@enableCSR')->name('ajaxCSRenable.post');
Route::post('/admin/csr_disable', 'AdminController@disableCSR')->name('ajaxCSRdisable.post');
Route::post('/admin/evt_enable', 'AdminController@enableEvent')->name('ajaxEVTenable.post');
Route::post('/admin/evt_disable', 'AdminController@disableEvent')->name('ajaxEVTdisable.post');
Route::post('/admin/award_enable', 'AdminController@enableAward')->name('ajaxAWDenable.post');
Route::post('/admin/award_disable', 'AdminController@disableAward')->name('ajaxAWDdisable.post');
Route::post('/admin/rfp_enable', 'AdminController@enableRFP')->name('ajaxRFPenable.post');
Route::post('/admin/rfp_disable', 'AdminController@disableRFP')->name('ajaxRFPdisable.post');
Route::post('/admin/fell_enable', 'AdminController@enableFell')->name('ajaxFELLenable.post');
Route::post('/admin/fell_disable', 'AdminController@disableFell')->name('ajaxFELLdisable.post');
Route::post('/admin/rg_enable', 'AdminController@enableRgrant')->name('ajaxRGenable.post');
Route::post('/admin/rg_disable', 'AdminController@disableRgrant')->name('ajaxRGdisable.post');
Route::post('/admin/pub_enable', 'AdminController@enablepub')->name('ajaxpubenable.post');
Route::post('/admin/pub_disable', 'AdminController@disablepub')->name('ajaxpubdisable.post');
Route::post('/admin/online_enable', 'AdminController@enableonline')->name('ajaxonlineenable.post');
Route::post('/admin/online_disable', 'AdminController@disableonline')->name('ajaxonlinedisable.post');
//callpaper
Route::post('/admin/call_enable', 'AdminController@enablecallpaper')->name('ajaxcallpaperenable.post');
Route::post('/admin/call_disable', 'AdminController@disablecallpaper')->name('ajaxcallpaperdisable.post');
Route::get('/admin/online-list', "AdminController@online_courselist");
Route::get('/admin/pub-list', "AdminController@publications");
Route::get('/admin/banner-list', "BannerController@showBanners_View");
Route::get('/admin/applicants-list', "AdminController@showapplicant_view");
Route::post('/admin/update-banner', "BannerController@submitBanner1");

Route::get('/admin/job-post-list', 'AdminController@jobposts');
Route::get('/admin/csr-list', "AdminController@CSRlist");
Route::get('/admin/event-list', "AdminController@Eventlist");
Route::get('/admin/award-list', "AdminController@AwardList");
Route::get('/admin/sch-list', "AdminController@scholarshiplist");
Route::get('/admin/fell-list', "AdminController@FELLOWSHIP");
Route::get('/admin/fcra-list', "FcraController@FCRAlIST");
Route::get('/admin/rfp-list', "AdminController@RFP");
Route::get('/admin/reg-list', "AdminController@REG");
Route::get('/admin/seo-list', "SeoController@SEOlist");

Route::get('/admin/recruiter-list', "AdminController@RECRUITER");
// Route::get('/admin/job-post-list',"AdminController@REC");
Route::get('/admin/csrfunder-list', "CsrfunderController@csrfunderlist");
Route::get("/admin/csrfunder/update/{encid}", 'CsrfunderController@show_csrfunder_Detail');
Route::post('/admin/csrfunder/updates/{encid}', 'CsrfunderController@update_csrfunder');

Route::get('/admin/post_csrfunder', "AdminController@admin_show_csrfunder_view");
Route::post('/admin/csrfunder/submit',"CsrfunderController@submitCSRfunder");

Route::get('/admin/post_fcrafunder', "AdminController@admin_show_fcrafunder_view");
Route::post('/admin/fcrafunder/submit',"FcraController@submitFCRAfunder");

Route::get('/admin/rec-payment-list', "AdminController@RecruiterPaymentList");
Route::get('/admin/rec-purchase-list', "AdminController@RecruiterPurchaseList");
Route::get('/admin/js-payment-list', "AdminController@JobseekerPaymentList");
Route::get('/admin/js-purchase-list', "AdminController@JobseekerPurchaseList");
Route::get('/admin/post_news', "AdminController@admin_show_news_view");
Route::get('/admin/post-donate', 'AdminController@post_donate');
Route::post('/admin/news/submit', "NewsController@submitNEWS");
Route::get('/admin/news_list', "AdminController@admin_news");
Route::get('/admin/subscriber_list', "SubscriberController@showSubsList");

Route::get('/admin/donation_list', "AdminController@admin_donations");
Route::get('/admin/adm_admission_list', "AdminController@adm_admission_list");
Route::get('/admin/adm_call_list','AdminController@adm_call_list'); //Form submit page
Route::post('/admin/adn_enable', 'AdminController@enableadmission')->name('ajaxadmissionenable.post');
Route::post('/admin/adn_disable', 'AdminController@disableadmission')->name('ajaxadmissiondisable.post');
Route::get("/admin/admissiondetail/{pbcid}", 'AdminController@adm_admission_edit');
Route::post('/admin/admission/update/{pbcid}', 'AdminController@adm_admission_update');
Route::get("/admin/eventdetail/{evt_id}", 'EventController@show_event_Detail');
Route::get("/admin/awarddetail/{awcid}", 'AwardController@show_award_Detail');
Route::get("/admin/donationdetail/{awcid}", 'AdminController@admin_show_donate_detail_view');
Route::get("/admin/publicationdetail/{pbcid}", 'AdminController@show_publication_Detail');
Route::post('/admin/publication/update/{pbcid}', 'AdminController@update_publication');
Route::get("/admin/onlinedetail/{pbcid}", 'AdminController@show_online');
Route::post('/admin/onlinecourse/update/{pbcid}', 'AdminController@update_onlinecourse');
Route::get("/admin/scdetail/{scid}", 'ScholarshipController@show_scholarship_Detail');
Route::get("/admin/job-postdetail/{scid}", 'AdminController@show_jobpost_Detail');
Route::get("/admin/reg-detail/{scid}", 'RegistergrantsController@show_registergrants_Detail');
Route::get("/admin/calldetail/{paper_id}",'CallpaperController@show_call_Detail'); //edit
Route::post("/admin/update_fcra/{f_f_id}",'FcraController@update_fcra');   //update
Route::post("/admin/update_news/{news_id}",'NewsController@update_news');   //update

Route::get("/admin/dashboard", 'AdminController@loadDashboard');

Route::get("/admin/csrdetail/{scid}", 'AdminController@show_csr_Detail');
Route::get("/admin/rfpdetail/{scid}", 'AdminController@show_rfp_Detail');
Route::get("/admin/felldetail/{scid}", 'AdminController@show_fell_Detail');
Route::get("/admin/fcradetail/{scid}", 'FcraController@show_fcra_Detail');
Route::get("/admin/newsdetail/{scid}", 'NewsController@show_news_Detail');
Route::get("/admin/seodetail/{scid}", 'SeoController@show_seo_Detail');


Route::post('/admin/scholarship_enable', 'AdminController@enablescholarship')->name('ajaxscholarshipdenable.post');
Route::post('/admin/scholarship_disable', 'AdminController@disablescholarship')->name('ajaxscholarshipdisable.post');
Route::post('/admin/jobpost_enable', 'JobpostController@enablejobpost')->name('ajaxjobpostenable.post');
Route::post('/admin/jobpost_disable', 'JobpostController@disablejobpost')->name('ajaxjobpostdisable.post');

Route::post('/admin/bcresume_enable', 'JobseekerController@enablebcresume')->name('ajaxbcenable.post');
Route::post('/admin/bcresume_disable', 'JobseekerController@disablebcresume')->name('ajaxbcdisable.post');

Route::post("/admin/update_jobpost/{evt_id}", 'AdminController@update_jobpost');
Route::post("/admin/updateevent/{evt_id}", 'EventController@update_event');
Route::post("/admin/updatesc/{sc_id}", 'ScholarshipController@update_scholarship');
Route::post('/admin/updaterfp/{encid}', 'AdminController@update_rfp');
Route::post('/admin/updatecsr/{encid}', 'AdminController@update_csr');
Route::post('/admin/update_fell/{encid}', 'AdminController@update_fell');
Route::post('/admin/update_reg/{encid}', 'RegistergrantsController@update_register');
Route::post("/admin/update_call/{paper_id}",'CallpaperController@update_call'); 
Route::post("/admin/updateseo/{seo_id}",'SeoController@update_seo');   //update
  //update


Route::post('/award/update/{encid}', 'AwardController@update_awards');
Route::get('/all-awards', 'AwardController@searchads');
Route::post('/allawards', 'AwardController@ajaxaward')->name('ajaxawards.post');
Route::post('/award/submit', 'AwardController@submitaward');


Route::get('/all-scholarship', 'ScholarshipController@searchscholarship');
Route::post('/allscholarship', 'ScholarshipController@ajaxscholarship')->name('ajaxscholarship.post');
Route::post('/scholarship/submit', 'ScholarshipController@submitscholarship');

Route::post('/shop/addtocart', 'PaymentController@addtoCart')->name('ajaxaddcart.post');
Route::post('/shop/addresumetocart', 'PaymentController@addResumetoCart')->name('ajaxaddresumetocart.post');

//new
Route::get('/homeupload', 'MiscController@home');
//admin login
// Route::post('/adminlogin/check',"AdminLoginController@adminlogin");
// Route::get('/adminlogin', function () {
//     return view('adminlogin');
// });

Route::get('/all-fcgrant-ads', 'RfpController@rfpads');
Route::post('/allrfp', 'RfpController@ajaxrfp')->name('ajaxrfp.post');

Route::get('/all-csr-ads', 'MiscController@csrads');
Route::post('/allcsr', 'MiscController@ajaxcsr')->name('ajaxcsr.post');

Route::get('/all-fellowship', 'FellowshipController@fellads');
Route::post('/allfell', 'FellowshipController@ajaxfell')->name('ajaxfell.post');

Route::get('/all-event-ads', 'MiscController@evtads');
Route::post('/allevt', 'MiscController@ajaxevt')->name('ajaxevt.post');

// Route::get('/js_job_list/edit/{jspid}', 'JobseekerController@show_job_edit');
Route::get('/js/show-js-edit/{jspid}', 'JobseekerController@show_job_edit');
Route::get('/js/show-js-edit/{jspid}', 'JobseekerController@show_job_edit');
Route::get('/js/show-js-resume-edit/{jspid}', 'JobseekerController@show_job_resume_edit');

Route::post('/js/js_profile/update/{jspid}', 'JobseekerController@admJobListupdate');
Route::post('/js/js_resume/update/{jspid}', 'JobseekerController@updateResumeContent');
Route::get('/js/dashboard','JobseekerController@showDashboard');
// Route::post('/js_job_list/update/{jspid}', 'JobseekerController@admJobListupdate');



Route::get('/admin/js_job_list', "JobseekerController@JOB");

//resume data 
Route::get('/resumes', 'MiscController@resumeads');
Route::post('/res', 'MiscController@ajaxresume')->name('ajaxresume.post');

Route::get('/adm_news', "AdminController@admin_show_news_view");
Route::post('/news/submit', "NewsController@submitNEWS");
// Route::get('/adm_news_list',"AdminController@admin_news");

Route::get('/donate', function () {
    return view('donate');
});
Route::post('/alldonate', 'DonateController@ajaxDonate')->name('ajaxDonate.post');
Route::post('/post-donate/submit', "DonateController@Donate");
Route::get('/all-donate', 'DonateController@Donates');
Route::get('/NGO/offices-policies', function(){
    return view('NGO_four');
});
Route::get('/NGO/overview', function(){
    return view('NGO_one');
});
Route::get('/NGO/byelaws', function(){
    return view('NGO_two');
});
Route::get('/NGO/fcra', function(){
    return view('NGO_three');
});

Route::get("/admin/donate/detail/{encid}", 'DonateController@show_donation_Detail');
Route::post('/admin/donation/updates/{encid}', 'DonateController@update_donate');
Route::get('/all-news', 'NewsController@News');
Route::get('/admin/rfp/export', 'ExportController@rfpexport');
Route::get('/admin/js/export', 'ExportController@jobseekerexport');
Route::get('/admin/org/export', 'ExportController@organizerexport');
Route::get('/admin/jobpost/export', 'ExportController@jobpostexport');
Route::get('/admin/registergrants/export', 'ExportController@regrantsexport');
Route::get('/admin/admission/export', 'ExportController@admissionexport');
Route::get('/admin/events/export', 'ExportController@eventexport');
Route::get('/admin/callpaper/export', 'ExportController@callpaperexport');
Route::get('/admin/award/export', 'ExportController@awardexport');
Route::get('/admin/scholarship/export', 'ExportController@scholarshipexport');
Route::get('/admin/onlinecourse/export', 'ExportController@onlinecourseexport');


Route::get("/testmail","NewsController@testmail");



Route::post("/organizer/sendmsg","RecruiterController@sendMsg")->name('ajaxsendmsg.post');;
Route::get("/jobseeker/showmsg","JobseekerController@showMsg");
Route::post("/subscriber/create","SubscriberController@createSubscriber")->name('ajaxcreatesubs.post');;

//NGO RESOURCE
Route::post('/admin/submitadm_ngo_docs',"NgoresourceController@adminngodocuments");
Route::post('/admin/submitadm_ngo_info',"NgoresourceController@submitadminngo");
Route::get('/admin/ngoresource',"NgoresourceController@getresources");

//Download DB
Route::get("/admin/download/DB","MiscController@downloaddb");