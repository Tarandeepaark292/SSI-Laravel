<?php
$input = array();
$input['inputObj']['c_uid'] = 1;//intval($_SESSION["tapman_user_id"]);
$input['inputObj']['c_token'] = "sfdfsfgfd";//"2018-09-27";

$payload = json_encode($input);

$ch = curl_init( "http://socialservicesindia.org/api/cron/fixPUB" );
# Setup request to send json via POST.
// $payload = json_encode( array( "customer"=> $data ) );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
error_log( json_encode($result));
echo json_encode($result) . "\n";
curl_close($ch);

?>