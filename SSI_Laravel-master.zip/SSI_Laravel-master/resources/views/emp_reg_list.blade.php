@extends('layouts.emp_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Employee Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Employee Panel</li>
            <li class="breadcrumb-item active">Register Grant List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Register Grant List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>org name</th>
                                <th>website</th>
                                <th>Organization Name</th>
                                <th>Create Date</th>
                                <th>Submitted By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($reglist)
                            <tfoot>
                                <tr>
                                    <th>org name</th>
                                    <th>website</th>
                                    <th>Organization Name</th>
                                    <th>Create Date</th>
                                    <th>Submitted By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($reglist as $noti)
                                    <tr>
                                        <td>{{ $noti['reg_v_org'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['reg_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['reg_website'] }}</td>
                                        <td>{{ $noti['reg_valid_To'] }}</td>
                                        <td>{{ $noti['reg_submitted_by'] }}</td>
                                        <td>{{ $noti['reg_status'] }}</td>
                                        {{-- <td>
                                            <button class="btn btn-outline-secondary">Details</button>
                                            
                                        </td> --}}
                                        <td>
                                            <!-- <button class="btn btn-outline-secondary">Preview</button> -->
                                            <a href="{{url('/preview/grant')}}/{{$noti['reg_enc_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                        </td>
                                        {{-- <td>
                                            @if($noti['reg_approved'] == '1')
                                            <span>Put on Hold</span>
                                            @else
                                            <span>Approve</span>
                                            @endif
                                        </td> --}}
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>

@endsection
