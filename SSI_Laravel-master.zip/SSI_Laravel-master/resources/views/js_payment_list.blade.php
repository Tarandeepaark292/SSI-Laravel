@extends('layouts.js_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Jobseeker Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Jobseeker Panel</li>
            <li class="breadcrumb-item active">Payment List</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Payment List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Order Number</th>
                                <th>Payment Total</th>
                                <th>Order ID</th>
                                <th>Create Date</th>
                                <th>Transaction Id</th>
                               
                            </tr>
                        </thead>
                        @isset($paylist)
                            <tfoot>
                                <tr>
                                    <th>Order Number</th>
                                    <th>Payment Total</th>
                                    <th>Order ID</th>
                                    <th>Create Date</th>
                                    <th>Transaction Id</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($paylist as $noti)
                                    <tr>
                                        <td>{{ $noti['pay_order_id'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['pay_total'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['pay_order_id'] }}</td>
                                <td>{{ $noti['pay_create_date'] }}</td>
                                <td>{{ $noti['pay_provider_trans_id'] }}</td>
                               
                                        
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>

@endsection
