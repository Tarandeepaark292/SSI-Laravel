@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Organisation Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">FellowShip List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>FellowShip List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Fellowship Title</th>
                                <th>Email</th>
                                <th>Organization Name</th>
                                <th>Create Date</th>
                                <th>Submitted By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($felllist)
                            <tfoot>
                                <tr>
                                    <th>Fellowship Title</th>
                                    <th>Email</th>
                                    <th>Organization Name</th>
                                    <th>Create Date</th>
                                    <th>Submitted By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($felllist as $noti)
                                    <tr>
                                        <td>{{ $noti['fell_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_o_name'] }}</td>
                                        <td>{{ $noti['fell_end_date'] }}</td>
                                        <td>{{ $noti['fell_submitted_by'] }}</td>
                                        <td>{{ $noti['fell_status'] }}</td>
                                        {{-- <td>
                                            <button class="btn btn-outline-secondary">Details</button>
                                            
                                        </td> --}}
                                        <td>
                                            @if($noti['fell_approved'] == '1')
                                            <a href="{{url('/fell')}}/{{$noti['fell_SEO']}}" target="_blank" class = "btn btn-outline-secondary">Live URL</a>
                                            @else
                                            <!-- <button class="btn btn-outline-secondary">Preview</button> -->
                                            <a href="{{url('/preview/fell')}}/{{$noti['fell_enc_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                            @endif
                                        </td>
                                        {{-- <td>
                                            @if($noti['fell_approved'] == '1')
                                            <span>Put on Hold</span>
                                            @else
                                            <span>Approve</span>
                                            @endif
                                        </td> --}}
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();

</script> 
@endsection
