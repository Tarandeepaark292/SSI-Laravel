@extends('layouts.home')
@section('content')
<section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">All </span> <span class="titleheading">Jobs</span> </h3>
                </header>
                <div class="row">
                    <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">
                        <div class="form-row">

                            <div class="form-group col-lg-6">

                                <input type="text" name="keywords" class="form-cntrl" id="keywords" placeholder="keywords" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">

                                <input type="text" name="keywords" class="form-cntrl" id="keywords" placeholder="location" />
                                <div class="validate"></div>
                            </div>


                        </div>

                        <label>job type</label>
                        <div class="field required-field">
                            <select name="job_type" id="job_type" class="form-cntrl" style="width:100%;">
                                <option class="level-0" value="3740">Contribution</option>
                                <option class="level-0" value="42">Freelance</option>
                                <option class="level-0" value="39" selected="selected">Full Time</option>
                                <option class="level-0" value="3649">Grant</option>
                                <option class="level-0" value="43">Internship</option>
                                <option class="level-0" value="40">Part Time</option>
                                <option class="level-0" value="41">Temporary</option>
                                <option class="level-0" value="3681">Work from Home</option>
                            </select>
                            <ul class="job_types">
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_contribution" class="contribution"><input type="checkbox" name="filter_job_type[]" value="contribution" checked="checked" id="job_type_contribution"> Contribution</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_freelance" class="freelance"><input type="checkbox" name="filter_job_type[]" value="freelance" checked="checked" id="job_type_freelance"> Freelance</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_full-time" class="full-time"><input type="checkbox" name="filter_job_type[]" value="full-time" checked="checked" id="job_type_full-time"> Full Time</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_grant" class="grant"><input type="checkbox" name="filter_job_type[]" value="grant" checked="checked" id="job_type_grant"> Grant</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_internship" class="internship"><input type="checkbox" name="filter_job_type[]" value="internship" checked="checked" id="job_type_internship"> Internship</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_part-time" class="part-time"><input type="checkbox" name="filter_job_type[]" value="part-time" checked="checked" id="job_type_part-time"> Part Time</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_temporary" class="temporary"><input type="checkbox" name="filter_job_type[]" value="temporary" checked="checked" id="job_type_temporary"> Temporary</label></li>
                                <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_work-from-home" class="work-from-home"><input type="checkbox" name="filter_job_type[]" value="work-from-home" checked="checked" id="job_type_work-from-home"> Work from Home</label></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12">
                        <span style="display: block;font-size: 16px;">
                            <p>
                                <br>
                                These are all the Jobs
                                <br>
                            </p>
                        </span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="query-content">
                            <table class="table-responsive-md">
                                <tbody>
                                    <tr>

                                        <td><a href="https://socialservicesindia.com/?job_listing=research-associate-2">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/2020/07/Pandit-Deendayal-Petroleum-University-150x94.png" alt="Pandit Deendayal Petroleum University" height="30px" width="30px">
                                        </td>
                                        <td>Research Associate<br>Pandit Deendayal Petroleum University</td>
                                        <td>Gandhinagar<br>(Gujarat)</td>
                                        <td>Full Time<br>Posted on July 25, 2020<br>Closes:</label> July 31, 2020</time> </td>
                                    </tr>

                                    <tr>
                                        <!-- <th scope="row">1</th> -->
                                        <td><a href="https://socialservicesindia.com/?job_listing=project-technical-officer">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/2020/02/ilo-150x88.png" alt="International Labour Organization (ILO)" height="30" width="30">
                                                <div class="position">
                                        </td>
                                        <td>Project Technical Officer<br>international Labour Organization (ILO)</td>
                                        <td> New Delhi(Delhi)</td>
                                        <td>Full Time<br>Posted on July 25, 2020<br> August 6, 2020</td>
                                    </tr>
                                    <tr>
                                        <td><a href="https://socialservicesindia.com/?job_listing=state-co-ordinator-inclusive-budget-cell-department-of-finance">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/job-manager-uploads/company_logo/2020/03/UNICEF.png" alt="UNICEF" height="30" width="30">
                                        </td>
                                        <td>State Co-ordinator – Inclusive Budget Cell, Department of Finance<br>UNICEF</td>
                                        <td> Guwahati, Assam</td>
                                        <td>Full Time<br>Posted on July 24, 202<br>July 30, 2020</td>
                                    </tr>
                                    <tr>

                                        <td> <a href="https://socialservicesindia.com/?job_listing=monitoring-and-evaluation-consultant">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/2019/06/carelogo.png" alt="CARE India" height="30" width="30">
                                        </td>
                                        <td>Monitoring and Evaluation Consultant
                                            <br>CARE India
                                        </td>
                                        <td> Tamil Nadu</td>
                                        <td>Full Time<br>Posted on July 24, 2020<br>July 29, 2020</td>
                                    </tr>


                                    <tr>

                                        <td> <a href="https://socialservicesindia.com/?job_listing=project-technical-assistant-senior-treatment-supervisor">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/2020/03/ICMR-National-Institute-For-Research-in-Tuberculosis-150x94.png" alt="ICMR-National Institute of Epidemiology (NIE)" height="30" width="30">
                                                <div class="position">
                                        </td>
                                        <td>Monitoring and Evaluation Consultant
                                            <br>CARE India
                                        </td>
                                        <td> Tamil Nadu</td>
                                        <td>Full Time<br>Posted on July 24, 2020<br>July 29, 2020</td>
                                    </tr>


                                    <tr>

                                        <td> <a href="https://socialservicesindia.com/?job_listing=project-technical-assistant-senior-treatment-supervisor">
                                                <img class="company_logo" src="https://socialservicesindia.com/wp-content/uploads/2020/03/ICMR-National-Institute-For-Research-in-Tuberculosis-150x94.png" alt="ICMR-National Institute of Epidemiology (NIE)" height="30" width="30">
                                                <div class="position">
                                        </td>
                                        <td>Project Technical Assistant (Senior Treatment Supervisor)
                                            <br>ICMR-National Institute of Epidemiology (NIE)
                                        </td>
                                        <td> Karnataka) (Goa) (Bihar) </td>
                                        <td>Full Time<br>Posted on July 23, 2020<br>August 10, 2020</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
        @endsection
