@extends('layouts.home')
@section('content')
<section id="State and UT" style="">
    <div class="intro-img" style="">
        {{-- <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

        <div class=" container">
            {{-- <header class="section-header">
                <h1><b>Email Service</b></h1>
            </header> --}}
            <h5 style="margin-bottom: 0px;"><b>Emailer Service -</b></h5> <p style="font-weight:600;">Content limit max. 800 words and upto 2 images.</p>
            <p style="font-weight:600;">
                Customized emailer to the target audience group : (Subject to approval)<br>
                Professionals (Development Professionals)<br>
                Organizations NGOs, Social Enterprises, CSR Foundations
            </p>
            <div>

                <table class="main_width " style="width: 100%;border:3px solid black;">
                    <tbody >
                        <thead >
                            <tr class="table_border">
                                <th scope="col" class="table_border">Database</th>
                                <th scope="col" class="table_border">Single Email Tariff  (INR) </th>
                                <th scope="col" class="table_border">Two Emailers Tariff (INR)</th>
                     
                            </tr>
                        </thead>
                        <tr class="table_border">
                            <td  class="table_border">
                                <strong>5000</strong>
                            </td>
                            <td class="table_border">
                                5000
                            </td>
                            <td class="table_border">
                                <strong>9000</strong>
                            </td>
                           
                        </tr>
                        <tr class="table_border">
                            <td class="table_border">
                                <strong>10000</strong>
                            </td>
                            <td class="table_border">
                                9000
                            </td>
                            <td class="table_border">
                                <strong>16000</strong>
                            </td>
                          
                        </tr>
                        <tr class="table_border">
                            <td class="table_border">
                                <strong>25000</strong>
                            </td>
                            <td class="table_border">
                                18000
                            </td>
                            <td class="table_border">
                                <strong>30000</strong>
                            </td>
                        
                        </tr>
                        <tr class="table_border">
                            <td class="table_border">
                                <strong>50000</strong>
                            </td>
                            <td class="table_border">
                               30000
                            </td>
                            <td class="table_border">
                                <strong>56000</strong>
                            </td>
                            
                        </tr>
                        <tr class="table_border">
                            <td class="table_border">
                                <strong>75000</strong>
                            </td>
                            <td class="table_border">
                              40000
                            </td>
                            <td class="table_border">
                                <strong>73000</strong>
                            </td>
                          
                        </tr>
                        <tr class="table_border">
                            <td class="table_border">
                                <strong>100000</strong>
                            </td>
                            <td class="table_border">
                               45000
                            </td>
                            <td class="table_border">
                                <strong>82500</strong>
                            </td>
                           
                        </tr>
                      

                    </tbody>
                </table>
               
                <p class="mt-4" style="font-weight:600;">
                    We will send you a detail report of emails sent and delivered from our end for your confirmation							
                    For more information please write to us at 							
                    <a href="mailto:contact@socialservicesindia.org">contact@socialservicesindia.org</a>
                </p>
                <h5 id="SMS-service" style="margin-bottom: 0px;"><b>SMS Service- SMS.</b><br></h5> 
                <p style="font-weight:600;">Content limit max. 160 characters</p>
                <p style="font-weight:600;">Customized SMS’s to the target audience group : (Subject to approval)<br>					
                    Professionals (Development Professionals)<br>					
                    Organizations NGOs, Social Enterprises, CSR Foundations</p>

                    <table class="main_width " style="width: 100%;border:3px solid black;">
                        <tbody >
                            <thead >
                                <tr class="table_border">
                                    <th scope="col" class="table_border">Database</th>
                                    <th scope="col" class="table_border">Single SMS Tariff  (INR) </th>
                                    <th scope="col" class="table_border">Two SMS Tariff (INR)</th>
                         
                                </tr>
                            </thead>
                            <tr class="table_border">
                                <td  class="table_border">
                                    <strong>5000</strong>
                                </td>
                                <td class="table_border">
                                    5000
                                </td>
                                <td class="table_border">
                                    <strong>9000</strong>
                                </td>
                               
                            </tr>
                            <tr class="table_border">
                                <td class="table_border">
                                    <strong>10000</strong>
                                </td>
                                <td class="table_border">
                                    9000
                                </td>
                                <td class="table_border">
                                    <strong>17000</strong>
                                </td>
                              
                            </tr>
                            <tr class="table_border">
                                <td class="table_border">
                                    <strong>25000</strong>
                                </td>
                                <td class="table_border">
                                   21250
                                </td>
                                <td class="table_border">
                                    <strong>40000</strong>
                                </td>
                            
                            </tr>
                            <tr class="table_border">
                                <td class="table_border">
                                    <strong>50000</strong>
                                </td>
                                <td class="table_border">
                                   40000
                                </td>
                                <td class="table_border">
                                    <strong>75000</strong>
                                </td>
                                
                            </tr>
                            <tr class="table_border">
                                <td class="table_border">
                                    <strong>75000</strong>
                                </td>
                                <td class="table_border">
                                  52500
                                </td>
                                <td class="table_border">
                                    <strong>97500</strong>
                                </td>
                              
                            </tr>
                            <tr class="table_border">
                                <td class="table_border">
                                    <strong>100000</strong>
                                </td>
                                <td class="table_border">
                                   60000
                                </td>
                                <td class="table_border">
                                    <strong>110000</strong>
                                </td>
                               
                            </tr>
                           
                            
                          
    
                        </tbody>
                    </table> 
                    <p class="mt-4" style="font-weight:600;">
                        We will send you a detail report of SMS sent and delivered from our end for your confirmation							
                        For more information please write to us at 							
                        <a href="mailto:contact@socialservicesindia.org">contact@socialservicesindia.org</a>
                    </p>   

            </div>
        </div>
</section>
@endsection
