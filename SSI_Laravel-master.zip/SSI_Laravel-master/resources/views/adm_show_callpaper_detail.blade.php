@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">POST CALL FOR PAPER </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organizer Panel</li>
                <li class="breadcrumb-item active">Update Call for Paper</li>
            </ol>

            <!-- {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post Jobseeker 
            </header> -->
            <!-- </div> --}} -->

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/update_call')}}/{{$jp_obj['paper_id']}}" method="post"
                        accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Paper Title</label>
                                        <input type="text" name="title" class="form-cntrl" id="title" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['paper_title']}}" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Paper Type </label>


                                        <select class="form-cntrl" name="type" id="type"
                                            value="{{$jp_obj['paper_type']}}">
                                            <option {{ ( $jp_obj['paper_type'] == "Aged/Elderly") ? 'selected' : '' }}
                                                value="Aged/Elderly">Aged/Elderly</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Animal Husbandry, Dairying & Fisheries") ? 'selected' : '' }}
                                                value="Animal Husbandry, Dairying & Fisheries">Animal Husbandry,
                                                Dairying & Fisheries</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Agriculture") ? 'selected' : '' }}
                                                value="Agriculture">Agriculture</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Artificial Intelligence and Development") ? 'selected' : '' }}
                                                value="Artificial Intelligence and Development">Artificial Intelligence
                                                and Development</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Biotechnology") ? 'selected' : '' }}
                                                value="Biotechnology">Biotechnology</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Civic Issues") ? 'selected' : '' }}
                                                value="Civic Issues">Civic Issues</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Differently Abled") ? 'selected' : '' }}
                                                value="Differently Abled">Differently Abled</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Drinking Water") ? 'selected' : '' }}
                                                value="Drinking Water">Drinking Water</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Development and Democracy") ? 'selected' : '' }}
                                                value="Development and Democracy">Development and Democracy</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Environment & Forests") ? 'selected' : '' }}
                                                value="Environment & Forests">Environment & Forests</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Health & Family Welfare") ? 'selected' : '' }}
                                                value="Health & Family Welfare">Health & Family Welfare</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Housing") ? 'selected' : '' }}
                                                value="Housing">Housing</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Information & Communication Technology (ICT)") ? 'selected' : '' }}
                                                value="Information & Communication Technology (ICT)">Information &
                                                Communication Technology (ICT)</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Internet governance") ? 'selected' : '' }}
                                                value="Internet governance">Internet governance</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Land Resources") ? 'selected' : '' }}
                                                value="Land Resources">Land Resources</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Micro Finance SHGs") ? 'selected' : '' }}
                                                value="Micro Finance SHGs">Micro Finance SHGs</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Minority Issues") ? 'selected' : '' }}
                                                value="Minority Issues">Minority Issues</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Nutrition") ? 'selected' : '' }}
                                                value="Nutrition">Nutrition</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Prisoner’s Issues") ? 'selected' : '' }}
                                                value="Prisoner’s Issues">Prisoner’s Issues</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Rural Development & Poverty Alleviation") ? 'selected' : '' }}
                                                value="Rural Development & Poverty Alleviation">Rural Development &
                                                Poverty Alleviation</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Scientific & Industrial Research") ? 'selected' : '' }}
                                                value="Scientific & Industrial Research">Scientific & Industrial
                                                Research</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Tourism") ? 'selected' : '' }}
                                                value="Tourism">Tourism</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Urban Development & Poverty Alleviation") ? 'selected' : '' }}
                                                value="Urban Development & Poverty Alleviation">Urban Development &
                                                Poverty Alleviation</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Water Resources") ? 'selected' : '' }}
                                                value="Water Resources">Water Resources</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Youth Affairs") ? 'selected' : '' }}
                                                value="Youth Affairs">Youth Affairs</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Art & Culture") ? 'selected' : '' }}
                                                value="Art & Culture">Art & Culture</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Children") ? 'selected' : '' }}
                                                value="Children">Children</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Dalit Upliftment") ? 'selected' : '' }}
                                                value="Dalit Upliftment">Dalit Upliftment</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Disaster Management") ? 'selected' : '' }}
                                                value="Disaster Management">Disaster Management</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Disability") ? 'selected' : '' }}
                                                value="Disability">Disability</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Education & Literacy") ? 'selected' : '' }}
                                                value="Education & Literacy">Education & Literacy</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Food Processing") ? 'selected' : '' }}
                                                value="Food Processing">Food Processing</option>
                                            <option {{ ( $jp_obj['paper_type'] == "HIV/AIDS") ? 'selected' : '' }}
                                                value="HIV/AIDS">HIV/AIDS</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Human Rights") ? 'selected' : '' }}
                                                value="Human Rights">Human Rights</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Labour & Employment") ? 'selected' : '' }}
                                                value="Labour & Employment">Labour & Employment</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Legal Awareness & Aid") ? 'selected' : '' }}
                                                value="Legal Awareness & Aid">Legal Awareness & Aid</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Micro Small & Medium Enterprises") ? 'selected' : '' }}
                                                value="Micro Small & Medium Enterprises">Micro Small & Medium
                                                Enterprises</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "New & Renewable Energy") ? 'selected' : '' }}
                                                value="New & Renewable Energy">New & Renewable Energy</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Panchayati Raj") ? 'selected' : '' }}
                                                value="Panchayati Raj">Panchayati Raj</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Right To Information & Advocacy") ? 'selected' : '' }}
                                                value="Right To Information & Advocacy">Right To Information & Advocacy
                                            </option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Science & Technology") ? 'selected' : '' }}
                                                value="Science & Technology">Science & Technology</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Sports") ? 'selected' : '' }}
                                                value="Sports">Sports</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Tribal Affairs") ? 'selected' : '' }}
                                                value="Tribal Affairs">Tribal Affairs</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Vocational Training") ? 'selected' : '' }}
                                                value="Vocational Training">Vocational Training</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Women’s Development & Empowerment") ? 'selected' : '' }}
                                                value="Women’s Development & Empowerment">Women’s Development &
                                                Empowerment</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Sanitation") ? 'selected' : '' }}
                                                value="Sanitation">Sanitation</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Sustainable Development") ? 'selected' : '' }}
                                                value="Sustainable Development">Sustainable Development</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Wildlife") ? 'selected' : '' }}
                                                value="Wildlife">Wildlife</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Skill Development") ? 'selected' : '' }}
                                                value="Skill Development">Skill Development</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Sustainable Development") ? 'selected' : '' }}
                                                value="Sustainable Development">Sustainable Development</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Financial Inclusion") ? 'selected' : '' }}
                                                value="Financial Inclusion">Financial Inclusion</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Entrepreneurship And Innovation") ? 'selected' : '' }}
                                                value="Entrepreneurship And Innovation">Entrepreneurship And Innovation
                                            </option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "Impact Investing") ? 'selected' : '' }}
                                                value="Impact Investing">Impact Investing</option>
                                            <option
                                                {{ ( $jp_obj['paper_type'] == "All Publications") ? 'selected' : '' }}
                                                value="All Publications">All Publications</option>
                                            <option {{ ( $jp_obj['paper_type'] == "Any Other") ? 'selected' : '' }}
                                                value="Any Other">Any Other</option>


                                        </select>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of Organisation</label>
                                        <input type="text" name="org" class="form-cntrl" id="org" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['paper_o_name']}}" />

                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Location</label>

                                        <input type="text" name="loc" class="form-cntrl" id="loc" placeholder=""
                                            value="{{$jp_obj['paper_loc']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Display Paste Complete AD</label>
                                        {{-- <input type="text" class="form-cntrl" name="display_page" id="display"
                                            placeholder="Address Line 1" data-msg="Please enter a valid Address Line 1"
                                            value="{{$jp_obj['paper_disp']}}" /> --}}
                                        <textarea class="form-cntrl" id="summernote" name="display_page" rows="10"
                                            style="height: auto;resize: none;">{{$jp_obj['paper_disp']}}
                                            </textarea>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Email</label><br>
                                        <input class="form-cntrl" name="Email" id="Email" placeholder="" rows="10"
                                            value="{{$jp_obj['paper_email']}}">
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Website URL Address</label>
                                        <input type="text" name="website_url" class="form-cntrl" id="url "
                                            placeholder="" style="width:100%;" value="{{$jp_obj['paper_web_url']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <!-- <small class="description">Leave this blank if the location is not important</small> -->

                                    <!-- <div class="form-group col-lg-6">
                                        <label for="name">Address Line 2</label>
                                        <input type="text" class="form-cntrl" name="jsaddrline2" id="jsaddrline2"
                                            placeholder="Address Line 2(Optional)" data-rule="email"
                                            data-msg="Please enter a valid Address Line 2" />
                                    </div> -->
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-3">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                            style="width:100%;" accept="image/png, image/jpeg" name="org_logo"
                                            id="org_logo" placeholder="" value="{{$jp_obj['paper_org_logo']}}">
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-3 mt-4">
                                        <!-- <label for="company_logo">Uploaded</label><br> -->
                                        <img src="{{asset($jp_obj['paper_org_logo'])}}" class="form-cntrl" name=""
                                            height="70%" alt="">
                                        <input type="hidden" name="org_old_logo" value="{{$jp_obj['paper_org_logo']}}">
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label for="company_logo">Upload Pdf Document</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="doc|pdf|text"
                                            style="width:100%;" accept="application/pdf" name="pdf_document"
                                            id="pdf_document" placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="">Uploaded</label><br>
                                        <span value="" class="form-cntrl" alt="">{{$jp_obj['paper_pdf_doc']}}</span>
                                        <input type="hidden" name="pdf_old" value="{{$jp_obj['paper_pdf_doc']}}">
                                    </div>


                                </div>




                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Media Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="media_url" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['paper_url']}}" />

                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By</label>
                                        <input type="date" name="apply" class="form-cntrl" id="apply" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['paper_apply_by']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>






                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:30%"> Update Data
                                        </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
        <!-- </div> -->
    </section>



</main>

@endsection
