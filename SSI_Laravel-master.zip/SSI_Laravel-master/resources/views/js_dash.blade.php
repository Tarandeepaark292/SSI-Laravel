@extends('layouts.js_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Dashboard</h1>
            {{-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Jobseeker Panel</li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> --}}

            <div class="row justify-content-center" style="margin-top:2rem;">
                <div class="col-md-4" style="padding: 0;">
                    <div class="card" style="border:0;text-align: center;border-radius: 6px;border: 1px solid #eceef3; padding: 1em;height:341px;">
                        @if(isset($jsobj['js_photo']))
                        <img src="{{asset($jsobj['js_photo'])}}" style="height: 200px;width: 200px;margin: 0 auto;border: 10px solid #eee;border-radius: 5px;"/>
                        @else
                        <img src="{{asset('img/profile-avatar.png')}}" style="height: 200px;width: 200px;margin: 0 auto;border: 10px solid #eee;border-radius: 5px;"/>
                        @endif

                        <h4 class="mb-1 mt-1" style="font-weight: 700;">{{session()->get('ssiapp_js_name')}}</h4>
                        <span class="text-info">{{$jsobj['js_p_title']}}</span>
                        @if($jsobj['js_broadcast_resume'] == 1)
                        <div><a target="_blank" href="{{url('/jobseeker/')}}/{{$jsobj['js_SEO']}}" style="color:#17a2b8 !important;font-weight:bold;margin-top:.5rem"><i class="far fa-eye" style="margin-right:.1rem;"></i> Live URL</a></div>
                        @else
                        <div><a target="_blank" href="{{url('/preview/job-seeker/')}}/{{session()->get('ssiapp_js_id')}}" style="color:#17a2b8 !important;font-weight:bold;margin-top:.5rem"><i class="far fa-eye" style="margin-right:.1rem;"></i> Preview</a></div>
                        @endif
                    </div>
                    <div class="tr-single-box" style="margin-top: 2rem;">
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Candidate Detail</h4>
                        </div>
                        
                        <div class="tr-single-body" style="height: 300px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-rupee-sign"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Expected Salary</strong>
                                            {{$jsobj['js_sal']}}
                                        </div>
                                    </div>
                                </li>
                                @if($jsobj['js_broadcast_resume'] == 1)
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-broadcast-tower"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Broadcasting Resume</strong>
                                            Yes
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-calendar-alt"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Broadcasting End Date</strong>
                                            {{$jsobj['js_bc_end_date']}}
                                        </div>
                                    </div>
                                </li>
                                @else
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                           <a href="{{url('/js/broadcastResume')}}" target="_blank"><i class="fas fa-broadcast-tower"></i></a> 
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Broadcasting Resume</strong>
                                            No
                                        </div>
                                    </div>
                                </li>
                                @endif
                                
                                <li>
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-clock"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Experience</strong>
                                            {{$jsobj['js_totexp']}}
                                        </div>
                                    </div>
                                </li>
                                
                               
                                
                            </ul>
                        </div>
                        
                    </div>

                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4 ><i class="fas fa-briefcase"></i> Skill Or Expertise</h4>
                        </div>
                        <div class="tr-single-body" style="height: 300px;overflow: auto;">
                            <div class="container">
                                @if(count($js_skill_list_obj)> 0)
                                <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                    <div class="col-12">
                                        Skills 
                                    </div>
                                    
                                    
                                </div>
                                <div id="skilldiv">
                                @foreach($js_skill_list_obj as $noti)
                                <div class="row" style="background:floralwhite;padding: 12px 5px;">
                                    <div class="col-8">
                                        {{ $noti['skill'] }}
                                    </div>
                                </div>
                                @endforeach
                                </div>
                                @else
                                <div style="text-align: center;">
                                    <a href="{{url('/js/show-js-resume-edit')}}/{{session()->get('ssiapp_js_id')}}" style="font-size: 1.32rem;font-weight: bold;" ><i class="fas fa-link"></i> Add Skills </a>
                                </div>
                                @endif
                            </div>
                            

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    {{-- <div class="card bg-info text-white mb-4">
                        <div class="card-header"> {{session()->get('ssiapp_js_name')}} </div>
                        <div class="card-body">
                            <b>Title</b> : {{$jsobj['js_p_title']}} <br>
                            @if($jsobj['js_broadcast_resume'] == 1)
                            <b>Is Broadcasting Resume</b> : YES <br>
                            <b>Broadcast Resume End Date</b> : {{$jsobj['js_bc_end_date']}} <br>
                            @else
                            <b>Is Broadcasting Resume</b> : NO <br>
                            @endif
                            <div><a href="{{url('/js/broadcastResume')}}" class="btn-sm btn-light"> Broadcast Resume </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white" href="{{url('/js/show-js-edit')}}/{{session()->get('ssiapp_js_id')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div> --}}

                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4 ><i class="fas fa-info"></i> Candidate Overview </h4>
                        </div>
                        <div class="tr-single-body" style="height: 300px;overflow: auto;">
                            <div class="container">
                                {!!htmlspecialchars_decode($jsobj['js_personal_info'])!!}
                            </div>
                        </div>
                    </div>


                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4><i class="fas fa-graduation-cap"></i> Education </h4>
                        </div>
                        <div class="tr-single-body" style="height: 300px;overflow: auto;">
                            <div class="container">
                                @if(count($js_edu_list_obj)> 0)
                                <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                    <div class="col-4">
                                        Qualification
                                    </div>
                                    <div class="col-4">
                                        Dates
                                    </div>
                                    <div class="col-4">
                                        School / Colleges
                                    </div>
                                   
                                </div>
                                <div id="edudiv">
                                @foreach($js_edu_list_obj as $noti)
                                <div class="row" style="background:floralwhite;padding: 12px 5px;">
                                    <div class="col-4">
                                        {{ $noti['degree'] }}
                                    </div>
                                    <div class="col-4">
                                        {{ $noti['start'] }} - {{ $noti['end'] }}
                                    </div>
                                    <div class="col-4">
                                        {{ $noti['school'] }}
                                    </div>
                                    
                                </div>
                                @endforeach
                                </div>
                                @else
                                <div style="text-align: center;">
                                    <a href="{{url('/js/show-js-resume-edit')}}/{{session()->get('ssiapp_js_id')}}" style="font-size: 1.32rem;font-weight: bold;" ><i class="fas fa-link"></i> Add Education </a>
                                </div>
                                @endif
                            </div>
                           

                        </div>
                    </div>

                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4><i class="fas fa-briefcase"></i> Experience </h4>
                        </div>
                        <div class="tr-single-body" style="height: 300px;overflow: auto;">
                            <div class="container">

                                
                                @if(count($js_exp_list_obj)> 0)
                                <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                    <div class="col-6">
                                        Skills @ Company
                                    </div>
                                    <div class="col-6">
                                        Dates
                                    </div>
                                    
                                </div>
                                <div id="expdiv">
                                @foreach($js_exp_list_obj as $noti)
                                <div class="row" style="background:floralwhite;padding: 12px 5px;">
                                    <div class="col-6">
                                        {{ $noti['title'] }} @ {{ $noti['school'] }}
                                    </div>
                                    <div class="col-4">
                                        {{ $noti['start'] }} - {{ $noti['end'] }}
                                    </div>
                                   
                                   
                                </div>
                                @endforeach
                                </div>
                                @else
                                <div style="text-align: center;">
                                    <a href="{{url('/js/show-js-resume-edit')}}/{{session()->get('ssiapp_js_id')}}" style="font-size: 1.32rem;font-weight: bold;" > <i class="fas fa-link"></i> Add Experience </a>
                                </div>
                                @endif
                            </div>
                            
                        </div>
                    </div>
                </div>
                {{-- <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-header"> Donations </div>
                        <div class="card-body">Donations : {{$dashObj['totaldonate']}}<br>
                            <div><a href="{{url('/admin/post-donate')}}" class="btn-sm btn-light"> Create Donation </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/donation_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div> --}}
            </div>


        </div>


    </section>
</main>



@endsection