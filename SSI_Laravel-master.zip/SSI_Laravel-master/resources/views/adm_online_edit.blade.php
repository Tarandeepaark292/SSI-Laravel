@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Online Course</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Post Online Course</li>
            </ol>

            {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post CSR Ad
            </header>
        </div> --}}
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/onlinecourse/update')}}/{{$jp_obj['on_id']}}" method="post"
                        accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Course Title </label>
                                        <input type="text" name="course" class="form-cntrl" id=""
                                            placeholder="" style="" maxlength="300"
                                            value="{{$jp_obj['on_detail']}}" />
                                        <div class="validate"></div>
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label>Name Of The Institution </label>
                                        <br>
                                        <input type="text" name="name" class="form-cntrl" id=""
                                            placeholder="" style=""
                                            value="{{$jp_obj['on_institute']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                {{-- </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By </label>
                                        <input type="date" name="apply" class="form-cntrl" id="" placeholder="Apply By"
                                            style="" value="{{$jp_obj['on_apply']}}" />

                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6  " >
                                        <label for="name">Course Type</label>
                                        <select name="category" class="form-cntrl" value="{{$jp_obj['on_radio']}}">
                                            <option {{ ( $jp_obj['on_radio'] == "free") ? 'selected' : '' }} value="free">Free</option>
                                            <option {{ ( $jp_obj['on_radio'] == "paid") ? 'selected' : '' }} value="paid">Paid</option>
                                           </select>
                                        {{-- <label for="name"> </label> --}}
                                        
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">


                                        <label for="name">Thematic Area</label>
                                        <input type="text" name="area" class="form-cntrl"
                                            value="{{$jp_obj['on_area']}}">
                                        
                                        <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Website URL</label><br>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['on_url']}}" />

                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Description</label>
                                        {{-- <input type="text" name="display" class="form-cntrl" id="display" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['on_display']}}" /> --}}
                                        <textarea class="form-cntrl" id="summernote" name="display" rows="10" style="height: auto;resize: none;">{{$jp_obj['on_display']}}
                                        </textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Email</label><br>
                                        <input type="email" name="email" class="form-cntrl" id="email" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['on_email']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Location</label><br>
                                        <input type="text" name="location" class="form-cntrl" id="" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['on_state']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Academic Year</label><br>
                                        <input type="text" name="year" class="form-cntrl" id="year" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['on_year']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl" name="logo" id="logo"
                                            data-file_types="doc|pdf|text" style="width:100%;"
                                            value="{{$jp_obj['on_logo']}}" accept="application/msword"
                                            placeholder="Add Media" value="{{$jp_obj['on_logo']}}">
                                        <input type="hidden" name="old_logo" value="{{$jp_obj['on_logo']}}"">
                                          
                                    </div>
                                    <div class=" form-group col-lg-6">
                                        <label for="company_logo">Current Logo</label><br>
                                        <input type="text" class="form-cntrl" name="logo" id="logo"
                                            data-file_types="doc|pdf|text" style="width:100%;"
                                            value="{{$jp_obj['on_logo']}}" accept="application/msword"
                                            placeholder="Add Media" value="{{$jp_obj['on_logo']}}">

                                    </div>
                                </div>

                               


                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                        <input type="file" class="form-cntrl" name="pdf" id="pdf"
                                            data-file_types="doc|pdf|text" style="width:100%;"
                                            value="{{$jp_obj['on_pdf_doc']}}" accept="pdf" placeholder="Add Media">
                                        <input type="hidden" name="old_pdf" value="{{$jp_obj['on_pdf_doc']}}">


                                    </div>


                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                    <label>Media Url</label>
                                    <input type="text" name="media" class="form-cntrl" id="" placeholder=""
                                        style="width:100%;" value="{{$jp_obj['on_url']}}" />


                                </div>
                                </div>






                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                    <label for="vehicle3">I agree Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%"> Update
                                            Online course</button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>
</main>

@endsection
