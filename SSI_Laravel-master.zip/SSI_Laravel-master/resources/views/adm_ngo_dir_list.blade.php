@extends('layouts.auth_bend_home')
@section('content')


<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">NGO Directory List</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>NGO Directory List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Organization Name</th>
                                <th>NGO Type</th>
                                <th>Website</th>
                                <th>Create Date</th>
                                <th>Edit</th>
                                <th>View</th>
                            </tr>
                        </thead>
                        @isset($ngodirlist)
                        <tfoot>
                            <tr>
                                <th>Organization Name</th>
                                <th>NGO Type</th>
                                <th>Website</th>
                                <th>Create Date</th>
                                <th>Edit</th>
                                <th>View</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            @foreach($ngodirlist as $noti)
                            <tr>
                                <td>{{ $noti['nd_org_name'] }}</td>
                                <td>{{ $noti['nd_ngo_type'] }}</td>

                                <td style="word-break: break-all;">{{ $noti['nd_website'] }} </td>
                                <td>{{ $noti['nd_createdate'] }}</td>
                                <td>
                                    <a class="btn btn-outline-secondary"
                                        href="{{url('/admin/ngo-directory-detail/')}}/{{$noti['nd_id']}}">EDIT</a>

                                </td>
                                <td><a href="#" class="btn btn-outline-dark">Preview</a></td> 

                            </tr>
                            @endforeach
                        </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
</script>
@endsection