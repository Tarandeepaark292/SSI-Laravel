@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Register for Grant</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organisation Panel</li>
                <li class="breadcrumb-item active">Post Register for Grant</li>
            </ol>

            @if(session()->has('ssiapp_rec'))

                <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                            <div class="col-12">
                                <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                            </div>
                        </header>

                        <form action="{{ url('/register-grants/submit') }}" method="post"
                            accept-charset="utf-8" enctype="multipart/form-data">
                            @csrf


                            <div class="row">
                                <div class="col-12 " style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">

                                    <div class="form-row">



                                        <div class="form-group col">
                                            <label for="name">Name Of the Organistation</label>
                                            <input type="text" name="name" class="form-cntrl" id="name"
                                                placeholder="Enter Organisation Name" data-rule="minlen:4"
                                                data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name"> Vision of Organisation</label>
                                            <textarea class="form-cntrl" name="vision" id="vision"
                                                placeholder="Vision of organisation" rows="10"
                                                style="height: auto;resize: none;"></textarea>
                                            <div class="validate"></div>
                                        </div>


                                        <div class="form-group col-lg-6">
                                            <label for="name">Organisation Mission</label>
                                            <textarea class="form-cntrl" name="mission" id="mission"
                                                placeholder="Organisation Mission" rows="10"
                                                style="height: auto;resize: none;"></textarea>
                                            <div class="validate"></div>
                                        </div>

                                    </div>




                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="">Areas of Work or Expertise</label>
                                        </div>
                                            {!! $html !!}
                                            <input type="hidden" id="cates" name="cates" value="" />
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="name">Organisation Achivement</label>
                                            <textarea class="form-cntrl" name="achivement" name="cates[]"
                                                id="achivement" placeholder="" rows="10"
                                                style="height: auto;resize: none;"></textarea>
                                            <div class="validate"></div>
                                        </div>
                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Head of the Organisation</label>
                                            <input type="text" name="headorganisation" class="form-cntrl"
                                                id="headorganisation" placeholder="Head of the Organisation"
                                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name"> Organisation PAN</label>
                                            <input type="text" name="organisationpan" class="form-cntrl"
                                                id="organisationpan" placeholder="Organisation Pan" data-rule="minlen:4"
                                                data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Organisation TAN </label>
                                            <input type="text" name="organisationtan" class="form-cntrl"
                                                id="organisationtan" placeholder=" Organisation TAN "
                                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">
                                                Organisation having 12A </label>
                                                <select class="form-control" name="organisation12A">
                                                    <option value="yes">Yes</option>
                                                    <option value="no">No</option>
                                                </select>
                                            {{-- <div>
                                                <div class="torro-toggle">
                                                    <input type="radio" id="torro-element-42-1"
                                                        name="torro_submission[values][42][_main]"
                                                        class="torro-element-input" value="Yes">
                                                    <label id="torro-element-42-1-label" class="torro-element-label"
                                                         for="torro-element-42-1">
                                                        Yes </label>
                                                </div>
                                                <div class="torro-toggle">
                                                    <input type="radio" id="torro-element-42-2"
                                                        name="torro_submission[values][42][_main]"
                                                        class="torro-element-input" value="No">
                                                    <label id="torro-element-42-2-label" class="torro-element-label"
                                                        for="torro-element-42-2">
                                                        No </label>
                                                </div>
                                            </div> --}}

                                        </div>


                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">80 G Registration No</label>
                                            <input type="text" name="80gregistrationno" class="form-cntrl"
                                                id="80gregistrationno" placeholder="80 G Registration No"
                                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">FCRA Registration No</label>
                                            <input type="text" name="fcraregistrationno" class="form-cntrl"
                                                id="fcraregistrationno" placeholder="FCRA  Registration No"
                                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                            <div>

                                            </div>

                                        </div>


                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <div id="torro-element-45-wrap" class="torro-element-wrap">

                                                <label id="torro-element-45-label" class="torro-element-label"
                                                    for="torro-element-45">
                                                    FCRA Valid From </label>

                                                <div>
                                                    <input id="torro-element-45" name="validfrom" class="form-cntrl"
                                                        type="date" value="">


                                                </div>

                                            </div>

                                        </div>
                                        <div class="form-group col-lg-6">
                                            <div id="torro-element-46-wrap" class="torro-element-wrap">

                                                <label id="torro-element-46-label" class="torro-element-label" 
                                                    for="torro-element-46">
                                                    FCRA Valid To </label>

                                                <div>
                                                    <input id="torro-element-46" name="validto" class="form-cntrl"
                                                        class="torro-element-input" type="date" value="">


                                                </div>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Website</label>
                                            <input type="text" name="website" class="form-cntrl" id="website"
                                                placeholder="Website" data-rule="minlen:4" data-msg="" />
                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">Email</label>
                                            <input type="text" name="email" class="form-cntrl" id="email"
                                                placeholder="Enter valid email id to receive grant updates"
                                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                            <div class="validate"></div>
                                            <div>

                                            </div>

                                        </div>


                                    </div>


                                    <div class="row" style="text-align:center;">
                                        <div class="col-lg-12">

                                            <button class="btn btn-primary" style="width:40%">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>



                    </div>
                </section>

            @endif
            <script>
                function onchkclick() {
                    $('#cates').val('');
                    chkeles = $('.proposal_chk');
                    chkeles.each((index, value) => {
                        if ($(value).prop('checked') == true) {
                            if ($('#cates').val() === '') {
                                $('#cates').val($(value).val());
                            } else {
                                $('#cates').val($('#cates').val() + ',' + $(value).val());
                            }

                        }
                    });
                    console.log($('#cates').val());
                }

            </script>
</main>

@endsection
