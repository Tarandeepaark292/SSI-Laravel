@extends('layouts.auth_bend_home')
@section('content')


<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Call For Paper List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Call for Papers</div>
            <div class="card-body">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                            aria-controls="home" aria-selected="false">UnExpired</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link " id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                            aria-controls="profile" aria-selected="false">Expired</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent" style="margin-top:2rem;">
                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                        @isset($callsearch)
                        <div class="table-responsive">
                            <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Name Of the Organisation</th>
                                        <th>Email</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Website URL</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th>Edit</th>

                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Title</th>
                                        <th>Name Of the Organisation</th>
                                        <th>Email</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Website URL</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th>Edit</th>

                                    </tr>
                                </tfoot>
                                <tbody>
                                    @foreach($callsearch as $noti)

                                    <tr>
                                        <td>{{ $noti['paper_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_o_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_email'] }}</td>
                                        <td>{{ $noti['paper_loc'] }}</td>
                                        <td>{{ $noti['paper_type'] }}</td>
                                        <td>{{ $noti['paper_url'] }}</td>
                                        <td>{{ $noti['paper_apply_by']}}</td>
                                        <td id="btn_layer_{{$noti['paper_id'] }}">
                                            @if($noti['paper_approved'] == '1')
                                            <button class="btn btn-danger"
                                                onclick="disablecallpaper({{$noti['paper_id'] }})">Put on Hold</button>
                                            @else
                                            <button class="btn btn-primary"
                                                onclick="enablecallpaper({{$noti['paper_id'] }})">Approve</button>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{url('/admin/calldetail')}}/{{$noti['paper_id']}}"
                                                class="btn btn-danger"> EDIT</a>

                                        </td>

                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>

                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        @isset($expcallsearch)
                        <div class="table-responsive">
                            <table class="table table-bordered" id="notidataTable2" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Name Of the Organisation</th>
                                        <th>Email</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Website URL</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th>Edit</th>

                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Title</th>
                                        <th>Name Of the Organisation</th>
                                        <th>Email</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Website URL</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th>Edit</th>

                                    </tr>
                                </tfoot>
                                <tbody>
                                    @foreach($expcallsearch as $noti)

                                    <tr>
                                        <td>{{ $noti['paper_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_o_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_email'] }}</td>
                                        <td>{{ $noti['paper_loc'] }}</td>
                                        <td>{{ $noti['paper_type'] }}</td>
                                        <td>{{ $noti['paper_url'] }}</td>
                                        <td>{{ $noti['paper_apply_by']}}</td>
                                        <td id="btn_layer_{{$noti['paper_id'] }}">
                                            @if($noti['paper_approved'] == '1')
                                            <button class="btn btn-danger"
                                                onclick="disablecallpaper({{$noti['paper_id'] }})">Put on Hold</button>
                                            @else
                                            <button class="btn btn-primary"
                                                onclick="enablecallpaper({{$noti['paper_id'] }})">Approve</button>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{url('/admin/calldetail')}}/{{$noti['paper_id']}}"
                                                class="btn btn-danger"> EDIT</a>
                                        </td>

                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
    $('#notidataTable2').DataTable();

    function enablecallpaper(idx) {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxcallpaperenable.post') }}",
            data: {
                paper_id: idx
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    $('#btn_layer_' + idx).html(data.data);
                } else {
                    alert('Problem!! in enabling Call Paper');
                    console.log(data.error);
                }
            }
        });
    }

    function disablecallpaper(idx) {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxcallpaperdisable.post') }}",
            data: {
                paper_id: idx
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    $('#btn_layer_' + idx).html(data.data);
                } else {
                    alert('Problem!! in disabling Call Paper');
                    console.log(data.error);
                }
            }
        });
    }
</script>





@endsection