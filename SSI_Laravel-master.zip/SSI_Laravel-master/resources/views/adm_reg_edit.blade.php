@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post Register Grants Course</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Post Online Course</li>
        </ol>
        
        {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post CSR Ad
            </header>
        </div> --}}
             <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;" >
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <div class="col-12">
                        <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                    </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/update_reg')}}/{{$jp_obj['reg_grant_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf



                        

                        <div class="row">
                            <div class="col-12 " style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">

                                <div class="form-row">



                                    <div class="form-group col">
                                        <label for="name">Name Of the Organistation</label>
                                        <input type="text" name="name" class="form-cntrl" id="name"
                                            placeholder="Enter Organisation name" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"  value="{{$jp_obj['reg_o_name']}}"/>
                                        <div class="validate"></div>
                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name"> vision of Organisation</label>
                                        <textarea class="form-cntrl" name="vision" id="vision"
                                            placeholder="Vision of organisation" rows="10"
                                            style="height: auto;resize: none;">{{$jp_obj['reg_v_org']}}</textarea>
                                        <div class="validate"></div>
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label for="name">Organisation Mission</label>
                                        <textarea class="form-cntrl" name="mission" id="mission"
                                            placeholder="Organisation mission" rows="10"
                                            style="height: auto;resize: none;">{{$jp_obj['reg_o_mission']}}</textarea>
                                        <div class="validate"></div>
                                    </div>

                                </div>




                       

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Organisation Achivement</label>
                                        <textarea class="form-cntrl" name="achivement" 
                                            id="achivement" placeholder="" rows="10"
                                            style="height: auto;resize: none;">{{$jp_obj['reg_o_ach']}}</textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Head of the Organisation</label>
                                        <input type="text" name="headorganisation" class="form-cntrl"
                                            id="headorganisation" placeholder="head of the organisation"
                                            data-rule="minlen:4" data-msg="Please enter at least 4 chars"  value="{{$jp_obj['reg_o_head']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name"> Organisation PAN</label>
                                        <input type="text" name="organisationpan" class="form-cntrl"
                                            id="organisationpan" placeholder="Organisation Pan" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars" value="{{$jp_obj['reg_o_pan']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Organisation TAN to</label>
                                        <input type="text" name="organisationtan" class="form-cntrl"
                                            id="organisationtan" placeholder=" organisation TAN to"
                                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" value="{{$jp_obj['reg_o_tan']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">
                                            Organisation having 12A </label>
                                            <input type="text" class="form-control" name="organisationtwelve" value="{{$jp_obj['reg_org12a']}}">
 
                                       

                                    </div>


                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">80 G Registration No</label>
                                        <input type="text" name="80gregistrationno" class="form-cntrl"
                                            id="80gregistrationno" placeholder="80 G Registration No"
                                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" value="{{$jp_obj['reg_80g']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">FCRA Registration No</label>
                                        <input type="text" name="fcraregistrationno" class="form-cntrl"
                                            id="fcraregistrationno" placeholder="FCRA  Registration No"
                                            data-rule="minlen:4" data-msg="Please enter at least 4 chars"  value="{{$jp_obj['reg_fcra']}}" />
                                        <div class="validate"></div>
                                        <div>

                                        </div>

                                    </div>


                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <div id="torro-element-45-wrap" class="torro-element-wrap">

                                            <label id="torro-element-45-label" class="torro-element-label"
                                                for="torro-element-45" >
                                                FCRA Valid From </label>

                                            <div>
                                                <input type="text" name="validfrom" class="form-cntrl"
                                                    type="date" value="{{$jp_obj['reg_valid_from']}}" >


                                            </div>

                                        </div>

                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div id="torro-element-46-wrap" class="torro-element-wrap">

                                                FCRA Valid To </label>

                                            <div>
                                                <input type="text" name="validto" class="form-cntrl"
                                                    class="torro-element-input" type="date" value="{{$jp_obj['reg_valid_To']}}">


                                            </div>
                                        </div>
                                    </div>
                                </div>


                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="{{$jp_obj['reg_category']}}" />
                                </div>
             
                                             @endisset



                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Website</label>
                                        <input type="text" name="website" class="form-cntrl" id="website"
                                            placeholder="website" data-rule="minlen:4" data-msg="" value="{{$jp_obj['reg_website']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Email</label>
                                        <input type="text" name="email" class="form-cntrl" id="email"
                                            placeholder="Enter valid email id to receive grant updates"
                                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" value="{{$jp_obj['reg_email']}}" />
                                        <div class="validate"></div>
                                        <div>

                                        </div>

                                    </div>


                                </div>


                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12">

                                        <button class="btn btn-primary" style="width:40%">Update Register Grants </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                              </form>
                </div>



            </section>




          
        </div>
        </div>
    </section>
    <script>
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>
</main>

@endsection