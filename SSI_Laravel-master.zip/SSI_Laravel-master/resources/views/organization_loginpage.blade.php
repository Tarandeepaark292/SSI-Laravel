@extends('layouts.auth_home')
@section('content')

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            {{-- <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="" /> --}}
            <a href="{{url('/')}}"><img src="{{asset('img/ssi_logo_white.png')}}" alt="" /></a>
            <h3>Welcome</h3>
            
            <a class="pagelink" href="{{url('/organization/register')}}">Sign Up</a><br />
        </div>

        <div class="col-md-9 register-right">
            <div class="row">
                <div class="col-12">
                    <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                        <!-- <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                aria-controls="home" aria-selected="true">Jobseeker</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                aria-controls="profile" aria-selected="false">Organisation</a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="tab-content" id="myTabContent">
                
                <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <h3 class="register-heading">Login as an Organisation</h3>
                    <form action="{{url('/userlogin')}}" method="post">
                        <div class="row register-form">
                            <div class="col-md-9  mx-auto">
                                {{-- <h3 class="">Login as a Recruiter</h3> --}}
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control"
                                         placeholder="Your Email *" value="" />
                                         @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>

                                <div class="form-group">
                                    <input type="password" name="password" class="form-control"
                                        placeholder="Password *" value="" />
                                        @error('password') <p style="color:red">{{$message}}</p>@enderror
                                    <input type="hidden" name="role" value="recruiter"/>
                                </div>

                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" class="btnRegister" 
                                    value="Login" />
                                <a href="{{url('/organization/forgot-password')}}" style="display:block; font-weight: bold;margin-top:.5rem;">Forgot Password</a>
                            </div> <!-- </div> -->
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection