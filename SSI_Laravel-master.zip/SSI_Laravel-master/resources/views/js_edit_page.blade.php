@extends('layouts.js_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container">
            <h1 class="mt-4">Profile</h1>


            {{-- <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;"> --}}
            <section>

                <div class="container" style="margin-bottom: 5rem;">


                    <form
                        action="{{ url('/js/js_profile/update') }}/{{ $joblist['js_id'] }}"
                        method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="tr-single-box">
                                    <div class="tr-single-header">
                                        <h4 class="mt-4"><i class="fas fa-desktop"></i> Profile</h4>
                                    </div>
                                    <div class="tr-single-body">
                                        <div class="form-row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Your Name </label>
                                                <input type="text" name="name" class="form-cntrl" id="name"
                                                    placeholder="Name of  the organisation" style="width:100%;"
                                                    value="{{ $joblist['js_name'] }}"
                                                    required />
                                                <div class="validate"></div>
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <label for="name">Your Email </label>
                                                <input type="text" name="email" class="form-cntrl" id="email"
                                                    placeholder="Grant title" style="width:100%;"
                                                    value="{{ $joblist['js_email'] }}"
                                                    required />
                                                <div class="validate"></div>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Title</label>
                                                <input type="text" name="title" class="form-cntrl" id="title"
                                                    placeholder="" style="width:100%;"
                                                    value="{{ $joblist['js_p_title'] }}"
                                                    required />

                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label for="name">Area of Expertise</label>

                                                <select class="form-cntrl" name="area" id="area" style="width:100%;"
                                                    value="{{ $joblist['js_area_expertise'] }}"
                                                    required>
                                                    <option value="">Choose a category… E.g Spotlight, Administration or
                                                        Research</option>
                                                    <option
                                                        value="Administration, HR, Management, Accounting/Finance Executive"
                                                        {{ ( $joblist['js_area_expertise'] == "Administration, HR, Management, Accounting/Finance Executive") ? 'selected' : '' }}>
                                                        Administration, HR, Management, Accounting/Finance Executive
                                                    </option>
                                                    <option
                                                        value="Agriculture, Livelihoods, Micro finance, Rural, Urban"
                                                        {{ ( $joblist['js_area_expertise'] == "Agriculture, Livelihoods, Micro finance, Rural, Urban") ? 'selected' : '' }}>
                                                        Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                                    <option
                                                        value="Auditing, Taxation, Financial accounting/Operations, Payroll officer"
                                                        {{ ( $joblist['js_area_expertise'] == "Auditing, Taxation, Financial accounting/Operations, Payroll officer") ? 'selected' : '' }}>
                                                        Auditing, Taxation, Financial accounting/Operations, Payroll
                                                        officer
                                                    </option>
                                                    <option value="Capacity Building, Training, Advocacy"
                                                        {{ ( $joblist['js_area_expertise'] == "Capacity Building, Training, Advocacy") ? 'selected' : '' }}>
                                                        Capacity Building, Training, Advocacy</option>
                                                    <option
                                                        value="Communications, IT, Media, Knowledge Management, Editor"
                                                        {{ ( $joblist['js_area_expertise'] == "Communications, IT, Media, Knowledge Management, Editor") ? 'selected' : '' }}>
                                                        Communications, IT, Media, Knowledge Management, Editor</option>
                                                    <option
                                                        value="Chairman, President, CEO, Director, Project Director, Deputy Director"
                                                        {{ ( $joblist['js_area_expertise'] == "Chairman, President, CEO, Director, Project Director, Deputy Director") ? 'selected' : '' }}>
                                                        Chairman, President, CEO, Director, Project Director, Deputy
                                                        Director
                                                    </option>
                                                    <option value="Disaster, Aid, Emergencies, Relief"
                                                        {{ ( $joblist['js_area_expertise'] == "Disaster, Aid, Emergencies, Relief") ? 'selected' : '' }}>
                                                        Disaster, Aid, Emergencies, Relief</option>
                                                    <option value="Environment, Climate, Energy, Water, Sanitation"
                                                        {{ ( $joblist['js_area_expertise'] == "Environment, Climate, Energy, Water, Sanitation") ? 'selected' : '' }}>
                                                        Environment, Climate, Energy, Water, Sanitation</option>
                                                    <option value="Fund-raising Business Development, Grants Writer"
                                                        {{ ( $joblist['js_area_expertise'] == "Fund-raising Business Development, Grants Writer") ? 'selected' : '' }}>
                                                        Fund-raising Business Development, Grants Writer</option>
                                                    <option value="Field Officers, Field Associates"
                                                        {{ ( $joblist['js_area_expertise'] == "Field Officers, Field Associates") ? 'selected' : '' }}>
                                                        Field Officers, Field Associates</option>
                                                    <option value="Government / Governance, Reforms, Corruption"
                                                        {{ ( $joblist['js_area_expertise'] == "Government / Governance, Reforms, Corruption") ? 'selected' : '' }}>
                                                        Government / Governance, Reforms, Corruption</option>
                                                    <option value="Health, Doctors, Nurses, HIV / AIDS, Nutrition"
                                                        {{ ( $joblist['js_area_expertise'] == "Health, Doctors, Nurses, HIV / AIDS, Nutrition") ? 'selected' : '' }}>
                                                        Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                                    <option value="Human Rights, Law, Migration, Conflicts, Justice"
                                                        {{ ( $joblist['js_area_expertise'] == "Human Rights, Law, Migration, Conflicts, Justice") ? 'selected' : '' }}>
                                                        Human Rights, Law, Migration, Conflicts, Justice</option>
                                                    <option value="Infrastructure, Technology, Engineering, Science"
                                                        {{ ( $joblist['js_area_expertise'] == "Infrastructure, Technology, Engineering, Science") ? 'selected' : '' }}>
                                                        Infrastructure, Technology, Engineering, Science</option>
                                                    <option value="Consultant, Monitoring, Evaluation, Policy, Research"
                                                        {{ ( $joblist['js_area_expertise'] == "Consultant, Monitoring, Evaluation, Policy, Research") ? 'selected' : '' }}>
                                                        Consultant, Monitoring, Evaluation, Policy, Research</option>
                                                    <option value="Private Sector, Corporate Social Responsibility"
                                                        {{ ( $joblist['js_area_expertise'] == "Private Sector, Corporate Social Responsibility") ? 'selected' : '' }}>
                                                        Private Sector, Corporate Social Responsibility</option>
                                                    <option
                                                        value="Project Associate, Project leaders, Project Assistant"
                                                        {{ ( $joblist['js_area_expertise'] == "Project Associate, Project leaders, Project Assistant") ? 'selected' : '' }}>
                                                        Project Associate, Project leaders, Project Assistant</option>
                                                    <option
                                                        value="Program Manager, Program Officer, Program Associate, Program Assistant"
                                                        {{ ( $joblist['js_area_expertise'] == "Program Manager, Program Officer, Program Associate, Program Assistant") ? 'selected' : '' }}>
                                                        Program Manager, Program Officer, Program Associate, Program
                                                        Assistant
                                                    </option>
                                                    <option
                                                        value="Research Analysts, Research Associate, Research Assistant"
                                                        {{ ( $joblist['js_area_expertise'] == "Research Analysts, Research Associate, Research Assistant") ? 'selected' : '' }}>
                                                        Research Analysts, Research Associate, Research Assistant
                                                    </option>
                                                    <option value="Social, Gender, Education, Youth, Child"
                                                        {{ ( $joblist['js_area_expertise'] == "Social, Gender, Education, Youth, Child") ? 'selected' : '' }}>
                                                        Social, Gender, Education, Youth, Child</option>
                                                    <option value="Trade, Finance, Economics, Cooperation, Global"
                                                        {{ ( $joblist['js_area_expertise'] == "Trade, Finance, Economics, Cooperation, Global") ? 'selected' : '' }}>
                                                        Trade, Finance, Economics, Cooperation, Global</option>
                                                    <option value="Technology Associate, Technical Assistant,"
                                                        {{ ( $joblist['js_area_expertise'] == "Technology Associate, Technical Assistant,") ? 'selected' : '' }}>
                                                        Technology Associate, Technical Assistant, </option>
                                                    <option value="Teachers, Teachers Educators, Principal"
                                                        {{ ( $joblist['js_area_expertise'] == "Teachers, Teachers Educators, Principal") ? 'selected' : '' }}>
                                                        Teachers, Teachers Educators, Principal</option>
                                                </select>


                                                <div class="validate"></div>
                                            </div>
                                        </div>

                                        <div class="form-row" style="margin-top:1rem;">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Phone Number</label>
                                                <input type="text" class="form-cntrl" name="jsnumber" id="jsnumber"
                                                    placeholder="Phone Number" data-rule=""
                                                    data-msg="Please enter a valid Number"
                                                    value="{{ $joblist['js_number'] }}"
                                                    required />
                                            </div>
                                        </div>
                                        <div class="form-row" style="margin-top:1rem;">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Photo</label>
                                                <input type="file" name="jsphoto" data-file_types="jpg|jpeg|gif|png"
                                                    accept="image/png, image/jpeg" class="form-cntrl" id="file" />
                                                <input type="hidden" name="old_jsphoto"
                                                    value="{{ $joblist['js_photo'] }}">
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label for="name">Current Photo</label><br />
                                                @if(isset($joblist['js_photo']))
                                                <img style="width: 200px;"
                                                    src="{{ asset($joblist['js_photo']) }}" /><br />
                                                @else
                                                <img style="width: 200px;"
                                                    src="{{ asset('img/profile-avatar.png') }}" /><br />
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-lg-12">
                                                <label for="name">Resume Content</label>
                                                <textarea id="summernote"
                                                    name="resumedata">{{ htmlspecialchars_decode($joblist['js_personal_info']) }}</textarea>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Resume</label>
                                                <input type="file" name="jsresume" data-file_types="pdf|doc|docx"
                                                    accept="application/pdf,application/msword,text/plain" class="form-cntrl" id="file" />
                                                <input type="hidden" name="old_jsresume"
                                                    value="{{ $joblist['js_resume_doc'] }}">
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label for="name">Current Resume</label>
                                                @if(isset($joblist['js_resume_doc']))
                                                <br/><a href="{{url($joblist['js_resume_doc'])}}" target="_blank">Download</a>
                                                @else
                                                <h6>No Resume is Uploaded</h6>
                                                @endif
                                            </div>
                                        </div>

                                    </div><!-- -->
                                </div>
                                <div class="tr-single-box">
                                    <div class="tr-single-header">
                                        <h4 class="mt-4"><i class="fas fa-map-marker"></i> Contact Info</h4>
                                    </div>
                                    <div class="tr-single-body">
                                        <div class="form-row" style="margin-top:1rem;">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Email</label>
                                                <input type="text" class="form-cntrl" name="jsemail" id="jsaddrline1"
                                                    placeholder="Address Line 1" data-rule="email"
                                                    data-msg="Please enter a valid Address Line 1"
                                                    value="{{ $joblist['js_email'] }}"
                                                    required />
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <label for="name">Phone</label>
                                                <input type="text" class="form-cntrl" name="jsnumber" id="jsaddrline1"
                                                    placeholder="Address Line 1" data-rule="email"
                                                    data-msg="Please enter a valid Address Line 1"
                                                    value="{{ $joblist['js_number'] }}"
                                                    required />
                                            </div>

                                        </div>
                                        <div class="form-row" style="margin-top:1rem;">
                                            <div class="form-group col-lg-12">
                                                <label for="name">Address Line 1</label>
                                                <input type="text" class="form-cntrl" name="jsaddrline1"
                                                    id="jsaddrline1" placeholder="Address Line 1" data-rule="email"
                                                    data-msg="Please enter a valid Address Line 1"
                                                    value="{{ $js_loc_obj['addr_1'] }}"
                                                    required />
                                            </div>

                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-lg-4">
                                                <label for="name">City</label>
                                                <input type="text" class="form-cntrl" name="jscity" id="jscity"
                                                    placeholder="City" data-rule="email"
                                                    data-msg="Please enter a valid City"
                                                    value="{{ $js_loc_obj['addr_city'] }}"
                                                    required />
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label for="name">State</label>
                                                <select class="form-cntrl" name="jsstate"
                                                    value="{{ $js_loc_obj['addr_state'] }}"
                                                    required>
                                                    <option value="">Choose State</option>
                                                    <option value="Andhra Pradesh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Andhra Pradesh") ? 'selected' : '' }}>
                                                        Andhra Pradesh</option>
                                                    <option value="Andaman and Nicobar Islands"
                                                        {{ ( $js_loc_obj['addr_state'] == "Andaman and Nicobar Islands") ? 'selected' : '' }}>
                                                        Andaman and Nicobar Islands
                                                    </option>
                                                    <option value="Arunachal Pradesh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Arunachal Pradesh") ? 'selected' : '' }}>
                                                        Arunachal Pradesh</option>
                                                    <option value="Assam"
                                                        {{ ( $js_loc_obj['addr_state'] == "Assam") ? 'selected' : '' }}>
                                                        Assam</option>
                                                    <option value="Bihar"
                                                        {{ ( $js_loc_obj['addr_state'] == "Bihar") ? 'selected' : '' }}>
                                                        Bihar</option>
                                                    <option value="Chandigarh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Chandigarh") ? 'selected' : '' }}>
                                                        Chandigarh</option>
                                                    <option value="Chhattisgarh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Chhattisgarh") ? 'selected' : '' }}>
                                                        Chhattisgarh</option>
                                                    <option value="Dadar and Nagar Haveli"
                                                        {{ ( $js_loc_obj['addr_state'] == "Dadar and Nagar Haveli") ? 'selected' : '' }}>
                                                        Dadar and Nagar Haveli</option>
                                                    <option value="Daman and Diu"
                                                        {{ ( $js_loc_obj['addr_state'] == "Daman and Diu") ? 'selected' : '' }}>
                                                        Daman and Diu</option>
                                                    <option value="Delhi"
                                                        {{ ( $js_loc_obj['addr_state'] == "Delhi") ? 'selected' : '' }}>
                                                        Delhi</option>
                                                    <option value="Lakshadweep"
                                                        {{ ( $js_loc_obj['addr_state'] == "Lakshadweep") ? 'selected' : '' }}>
                                                        Lakshadweep</option>
                                                    <option value="Puducherry"
                                                        {{ ( $js_loc_obj['addr_state'] == "Puducherry") ? 'selected' : '' }}>
                                                        Puducherry</option>
                                                    <option value="Goa"
                                                        {{ ( $js_loc_obj['addr_state'] == "Goa") ? 'selected' : '' }}>
                                                        Goa</option>
                                                    <option value="Gujarat"
                                                        {{ ( $js_loc_obj['addr_state'] == "Gujarat") ? 'selected' : '' }}>
                                                        Gujarat</option>
                                                    <option value="Haryana"
                                                        {{ ( $js_loc_obj['addr_state'] == "Haryana") ? 'selected' : '' }}>
                                                        Haryana</option>
                                                    <option value="Himachal Pradesh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Himachal Pradesh") ? 'selected' : '' }}>
                                                        Himachal Pradesh</option>
                                                    <option value="Jammu and Kashmir"
                                                        {{ ( $js_loc_obj['addr_state'] == "Jammu and Kashmir") ? 'selected' : '' }}>
                                                        Jammu and Kashmir</option>
                                                    <option value="Jharkhand"
                                                        {{ ( $js_loc_obj['addr_state'] == "Jharkhand") ? 'selected' : '' }}>
                                                        Jharkhand</option>
                                                    <option value="Karnataka"
                                                        {{ ( $js_loc_obj['addr_state'] == "Karnataka") ? 'selected' : '' }}>
                                                        Karnataka</option>
                                                    <option value="Kerala"
                                                        {{ ( $js_loc_obj['addr_state'] == "Kerala") ? 'selected' : '' }}>
                                                        Kerala</option>
                                                    <option value="Madhya Pradesh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Madhya Pradesh") ? 'selected' : '' }}>
                                                        Madhya Pradesh</option>
                                                    <option value="Maharashtra"
                                                        {{ ( $js_loc_obj['addr_state'] == "Maharashtra") ? 'selected' : '' }}>
                                                        Maharashtra</option>
                                                    <option value="Manipur"
                                                        {{ ( $js_loc_obj['addr_state'] == "Manipur") ? 'selected' : '' }}>
                                                        Manipur</option>
                                                    <option value="Meghalaya"
                                                        {{ ( $js_loc_obj['addr_state'] == "Meghalaya") ? 'selected' : '' }}>
                                                        Meghalaya</option>
                                                    <option value="Mizoram"
                                                        {{ ( $js_loc_obj['addr_state'] == "Mizoram") ? 'selected' : '' }}>
                                                        Mizoram</option>
                                                    <option value="Nagaland"
                                                        {{ ( $js_loc_obj['addr_state'] == "Nagaland") ? 'selected' : '' }}>
                                                        Nagaland</option>
                                                    <option value="Odisha"
                                                        {{ ( $js_loc_obj['addr_state'] == "Odisha") ? 'selected' : '' }}>
                                                        Odisha</option>
                                                    <option value="Punjab"
                                                        {{ ( $js_loc_obj['addr_state'] == "Punjab") ? 'selected' : '' }}>
                                                        Punjab</option>
                                                    <option value="Rajasthan"
                                                        {{ ( $js_loc_obj['addr_state'] == "Rajasthan") ? 'selected' : '' }}>
                                                        Rajasthan</option>
                                                    <option value="Sikkim"
                                                        {{ ( $js_loc_obj['addr_state'] == "Sikkim") ? 'selected' : '' }}>
                                                        Sikkim</option>
                                                    <option value="Tamil Nadu"
                                                        {{ ( $js_loc_obj['addr_state'] == "Tamil Nadu") ? 'selected' : '' }}>
                                                        Tamil Nadu</option>
                                                    <option value="Telangana"
                                                        {{ ( $js_loc_obj['addr_state'] == "Telangana") ? 'selected' : '' }}>
                                                        Telangana</option>
                                                    <option value="Tripura"
                                                        {{ ( $js_loc_obj['addr_state'] == "Tripura") ? 'selected' : '' }}>
                                                        Tripura</option>
                                                    <option value="Uttar Pradesh"
                                                        {{ ( $js_loc_obj['addr_state'] == "Uttar Pradesh") ? 'selected' : '' }}>
                                                        Uttar Pradesh</option>
                                                    <option value="Uttarakhand"
                                                        {{ ( $js_loc_obj['addr_state'] == "Uttarakhand") ? 'selected' : '' }}>
                                                        Uttarakhand</option>
                                                    <option value="West Bengal"
                                                        {{ ( $js_loc_obj['addr_state'] == "West Bengal") ? 'selected' : '' }}>
                                                        West Bengal</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label for="name">Zip</label>
                                                <input type="text" class="form-cntrl" name="jszip" id="jszip"
                                                    placeholder="Zip" data-rule="email"
                                                    data-msg="Please enter a Zip Code"
                                                    value="{{ $js_loc_obj['addr_zip'] }}"
                                                    required />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12" style="margin-top: 2rem;">
                                        <h2 style="letter-spacing: 2px;"><span
                                                style="font-weight: bold;">OPTIONAL</span> FIELDS</h2>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Video</label>
                                        <input type="text" name="jsvideos" class="form-cntrl" id="video"
                                            placeholder="A link to video about yourself" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"
                                            value="{{ $joblist['js_vids'] }}" />
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Skills</label>
                                        <input type="text" name="jsskills" class="form-cntrl" id="skill"
                                            placeholder="Comma seperate a list of relevent skills" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"
                                            value="{{ $joblist['js_skills'] }}" />
                                    </div>
                                </div>



                                {{-- <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <label for="name" style="display: block;">URL(s)</label>
                                        <button style="width:100%" class="btn btn-outline-primary btn-sm"
                                            onclick="showURLmodal(event);"> +
                                            Add URL </button>
                                        <div id="urlsdiv">
                                            @foreach($js_url_list_obj as $noti)
                                                <div id="row_url_{{ $noti['idx'] }}" class="row"
                                                    style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 52px;">
                                                    <div class="col-md-8" style="font-size: 12px;"><span
                                                            style="font-weight: bold">{{ $noti['url'] }}</span>
                                                    </div>
                                                    <div class="col-md-4" style="font-size:20px;text-align: right;"><i
                                                            class="fa fa-trash" style="margin-right:15px"
                                                            onclick=removeURL(event,{{ $noti['idx'] }})></i>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <input type="hidden" name="urlsdivjson" id="urlsdivjson"
                                            value="{{ $joblist['js_urlslist'] }}" />

                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="name" style="display: block;text-align: center;">Education</label>
                                        <button style="width:100%" class="btn btn-outline-primary btn-sm"
                                            onclick="showEDUModal(event)"> + Add Education </button>
                                        <div id="edudiv">
                                            @foreach($js_edu_list_obj as $noti)
                                                <div id="row_url_{{ $noti['idx'] }}" class="row"
                                                    style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;">
                                                    <div class="col-md-8" style="font-size: 12px;">
                                                        <span style="font-weight: bold">
                                                            {{ $noti['school'] }}
                                                        </span><br /><span style="font-weight: bold">
                                                            {{ $noti['degree'] }}
                                                        </span><br /><span>
                                                            {{ $noti['start'] }} </span>
                                                        TO <span>{{ $noti['end'] }}
                                                        </span></div>
                                                    <div class="col-md-4" style="font-size:20px;text-align: right;"><i
                                                            class="fa fa-trash" style="margin-right:15px"></i>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <input type="hidden" name="edudivjson" id="edudivjson"
                                            value="{{ $joblist['js_education'] }}" />


                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="name" style="display: block;text-align:right;">Experience</label>
                                        <button style="width:100%" class="btn btn-outline-primary btn-sm"
                                            onclick="showEXPModal(event)"> + Add Experience </button>
                                        <div id="expdiv">
                                            @foreach($js_exp_list_obj as $noti)
                                                <div id="row_url_{{ $noti['idx'] }}" class="row"
                                                    style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;">
                                                    <div class="col-md-8" style="font-size: 12px;">
                                                        <span style="font-weight: bold">
                                                            {{ $noti['school'] }}
                                                        </span><br /><span style="font-weight: bold">
                                                            {{ $noti['title'] }}
                                                        </span><br /><span>
                                                            {{ $noti['start'] }} </span>
                                                        TO <span>{{ $noti['end'] }}
                                                        </span></div>
                                                    <div class="col-md-4" style="font-size:20px;text-align: right;"><i
                                                            class="fa fa-trash" style="margin-right:15px"></i>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <input type="hidden" name="expdivjson" id="expdivjson"
                                            value="{{ $joblist['js_experience'] }}" />

                                    </div>
                                </div>

                                <div class="col-lg-12">

                                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                    <label for="vehicle3">Terms and Condition</label><br>

                                </div> --}}


                            </div>


                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12 ml-auto">

                                    <button class="btn btn-primary  btn-register" style="width:30%"> Update Data
                                    </button>
                                </div>
                            </div>
                    </form>

                </div>



            </section>





        </div>
        </div>
        <!-- </div> -->
    </section>

</main>

<!-- Modal -->
<div class="modal fade" id="myURLModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Modal Header</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">URL</label>
                        <input type="text" id="inputURL" name="name" class="form-cntrl" id="name" placeholder="URL"
                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addURL()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myEduModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Add Education</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">School/University Name</label>
                        <input type="text" id="inputEDUname" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" />
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="name">Degree</label>
                        <input type="text" id="inputEDUdegree" name="name" class="form-cntrl" id="name"
                            placeholder="Degree" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="edustartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="eduendyr">
                            <option value="pursuing">Pursuing</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addEDU()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myExpModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Experience</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Company Name</label>
                        <input type="text" id="inputEXPname" name="name" class="form-cntrl" id="name"
                            placeholder="Company Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Job Title</label>
                        <input type="text" id="inputEXPtitlename" name="name" class="form-cntrl" id="name"
                            placeholder="Job Title" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="expstartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="expendyr">
                            <option value="present">Present</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addEXP()">Submit</button>
            </div>
        </div>
    </div>

</div>
<script>
    jsfunc = {
        test: {!!$joblist['js_urlslist']!!},
        urlarr: {!!$joblist['js_urlslist']!!},
        eduarr: {!!$joblist['js_education']!!},
        exparr: {!!$joblist['js_experience']!!},
        removeURLobj: (idx) => {
            // e.preventDefault();
            var pos = 0;
            jsfunc.urlarr.forEach(function (item, index, array) {
                if (item.idx === idx) {
                    pos = index;
                }
            });
            jsfunc.urlarr.splice(pos, 1);
            var res = JSON.stringify(jsfunc.urlarr);
            $('#urlsdivjson').val(res);
            console.log(res);
        },
        addURLobj: (urlval) => {
            var retval = 0;
            if (jsfunc.urlarr.length > 0) {
                let idx = 0;
                jsfunc.urlarr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.urlarr.push({
                    idx: idx,
                    url: urlval
                });
                retval = idx;
            } else {
                jsfunc.urlarr.push({
                    idx: 1,
                    url: urlval
                });
                retval = 1;
            }
            var res = JSON.stringify(jsfunc.urlarr);
            $('#urlsdivjson').val(res);
            console.log(res);
            return retval;
        },
        addEDUobj: (schoolname, startyr, endyr, degree) => {
            if (jsfunc.eduarr.length > 0) {
                let idx = 0;
                jsfunc.eduarr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.eduarr.push({
                    idx: idx,
                    school: schoolname,
                    degree: degree,
                    start: startyr,
                    end: endyr
                });
            } else {
                jsfunc.eduarr.push({
                    idx: 1,
                    school: schoolname,
                    degree: degree,
                    start: startyr,
                    end: endyr
                });
            }
            var res = JSON.stringify(jsfunc.eduarr);
            $('#edudivjson').val(res);
            console.log(res);
        },
        addEXPobj: (schoolname, startyr, endyr, title) => {
            if (jsfunc.exparr.length > 0) {
                let idx = 0;
                jsfunc.exparr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.exparr.push({
                    idx: idx,
                    school: schoolname,
                    title: title,
                    start: startyr,
                    end: endyr
                });
            } else {
                jsfunc.exparr.push({
                    idx: 1,
                    school: schoolname,
                    title: title,
                    start: startyr,
                    end: endyr
                });
            }
            var res = JSON.stringify(jsfunc.exparr);
            $('#expdivjson').val(res);
            console.log(res);
        }

    }

    function showURLmodal(e) {
        e.preventDefault();
        console.log(jsfunc.test);
        $("#myURLModal").modal('show');
    }

    function showEDUModal(e) {
        e.preventDefault();
        $("#myEduModal").modal('show');
    }

    function showEXPModal(e) {
        e.preventDefault();
        $("#myExpModal").modal('show');
    }

    function addEDU() {

        $('#myEduModal').modal('hide');
        $('#edudiv').append(
            '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">' +
            $('#myEduModal #inputEDUname').val() + '</span><br/><span style="font-weight: bold">' +
            $('#myEduModal #inputEDUdegree').val() + '</span><br/><span>' + $('#myEduModal #edustartyr').val() +
            '</span> TO <span>' + $('#myEduModal #eduendyr').val() +
            '</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        );
        jsfunc.addEDUobj($('#myEduModal #inputEDUname').val(), $('#myEduModal #edustartyr').val(), $(
            '#myEduModal #eduendyr').val(), $('#myEduModal #inputEDUdegree').val());

        console.log(jsfunc.eduarr);
        $('#myEduModal #inputEDUname').val('');
        $('#myEduModal #inputEDUdegree').val('');

    }

    function addURL() {
        if ($('#myURLModal #inputURL').val() !== "") {
            $('#myURLModal').modal('hide');
            let retidx = jsfunc.addURLobj($('#myURLModal #inputURL').val());
            $('#urlsdiv').append(
                '<div id="row_url_' + retidx +
                '" class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">' +
                $('#myURLModal #inputURL').val() +
                '</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px" onclick=removeURL(event,' +
                retidx + ')></i></div></div>'
            );
            // let retidx = jsfunc.addURLobj($('#myURLModal #inputURL').val());
            console.log(jsfunc.urlarr);
            $('#myURLModal #inputURL').val('');
        } else {
            console.log('error');
        }
    }

    function addEXP() {

        $('#myExpModal').modal('hide');
        $('#expdiv').append(
            '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">' +
            $('#myExpModal #inputEXPname').val() + '</span><br/><span style="font-weight: bold">' +
            $('#myExpModal #inputEXPtitlename').val() + '</span><br/><span>' + $('#myExpModal #expstartyr').val() +
            '</span> TO <span>' + $('#myExpModal #expendyr').val() +
            '</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        );
        jsfunc.addEXPobj($('#myExpModal #inputEXPname').val(), $('#myExpModal #expstartyr').val(), $(
            '#myExpModal #expendyr').val(), $('#myExpModal #inputEXPtitlename').val());
        console.log(jsfunc.eduarr);
        $('#myExpModal #inputEXPname').val('');
        $('#myExpModal #inputEXPtitlename').val('');
    }

    function removeURL(e, idx) {
        e.preventDefault();
        jsfunc.removeURLobj(idx);
        $('#row_url_' + idx).remove();
    }

</script>
@endsection
