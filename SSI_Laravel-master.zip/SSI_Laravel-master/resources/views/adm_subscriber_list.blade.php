@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Subscriber List</li>
        </ol>
        
        <div class="card mb-4">
            <div class="card-header" style="display: flex;justify-content: space-between;align-items: center;">
                <div>
                    <i class="fas fa-table mr-1"></i>Subscriber List
                </div>
                <div>
                    <i class="fas fa-download mr-1"></i><a href="{{url('/admin/subscriber/export')}}" style="color: black"> Download </a>
                </div>
            </div>
            <div class="card-body">
                @isset($subslist)
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Category</th>
                                <th>Create Date</th>
                                
                            </tr>
                        </thead>
                        
                        <tfoot>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Category</th>
                                <th>Create Date</th>
                                
                            </tr>
                        </tfoot>
                        <tbody>
                            @foreach($subslist as $noti)
                            <tr>
                                <td>{{ $noti['subs_fname'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['subs_lname'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['subs_email'] }}</td>
                                <td>{{ $noti['subs_desc'] }}</td>
                                <td>{{ $noti['subs_create_date'] }}</td>
                               
                                
                            </tr>
                            @endforeach
                        </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
@endsection