@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading"> Foreign <span class="titleheading">Contribution</span> <span class="titleheading">Regulation</span> <span class="titleheading">Act</span> (FCRA)
                            <span class="titleheading"> Services</span></span>
                        <h3>


                </header>
                <div class="row">
                    <div class="col-md-6">
                        <h4>We are expertise in providing FCRA services to all NGO’s, Voluntary Organization, NPO’s,
                            Charitable and Education Institution.</h4>

                        <span style="display: block;font-size: 16px;">Charitable Trusts, Society, NGOs and NPOs,
                            receiving grants and donations from foreign countries are required to report to Ministry of
                            Home Affairs (MHA). We provide services on reporting to MHA for:</span>

                        <ol style="line-height: 2rem;padding:1em">
                            <li>Annual filing of FCRA returns.

                            </li>
                            <li>Intimation of Quarterly Receipt of Foreign Contribution received by organizations.

                            </li>
                            <li>Application for Renewal of FCRA Registration.
                            </li>
                            <li>Generating unique ID’s for organization with Darpan Portal of Niti Aayog.
                            </li>
                            <li>Keeping the organization updated with any changes bought in under FCRA.</li>

                        </ol>
                        <hr style="color:#007bff;border:3px solid;">
                        <span style="display: block;font-size: 16px;"><b>For any further assistance our experts will get
                                in touch with you and take it forward.</b></span>
                        <br>
                        <p> Please email us at:<a style="color:blue;" href="mailto:Team@SocialServicesIndia.org">Team@SocialServicesIndia.org</a><strong> with
                                subject of the email "tax-compliance"</strong></p>


                    </div>
                    <div class="col-lg-6 background order-lg-2 order-1 wow fadeInUp">
                        <img src="{{ asset('img/about-img.svg')}}" style="width:100%" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>

    @endsection