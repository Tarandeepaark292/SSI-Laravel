@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' =>
$seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
    style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading"> </span> <span class="titleheading">Online</span> <span
                    class="titleheading">Courses</span>
        </header> --}}




        <div class="form-row mt-5">





            <div class="form-group col-lg-6">
                <select name="area" id="filter" onchange="myfunction(event)" class="form-cntrl">
                    <option value="">All Course Categories</option>
                    <option value=" Agriculture,food and nutrition"> Agriculture,food and nutrition</option>
                    <option value="CSR and Sustainability"> CSR and Sustainability</option>
                    <option value="Community Development">Community Development</option>
                    <option value="Disaster Management">Disaster Management</option>
                    <option value="Education/ Skill Development">Education/ Skill Development</option>
                    <option value="Energy, Environment and Climate Change">Energy, Environment and Climate Change
                    </option>
                    <option value="Microfinance">Microfinance</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Human Rights"> Human Rights</option>
                    <option value="Livelihoods">Livelihoods</option>
                    <option value="Social Entrepreneurship">Social Entrepreneurship</option>
                    <option value="Social Change">Social Change</option>
                    <option value="Water and Sanitation">Water and Sanitation</option>
                    <option value="Waste and Recycling"> Waste and Recycling</option>
                    <option value="Gender studies">Gender studies</option>
                    <option value="Cross-sectoral/Others">Cross-sectoral/Others</option>
                    <option value="Disability or specially-abled related">Disability or specially-abled related</option>
                    <option value="Communication/IEC/BCC">Communication/IEC/BCC</option>
                    <option value="Public Policy">Public Policy</option>
                    <option value="Technology (IT/MIS/GIS)">Technology (IT/MIS/GIS)</option>
                    <option value="Urban Policy">Urban Policy</option>
                    <option value="Employability">Employability</option>
                    <option value="Women Empowerment">Women Empowerment</option>
                    <option value="Rural Management">Rural Management</option>
                </select>
            </div>

            <div class="form-group col-lg-6">
                <select name="category" id="filters" onchange="myfunction(event)" class="form-cntrl">
                    <option value="">All Course Types</option>
                    <option value="free">Free</option>
                    <option value="paid"> Paid</option>
                </select>

            </div>















            <div class="row">

                <div class="col-12">
                    <form class="searchform">


                        {{-- <input type="text" placeholder="Search.." id="filter">
                        <button type="" style="width:100%;" onclick="myfunction(event)"><i
                                class="fa fa-search"></i></button> --}}
                    </form>
                </div>
            </div>




        </div>














        <div class="row">
            <div class="col-12">
                <span style="display: block;font-size: 16px;">
                    <p>
                        <br>
                        {{-- These are all the RF ads --}}
                        <br>
                    </p>
                </span>


            </div>











            <div id="search_results" style="width: 100%;" class="paginate">
                <div class="items">
                @isset($onlinesearch)
                @foreach($onlinesearch as $res)
                <div class="col-12 " style="margin-bottom:2rem;">
                    <div class="card content joblist_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">

                                <div class="col-md-2" style="text-align: center;">
                                    <img style="width: 80%;" src="{{asset($res['on_logo'])}}" />
                                </div>
                                <div class="col-md-8">
                                    <div class="limittext" id="results" style="font-weight: bold;color:#004a99;">
                                        {{ ($res['on_title']) }}
                                    </div>
                                    <div id="results" style="font-weight: bold;color:#004a99;">
                                        {{ $res['on_institute'] }}
                                    </div>
                                    <div id="results" style="color:#00254d;">
                                       Course Type: <b style="text-transform: capitalize;">{{ $res['on_radio'] }}</b>
                                    </div>
                                    <div class="results" style="color:#00254d;">
                                        <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;"></i> Closing date: {{ $res['on_apply'] }} 
                                    </div>
                                </div>
                                <div class="col-md-2 my-auto ">
                                    <a href="{{url('/online-course/')}}/{{$res['on_SEO']}}" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
                @endisset
                </div>
                <div class="pager">
                    <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
                    <div class="pageNumbers"></div>
                    <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
                </div>
    
            </div>
            
        </div>

    </div>

    </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxonline.post') }}",
            data: {
                focus: $('#filter').val(),
                state: $('#filters').val(),
            },

            success: function (data) {
                console.log(data);
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    $('#search_results').html('<h1>No Course Found</h1>');
                    // alert(data.error);
                }
            }
        });
    }
</script>



@endsection
@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection