@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])

@section('content')


<section style="">



    <div style="" id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleSlidesOnly" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleSlidesOnly" data-slide-to="1"></li>
            <li data-target="#carouselExampleSlidesOnly" data-slide-to="2"></li>
            <li data-target="#carouselExampleSlidesOnly" data-slide-to="3"></li>
            <li data-target="#carouselExampleSlidesOnly" data-slide-to="4"></li>
          </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="{{$banners[0]['b_link']}}" target="_blank">
                    <img src="{{ asset($banners[0]['b_img_name'])}}" class="d-block w-100" alt="...">
                </a>
            </div>
            <div class="carousel-item">
                <a href="{{$banners[1]['b_link']}}" target="_blank">
                    <img src="{{ asset($banners[1]['b_img_name'])}}" class="d-block w-100" alt="...">
                </a>
            </div>
            <div class="carousel-item">
                <a href="{{$banners[2]['b_link']}}" target="_blank">
                    <img src="{{ asset($banners[2]['b_img_name'])}}" class="d-block w-100" alt="...">
                </a>
            </div>
            <div class="carousel-item">
                <a href="{{$banners[3]['b_link']}}" target="_blank">
                    <img src="{{ asset($banners[3]['b_img_name'])}}" class="d-block w-100" alt="...">
                </a>
            </div>
            <div class="carousel-item">
                <a href="{{$banners[4]['b_link']}}" target="_blank">
                    <img src="{{ asset($banners[4]['b_img_name'])}}" class="d-block w-100" alt="...">
                </a>
            </div>
        </div>
    </div>



    @isset($news)
    <div class="container-fluid mt-5" style="background-color:white;">
        <div class="row   mx-5">
            <div class="col-md-12 ">
                <h1 style="text-align:center;"><b>Latest News</b></h1>
                <hr style="border:2px solid #30AFC0;width:200px; ">


            </div>
        </div>
        <div class="row">
            
            @foreach ($news as $item)

            <div class="col-md-4 pads">
                <a href="{{$item['news_link']}}" target="_blank">
                    <img src="{{ asset($item['news_image']) }}" alt="" class="img-fluid" style="width: 100%;">

                    <div class="card ml-3"
                        style="margin-top:-100px; box-shadow: 0 -5px 5px -5px #333;    background-color:#e6ece4; ">
                        <div class="card-body ">
                            <h5 style="text-align:center" class="card-subtitle mb-2 text-muted">
                                <b>{{$item['news_head']}}</b></h5>
                            <hr style="border:2px solid #30AFC0;width:200px;">
                            <p class="card-text limittext_news">{{$item['news_body']}} </p>

                        </div>
                    </div>
                </a>
            </div>

            @endforeach
           


        </div>

    </div>
    @endisset


    <div class="row mx-4">
        <div class="col-md-6 mt-5">

            <div style="background-color:#30AFC0;color:white;height:60px;" class="well well-sm">
                <div class="row">
                    <div class="col-md-10   mt-3">
                        <p style="padding-left:20px;font-weight:bold;">Featured Opportunities</p>
                    </div>
                    <div class="col-md-2 mt-3">
                        <a style="color: white;" href="{{url('/all-jobs')}}"><b>View All</b></a>

                    </div>
                </div>
            </div>

            <div class="card" style="height:800px;overflow:auto;">
                <div class="card-body">

                    @isset($jobs)
                    @foreach($jobs as $fell)


                    <div class="row"
                        style="border:2px solid #f2f2f2; border-radius:5px;margin-bottom: 1rem;box-shadow: #e7ebfd 0px 1px 2px;">

                        <div class="col-md-2" style="text-align: center;">
                            <img style="width: 100%;" src="{{ asset($fell['jp_org_logo']) }}" />
                        </div>
                        <div class="col-md-8">
                            <div class="results" style="font-weight: bold;font-size: 16px;">
                                {{ $fell['jp_org_name'] }}
                            </div>
                            <div id="results" style="font-weight: bold;"">
                                {{ $fell['jp_title'] }}
                            </div>
                            <div id="results">
                                <i class="fa fa-map-marker" aria-hidden="true"
                                    style="color:#007bff;font-size: 18px;"></i> <span
                                    style="font-weight: bold;color:#007bff;font-size:16px;">{{ $fell['jp_loc'] }}</span>

                            </div>
                            <div id="results">
                                <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i>
                                Closing date: <span
                                    style="color:#00254d;font-size:14px;">{{ $fell['jp_closing_date'] }}
                                </span>
                            </div>
                        </div>
                        <div style="text-align:right" class="col-md-2 my-auto">
                            {{-- <div id="results" style="color:#293e09;font-size: 15px;">
                                <span style="font-weight: bold;"> {{ $int['evt_email'] }}</span>
                        </div> --}}
                        <a href="{{ url('/job-post/') }}/{{ $fell['jp_SEO'] }}" class="btn btn-newprimary">Details</a>
                    </div>



                </div>
                @endforeach
                @endisset



                </p>
            </div>
        </div>

        <div style="background-color:#30AFC0;color:white;height:60px;" class="well well-sm mt-4">
            <div class="row">
                <div class="col-md-10   mt-3">
                    <p style="padding-left:20px;font-weight:bold;">Awards</p>
                </div>
                <div class="col-md-2 mt-3">
                    <a style="color: white;" href="{{url('/all-awards')}}"><b>View All</b></a>

                </div>
            </div>
        </div>

        <div class="card" style="height:800px;overflow:auto;">
            <div class="card-body">

                @isset($awards)
                @foreach($awards as $fell)


                <div class="row"
                    style="border:2px solid #f2f2f2; border-radius:5px;margin-bottom: 1rem;box-shadow: #e7ebfd 0px 1px 2px;">

                    <div class="col-md-2" style="text-align: center;">
                        <img style="width: 100%;" src="{{ asset($fell['award_org_logo']) }}" />
                    </div>
                    <div class="col-md-8">
                        <div class="results" style="font-weight: bold;font-size: 16px;">
                            {{ $fell['award_org_name'] }}
                        </div>
                        <div id="results">
                            {{ $fell['award_title'] }}
                        </div>
                        <div id="results">
                            <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i>
                            <span
                                style="font-weight: bold;color:#007bff;font-size:16px;">{{ $fell['award_loc'] }}</span>

                        </div>
                        
                    </div>
                    <div style="text-align:right" class="col-md-2 my-auto">
                        {{-- <div id="results" style="color:#293e09;font-size: 15px;">
                                <span style="font-weight: bold;"> {{ $int['evt_email'] }}</span>
                    </div> --}}
                    <a href="{{ url('/award/') }}/{{ $fell['award_SEO'] }}" class="btn btn-newprimary">Details</a>
                </div>



            </div>
            @endforeach
            @endisset



            </p>
        </div>
    </div>
    </div>
    <div class="col-md-6 mt-5">
        <div style="background-color:#30AFC0;color:white;height:60px;" class="well well-sm">
            <div class="row">
                <div class="col-md-10   mt-3">
                    <p style="padding-left:20px;"><b>FC Grants</b></p>
                </div>
                <div class="col-md-2 mt-3">
                    <a style="color: white;" href="{{url('/all-fcgrant-ads')}}"><b>View All</b></a>

                </div>
            </div>
        </div>

        <div class="card" style="height:800px;overflow:auto;">
            <div class="card-body">


                @isset($rfps)
                @foreach($rfps as $int)


                <div class="row"
                    style="border:2px solid #f2f2f2; border-radius:5px;margin-bottom: 1rem;box-shadow: #e7ebfd 0px 1px 2px;">
                    <div class="col-md-2" style="text-align: center;">
                        <img style="width: 100%;" src="{{ asset($int['rfp_logo']) }}" />
                    </div>
                    <div class="col-md-8 ">
                        <div class="results" style="font-weight: bold;font-size: 16px;">
                            {{ $int['rfp_title'] }}
                        </div>
                        <div id="results">
                            {{ $int['rfp_org'] }}
                        </div>
                        {{-- <div id="results">
                                <!-- <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i>  -->
                                <span
                                    style="font-weight: bold;color:#007bff;font-size:16px;">{{ $int['reg_o_mission'] }}</span>

                    </div> --}}
                    <div id="results">
                        <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i>
                        Closing date: <span
                            style="color:#00254d;font-size:14px;">{{ $int['rfp_close_date'] }}
                        </span>
                    </div>
                </div>
                <div style="text-align:right" class="col-md-2 my-auto">
                    {{-- <div id="results" style="color:#293e09;font-size: 15px;">
                                <span style="font-weight: bold;"> {{ $int['evt_email'] }}</span>
                </div> --}}
                <a href="{{ url('/rfp/') }}/{{ $int['rfp_SEO'] }}" class="btn btn-newprimary">Details</a>
            </div>
        </div>
        @endforeach
        @endisset



        </p>
    </div>
    </div>








    <div style="background-color:#30AFC0;color:white;height:60px;" class="well well-sm mt-4">



        <div class="row">
            <div class="col-md-10   mt-3">
                <p style="padding-left:20px;"><b>Events</b></p>
            </div>
            <div class="col-md-2 mt-3">
                <a style="color: white;" href="{{url('/all-event-ads')}}"><b>View All</b></a>

            </div>
        </div>


    </div>







    <div class="card" style="height:800px;overflow:auto;">
        <div class="card-body">

            @isset($homesearch)
            @foreach($homesearch as $int)


            <div class="row"
                style="border:2px solid #f2f2f2; border-radius:5px;margin-bottom: 1rem;box-shadow: #e7ebfd 0px 1px 2px;">
                <div class="col-md-2" style="text-align: center;">
                    <img style="width: 100%;" src="{{ asset($int['evt_org_logo']) }}" />
                </div>
                <div class="col-md-8">
                    <div class="limittext" style="font-weight: bold;font-size: 16px;">
                        {{ $int['evt_title'] }}
                    </div>
                    {{-- <div id="results">
                                {{ $int['evt_org_name'] }}
                </div> --}}
                <div id="results">
                    <i class="fa fa-map-marker" aria-hidden="true" style="font-size: 18px;"></i> <span
                        style="font-weight: bold;font-size:16px;">
                        {{ $int['evt_loc'] }}</span>

                </div>
                <div id="results">
                    <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i>
                    Closing date: <span
                        style="color:#00254d;font-size:14px;">{{ $int['evt_end_date'] }}
                    </span>
                </div>
            </div>
            <div style="text-align:right" class="col-md-2 my-auto">
                {{-- <div id="results" style="color:#293e09;font-size: 15px;">
                                <span style="font-weight: bold;"> {{ $int['evt_email'] }}</span>
            </div> --}}
            <a href="{{ url('/evt/') }}/{{ $int['evt_SEO'] }}" class="btn btn-newprimary">Details</a>
        </div>
    </div>
    @endforeach

    @endisset
    </p>
    </div>
    </div>




    </div>




    </div>






    </div>







    <div class="background-area-11 mb-4 back"
        style="margin-top:50px; margin-bottom:30px; background-image:url('{{ asset('/img/Group 12.png') }}">
        <h2 style="color:white;text-align:center;padding-top:20px;"><b>NGO RESOURCES</b></h2>
        <hr style="border:2px solid #30AFC0;width:200px;margin-bottom:0px!important;">

        <div class="owl-carousel" style="padding:20px; ">
            <div class="card mb-2">
                <a href="{{url('/NGO/overview')}}">
                <img class="card-img-top" src="{{ asset('img/NGO/NGO-1.png') }}" alt="Card image cap">
                <div class="card-body">
                    {{-- Voluntary National Reviews
                    Database --}}
                </div>
                </a>
            </div>
            <div class="card mb-2">
                <a href="{{url('/NGO/byelaws')}}">
                <img class="card-img-top" src="{{ asset('img/NGO/NGO-2.png') }}" alt="Card image cap">
                <div class="card-body">
                    {{-- Voluntary National Reviews
                    Database --}}
                </div>
                </a>
            </div>
            <div class="card mb-2">
                <a href="{{url('/NGO/fcra')}}">
                <img class="card-img-top" src="{{ asset('img/NGO/NGO-3.png') }}" alt="Card image cap">
                <div class="card-body">
                    {{-- Voluntary National Reviews
                    Database --}}
                </div>
                </a>
            </div>
            <div class="card mb-2">
                <a href="{{url('/NGO/offices-policies')}}">
                <img class="card-img-top" src="{{ asset('img/NGO/NGO-4.png') }}" alt="Card image cap">
                <div class="card-body">
                    {{-- Voluntary National Reviews
                    Database --}}
                </div>
                </a>
            </div>

</section>

@endsection
@section('custom_script')
<script>
    $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            navText: [
                "<i class='fa fa-chevron-left'></i>",
                "<i class='fa fa-chevron-right'></i>"
            ],
            autoplay: true,
            autoplayHoverPause: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 4
                }
            }
        })
    });

</script>

<script type="application/ld+json">
    [ 
    { "@context":"https://schema.org",
      "@graph":[{"@type":"Organization",
      "@id":"https://socialservicesindia.org/#organization",
      "name":"Social Services India",
      "url":"https://semupdates.com/",
      "sameAs":["https://www.facebook.com/semupdatesinc/",
      "https://www.instagram.com/social.services.india/",
      "https://t.me/SocialServicesIndia",
      "https://twitter.com/write_to_ssi"],
      "logo":{"@type":"ImageObject","@id":"https://socialservicesindia.org/#logo","inLanguage":"en-GB","url":"https://socialservicesindia.org/img/ssi_logo.png"},"image":{"@id":"https://socialservicesindia.org/#logo"}
    },{
      "@type" : "Website",
      "@id":"https://socialservicesindia.org/#website",
      "url":"https://socialservicesindia.org/",
      "name":"Social Services India",
      "description":"India's only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs.",
      "publisher" : {
        "@type" : "Organization",
        "name" : "SocialServicesIndia.org"},
      "potentialAction":{"@type":"SearchAction",
      "target":"https://socialservicesindia.org/?s={search_term_string}",
      "query-input":"required name=search_term_string"},
      "inLanguage":"en-GB"
    },{
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Login",
      "url" : "https://socialservicesindia.org/login"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Post Announcement",
      "url" : "https://socialservicesindia.org/organizer-services"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Jobs",
      "url" : "https://socialservicesindia.org/all-jobs"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Resumes",
      "url" : "https://socialservicesindia.org/resumes"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "CSR Grants",
      "url" : "https://socialservicesindia.org/all-csr-ads"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "FC Grants",
      "url" : "https://socialservicesindia.org/all-fcgrant-ads"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Scholarships",
      "url" : "https://socialservicesindia.org/all-scholarship"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Fellowships",
      "url" : "https://socialservicesindia.org/all-fellowship"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Awards",
      "url" : "https://socialservicesindia.org/all-awards"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Events",
      "url" : "https://socialservicesindia.org/all-event-ads"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Admissions",
      "url" : "https://socialservicesindia.org/all-admissions"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Online Courses",
      "url" : "https://socialservicesindia.org/all-online-course"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Call for Papers",
      "url" : "https://socialservicesindia.org/all-callpaper"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Publications",
      "url" : "https://socialservicesindia.org/all-publication"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Services",
      "url" : "https://socialservicesindia.org/organizer-services"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Financial Services",
      "url" : "https://socialservicesindia.org/financial-services"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Accounting",
      "url" : "https://socialservicesindia.org/accounting"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Auditing",
      "url" : "https://socialservicesindia.org/auditing"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Tax Compliance",
      "url" : "https://socialservicesindia.org/tax-compliance"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Fcra Services",
      "url" : "https://socialservicesindia.org/fcra-services"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "About Us",
      "url" : "https://socialservicesindia.org/about"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Contact",
      "url" : "https://socialservicesindia.org/contact"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "ORG's Sector Wise",
      "url" : "https://socialservicesindia.org/org-sector-wise"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "State and UT",
      "url" : "https://socialservicesindia.org/state-ut"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "FAQ",
      "url" : "https://socialservicesindia.org/faq"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Privacy Policy",
      "url" : "https://socialservicesindia.org/privacy-policy"
    }, {
      "@context" : "http://schema.org",
      "@type" : "Article",
      "name" : "Terms And Conditions",
      "url" : "https://socialservicesindia.org/terms-condition"
    }
               ]}]
    </script>
    
@endsection
