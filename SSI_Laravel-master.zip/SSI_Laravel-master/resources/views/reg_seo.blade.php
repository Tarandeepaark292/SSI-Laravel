@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    

    <div class="row" style="margin-top: 4rem;">
        <div class="col-8" style="margin:0 auto;">
            <div class="container" style="background: #e9f3fb;padding: 1rem;margin-bottom: 5rem;">

                <div class="row">
                    {{-- <div class="col-md-12">
                        <h1 style="text-align: center;font-weight: bold;font-variant: petite-caps;">
                            {{ $jp_obj['rfp_title'] }} </h1>
                    </div> --}}
                </div>
                <div class="row" style="margin-bottom:2rem;">
                    <div class="col-md-4">
                        <img src="{{ asset('img/export.png') }}" style="width:100%; " alt="">
                    </div>
                    <div class="col-8">
                        <div id="name">
                            <h1 class="quickFade delayTwo " style="font-size:30px;">
                                {{$jp_obj['reg_o_name']}}
                            </h1>
                            <hr style="width:80%;">


                            <i class="fa fa-calendar ml-1 mr-2" aria-hidden="true"></i> <a
                                    href="  {{ $jp_obj['reg_valid_from'] }}" target="_blank">
                                    {{ $jp_obj['reg_valid_To'] }}</a></br>
                                    <i class="fa fa-globe ml-1 mr-2" aria-hidden="true"></i> 
                                    {{ $jp_obj['reg_website'] }}</a></br>
                                    <i class="fa fa-envelope ml-1 mr-2" aria-hidden="true"></i> 
                                    {{ $jp_obj['reg_email'] }}</a></br>
                            
                            <a href="#"> Download Proposal <i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h1 style="font-size:1.2em;"><b>Vision Of Organisation</b></h1>

                        <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p style="line-height: 1.5rem;text-align: justify;font-size:15px"> {{ $jp_obj['reg_v_org']}}</p>
                        <!-- </div> -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h1 style="font-size:1.2em;"><b>Organisation Mission</b></h1>

                        <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p style="line-height: 1.5rem;text-align: justify;font-size:15px"> {{$jp_obj['reg_o_mission']}}</p>
                        <!-- </div> -->
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h1 style="font-size:1.2em;"><b>Organisation Achievement</b></h1>

                        <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p style="line-height: 1.5rem;text-align: justify;font-size: 15px;"> {{$jp_obj['reg_o_ach']}}</p>
                        <!-- </div> -->
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h1 style="font-size:1.2em;"><b>Validity</b></h1>

                        <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p style="line-height: 1.5rem;text-align: justify;font-size: 15px;"> {{$jp_obj['reg_valid_To']}}</p>
                        <!-- </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>






</section>

@endsection
