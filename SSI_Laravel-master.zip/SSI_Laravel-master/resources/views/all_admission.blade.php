@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' =>
$seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Admissions <span class="titleheading"> </span> <span class="titleheading">
                    </span> <span class="titleheading">
                    </span> </span></h3>



        </header> --}}

        <div class="container">
            <div class="form-row mt-5">





                <div class="form-group col-lg-6">
                    <select name="area" id="filter" onchange="myfunction(event)" class="form-cntrl">
                        <option value="">All Areas</option>
                        <option value="Agriculture ,food and nutrition">Agriculture ,food and nutrition</option>
                        <option value="Entrepreneurship">Entrepreneurship </option>

                        <option value="CSR and Sustainability">CSR and Sustainability</option>
                        <option value="Community Development">Community Development </option>

                        <option value="Disaster Management">Disaster Management</option>
                        <option value="Education/Skill Development">Education/Skill Development</option>
                        <option value="Energy ,Environment and climate change">Energy ,Environment and climate change
                        </option>
                        <option value="Microfinance">Microfinance</option>
                        <option value="Healthcare">Healthcare</option>
                        <option value="Human Right">Human Right</option>
                        <option value="Livelihood">Livelihood</option>
                        <option value="Social Entrepreneurship">Social Entrepreneurship</option>
                        <option value="Social Change">Social Change</option>
                        <option value="Water and sanitation">Water and sanitation</option>
                        <option value="Waste and recycling"> Waste and recycling</option>
                        <option value="Gender studies">Gender studies</option>
                        <option value="Cross-sectrol/others">Cross-sectrol/others</option>
                        <option value="Disablity or specially-abled-related">Disablity or specially-abled-related
                        </option>
                        <option value="Communication/IEC/BCC">Communication/IEC/BCC
                        </option>
                        <option value="Public policy">Public policy</option>
                        <option value="Technology">Technology</option>
                        <option value="Urban policy">Urban policy</option>
                        <option value="Employability">Employability </option>
                        <option value="Women Empowerment<">Women Empowerment</option>
                        <option value="Rural management">Rural management</option>


                    </select>




                </div>

                <div class="form-group col-lg-6">
                    <select name="category" id="filters" onchange="myfunction(event)" class="form-cntrl">
                        <option value="">All Locations</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands
                        </option>
                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                        <option value="Assam">Assam</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Chhattisgarh">Chhattisgarh</option>
                        <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                        <option value="Daman and Diu">Daman and Diu</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Lakshadweep">Lakshadweep</option>
                        <option value="Puducherry">Puducherry</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                        <option value="Jharkhand">Jharkhand</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Meghalaya">Meghalaya</option>
                        <option value="Mizoram">Mizoram</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Odisha">Odisha</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Sikkim">Sikkim</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="Uttarakhand">Uttarakhand</option>
                        <option value="West Bengal">West Bengal</option>
                    </select>

                </div>
            </div>

            {{-- <div class="form-row">
                <div class="form-group col-lg-12">
                    <select name="category" id="filterss" onchange="myfunction(event)" style="width:100%;height:43px;">
                        <option value="2000">2000</option>
                        <option value="2001">2001</option>
                        <option value="2002">2002</option>
                        <option value="2003">2003</option>
                        <option value="2004">2004</option>
                        <option value="2005">2005</option>
                        <option value="2006">2006</option>
                        <option value="2007">2007</option>
                        <option value="2008">2008</option>
                        <option value="2009">2009</option>
                        <option value="2010">2010</option>
                        <option value="2011">2011</option>
                        <option value="2012">2012</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>

                    </select>

                </div>
            </div> --}}

            <form class="searchform">

                {{-- <button type="" onclick="myfunction(event)" style="width:100%;" ><i class="fa fa-search"></i></button> --}}
            </form>





            <div class="row">
                <div class="col-lg-12">

                </div>
                <!-- </div> -->
                <div class="col-12">
                    <span style="display: block;font-size: 16px;">
                        <p>

                    </span>

                </div>

                <div id="search_results" style="width: 100%;" class="paginate">
                    <div class="items">
                    @isset($adnsearch)
                    @foreach($adnsearch as $res)
                    <div class="col-12" style="margin-bottom:2rem;">
                        <div class="card content joblist_item" id="results">
                            <div class="card-body" id="results">
                                <div class="row " id="resultss">
                                    <div class="col-md-2" style="text-align: center;">

                                        <img style="width: 80%;" src="{{asset($res['adn_org_logo'])}}" />
                                    </div>
                                    <div class="col-md-8">
                                        <div class="results" >

                                            <div id="results" class="limittext" style="font-weight: bold;color:#004a99">
                                                {{$res['adn_title']}}
                                            </div>
                                            <div id="results">
                                                <i class="" aria-hidden="true"
                                                    style="color:#004a99;font-size: 18px;"></i> <span
                                                    style="font-weight: bold;color:#004a99;">{{$res['adn_inst_name']}}</span>

                                            </div>
                                            <div id="results">
                                                <i class="fa fa-map-marker" aria-hidden="true"
                                                    style="color:#007bff;;font-size: 18px;"></i> <span
                                                    style="">{{$res['adn_state']}}
                                                </span>
                                            </div>
                                        </div>
                                        <!-- <div class="col-md-2 "> -->
                                        <div id="results" style="color:#293e09;">
                                            <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date:  <span
                                                style="">{{$res['adn_apply']}}</span>
                                            <!-- </div> -->
                                        </div>
                                    </div>
                                    <div class="col-md-2 my-auto ">
                                        <a href="{{url('/admission/')}}/{{$res['adn_SEO']}}" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    @endforeach
                    @endisset
                    </div>
                    <div class="pager">
                        <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
                        <div class="pageNumbers"></div>
                        <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {

        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajax_search_admission.post') }}",
            data: {
                area: $('#filter').val(),
                state: $('#filters').val(),
                year: $('#filterss').val(),

            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    $('#search_results').html('<h1>NO ADMISSION FOUND</h1>');
                    // alert(data.error)
                }
            }
        });
    }
</script>
@endsection
@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection