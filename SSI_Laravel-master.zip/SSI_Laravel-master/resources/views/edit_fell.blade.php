@extends('layouts.auth_bend_home')
@section('content')
<main id="main">
<section >

    <div class="container-fluid">
        <h1 class="mt-4">Post Fell</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organizer PANEL</li>
            <li class="breadcrumb-item active">Update Fell </li>
        </ol>


          
            

        <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4> </h4>

                    </header>


             


                    <form action="{{url('/admin/update_fell')}}/{{$jp_obj['fell_id']}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        
                        @csrf
                        <div class="row" >
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;background-color:f0f2f4;">
                            <!-- <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0; "> -->
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="name" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" value="{{$jp_obj['fell_o_name']}}" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Fellowship Title </label>
                                        <input type="text" name="title" class="form-cntrl" id="title"
                                            placeholder="Fellowship Title" value="{{$jp_obj['fell_title']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="Location"   value="{{$jp_obj['fell_loc']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Organisation logo</label>
                                        <input type="file" name="org_logo" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" class="form-cntrl" id="org_logo"  value="{{$jp_obj['fell_o_logo']}}"  />

                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-3">
                                    <!-- <label for="company_logo">Uploaded</label><br> -->
                                        <img src="{{asset($jp_obj['fell_o_logo'])}}" class="form-cntrl-file" name=""  height="70%" alt="">
                                        <input type="hidden" name="org_old_logo" value="{{$jp_obj['fell_o_logo']}}">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6" style="position:relative">
                                        <label for="company_logo">Deadline date</label><br>
                                        <input type="date" class="form-cntrl"  name="deadlinedate" id="deadlinedate"
                                            placeholder="Deadline Date"   value="{{$jp_obj['fell_end_date']}}" >
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label>Email</label>
                                        <input type="text" class="form-cntrl" name="email" id="email"
                                            placeholder="email"  value="{{$jp_obj['fell_email']}}" >

                                        <div class="validate"></div>
                                    </div>

                                </div>
                               
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the fellowshp</label><br>
                                        <textarea class="form-cntrl" name="desc" id="summernote" placeholder=""
                                            rows="10" style="height: auto;resize: none;"  >{{$jp_obj['fell_desc']}}</textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Scholarship Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="{{$jp_obj['fell_cate']}}" />
                                </div>
                                @endisset
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload Proposal Document</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text"
                                            accept="application/pdf" name="upload" id="upload"  value="{{$jp_obj['fell_upload_doc']}}" >
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="">Uploaded</label><br>
                                            <span value="" class="form-cntrl" alt="">{{$jp_obj['fell_upload_doc']}}</span>
                                            <input type="hidden" name="pdf_old_doc" value="{{$jp_obj['fell_upload_doc']}}">
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url"
                                            placeholder="refrenceurl"  value="{{$jp_obj['fell_url']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-group col-lg-12">
                                    <label name=""> Fellowship Category</label>
                                    <br>
                                    <input type="checkbox" id="" name="cates[]" value="fellowship">
                                    <label for="vehicle1"> Fellowship</label><br>
                                    <input type="checkbox" id="" name="cates[]" value="scholarship">
                                    <label for="vehicle2"> Scholarship</label><br>
    
                                </div>
                                <div class="form-row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">
        
                                        <button type="submit" class="btn btn-primary  btn-register" style="margin-top:10;">
                                            Submit Fellowship</button>
                                    </div>
                                </div>
                            </div>
                       </div>

                            

                    





                        

                    </form>
                <!-- </div> -->



           

</div>
</section>

     
    </div>
</section>
<script>
    function onchkclick() {
        $('#cates').val('');
        chkeles = $('.proposal_chk');
        chkeles.each((index, value) => {
            if ($(value).prop('checked') == true) {
                if ($('#cates').val() === '') {
                    $('#cates').val($(value).val());
                } else {
                    $('#cates').val($('#cates').val() + ',' + $(value).val());
                }

            }
        });
        console.log($('#cates').val());
    }

</script>
</main>

@endsection
