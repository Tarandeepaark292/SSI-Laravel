@extends('layouts.home')
@section('content')
<div class="container" >
    <div class="row">
        <div class="col-md-12">



            <div id="notfounds">
                <div class="notfounds">
                    <div class="notfound-404s" >
        
        
                        <h1 >Error</h1>
        
                    </div>
        @if(isset($msg))
                    <h2>{{ $msg }}</h2>
        @else
                    <h2>Some Problem in Serving your request</h2>
        @endif
            <a style="font-size:30px;" href="{{ url('/') }}"><span class="arrows"
                    style="height:16px;width:16px;"></span>Return To Homepage</a>
            </div>
        </div>

        </div>

    </div>
@endsection