@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
    style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            {{-- <h3><span class="titleheading">All </span> <span class="titleheading">publication</span>  --}}
        </header>




        <div class="form-row mt-5">
            <div class="form-group col-lg-12">
                <input type="text" name="cat" id="cat" onchange="myfunction(event)" class="form-cntrl" id="filter"
                    placeholder="Keywords" />
                <div class="validate"></div>
            </div>

        </div>


        <div class="form-row ">




            <div class="form-group col-lg-6">


                <select name="advoracy" id="filter" onchange="myfunction(event)" class="form-cntrl"
                    style="width:100%;height:40px;">
                    <option value="">Choose Publication Type</option>
                    @foreach ($catelist as $cate)
                        <option value="{{$cate['pub_cate_id']}}">{{$cate['pub_cate_name']}}</option>
                    @endforeach
                    {{-- <option value="1">Advocacy and Government</option>
                    <option value="2">Aged/Elderly</option>
                    <option value="3">Agriculture</option>
                    <option value="4"> Publications</option>
                    <option value="5"> Husbandry, Dairying & Fisheries</option>
                    <option value="6">Any Other</option>
                    <option value="7">Art & Culture</option>
                    <option value="8">Artificial Intelligence and Development</option>
                    <option value="9">Biotechnology</option>
                    <option value="10">Children</option>
                    <option value="11">Civic Issues</option>
                    <option value="12">Dalit Upliftment</option>
                    <option value="13">Development and Democracy</option>
                    <option value="14">Differently Abled</option>
                    <option value="15">Disability</option>
                    <option value="16">Disaster Management</option>
                    <option value="17">Diversity and Inclusion</option>
                    <option value="18">Drinking Water</option>
                    <option value="19">Education & Literacy</option>
                    <option value="20">Entrepreneurship And Innovation</option>
                    <option value="21">Environment & Forests</option>
                    <option value="22">Financial Inclusion</option>
                    <option value="23">Food Processing</option>
                    <option value="24">Gender</option>
                    <option value="25">Health & Family Welfare</option>
                    <option value="26">HIV/AIDS</option>
                    <option value="27">Housing</option>
                    <option value="28">Human Rights</option>
                    <option value="29">Impact Investing</option>
                    <option value="30">Information & Communication Technology (ICT)</option>
                    <option value="31">Internet governance</option>
                    <option value="32">Labour & Employment</option>
                    <option value="33">Land Resources</option>
                    <option value="34">Legal Awareness & Aid</option>
                    <option value="35">Micro Finance SHGs</option>
                    <option value="36"> Small & Medium Enterprises</option>
                    <option value="37">Minority Issues</option>
                    <option value="38">New & Renewable Energy</option>
                    <option value="39">Nutrition</option>
                    <option value="40">Panchayati Raj</option>
                    <option value="41">Prisoner’s Issues</option>
                    <option value="42">Right To Information & Advocacy</option>
                    <option value="43">Rural Development & Poverty Alleviation</option>
                    <option value="44">Sanitation</option>
                    <option value="45">Science & Technology</option>
                    <option value="46">Scientific & Industrial Research</option>
                    <option value="47">Skill Development</option>
                    <option value="48">Social Justice</option>
                    <option value="49">Sports</option>
                    <option value="50">Sustainable Development</option>
                    <option value="51">Tourism</option>
                    <option value="52">Tribal Affairs</option>
                    <option value="53">Urban Development & Poverty Alleviation</option>
                    <option value="54">Vocational Training</option>
                    <option value="55">Water Resources</option>
                    <option value="56">Wildlife</option>
                    <option value="57">Women’s Development & Empowerment</option>
                    <option value="58">Youth Affairs</option> --}}
                </select>




            </div>

            <div class="form-group col-lg-6">
                <select name="focus" id="filters" class="form-cntrl" class="form-cntrl" onchange="myfunction(event)"
                    style="width:100%;height:40px;">
                    <option value="">Choose Focus Type</option>
                    <option value="1">Education</option>
                    <option value="2">Women and Girls</option>
                    <option value="3">Health</option>
                    <option value="4">Environment</option>
                    <option value="5">Hunger</option>
                    <option value="6">Any Other</option>
                </select>



            </div>




            <div class="row">

                <div class="col-12">
                    <form class="searchform">


                        {{-- <input type="text" placeholder="Search.." id="filter">  --}}
                        {{-- <button type=""  style="width:100%;"onclick="myfunction(event)"><i class="fa fa-search" ></i></button> --}}
                    </form>
                </div>
            </div>




        </div>

        <div class="col-12">
            <span style="display: block;font-size: 16px;">
                <p>
                    <br>
                    {{-- These are all the RF ads --}}
                    <br>
                </p>
            </span>


        </div>











        <div id="search_results" style="width: 100%;" class="paginate">
            <div class="items">
            @isset($pubsearch)
            @foreach($pubsearch as $res)
            
            <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content joblist_item" id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">

                            <div class="col-md-2" style="text-align: center;">
                                <img style="width: 80%;" src="{{asset($res['pub_upload_image'])}}" />
                            </div>
                            <div class="col-md-8">

                                <div class="limittext" id="results" style="font-weight: bold;color:#004a99">
                                    {{ $res['pub_title'] }}
                                </div>
                                <div class="results" style="margin-bottom:2px;font-weight: bold;color:#004a99">
                                    Author : {{ $res['pub_name'] }}
                                </div>
                                <div class="results" style="margin-bottom:2px;font-weight: bold;color:#004a99">
                                    {{ $res['pub_year'] }}
                                </div>
                                
                                <div class="limittext_news" style="text-align: justify;">
                                    {{ $res['pub_desc'] }}
                                </div>


                            </div>
                            <div class="col-md-2" style="align-self: center;justify-content: center;">
                                <a href="{{url('/publication_seo')}}/{{$res['pub_SEO']}}" class="btn btn-primary">Detail <i
                                        class="fa fa-chevron-right"></i></a>
                            </div>






                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            @endisset
            </div>
            <div class="pager">
				<div class="previousPage"><i class="fa fa-arrow-left"></i></div>
				<div class="pageNumbers"></div>
				<div class="nextPage"><i class="fa fa-arrow-right"></i></div>
			</div>
        </div>


    {{-- </div> --}}

    </div>

    </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxpublication.post') }}",
            data: {
                focus: $('#filter').val(),
                state: $('#filters').val(),
                cate: $('#cat').val()
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    //console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    $('#search_results').html('<h1>No Publications found</h1>');
                    // alert(data.error);
                }
            }
        });
    }

    

</script>



@endsection

@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection
