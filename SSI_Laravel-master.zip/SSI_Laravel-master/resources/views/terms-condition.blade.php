@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

        <section id="Terms And Conditions" style=""">
            {{-- <div class=" intro-img" style="">
            <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">


                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Terms</span> <span class="titleheading">And</span> <span class="titleheading">Conditions</span></h3>
                </header>

                <div class="container">

                    <span style="font-size: 12pt;"><b>Terms of Service – Social Services India Premium Membership</b></span><br><br>
                    <p>
                        These “Terms of Service” bring forth the terms and conditions that are applied to your use of Social Services India Premium Services. By using the Social Services India Premium Services, you agree to comply with all of the Terms of services set forth herein.
                        The right to use the Social Services India Premium Services is personal to you and is not transferable to any other person or entity. These terms and conditions apply to all Social Services India Premium Services, that carry the official logo of Social Services India and offer digital products for sale.
                        Social Services India may revise these Terms of Services at any time and you will agree to be bound by the revised Terms of Services. Any modification will become effective only when it will be first posted to this page. You are responsible to return to the Terms of Service from time to time to review the current terms and conditions.
                    </p>
                    <span style="font-size: 12pt;"><b>1. Premium Membership Obligations</b></span><br><br>
                    <p>
                        As a Premium Member of Social Services India, you represent and agree that:<br><br>
                        1.1 You are able to enter into this agreement. You have the right, authority, and capacity to enter into the agreement represented by these Terms and to abide by all of the rules and conditions of these Terms;<br><br>
                        1.2 You are at least 18 years old, and if you are less than the age of consent in the state or jurisdiction where you are located, your parent or legal guardian has reviewed these Terms and granted permission to use the Service. If you are not at least 18 years old, you must discontinue using the Services immediately;<br><br>
                        1.3 You will be bound by any additional rules or policies published within or with respect to any application provided in the Premium Services; except as exceptionally permitted, you will not copy, redistribute, publish or otherwise exploit material from the Premium Services without the exceptional prior written permission of the Orginisation.<br><br>
                    </p>
                    <span style="font-size: 12pt;"><b>2. Refund & Cancellation Policy</b></span><br><br>
                    <p>
                        2.1 Social Services India Premium membership offers non-tangible products to its users and it is the responsibility of the customers to fully understand the product/s offered before placing an order.<br><br>
                        2.2 Customers cannot request refunds immediately after purchasing a premium membership simply because they did not receive sign-up information, username/password, activation email and/or are unable to access the premium membership page instantly. If any of these problems occur, they can raise a complaint by contacting us at contact@SocailServicesIndia.org and we will promptly respond back with the missing details within 48 hours or less. In many cases, such problems occur due to strong spam filters in the email servers of customers that block our messages and we urge customers to check their records properly before reaching us out.<br><br>
                        2.3 Within 07 days of purchasing the premium membership, customers can request a refund under special conditions such as the premium membership was not suitable, not of satisfactory nature and/or of no interest to them anymore. To request refund within 07 days, please contact us at <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a>. Mention the subject line of the email as “Refund request”<br><br>
                        2.4 Under certain conditions, Social Services India will allow exchanges, substitutions, or if this is not possible a pro-rated refund of a premium subscription already purchased if the customer informs us within 07 days at <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a>. Explaining the reason for the exchange.<br><br>
                        2.5 Social Services India will issue a refund only under the following conditions:<br><br>

                        <ul>
                            <li>Unauthorized payment made from a third party account without the knowledge of the account holder.</li>
                            <li>If a customer duplicates a payment for a single product.</li>
                            <li>If a customer is not satisfied with the premium membership service and places a request for refund within 07 days only after sign up at <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a>.</li>
                        </ul>
                    </p>
                    <span style="font-size: 12pt;"><b>3. Premium Membership Auto-Renewal</b></span><br><br>
                    <p>
                        3.1 Unless otherwise specified, the Social Services India Premium membership is not automatically renewed before the end of membership year.<br><br>
                        3.2 Cancellation of the premium membership can be requested at any time, and for any reason, with at least 7 days notice, for the following membership period.<br><br>
                    </p>
                    <span style="font-size: 12pt;"><b>4. Copyright</b></span><br><br>
                    <p>
                        4.1 Social Services India, located at Elegant Valley, FF 111 “A” Block, 1st Floor, B.E.M.L Layout 3rd Stage, Rajarajeshwari Nagar Bengaluru – 560 098 is the sole owner and copyright holder of Social Services India sites and services. No part of its sites and services maybe copied or stored in a data file in any manner or form, be it electronic, digital, mechanical, manual, photographic or in any other way without the prior written consent of Social Services India.<br><br>
                        4.2 You may not post, modify, distribute, or reproduce in any way any copyrighted material, trademarks, or other proprietary information belonging to others without obtaining the prior written consent of the owner of such proprietary rights.<br><br>
                        4.3 If you are a copyright owner and you believe that your work has been copied in a way that constitutes copyright infringement, or your intellectual property rights have been otherwise violated, you can contact us at <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a> and we will promptly attend and resolve your request.
                    </p>
                    <span style="font-size: 12pt;"><b>5. Bugs, Issues and Third-Party Services</b></span><br><br>
                    <p>
                        5.1 The Premium Services offered through Social Services India websites have been tested over and over under different environments; however it may not function correctly, it may have functional, conceptual and/or documentation bugs and issues. In such cases,Social Services India will try to fix the bugs, issues and errors found and will supply the Premium Member with working updates.<br><br>
                        5.2 Social Services India uses various essential third party software tools and services to deliver Premium Services. These third party software programs are chosen based upon our review of its high quality, reliability and support. However, there may be certain service issues for which Social Services India cannot be held liable for any faults, failures, errors, or issues, including permanent data loss due to third party server issues.
                    </p>
                    <span style="font-size: 12pt;"><b>6. External Links</b></span><br><br>
                    <p>
                        6.1 Social Services India Premium Site contains external links to third party websites. Unless otherwise specified,Social Services India is not affiliated to the owners or webmasters of these websites in any manner and it does not control, advise, endorse or influence its content and/or products.<br><br>
                        6.2 The material provided on the Premium Site is solely for informational purposes only without any warranty. Visitors are advised to use it at their own discretion
                    </p>
                    <span style="font-size: 12pt;"><b>7. Indemnity</b></span><br><br>
                    <p>
                        7.1 You agree to indemnify and hold us, our officers, subsidiaries, affiliates, successors, assigns, directors, officers, agents, service providers, suppliers and employees, harmless from any claim or demand, including reasonable attorney fees and court costs, made by any third party due to or arising out of materials you submit,
                        post or make available through the Social Services India Premium Services, your use of the Services, your violation of the Terms, your breach of any of the representations and warranties in these Terms, or your violation of any rights of another person or entity.
                    </p>
                    <span style="font-size: 12pt;"><b>8. Limitation of Liability</b></span><br><br>
                    <p>
                        8.1 Under no circumstances are we liable for direct, indirect, incidental, special, consequential or exemplary damages (even if we have been advised of the possibility of such damages), resulting from any aspect of your use of the Premium Services, whether the damages arise
                        from use or misuse of the Premium Services and Sites, from inability to use the sites or the services, or the interruption, suspension, modification, alteration, or termination of the Premium Services. Such limitation shall also apply with respect to damages incurred by reason of other services or products received through or advertised in connection with our Premium Services or any links on the Premium Sites, as well as by reason of any information or advice received through or advertised in connection with the sites or the service or any links on the sites. These limitations shall apply to the fullest extent permitted by law. In some jurisdictions, limitations of liability are not permitted and some of the foregoing limitations may not apply to you.
                    </p>
                    <span style="font-size: 12pt;"><b>9. Premium Newsletter and Funding Alerts Subscription</b></span><br><br>
                    <p>
                        9.1 Social Services India Premium Newsletter and Funding Alerts subscription will receive information according to your preferences on Premium Service updates, NGO funding alerts, fellowships, scholarships, conferences and resource guides for various countries on daily/weekly/monthly basis. You will also receive information about <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a> small grants announcement, competitions and call for proposals as and when they are open.<br><br>
                        9.2 You will also receive information about any new paid content and other products that are related to fundraising and NGO capacity development.<br><br>
                        9.3 All information disseminated through our newsletter service will be related to NGOs, NPO’s, NGO fundraising and NGO capacity development.<br><br>
                        9.4 We will not sell your email and/or any personal details to any third party service.<br><br>
                        9.5 You are free to unsubscribe anytime from the newsletter and/or funding alert subscription by choosing “Unsubscribe” link at the bottom of all our email newsletters.
                    </p>
                    <span style="font-size: 12pt;"><b>10. Delivery and Shipping Policy</b></span><br><br>
                    <p>
                        10.1 Premium services at Social Services India are delivered instantly soon after the confirmation of payment is received or verified through payment gateways. Soon after the payment is confirmed, the username/password created by the user during registration gets activated automatically.<br><br>
                        10.2 For payments received through bank transfer, cheque or other means, the premium account shall be activated only after the actual amount is credited into our bank account and a scanned copy of the payment receipt is submitted at <a href="mailto:contact@SocialServicesIndia.org">contact@SocialServicesIndia.org</a>
                    </p>
                </div>
            </div>
        </section>
    @endsection