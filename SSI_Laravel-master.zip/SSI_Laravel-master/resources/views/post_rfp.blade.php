@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post FC grant</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Post FC grant </li>
        </ol>

        @if(session()->has('ssiapp_rec'))
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4>Post RFP </h4>

                    </header> --}}





                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-proposal/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="orgname" class="form-cntrl" id="orgname"
                                            placeholder="Name of  the organisation" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant Title </label>
                                        <input type="text" name="grant_title" class="form-cntrl" id="grant_title"
                                            placeholder="Grant title" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="India" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Total Amount </label>
                                        <input type="text" name="total_amt" class="form-cntrl" id="total_amt"
                                            placeholder="USD 10000" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing date of proposal </label>
                                        <input type="date" name="close_date" class="form-cntrl" id="close_date"
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Applicant Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email" placeholder="abc@example.com" />
                                        <div class="validate"></div>
                                    </div>

                                </div>

                                <div class="form-row">



                                    <div class="form-group col-lg-12">
                                        <label for="name">Description of the proposal </label>
                                        </br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="summernote"
                                            placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Upload PDF Document</label>
                                        </br>
                                        <input type="file" name="document" class="form-cntrl" data-file_types="doc|pdf|text"
                                            accept="application/pdf">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Organisation logo</label>
                                        </br>
                                        <input type="file" name="company_logo" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg">
                                    </div>


                                </div>
                                @isset($html)
                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <h4>Proposal Category</h4>
                                        </div>
                                        {{-- <div class="form-group col-lg-12"> --}}
                                        {!! $html !!}
                                        {{-- </div> --}}
                                        <input type="hidden" id="cates" name="cates" value="" />
                                    </div>
                                @endisset


                                
                                {{-- <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name"> Organisation Achivement </label>

                                        <textarea class="form-cntrl" name="Description" id="Description" placeholder=""
                                            rows="10" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                        <div class="validate"></div>
                                    </div>
                                </div> --}}

                                <div class="form-row">

                                    <div style="display: none;" class="form-group col-lg-6">
                                        <label for="name"> Organisation Achivement</label>
                                        <input type="text" name="organisation_ach" class="form-cntrl"
                                            id="organisation_ach" placeholder="Organisation Achivement" />
                                        <div class="validate"></div>
                                    </div>
                                    <div style="display: none;" class="form-group col-lg-6">
                                        <label for="name"> Organisation PAN No</label>
                                        <input type="text" name="organisation_pan" class="form-cntrl"
                                            id="organisation_pan" placeholder="" />
                                        <div class="validate"></div>
                                    </div>


                                </div>


                                {{-- <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name"> Human Check 2+7=</label>
                                        <input type="text" name="organisation" class="form-cntrl" id=""
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>
                                </div> --}}

                            </div>

                            {{-- <div class="form-row"">
                                <div class="form-group col-lg-12">
                                    <input type="checkbox" id="terms" name="terms" value="">
                                    <label for="vehicle3"> Terms and condition</label><br>
                                </div>
                            </div> --}}
                        </div>
                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12 ml-auto">
                                    <button class="btn btn-primary  btn-register">Submit FC Grant</button>
                                </div>
                            </div>
                    </form>
                </div>



            </section>








        @else

            <div class="row about-container">
                <div class="col-lg-12">

                    <hr style="color:#007bff;border:3px solid;">
                    <p class="card-text"><i>Please login to submit RFP/CFPs.</i> <a
                            href="{{url('/login')}}"
                            class="btn btn-primary">Login</a></p>

                    <p style="margin-top: 30px; font-size: 1rem;">
                        For any further assistance our experts will get in touch with you and take it forward.
                        <br /><br />
                        Please email us at: <b>contact@SocialServicesIndia.com</b> for <b>Queries</b>
                    </p>
                </div>

            </div>
        @endif
    
    </div>
    </section>
    <script>
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>
</main>

@endsection