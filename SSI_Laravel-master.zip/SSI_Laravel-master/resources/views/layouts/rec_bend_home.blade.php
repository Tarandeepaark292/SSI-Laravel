<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="" />
    <meta name="author" content="" />
     <!-- Favicons -->
     <link rel="apple-touch-icon" sizes="180x180" href="{{asset('/img/favicons/apple-touch-icon.png')}}">
     <link rel="icon" type="image/png" sizes="32x32" href="{{asset('/img/favicons/favicon-32x32.png')}}">
     <link rel="icon" type="image/png" sizes="16x16" href="{{asset('/img/favicons/favicon-16x16.png')}}">
     <link rel="manifest" href="{{asset('/img/favicons/site.webmanifest')}}">
    <link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link rel="stylesheet" href="{{asset('css/bend_style.css')}}">

    <title>@yield('title')</title>
    <link href="{{asset('css/summernote-bs4.css')}}" rel="stylesheet">

    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    @include('inc.rec_bend_nav')
    <div id="layoutSidenav">
        @include('inc.rec_bend_sidebar')
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    {{-- <script src="{{asset('js/app.js')}}" defer></script> --}}
    <script src="{{asset('js/scripts.js')}}" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>

    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>

    <script src="{{asset('js/jquery.blockUI.js')}}"></script>
    <script src="{{asset('js/utils.js')}}"></script>
    <script src="{{asset('js/summernote-bs4.js')}}"></script>
        <div id="layoutSidenav_content">
            @yield('content')
           
        </div>
    </div>
    @include('inc.shopping')
</body>
<script>
    $(document).ready(function() {
        $('#summernote').summernote({
            height: 200,
            toolbar: [
              
              ['font', ['bold', 'underline', 'clear']],
             
              ['para', ['ul', 'ol', 'paragraph']],
              
              ['view', ['codeview']]
            ]
        });
      });
    </script>
</html>
