<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>{{ $title ?? "Home | SocialServicesIndia.org | NGO Jobs | CSR Funds" }}</title>
    {{-- <meta content={{ "$metadescription" ?? "India’s only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs."}} name="description"> --}}
    @isset($metadescription)
    <meta content="{!! $metadescription !!}" name="description">
    @else
    <meta content="India’s only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs."}} name="description">
    @endisset

    @isset($metadescription)
    <meta content="{!! $seokeywords !!}" name="keywords">
    @else
    <meta content="social service,socialservice,indian social service,csr funding,fcgrant, fc grant,forbes 30 under 30,social service india,social service in india,social services in india"}} name="keywords">
    @endisset

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!--GOOGLE -->
    @isset($title)
    <meta itemprop="name" content="{!! $title !!}">
    @else
    <meta itemprop="name" content="Home | SocialServicesIndia.org | NGO Jobs | CSR Funds">
    @endisset

    @isset($metadescription)
    <meta itemprop="description" content="{!! $metadescription !!}">
    @else
    <meta itemprop="description" content="India’s only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs.">
    @endisset

    @isset($metaimg)
    <meta itemprop="image" content="{{asset($metaimg)}}">
    @else
    <meta itemprop="image" content="{{asset("/img/SEO/home-page.jpg")}}">
    @endisset
    
    <!--FACEBOOK -->
   
    <meta property="og:url" content="{{url()->current()}}">
   
    <meta property="og:type" content="website">
    @isset($title)
    <meta property="og:title" content="{!! $title !!}">
    @else
    <meta property="og:title" content="Home | SocialServicesIndia.org | NGO Jobs | CSR Funds">
    @endisset
    
    @isset($metadescription)
    <meta property="og:description" content="{!! $metadescription !!}">
    @else
    <meta property="og:description" content="India’s only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs.">
    @endisset

    @isset($metaimg)
    <meta property="og:image" content="{{asset($metaimg)}}">
    @else
    <meta property="og:image" content="{{asset("/img/SEO/home-page.jpg")}}">
    @endisset
    <!--twitter -->
    <meta name="twitter:card" content="summary_large_image">
    @isset($title)
    <meta name="twitter:title" content="{!! $title !!}">
    @else
    <meta name="twitter:title" content="Home | SocialServicesIndia.org | NGO Jobs | CSR Funds">
    @endisset
    @isset($metadescription)
    <meta name="twitter:description" content="{!! $metadescription !!}">
    @else
    <meta name="twitter:description" content="India’s only independent platform for NGO jobs, NGO Job post, CSR Funds for NGO, Grants for NGO, Funding opportunity for NGO, Financial Services for NGOs.">
    @endisset
    @isset($metaimg)
    <meta name="twitter:image" content="{{asset($metaimg)}}">
    @else
    <meta name="twitter:image" content="{{asset("/img/SEO/home-page.jpg")}}">
    @endisset
    
    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{asset('/img/favicons/apple-touch-icon.png')}}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{asset('/img/favicons/favicon-32x32.png')}}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('/img/favicons/favicon-16x16.png')}}">
    <link rel="manifest" href="{{asset('/img/favicons/site.webmanifest')}}">

    @include('inc.style')

    <!-- =======================================================
  * Template Name: NewBiz - v2.0.0
  * Template URL: https://bootstrapmade.com/newbiz-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
    @include('inc.header')

    <main id="main">
        @yield('content')
    </main>

    @include('inc.footer')
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
    @include('inc.script')
    @include('inc.shopping')
    @yield('custom_script')
</body>

</html>