@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Edit SEO</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active"><span>Update SEO</span></li>
            </ol>

            <!-- {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post Jobseeker 
            </header> -->
            <!-- </div> --}} -->

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/updateseo')}}/{{$jp_obj['seo_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Seo Page Name </label>
                                        <span type="text" name="name" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" style="width:100%;"
                                            value="" >{{$jp_obj['seo_page_name']}}</span>
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Seo Link </label>
                                        <span type="text" name="link" class="form-cntrl" id="link"
                                            placeholder="Grant title" style="width:100%;"
                                            value="" >{{$jp_obj['seo_link']}}</span>
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name"> Seo Title</label>
                                        <input type="text" name="seotitle"  class="form-cntrl" id="desc" placeholder="" value="{{$jp_obj['seo_data']['seotitle'] ?? ''}}" required>
                                        <div class="validate"></div>
                                    </div>
                                   
                                </div>    
                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <label for="name"> Seo Image</label>
                                        <input type="text" name="seoimg"  class="form-cntrl" id="desc" placeholder="" value="{{$jp_obj['seo_data']['seoimg'] ?? ''}}" required>
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-8">
                                        <label for="name"> Seo Image (Preview)</label>
                                        @isset($jp_obj['seo_data']['seoimg'])
                                        <img style="width: 100%;" src="{{asset($jp_obj['seo_data']['seoimg'])}}" />
                                        @endisset
                                    </div>
                                   
                                </div>    
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Seo Keyword</label>
                                        <textarea type="text" name="seokeywords" rows="5" col="10" class="form-cntrl" id="desc" placeholder=""
                                        style="height: auto;resize: none;" required >{{$jp_obj['seo_data']['seokeywords'] ?? ''}}</textarea>
                                        
                                        <div class="validate"></div>
                                    </div>
                                   
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Seo Description</label>
                                        <textarea type="text" name="seodesc" rows="10" col="20" class="form-cntrl" id="seodesc" placeholder=""
                                        style="height: auto;resize: none;" required >{{$jp_obj['seo_data']['seodesc'] ?? ''}}</textarea>

                                        <div class="validate"></div>
                                    </div>
                                   
                                </div>


                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:60%"> Update Data
                                        </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
        <!-- </div> -->
    </section>



</main>

@endsection
