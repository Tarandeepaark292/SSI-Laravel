@extends('layouts.js_bend_home')
@section('content')

<main>
    <form action="{{url('/js_job_list/update')}}/{{$joblist['js_id']}}" method="Post">
        @csrf

<div class="row">
<!-- <div class="col-md-12"> -->
        <div class="container">
            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-table mr-1"></i><b>Jobseeker Edit Panel</b></div>
                <div class="form-row">
                    <div class="form-group col-lg-6 px-3">
                        <label for="name">Your Title</label>
                        <input type="text" name="title" class="form-cntrl" id="title" style="width:100%; "
                             placeholder="Your Title" value="{{$joblist['js_p_title']}}" /> 
                        <div class="validate"></div>
                    </div>

                    <div class="form-group col-lg-6 px-3">
                        <label for="name">Your Email</label>
                        <input type="text" class="form-cntrl" name="email" id="email" style="width:100%;"
                            placeholder="Your Email" value="{{$joblist['js_email']}}" />
                        <div class="validate"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-lg-6 px-3">
                        <label for="name">Your Name</label>
                        <input type="text" name="name" class="form-cntrl" id="name" style="width:100%;"
                             placeholder="Your Name" value="{{$joblist['js_name']}}" /> 
                        <div class="validate"></div>
                    </div>

                    <div class="form-group col-lg-6 px-3">
                        <label for="name">Create Date</label>
                        <input type="text" name="date" class="form-cntrl" id="date" style="width:100%;" 
                            placeholder="Create Date" value="{{$joblist['js_createdate']}}" />
                        <div class="validate"></div>
                    </div>
                </div>

                <div class="row"  >
                    <div class="form-group col-lg-6 px-3 ">
                        <label for="name">Area Expertise</label>
                        <!-- <input type="text" name="area" class="form-cntrl" id="area" style="width:100%;" 
                             placeholder="Area Expertise" value="{{$joblist['js_area_expertise']}}" /> -->
                             <select class="form-cntrl" name="area" style="width:100%;">
                                    <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                                    <option>Administration, HR, Management, Accounting/Finance Executive</option>
                                    <option>Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                    <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                    <option>Capacity Building, Training, Advocacy</option>
                                    <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                    <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                    <option>Disaster, Aid, Emergencies, Relief</option>
                                    <option>Environment, Climate, Energy, Water, Sanitation</option>
                                    <option>Fund-raising Business Development, Grants Writer</option>
                                    <option>Field Officers, Field Associates</option>
                                    <option>Government / Governance, Reforms, Corruption</option>
                                    <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                    <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                    <option>Infrastructure, Technology, Engineering, Science</option>
                                    <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                    <option>Private Sector, Corporate Social Responsibility</option>
                                    <option>Project Associate, Project leaders, Project Assistant</option>
                                    <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                    <option>Research Analysts, Research Associate, Research Assistant</option>
                                    <option>Social, Gender, Education, Youth, Child</option>
                                    <option>Trade, Finance, Economics, Cooperation, Global</option>
                                    <option>Technology Associate, Technical Assistant, </option>
                                    <option>Teachers, Teachers Educators, Principal</option>
                                </select>

                        <div class="validate"></div>
                    </div>
                    
                    <div class="form-group col-lg-6 px-3">
                        <label for="name">Location</label>
                        <input type="text" name="location" class="form-cntrl" id="location" style="width:100%;" 
                            placeholder="Create Date" value="{{$joblist['js_loc']}}" />
                        <div class="validate"></div>
                    </div>
                <!-- </div> -->


                <div class="row" style="margin-left:150px;">
                    <div class="col-md-4">
                        <div class="form-group  px-3">
                            <label for="name">Video</label>
                            <input type="text" name="video" class="form-cntrl" id="video" style="width:100%;"
                                 placeholder="Video" value="{{$joblist['js_vids']}}" /> 
                            <div class="validate"></div>
                        </div>
                        </div>

                        <div class="col-md-4">
                        <div class="form-group px-3">
                            <label for="name">Skills</label>
                            <td> <input type="text" name="skill" class="form-cntrl" id="skill" style="width:100%;"
                                     placeholder="Skills" value="{{$joblist['js_skills']}}" /> 
                                <div class="validate">
                                
                               
                        </div>
                        <!-- </div> -->
                        
                    </div>
                    <button type="submit" name="Submit" class="btn btn-primary"
                            style="width:50%; margin-left:50px;">Update Data</button></div>
                    
                </div>
               
               
                   
                
                </div>
                
                    
                       
            </div>
            </div>

            <!-- </div> -->
   </div>

                   </form>
                   </main>


        @endsection
