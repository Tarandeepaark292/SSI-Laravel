@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Organisation Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Services</li>
        </ol>

        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/jobs.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Job</h5>
                            <h6 style="text-align: center;">Rs 999/-</h6>
                            <a href="#" onclick="addTocart(6)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/CSR.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post CSR</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(1)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">

                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/fellowship.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Fellowship</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(3)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/grants.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Grant</h5>
                            <h6 style="text-align: center;">Rs 5499/-</h6>
                            <a href="#" onclick="addTocart(2)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/scholarships.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Scholarship</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(13)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/awards.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Award</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(12)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">

                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/addmission.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Admission</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(18)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/online course.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Online Course</h5>
                            <h6 style="text-align: center;">Rs 5499/-</h6>
                            <a href="#" onclick="addTocart(17)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/publication.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Publication</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(16)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/call for paper.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Call For Paper</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(15)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/Events.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post Event</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(4)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">

                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/RFP.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">Post RFP</h5>
                            <h6 style="text-align: center;">Rs 2499/-</h6>
                            <a href="#" onclick="addTocart(5)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        

        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/resume.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">35 Resumes</h5>
                            <h6 style="text-align: center;">Rs 5000/-</h6>
                            <a href="#" onclick="addTocart(8)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/resume.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">50 Resumes</h5>
                            <h6 style="text-align: center;">Rs 6000/-</h6>
                            <a href="#" onclick="addTocart(9)" style="display: block;text-align: center;">Add To
                                Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <img src="{{asset('/img/icons/resume.png')}}" style="width: 50%;" />
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; padding-top:1rem">85 Resumes</h5>
                            <h6 style="text-align: center;">Rs 10000/-</h6>
                            <a href="#" onclick="#" onclick="addTocart(10)"
                                style="display: block;text-align: center;">Add To Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</main>

@endsection
