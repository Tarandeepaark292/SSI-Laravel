@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Recruiters </span> </h3>
                </header>
                <div class="row">
                    <div class="col-12">

                        <p style=""><strong>Post your "Job Ad" <span style="color: #0000ff;">@ Rs 999/- 
                            @if(session()->has('ssiapp_rec'))
                            <a href="#" onclick="addTocart(6)">(Add To Cart)</a>
                            @endif
                        </span> only</strong><br />
                            Information about Job Posting options for Recruiters. Our reach over 10,00,000 Indian Development Professional. Please fill below application to post your job on the site. One time registration is required for posting jobs.<br>(OR)
                            <br />
                            <strong>If you want us to post your “Job Ad” please email us at – <span style="color: #0000ff;" a href="mailto:contact@SocialServicesIndia.com" target="_blank" rel="noopener">contact@SocialServicesIndia.com</a></span>Please mention the "Position" in the subject line of your email.</strong><br>(AND)<br />
                            <strong>
                                Organisations less than 20 lakh turnover can post “Job Ad” for free. Send us your “Job Ad” with subject line “OT20” to <span style="color: #0000ff;" href="mailto:Contact@SocialServicesIndia.com" target="_blank" rel="noopener">contact@SocialServicesIndia.com.</span></span></strong></p></br>

                    </div>
                </div>

                @if(session()->has('ssiapp_rec'))
                
                <div class="row" style="text-align: center;">

                </div>
                <form action="{{url('/recruiters/submit')}}" method="post"  enctype="multipart/form-data">

                @csrf
                <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                        <div class="form-row">

                            <div class="form-group col-lg-12">
                                <label for="name">Your email </label>
                                <input type="text" name="email" class="form-cntrl" id="email" placeholder="you@yourdomain.com" />
                                <div class="validate"></div>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name"> job title</label>
                                <input type="text" name="jobtitle" class="form-cntrl" id="jobtitle" placeholder="e.g. United Nations India looking for “Senior Consultants""  />
                                <div class=" validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Location </label>
                            <input type="text" name="location" class="form-cntrl" id="location" placeholder="e.g.Bengaluru" />
                            <small class="description">Leave this blank if the location is not important</small>
                            <div class="validate"></div>
                        </div>
                    </div>

                    <label>job type</label>
                    <div class="field required-field">
                        <select name="job_type" id="job_type" class="form-cntrl" style="width:100%;">
                            <option class="level-0" value="3740">Contribution</option>
                            <option class="level-0" value="42">Freelance</option>
                            <option class="level-0" value="39" selected="selected">Full Time</option>
                            <option class="level-0" value="3649">Grant</option>
                            <option class="level-0" value="43">Internship</option>
                            <option class="level-0" value="40">Part Time</option>
                            <option class="level-0" value="41">Temporary</option>
                            <option class="level-0" value="3681">Work from Home</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label for="name" >Area of Expertise</label>
                            <select name="area" id="area" class="form-cntrl">
                                <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                                <option value="admin">Administration, HR, Management, Accounting/Finance Executive</option>
                                <option value="sjkd">Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                <option>Capacity Building, Training, Advocacy</option>
                                <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                <option>Disaster, Aid, Emergencies, Relief</option>
                                <option>Environment, Climate, Energy, Water, Sanitation</option>
                                <option>Fund-raising Business Development, Grants Writer</option>
                                <option>Field Officers, Field Associates</option>
                                <option>Government / Governance, Reforms, Corruption</option>
                                <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                <option>Infrastructure, Technology, Engineering, Science</option>
                                <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                <option>Private Sector, Corporate Social Responsibility</option>
                                <option>Project Associate, Project leaders, Project Assistant</option>
                                <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                <option>Research Analysts, Research Associate, Research Assistant</option>
                                <option>Social, Gender, Education, Youth, Child</option>
                                <option>Trade, Finance, Economics, Cooperation, Global</option>
                                <option>Technology Associate, Technical Assistant, </option>
                                <option>Teachers, Teachers Educators, Principal</option>
                            </select>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:1rem;">
                        <div class="form-group col-lg-12">
                            <label for="name">Description</label>
                            <textarea class="form-cntrl" name="description" id="description" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Application email </label>
                            <input type="text" name="applicationemail" class="form-cntrl" id="applicationemail" placeholder="application email" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">closing dates </label> <span> (optional)</span>
                            
                            
                            <input type="text" name="closingdate" class="form-cntrl" id="closingdate" placeholder="" />
                            <small class="description">Deadline for new applicants</small>
                            <div class="validate"></div>
                        </div>

                    </div>
                    <label for="job_jd_file">Job description file (pdf) <small>(optional)</small></label>
                    <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text" accept="application/pdf" data-file_types="pdf" name="files" id="files" placeholder="">

                
            
            <div class="row">

                <div class="col-12" style="margin-top: 2rem;">
                    <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">ORGANIZATION</span> DETAILS</h2>
                </div>
                <div class="col-12" style="margin-top: 2rem;">
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Organization Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="applications" placeholder="Organization Name" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">website </label> <span>(optional)</span>
                            <input type="text" name="website" class="form-cntrl" id="website" placeholder="http://" />

                            <div class="validate"></div>
                        </div>

                    </div>



                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Video<span>(optional)</span> </label>
                            <input type="text" name="video" class="form-cntrl" id="video" placeholder="A link to a Video about your organization" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Twitter username<span>(optional)</span> </label>
                            <input type="text" name="twitterusername" class="form-cntrl" id="twitterusername" placeholder="@yourCompany" />

                            <div class="validate"></div>
                        </div>



                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="company_logo">Logo <small>(optional)</small></label><br>
                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="logo" id="_logo" placeholder="">
                        </div>
                        <div class="col-lg-6">
                            <fieldset class="fieldset-recaptcha" style="padding:10px;">
                                <label for="recaptcha">Are you human? Making sure you are not a bot!</label>
                                <div class="field required-field">
                                    <div class="g-recaptcha" data-sitekey="6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7">
                                        <div style="width: 304px; height: 78px;">
                                            <div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7&amp;co=aHR0cHM6Ly9zb2NpYWxzZXJ2aWNlc2luZGlhLmNvbTo0NDM.&amp;hl=en&amp;v=r8WWNwsCvXtk22_oRSVCCZx9&amp;size=normal&amp;cb=y1m1p94rndam" width="304" height="78" role="presentation" name="a-g2zv31jg0np" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="row" >
                    <div class="col-lg-12 ml-auto">
                        <button class="btn btn-primary" style="width:40%">Submit</button>
                    </div>
                </div>
                </div>

                
                @else

                <div class="row">
                    <div class="col-12">
                        <p>Have an account? <a class="button" href="#" style="color:#0000ff;">Sign in</a> If you don't have an account you can create one below by entering your email address/username. Your account details will be confirmed via email.</p>
                    </div>
                </div>

                <div class="row" style="text-align: center;">

                </div>
                <!-- <form action="{{url('recruiters/submit')}}" method="post"  enctype="multipart/form-data"> -->

                @csrf
                <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                        <div class="form-row">

                            <div class="form-group col-lg-12">
                                <label for="name">Your email </label>
                                <input type="text" name="email" class="form-cntrl" id="email" placeholder="you@yourdomain.com" />
                                <div class="validate"></div>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name"> job title</label>
                                <input type="text" name="jobtitle" class="form-cntrl" id="jobtitle" placeholder="e.g. United Nations India looking for “Senior Consultants""  />
                                <div class=" validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Location </label>
                            <input type="text" name="location" class="form-cntrl" id="location" placeholder="e.g.Bengaluru" />
                            <small class="description">Leave this blank if the location is not important</small>
                            <div class="validate"></div>
                        </div>
                    </div>

                    <label>job type</label>
                    <div class="field required-field">
                        <select name="job_type" id="job_type" class="form-cntrl" style="width:100%;">
                            <option class="level-0" value="3740">Contribution</option>
                            <option class="level-0" value="42">Freelance</option>
                            <option class="level-0" value="39" selected="selected">Full Time</option>
                            <option class="level-0" value="3649">Grant</option>
                            <option class="level-0" value="43">Internship</option>
                            <option class="level-0" value="40">Part Time</option>
                            <option class="level-0" value="41">Temporary</option>
                            <option class="level-0" value="3681">Work from Home</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label for="name" >Area of Expertise</label>
                            <select name="area" id="area" class="form-cntrl">
                                <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                                <option value="admin">Administration, HR, Management, Accounting/Finance Executive</option>
                                <option value="sjkd">Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                <option>Capacity Building, Training, Advocacy</option>
                                <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                <option>Disaster, Aid, Emergencies, Relief</option>
                                <option>Environment, Climate, Energy, Water, Sanitation</option>
                                <option>Fund-raising Business Development, Grants Writer</option>
                                <option>Field Officers, Field Associates</option>
                                <option>Government / Governance, Reforms, Corruption</option>
                                <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                <option>Infrastructure, Technology, Engineering, Science</option>
                                <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                <option>Private Sector, Corporate Social Responsibility</option>
                                <option>Project Associate, Project leaders, Project Assistant</option>
                                <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                <option>Research Analysts, Research Associate, Research Assistant</option>
                                <option>Social, Gender, Education, Youth, Child</option>
                                <option>Trade, Finance, Economics, Cooperation, Global</option>
                                <option>Technology Associate, Technical Assistant, </option>
                                <option>Teachers, Teachers Educators, Principal</option>
                            </select>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:1rem;">
                        <div class="form-group col-lg-12">
                            <label for="name">Description</label>
                            <textarea class="form-cntrl" name="description" id="description" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Application email </label>
                            <input type="text" name="applicationemail" class="form-cntrl" id="applicationemail" placeholder="application email" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">closing dates </label> <span> (optional)</span>
                           
                           
                            <input type="text" name="closingdate" class="form-cntrl" id="closingdate" placeholder="" />
                            <small class="description">Deadline for new applicants</small>
                            <div class="validate"></div>
                        </div>

                    </div>
                    <label for="job_jd_file">Job description file (pdf) <small>(optional)</small></label>
                    <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text" accept="application/pdf" data-file_types="pdf" name="files" id="files" placeholder="">

                </div>
            
            <div class="row">

                <div class="col-12" style="margin-top: 2rem;">
                    <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">ORGANIZATION</span> DETAILS</h2>
                </div>
                <div class="col-12" style="margin-top: 2rem;">
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Organization Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="applications" placeholder="Organization Name" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">website </label> <span>(optional)</span>
                            <input type="text" name="website" class="form-cntrl" id="website" placeholder="http://" />

                            <div class="validate"></div>
                        </div>

                    </div>



                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Video<span>(optional)</span> </label>
                            <input type="text" name="video" class="form-cntrl" id="video" placeholder="A link to a Video about your organization" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Twitter username<span>(optional)</span> </label>
                            <input type="text" name="twitterusername" class="form-cntrl" id="twitterusername" placeholder="@yourCompany" />

                            <div class="validate"></div>
                        </div>



                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="company_logo">Logo <small>(optional)</small></label><br>
                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="logo" id="_logo" placeholder="">
                        </div>
                        <div class="col-lg-6">
                            <fieldset class="fieldset-recaptcha" style="padding:10px;">
                                <label for="recaptcha">Are you human? Making sure you are not a bot!</label>
                                <div class="field required-field">
                                    <div class="g-recaptcha" data-sitekey="6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7">
                                        <div style="width: 304px; height: 78px;">
                                            <div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7&amp;co=aHR0cHM6Ly9zb2NpYWxzZXJ2aWNlc2luZGlhLmNvbTo0NDM.&amp;hl=en&amp;v=r8WWNwsCvXtk22_oRSVCCZx9&amp;size=normal&amp;cb=y1m1p94rndam" width="304" height="78" role="presentation" name="a-g2zv31jg0np" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                    
                </div>
            </div>
           
                                            
                @endif
                </div>
                </form>

        </section>
        @endsection
