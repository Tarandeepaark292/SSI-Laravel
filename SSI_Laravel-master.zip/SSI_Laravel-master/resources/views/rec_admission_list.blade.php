@extends('layouts.rec_bend_home')
@section('content')


<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organization Panel</li>
            <li class="breadcrumb-item active">Admission List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Admission</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Name Of the Institution</th>
                                <th>Email</th></th>
                                <th>Cost Details</th>
                                <th>Thematic Area</th>
                                <th>Course State</th>
                               
                            </tr>
                        </thead>
                        @isset($adnsearch)
                        <!-- error_log($adnsearch); -->
                            <tfoot>
                                <tr>
                                <th>Title</th>
                                <th>Name Of the Institution</th>
                                <th>Email</th></th>
                                <th>Cost Details</th>
                                <th>Thematic Area</th>
                                <th>Course State</th>
                                
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($adnsearch as $noti)
                               
                                    <tr>
                                        <td>{{ $noti['adn_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['adn_inst_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['adn_email'] }}</td>
                                            <td>{{ $noti['adn_cost_details'] }}</td>
                                            <td>{{ $noti['adn_area'] }}</td>
                                        <td>{{ $noti['adn_state'] }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>

<script>
    $('#notidataTable').DataTable();
</script> 

@endsection