@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">FCRA List</li>
        </ol>
        
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>FCRA List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>FCRA Title</th>
                                <th>Email</th>
                                
                        
                                <th></th>
                            </tr>
                        </thead>
                        @isset($felllist)
                            <tfoot>
                                <tr>
                                    <th>FCRA Title</th>
                                    <th>Email</th>
                                    
                                   
                                    <th></th>
                                   
                                   
                                   
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($felllist as $noti)
                                    <tr>
                                        <td>{{ $noti['f_f_org_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['f_f_email'] }}</td>
                                        
                                        
                                      
                                     
                                        <td>
                                            
                                            <a class="btn btn-outline-secondary" href="{{url('/admin/fcradetail/')}}/{{$noti['f_f_id']}}">EDIT</a>
                                        </td>
                                        
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
{{-- <script>
    $('#notidataTable').DataTable();
    function enableFell(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxFELLenable.post') }}",
                data:{fell_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in enabling CSR');
                        console.log(data.error);
                    }
               }
            });
    }
    
    function disableFell(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxFELLdisable.post') }}",
                data:{fell_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in disabling Event');
                        console.log(data.error);
                    }
                }
            });
    }
    </script> --}}
@endsection
