@extends('layouts.rec_bend_home')
@section('content')


<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Recruiter Panel</li>
            <li class="breadcrumb-item active">Call for Paper List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Call for Paper</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Name Of the Organisation</th>
                                <th>Email</th></th>
                                <th>Location</th>
                                <th>Type</th>
                                <th>Website URL</th>
                               
                                
                            </tr>
                        </thead>
                        @isset($callsearch)
                        <!-- error_log($adnsearch); -->
                            <tfoot>
                                <tr>
                                <th>Title</th>
                                <th>Name Of the Organisation</th>
                                <th>Email</th></th>
                                <th>Location</th>
                                <th>Type</th>
                                <th>Website URL</th>
                                
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($callsearch as $noti)
                               
                                    <tr>
                                        <td>{{ $noti['paper_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_o_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['paper_email'] }}</td>
                                            <td>{{ $noti['paper_loc'] }}</td>
                                            <td>{{ $noti['paper_type'] }}</td>
                                        <td>{{ $noti['paper_url'] }}</td>
                                        
                                      
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();

</script>





@endsection