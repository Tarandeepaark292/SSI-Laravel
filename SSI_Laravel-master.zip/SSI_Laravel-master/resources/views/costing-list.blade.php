@extends('layouts.home')
@section('content')

        <!-- ======= About Section ======= -->
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}

            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Costing</span> <span class="titleheading">List</span> </h3>
                </header>
                <div>
                    <div class="col-lg-12">
                        <h6 style="font-weight:600;">Tentative dates followed by Social Services India team for all statutory obligations for effective services.
                        </h6>
                    </div>
                </div>
                <div class="row about-container">
                    <div class="col-lg-12 background wow fadeInUp">
                        <table class="table-responsive-md">
                            <caption>
                                <hr style="color:#007bff;border:3px solid;">
                                * Includes cost of Audit, scrutiny of books of accounts, filing of organisation Income tax.
                                <br /><br />
                                ** We request you to kindly send us an e-mail with all your requirements to <b>Team@SocialServicesIndia.org</b> with the organisation contact information we will send you the quotes and take it forward.
                            </caption>
                            <thead>
                                <tr>
                                    <th scope="col">Sl.No</th>
                                    <th scope="col">Particulars – 1</th>
                                    <th scope="col">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        1
                                    </td>
                                    <td>
                                        *Statutory Audit<br />
                                        Turnover
                                        < 1 crore<br />
                                        Turnover > 1 crore to
                                        < 3 crore<br />
                                        Turnover > 3 crore to
                                        < 8 crore<br />
                                        Turnover > 8 crore to
                                        < 12 crore<br />
                                    </td>
                                    <td>
                                        <br />
                                        40,000<br />
                                        60,000<br />
                                        75,000<br />
                                        90,000<br />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        2
                                    </td>
                                    <td>
                                        Other Audit:<br />
                                        Internal Audit<br />
                                        Special Audit for CSR funding<br />
                                        Special Audit for grants released to NGO’s by donor agency.<br />
                                        Management Audit<br />
                                        Financial accounting<br />
                                        Systems studies and accounting manuals<br />
                                        Training programs on audit and accounting matters<br />
                                        Income tax scrutiny or any other Audit<br />
                                    </td>
                                    <td>
                                        ** See note Below
                                    </td>
                                </tr>


                            </tbody>

                        </table>
                    </div>
                </div>


        </section><!-- End About Section -->

@endsection