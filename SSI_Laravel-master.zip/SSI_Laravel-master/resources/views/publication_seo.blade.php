@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    <div class="intro-img" style="">
        {{-- <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>

    <div class="container" style="padding: 14px;margin-bottom: 5rem;margin-top:5rem; box-shadow: 1px 4px 4px 4px #e9f3fb;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width:100%;" src="{{$jp_obj['pub_upload_image']}}" alt="" />
            </div>
            <div class="col-md-9">
                
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$jp_obj['pub_title']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">Author : {{$jp_obj['pub_name']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">Focus Area : {{$jp_obj['pub_focusarea']}}</span>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-12">
                        {{-- <h5 style="font-weight: bold"><span class="subDetails">Application Email:</span> {{$jp_obj['jp_app_email']}}</h5> --}}
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">Publication Type: {{$jp_obj['pub_type']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <h5 style="font-weight: bold"><span class="subDetails">Application Email:</span> {{$jp_obj['jp_app_email']}}</h5> --}}
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">Publication Date: {{$jp_obj['pub_year']}}</span>
                    </div>
                </div>
                
            </div>
           
        </div>

        <div class="row" >
            <div class="col-md-8 ml-4" style="font-size: 14px;">
                <h3><b>Website</b></h3>
                <span style="line-height: 1.5rem;overflow-wrap: break-word;font-size: 14px;">
                   <a href="{{$jp_obj['pub_website']}}" target="_blank">{{$jp_obj['pub_website']}}</a>
                </span>
            </div>
            {{-- <div class="col-md-4" style="border-right: 5px solid #e9f3fb;
            border-left: 5px solid #e9f3fb;">
                <h3><b>Publication Type</b></h3>
                <span style="line-height: 1.5rem;font-size: 14px;">
                    {{$jp_obj['pub_type']}}
                </span>
            </div>
            <div class="col-md-4">
                <h3><b>Publication No</b></h3>
                <span style="line-height: 1.5rem;font-size: 14px;">
                    {{$jp_obj['pub_no']}}
                </span>
            </div> --}}
        </div>

        <div class="row" style="margin-top:14px;">
            <div class="col-md-11 ml-4" style="font-size: 14px;">
                <h3><b>Description</b></h3>
                <p style="line-height: 1.5rem;text-align: justify;">
                    {!!htmlspecialchars_decode($jp_obj['pub_desc'])!!}
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 ml-4">
                @if (isset($jp_obj['pub_upload_word']) && $jp_obj['pub_upload_word'] != "")
                <h3><a target="_blank" class="btn btn-primary" href="{{url($jp_obj['pub_upload_word'])}}">Open Full Report <i class="fa fa-chevron-right"></i></a></h3>
                {{-- <h4 style="font-size:15px;"><a target="_blank" href="{{url($jp_obj['jp_files'])}}">Download File <i class="fa fa-download"></i></a></h4> --}}
                @endif
            </div>
        </div>

    </div>

</section>

@endsection