@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Online Course</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Post Online Course</li>
            </ol>

            {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post CSR Ad
            </header>
        </div> --}}
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-onlinecourse/submit')}}" method="post" accept-charset="utf-8" onsubmit="validate(event);"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Choose Organization </label>
                                        <select class="form-control" name="org_id" id="org_id" required="required">
                                            <option value="-1">N/A</option>
                                            @foreach ($organizationlist as $organization )
                                                <option value="{{$organization['r_id']}}">{{$organization['r_org_name']}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Course Title </label>
                                        <input type="text" name="course" class="form-cntrl" id="" placeholder=""
                                            style="" maxlength="300" />
                                        <div class="validate"></div>
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label>Name Of The Institution </label>
                                        <br>
                                        <input type="text" name="name" class="form-cntrl" id="" placeholder=""
                                            style="" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                {{-- </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By </label>
                                        <input type="date" name="apply" class="form-cntrl" id="" placeholder=""
                                            style="" />


                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6 mt-2">
                                        <label for="name"> </label>
                                        <select name="category" class="form-cntrl">
                                            <option value="free">Free</option>
                                            <option value="paid">Paid</option>
                                        </select>
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">


                                        <label for="name">Thematic Area</label>
                                        <select name="area" class="form-cntrl">

                                            <option value="Agriculture,food and nutrition">Agriculture,food and
                                                nutrition</option>
                                            <option value="CSR and Sustainability">CSR and Sustainability</option>
                                            <option value="Community Development">Community Development</option>
                                            <option value="Disaster Management">Disaster Management</option>
                                            <option value="Education/ Skill Development">Education/ Skill Development
                                            </option>
                                            <option value="Energy, Environment and Climate Change">Energy, Environment
                                                and Climate Change</option>
                                            <option value="Microfinance">Microfinance</option>
                                            <option value="Healthcare">Healthcare</option>
                                            <option value="Human Rights"> Human Rights</option>
                                            <option value="Livelihoods">Livelihoods</option>
                                            <option value="Social Entrepreneurship">Social Entrepreneurship</option>
                                            <option value="Social Change">Social Change</option>
                                            <option value="Water and Sanitation">Water and Sanitation</option>
                                            <option value="Waste and Recycling"> Waste and Recycling</option>
                                            <option value="Gender studies">Gender studies</option>
                                            <option value="Cross-sectoral/Others">Cross-sectoral/Others</option>
                                            <option value="Disability or specially-abled related">Disability or
                                                specially-abled related</option>
                                            <option value="Communication/IEC/BCC">Communication/IEC/BCC</option>
                                            <option value="Public Policy">Public Policy</option>
                                            <option value="Technology (IT/MIS/GIS)">Technology (IT/MIS/GIS)</option>
                                            <option value="Urban Policy">Urban Policy</option>
                                            <option value="Employability">Employability</option>
                                            <option value="Women Empowerment">Women Empowerment</option>
                                            <option value="Rural Management">Rural Management</option>


                                        </select>

                                        <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Website URL</label><br>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder="Website"
                                            style="width:100%;" />

                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Description</label>
                                        {{-- <input type="text" name="display" class="form-cntrl" id="display" placeholder="" style="width:100%;"  /> --}}
                                        <textarea class="form-cntrl" id="summernote" name="display" rows="10"
                                            style="height: auto;resize: none;">
                                        </textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Application Email</label><br>
                                        <input type="email" name="email" class="form-cntrl" id="email" placeholder="Enter valid email id to receive application"
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Location</label><br>
                                        <input type="text" name="location" class="form-cntrl" id="" placeholder="India"
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Academic Year</label><br>
                                        <input type="text" name="year" class="form-cntrl" id="year" placeholder="2021-22"
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl" name="logo" id="logo"
                                            data-file_types="doc|pdf|text" style="width:100%;"
                                            accept="application/msword" id="" placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                        <input type="file" class="form-cntrl" name="pdf" id="pdf"
                                            data-file_types="doc|pdf|text" style="width:100%;" accept="pdf" id=""
                                            placeholder="Add Media">

                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label>Media Url</label>
                                        <input type="text" name="media" class="form-cntrl" id="" placeholder="Youtube link or Social Media Link"
                                            style="width:100%;" />


                                    </div>

                                </div>

                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                    <label for="vehicle3">I agree Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%"> Submit
                                        </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
    </section>
    <script>
        function validate(event){
            var sel = $('#org_id').val();
            if(sel === "-1"){
                alert("Please Select Organization");
                event.preventDefault();
            }
        }
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>
</main>

@endsection
