@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Post NGO Directory</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Post NGO Directory</li>
        </ol>
        <div class="row">
            <div class="col-12">

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">


            </div>
        </div>
        <form action="{{url('/admin/post-ngodirectory/submit')}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;background:#f0f2f4;padding: 1rem;">

                    <div class="form-row">



                        <div class="form-group col">
                            <label for="name">Organisation Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="org_name" placeholder="Organization name"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                    </div>


                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Website</label>
                            <input type="text" name="Website" class="form-cntrl" id=""
                                placeholder="Website" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-6">
                            <label for="name">Chief functionality</label>
                            <input type="text" name="cfunctionality" class="form-cntrl" id=""
                                placeholder="Chief functionality" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>

                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-lg-4">
                            <label for="name">NGO Type</label>
                            <select name="ngo_type" class="form-cntrl">
                                <option value="trust">Trust</option>
                                <option value="Registered Societies">Registered Societies</option>
                                <option value="Section 8 or 25 company registration">Section 8 or 25 company registration</option>
                            </select>
                            {{-- <input type="text" name="ngo_type" class="form-cntrl" id=""
                                placeholder="NGO Type" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required /> --}}
                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-4">
                            <label for="name">FCRA Avaliable</label>
                            <select name="fcra_avaliable" class="form-cntrl">
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                            {{-- <input type="text" name="stateReg" class="form-cntrl" id=""
                                placeholder="FCRA Avaliable" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required /> --}}
                            <div class="validate"></div>

                        </div>
                        <div class="form-group col-lg-4">
                            <label for="name">Registeration Number</label>
                            <input type="text" name="regNo" class="form-cntrl" id=""
                                placeholder="Registeration Number" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>

                        </div>

                    </div>

                    <div class="form-row">
                        
                        <div class="form-group col-lg-6">
                            <label for="name">Date of Registeration</label>
                            <input type="date" name="dateReg" class="form-cntrl" id=""
                                placeholder="Date of Registeration" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>

                        </div>

                        <div class="form-group col-lg-6">
                            <label for="name">State of Registeration</label>
                            <input type="text" name="stateReg" class="form-cntrl" id=""
                                placeholder="State of Registeration" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>

                        </div>
                    </div>



                    @isset($html)
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <h4>Focus Area</h4>
                        </div>
                        
                        {!! $html !!}
                        
                        <input type="hidden" id="cates" name="cates" value="" />
                    </div>
                    @endisset

                    <div class="form-row">
                        
                        <div class="form-group col-lg-12">
                            <label for="name">Address</label>
                            <textarea id="" class="form-cntrl" name="address" rows="5"
                            style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-3">
                            <label for="name">Country</label>
                            <input type="text" name="country" class="form-cntrl" id="" placeholder="Country"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-3">
                            <label for="name">City</label>
                            <input type="text" name="city" class="form-cntrl" id="" placeholder="City"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-3">
                            <label for="name">Email</label>
                            <input type="text" name="Email" class="form-cntrl" id="" placeholder="Email"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-3">
                            <label for="name">Contact</label>
                            <input type="text" name="contact" class="form-cntrl" id="" placeholder="Contact Number"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>


                    </div>





                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12">

                            <button class="btn btn-primary" style="width:40%">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            function onchkclick(){
                $('#cates').val('');
                chkeles = $('.proposal_chk');
                chkeles.each((index,value)=>{
                    if($(value).prop('checked') == true){
                        if($('#cates').val() === ''){
                            $('#cates').val( $(value).val());
                        }else{
                            $('#cates').val( $('#cates').val() + ',' + $(value).val());
                        }
                        
                    }
                });
                console.log($('#cates').val());
            }
        </script>
</main>
@endsection