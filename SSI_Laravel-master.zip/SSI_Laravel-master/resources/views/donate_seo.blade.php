@extends('layouts.home')
@section('content')
<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3 style="text-align: left;"> {{ $datasearch['donate_title'] }} </h3>

        </header>
        <div class="row">
            <div class="col-md-8">
              <div class="container" style="background: #e9f3fb;padding-top: 1rem;">
                <div class="row">
                    <div class="col-md-12" style="margin-bottom:3rem">
                        <img src="{{ asset($datasearch['donate_banner']) }}" alt=""
                            class="img-fluid" style="width: 100%;border: 4px solid white;">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Summary</b></h3>
                        <p style="line-height: 1.5rem;text-align: justify;">
                            {{ $datasearch['donate_Summary'] }}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Challenge</b></h3>
                        <p style="line-height: 1.5rem;text-align: justify;">
                            {{ $datasearch['donate_challenge'] }}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Solution</b></h3>
                        <p style="line-height: 1.5rem;text-align: justify;">
                            {{ $datasearch['donate_solution'] }}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Long-Term Impact</b></h3>
                        <p style="line-height: 1.5rem;text-align: justify;">
                            {{ $datasearch['donate_long_impact'] }}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h3><b>Reference Url</b></h3>
                        <p><i class="fa fa-link" aria-hidden="true"></i>
                            {{ $datasearch['donate_ref_url'] }}</p>
                    </div>
                </div>

                <hr>
                <div class="row">
                  <div class="col-md-12" style="text-align: center;">
                    <h2><b><u>Organization</u></b></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-4" style="text-align: center;">
                    <img style="width: 150px;" src="{{asset($datasearch['donate_logo'])}}"/>
                  </div>
                  <div class="col-md-8">
                    <h3><b>{{$datasearch['donate_org_name']}}</b></h3>
                      <p style="line-height: 1.5rem;text-align: justify;">
                          {{ $datasearch['donate_org_detail'] }}</p>
                  </div>
              </div>


              </div>
            </div>

            <div class="col-md-4">
              <div class="container" style="background: #e9f3fb;
              padding-top: 1rem; padding-bottom:1rem">
                <div class="row">
                  <div class="col-md-12">
                      <h3><b>Address</b></h3>
                      <p style="line-height: 1.5rem;">
                          {{ $datasearch['donate_loc'] }} ({{ $datasearch['donate_category'] }})</p>
                          
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                      <h3><b>Focus</b></h3>
                      <p style="line-height: 1.5rem; font-size:1rem;">
                          {{ $datasearch['donate_foc_Area'] }}</p>
                          
                  </div>
                  <div class="col-md-6">
                    <h3><b>Goal</b></h3>
                    <p style="line-height: 1.5rem;font-size:1rem;">
                        {{ $datasearch['donate_total_goal'] }}</p>
                        
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-12">
                    <a target="_blank" href="{{url($datasearch['donate_checkout_url'])}}" class="btn btn-outline-primary" style="width: 100%;
                    padding: .5rem;
                    font-size: 22px;
                    font-weight: bold;
                    letter-spacing: 2px;">Donate</a>
                  </div>
                </div>
              </div>
                {{-- <div class="card" style="width: 18rem;">
                    <div class="card-body">

                        <button type="text" style="background-color:#3490dc;color:white;">Donate Now</button>

                    </div>
                </div> --}}


            </div>


        </div>


    </div>


    </div>
    </div>
</section>
@endsection
