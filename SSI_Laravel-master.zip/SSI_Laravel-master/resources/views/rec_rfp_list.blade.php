@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Organisation Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">RFP List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>RFP List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Grant Title</th>
                                <th>Grant Amt</th>
                                <th>Organization Name</th>
                                <th>Create Date</th>
                                <th>Submitted By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($rfplist)
                            <tfoot>
                                <tr>
                                    <th>Grant Title</th>
                                    <th>Grant Amt</th>
                                    <th>Organization Name</th>
                                    <th>Create Date</th>
                                    <th>Submitted By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($rfplist as $noti)
                                    <tr>
                                        <td>{{ $noti['rfp_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['rfp_g_amt'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['rfp_org'] }}</td>
                                        <td>{{ $noti['rfp_close_date'] }}</td>
                                        <td>{{ $noti['rfp_submitted_by'] }}</td>
                                        <td>{{ $noti['rfp_status'] }}</td>
                                        {{-- <td>
                                            <button class="btn btn-outline-secondary">Details</button>
                                            
                                        </td> --}}
                                        <td>
                                            @if($noti['rfp_approved'] == '1')
                                            <a href="{{url('/rfp')}}/{{$noti['rfp_SEO']}}" target="_blank" class = "btn btn-outline-secondary">Live URL</a>
                                            @else
                                            <a href="{{url('/preview/rfp')}}/{{$noti['rfp_enc_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                            @endif
                                        </td>
                                        {{-- <td>
                                            @if($noti['rfp_approved'] == '1')
                                            <span>Put on Hold</span>
                                            @else
                                            <span>Approve</span>
                                            @endif
                                        </td> --}}
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();

</script> 
@endsection
