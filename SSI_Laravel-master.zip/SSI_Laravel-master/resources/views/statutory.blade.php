@extends('layouts.home')
@section('content')

        <!-- ======= About Section ======= -->
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}

            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Statutory</span> <span class="titleheading">Obligation</span> </h3>
                </header>
                <div>
                    <div class="col-lg-12">
                        <h6 style="font-weight:600;">Tentative dates followed by Social Services India team for all
                            statutory obligations for effective services.
                        </h6>
                    </div>
                </div>
                <div class="row about-container">
                    <div class="col-lg-12 background wow fadeInUp">
                        <table class="table-responsive-md table-hover">
                            <caption>
                                <hr style="color:#007bff;border:3px solid;">
                                * Note: Any changes on filing dates as per government guidelines will be updated and
                                followed accordingly.
                            </caption>
                            <thead>
                                <tr>
                                    <th scope="col">Date</th>
                                    <th scope="col">Obligation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        30<sup>th</sup> April
                                    </td>
                                    <td>
                                        Closure of previous year books of accounts and preparation for audit
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> June
                                    </td>
                                    <td>
                                        Quarterly statement for deduction of tax for the last quarter of the previous
                                        financial year (form 24Q and 26Q)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        30<sup>th</sup> June
                                    </td>
                                    <td>
                                        Form 16 to employees
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        30<sup>th</sup> June
                                    </td>
                                    <td>
                                        Form 16 A to consultants
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> July
                                    </td>
                                    <td>
                                        Quarterly statement for deduction of tax for the first quarter of the current
                                        financial year (Form 24Q and 26Q)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        31<sup>st</sup> July
                                    </td>
                                    <td>
                                        Closure of Audit and Signing of accounts, filing of orginisation Income tax
                                        returns.
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        31<sup>st</sup> July
                                    </td>
                                    <td>
                                        Filing of Individual Income tax returns
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        30<sup>th</sup> September
                                    </td>
                                    <td>
                                        AGM needs to be held by this date
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15 days from AGM
                                    </td>
                                    <td>
                                        Submit Register of Societies with statements required , notice of meetings,
                                        meeting proceeding/minutes and attendance record within 15 days of the AGM
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> October
                                    </td>
                                    <td>
                                        Quarterly statement for deduction of tax for the second quarter of the current
                                        financial year (Form 24Q and 26Q)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        31<sup>st</sup> October
                                    </td>
                                    <td>
                                        Furnishing of audit report for the previous financial year to IT authorities
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        30<sup>st</sup> December
                                    </td>
                                    <td>
                                        Filing with Ministry of home affairs (MHA) – Submit FC-4 with audit report and
                                        Financial statements (FCRA Return)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> January
                                    </td>
                                    <td>
                                        Quarterly statement for deduction of tax for the third quarter of the current
                                        financial year (Form 24Q and 26Q)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> April
                                    </td>
                                    <td>
                                        Quarterly statement for deduction of tax for the third quarter of the current
                                        financial year (Form 24Q and 26Q)
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        7<sup>th</sup> of following month
                                    </td>
                                    <td>
                                        Amount deducted as TDS in the preceding month to be deposited into the
                                        Government treasury
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> of following month
                                    </td>
                                    <td>
                                        Amount deducted as Professional tax in the preceding month to be deposited into
                                        the Government treasury
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        15<sup>th</sup> of following month
                                    </td>
                                    <td>
                                        Amount deducted as Provident fund in the preceding month to be deposited into
                                        the Government treasury
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        20<sup>th</sup> of following month
                                    </td>
                                    <td>
                                        Amount deducted as GST in the preceding month to be deposited into the
                                        Government treasury
                                    </td>
                                </tr>

                            </tbody>

                        </table>
                    </div>
                </div>


        </section><!-- End About Section -->

@endsection