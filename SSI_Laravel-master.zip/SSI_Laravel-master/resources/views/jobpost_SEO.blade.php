@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    <div class="intro-img" style="">
        {{-- <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>

    <div class="container" style="padding: 1rem;margin-bottom: 5rem;margin-top:5rem; box-shadow: 1px 4px 4px 4px #e9f3fb;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset($jp_obj['jp_org_logo'])}}" />
            </div>
            <div class="col-md-7">
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$jp_obj['jp_org_name']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$jp_obj['jp_title']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">{{$jp_obj['jp_ad_type_area_of_expertise']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <h4><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_1']}},
                            {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}} ({{$js_loc_obj['addr_zip']}})</h4> --}}
                        <span style="font-size: 14px;"><i class="fa fa-map-marker" aria-hidden="true"></i> {{$jp_obj['jp_loc']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        {{-- <h5 style="font-weight: bold"><span class="subDetails">Application Email:</span> {{$jp_obj['jp_app_email']}}</h5> --}}
                        <span style="font-size: 14px;font-weight: bold">Application Email : </span> <a style="font-size: 14px;" href="mailto:{{$jp_obj['jp_app_email']}}">{{$jp_obj['jp_app_email']}}</a>
                    </div>
                </div>
                {{-- <div class="row">
                    <div class="col-12">
                        <h5 style="font-weight: bold"><i class="fa fa-clock-o" style="margin-right: 1rem;"  aria-hidden="true"></i><span class="subDetails">Valid till:</span> {{$jp_obj['jp_closing_date']}}</h5>
                    </div>
                </div> --}}

            </div>
            @if(session()->has('ssiapp_js_id'))
            <div class="btn_container col-md-2" style="text-align: center;">
                <a href="#" onclick="apply({{$jp_obj['jp_id']}},{{session()->get('ssiapp_js_id')}})" class="custom_btn custom_btn_blue"><span>Apply</span></a>
            </div>
            @else
            <div class="btn_container col-md-2" style="text-align: center;">
                <a href="#" onclick="alert('Please Create Job Seeker Account First')" class="custom_btn custom_btn_blue"><span>Apply</span></a>
            </div>
            {{-- <div class="col-md-2">
                <a href="#" onclick="" class="btn btn-primary">Na Apply</a>
            </div> --}}
            
            @endif
           
        </div>

        <div class="row" style="text-align: center;margin-bottom: 2rem;">
            <div class="col-md-4">
                <h4><b>Website</b></h4>
                <span style="line-height: 1.5rem;overflow-wrap: break-word;font-size: 14px;">
                   <a href="{{$jp_obj['jp_org_web']}}" target="_blank">{{$jp_obj['jp_org_web']}}</a>
                </span>
            </div>
            <div class="col-md-4" style="border-right: 5px solid #e9f3fb;
            border-left: 5px solid #e9f3fb;">
                <h4><b>Job Type</b></h4>
                <span style="line-height: 1.5rem;font-size: 14px;">
                    {{$jp_obj['jp_job_type_str']}}
                </span>
            </div>
            <div class="col-md-4">
                <h4><b>Closing Date</b></h4>
                <span style="line-height: 1.5rem;font-size: 14px;">
                    {{$jp_obj['jp_closing_date']}}
                </span>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12" style="font-size: 14px;">
                <h3><b>Description</b></h3>
                <p  style="line-height: 1.5rem;text-align: justify;">
                    {!!htmlspecialchars_decode($jp_obj['jp_desc'])!!}
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @if (isset($jp_obj['jp_files']) && $jp_obj['jp_files'] != "")
                <h3><a target="_blank" class="btn btn-primary" href="{{url($jp_obj['jp_files'])}}">Download Attachment <i class="fa fa-chevron-right"></i></a></h3>
                {{-- <h4 style="font-size:15px;"><a target="_blank" href="{{url($jp_obj['jp_files'])}}">Download File <i class="fa fa-download"></i></a></h4> --}}
                @endif
            </div>
        </div>
        

    </div>

</section>

@endsection

@section('custom_script')
<script>
function apply(job_id,r_id){
        //alert('Apply');
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxapplyjob.post') }}",
                data:{job_id:job_id,r_id:r_id},
                success:function(data){
                    console.log(data);
                    if(data.res == 'SUCCESS'){
                        // $('#btn_layer_'+idx).html(data.data);
                        alert("Applicaed Successfully")
                    }else{
                        alert(data.error);
                        console.log(data.error);
                    }
               }
            });
    }
</script>
@endsection