@extends('layouts.home')
@section('content')
<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">RFP </span> </h3>

        </header>





        <div class="row" style="text-align: center;">

        </div>

        <form action="{{url('/rfp/submit')}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            @csrf
            <div class="row" style="border-bottom: 3px solid #444;">
                <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                    <div class="form-row">

                        <div class="form-group col-lg-6">
                            <label for="name">Name of the Organisation </label>
                            <input type="text" name="orgname" class="form-cntrl" id="orgname" placeholder="Name of  the organisation" />
                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Grant Title </label>
                            <input type="text" name="grant_title" class="form-cntrl" id="grant_title" placeholder="Grant title" />
                            <div class="validate"></div>
                        </div>


                    </div>

                    <div class="form-row">

                        <div class="form-group col-lg-6">
                            <label for="name">Location </label>
                            <input type="text" name="location" class="form-cntrl" id="location" placeholder="" />
                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Total Amount </label>
                            <input type="text" name="total_amt" class="form-cntrl" id="total_amt" placeholder="" />
                            <div class="validate"></div>
                        </div>


                    </div>

                    <div class="form-row">

                        <div class="form-group col-lg-6">
                            <label for="name">closing date of proposal </label>
                            <input type="text" name="close_date" class="form-cntrl" id="close_date" placeholder="" />
                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Email </label>
                            <input type="text" name="email" class="form-cntrl" id="email" placeholder="" />
                            <div class="validate"></div>
                        </div>





                        <div class="row">
                            <div class="form-group col-lg-12">
                                <label for="name">Description of the proposal </label>
                                </br>
                                {{-- <input type="file" name=""> --}}
                                <textarea class="form-cntrl" name="proposal_desc" id="proposal_desc" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                                <div class="validate"></div>
                                <div class="validate"></div>
                            </div>
                            <!-- <div class="form-group col-lg-6">
      <label for="name">Organisation mission </label>
      
      <textarea class="form-cntrl" name="misssion" id="mission" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
      
      <div class="validate"></div>
  </div>                 -->
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label> proposal category</label>
                                </br>
                                <input type="file" name="document" data-file_types="doc|pdf|text" accept="application/pdf">
                            </div>
                            <div class="col-md-6">
                                <label>organisation logo</label>
                                </br>
                                <input type="file" name="company_logo" data-file_types="jpg|jpeg|gif|png" accept="image/png, image/jpeg">
                            </div>

                        </div>
                    </div>
                    @isset($html)
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <h4>Proposal Category</h4>
                        </div>
                        {{-- <div class="form-group col-lg-12"> --}}
                        {!! $html !!}
                        {{-- </div> --}}
                        <input type="hidden" id="cates" name="cates" value="" />
                    </div>
                    @endisset


                    {{-- <div class="row">
                                    <div class="col-md-4">

                                        <label><b>Proposal Category</b></label><br>
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Adolescent</label><br>
                                        <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                                        <label for="vehicle2"> Advocacy</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Aged/Elderly</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Animal Husbandry,Darying & Fisheries</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Animal & Wildlife</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Art & Culture</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Biotechnology</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Bussiness & industry</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Children</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Children and childcare</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Civil issues</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Community Development</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Corporate Social Responsibility</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Covid 19</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Dalit Upliftment</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Differently abled </label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Disability and inclusion </label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Disaster Management</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Drinking water</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Economic Development</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Education</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Education & Literacy</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Education and Education Technology</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Employment and labor</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Enterpreneurship</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Enviroment</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Enviroment and forest</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> financial Inclusion</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> food Agriculture nd nutrition</label><br>
                                    </div>
                                    <div class="col-lg-4" style="margin-top:30px;">

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> food processing</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">



                                        <label for="vehicle3">Governance</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Health & family Welfare </label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Health Care </label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Health Care and Health tech</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">HIVS/ADS</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Housing</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Housing</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Human Rights</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Human Relief</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">impact investing</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">information and Communication Texhnology</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">innovation and technologies</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">journalism</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Labour and Employment</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Land Resources</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Leadership</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Land Awarness & Aids</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">LGBTQ</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Liberal Arts</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Livelihood</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Media</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Micro Finance SHG's</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Micro Small & Medium Enterperises</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Minority Issue</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Narcotics,Drugs&crime</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">New & Renewable Energy</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Nutrition</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Others</label><br>
                                    </div>
                                    <div class="col-lg-4" style="margin-top:30px;">
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Panchayati RAj</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Photo Journalism</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Post Dectorate</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Poverty Alleviation</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Prisoners Issues</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Photo Docrator</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Poverty Alleviation</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Prisoners issues</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">public policy</label><br>
                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Recycling and Waste Management</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Research</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Right to information & Advocacy</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Rural Development and Allevation</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Sanitation</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Science</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Science & Technology</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Scientific & Industrial Research</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Smart city and Urban Issues</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Social Change</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Solar</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Sports </label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Sports and Recreation </label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Sustainable Development Goals</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Tourism</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Tribal Affair</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Urban Development & Poverty Allevation</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Urban Issues</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Vocational training</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> water</label><br>


                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> water Resources</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> Women and Gender</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3"> women's Development & Employment</label><br>

                                        <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                        <label for="vehicle3">Youth Icon</label><br>

                                    </div>
                                </div> --}}




                   
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <label for="name"> Human Check 2+7=</label>
                            <input type="text" name="organisation" class="form-cntrl" id="" placeholder="" />
                            <div class="validate"></div>
                        </div>


                    </div>


                    <div class="row">
                    <div class="col-lg-12">


                        {{-- <input type="checkbox" id="terms" name="terms" value="">
                        <label for="vehicle3"> Terms and condition</label><br> --}}


                        <div class="row" style="text-align:center;">
                    <div class="col-lg-12 ml-auto">
                        <button class="btn btn-primary  btn-register" style="width:10%">Submit RFP</button>
                    </div>
                </div>

                    </div>

                </div>


                </div>

               









        </form>
    </div>



</section>


@endsection