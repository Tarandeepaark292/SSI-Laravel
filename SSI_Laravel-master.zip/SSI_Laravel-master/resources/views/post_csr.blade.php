@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post CSR Ad</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Post CSR AD</li>
        </ol>
        
        {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post CSR Ad
            </header>
        </div> --}}
            @if(session()->has('ssiapp_rec'))
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;" >
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <div class="col-12">
                        <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                    </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/csr/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="orgname" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" style="width:100%;"  />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant title </label>
                                        <input type="text" name="grant_title" class="form-cntrl" id="email"
                                            placeholder="Grant title" style="width:100%;"  />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="email"
                                            placeholder="India"  style="width:100%;" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant Amount </label>
                                        <input type="text" name="grant_amt" class="form-cntrl" id="amount"
                                            placeholder="USD 100000" style="width:100%;"  />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        
                                        
                                    <label for="name">Closing dates for proposal</label> 

                                        <input type="date" name="close_date" class="form-cntrl" id="amount"
                                            placeholder="" style="width:100%;"  /> 

                                        <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Applicant Email</label>
                                        <input type="email" name="email" class="form-cntrl" id="email" placeholder="abc@example.com" style="width:100%;"  />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                {{-- <div class="col-lg-12">
                                    <label for="company_logo">Description of the proposal</label><br>
                                    <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                        accept="image/png, image/jpeg" name="" id="" placeholder="Add Media" >
                                </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the proposal</label><br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="summernote" placeholder="" rows="10" 
                                            style="height: auto;resize: none;  width:100%;" ></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                        <input type="file" class="form-cntrl-file" name="document" id="document" data-file_types="doc|pdf|text" style="width:100%;" 
                                          accept="application/pdf" id="" placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png" style="width:100%;" 
                                            accept="image/png, image/jpeg" name="company_logo" id="" placeholder="Add Media">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder="Insert Website link"  style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                


                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                    <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                        {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value=""/>
                                </div>
                                @endisset





                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                    <label for="vehicle3">Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%"> Submit CSR Funding
                                            Ad</button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>




            @else
            <div class="row about-container">
                <div class="col-lg-12">

                    <hr style="color:#007bff;border:3px solid;">
                    <p class="card-text"><i>Please login to submit CSR Funding.</i> <a
                        href="{{url('/login')}}"
                            class="btn btn-primary">Login</a></p>

                    <p style="margin-top: 30px; font-size: 1rem;">
                        For any further assistance our experts will get in touch with you and take it forward.
                        <br /><br />
                        Please email us at: <b>contact@SocialServicesIndia.com</b> for <b>Queries</b>
                    </p>
                </div>

            </div>
            @endif
        </div>
        </div>
    </section>
    <script>
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>
</main>

@endsection