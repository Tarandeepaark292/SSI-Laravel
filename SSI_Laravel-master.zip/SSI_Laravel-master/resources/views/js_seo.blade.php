@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')




<section style="">
    <div class="intro-img" style="">
        {{-- <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>

    <div class="container" style="box-shadow:1px 4px 4px 4px #e9f3fb;padding: 1rem;margin-bottom: 5rem;margin-top:5rem;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset($jp_obj['js_photo'])}}" />
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;">{{$jp_obj['js_name']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;">{{$jp_obj['js_p_title']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;">{{$jp_obj['js_area_expertise']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <h4><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_1']}},
                            {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}} ({{$js_loc_obj['addr_zip']}})</h4> --}}
                        <span style=""><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <span style=""><i class="fa fa-rupee"  aria-hidden="true"></i> Expected Salary : {{$jp_obj['js_sal']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style=""><i class="fa fa-clock-o"  aria-hidden="true"></i> Total Experience : {{$jp_obj['js_totexp']}}</span>
                    </div>
                </div>
            </div>
           
        </div>

    <div class="row">
        <div class="col-md-12"   style="font-size: 1.1rem;">
            <h3><b>Candidate Overview</b></h3>
            <div class="jsdesc-container" style="line-height: 1.5rem;text-align: justify;height: 550px;overflow: hidden;">
                {!!htmlspecialchars_decode($jp_obj['js_personal_info'])!!}
            </div>
            <button style="margin-bottom: 1rem;box-shadow: 1px 3px 8px #3490dc;" id="btn-readmore" class="btn btn-primary" onclick="showAllData()">Read More</button> 
        </div>
    </div>

    @isset($js_exp_obj)
    <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Work Experience</b></h3>
            <div class="col-md-10" style="margin:0 auto;background: #fffaf045;box-shadow: 0px 6px 2px 0px #e9f3fb;border:3px solid;">
            @foreach($js_exp_obj as $res)
            {{-- <article style="border-bottom: 2px dotted #fff;padding-top: 1rem;">
                <h4>{{$res['title']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p>
                
            </article> --}}
            <div class="row" style="padding: 6px 5px;">
                <div class="col-md-4">   
                    {{$res['title']}}
                </div>
                <div class="col-md-4">    
                    {{$res['school']}}
                </div>
                <div class="col-md-4">    
                    {{$res['start']}} - {{$res['end']}}
                    
                </div>
            </div>
            @endforeach
            </div>
        </div>
    </div>
    @endisset

    @isset($js_skill_list_obj)
    <div class="row">
        <div class="col-md-12" style="padding-top:1rem;">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Skills</b></h3>
            {{-- @foreach($js_skill_list_obj as $res) --}}
            <article style="border-bottom: 2px dotted #fff;">
                {{-- <h4>{{$res['title']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p> --}}
                <ul>
                    @foreach($js_skill_list_obj as $res)
                    <li>{{$res['skill']}}</li>
                    @endforeach
                </ul>
            </article>
            {{-- @endforeach --}}
        </div>
    </div>
    @endisset
    {{-- <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Area of Expertise</b></h3>
            <article>
                <h5>{{$jp_obj['js_area_expertise']}}</h5>
            </article>

        </div>
    </div> --}}

    @isset($js_edu_obj)
    <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-graduation-cap" style="margin-right: 1rem"></i><b>Education</b></h3>
            <div class="col-md-10" style="margin:0 auto;background: #fffaf045;box-shadow: 0px 6px 2px 0px #e9f3fb;border:3px solid;">
            @foreach($js_edu_obj as $res)
            {{-- <article style="border-bottom: 2px dotted #fff;padding-top: 1rem;">
                <h4>{{$res['degree']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p>
            </article> --}}
            <div class="row" style="padding: 6px 5px;">
                <div class="col-md-4">   
                    {{$res['degree']}} 
                </div>
                <div class="col-md-2">    
                    {{$res['start']}} - {{$res['end']}}
                </div>
                <div class="col-md-6">    
                    {{$res['school']}}
                </div>
            </div>
            @endforeach
            </div>
        </div>
    </div>
    @endisset
    @if(session()->has('ssiapp_rec_id'))
    <div class="row" style="justify-content: flex-end;">
        <div class="col-md-4 btn_container" style="margin-top: 4em;margin-bottom: 4em;">
            <a href="#" onclick="$('#org_msg_dlg').modal('show');" class="custom_btn custom_btn_blue"><span>Send Message</span></a>
        </div>
    </div>
    @else
    <div class="row" style="justify-content: flex-end;">
        <div class="col-md-4 btn_container" style="margin-top: 4em;margin-bottom: 4em;">
            <a href="#" onclick="alert('Please Create Organization Account First')" class="custom_btn custom_btn_blue"><span>Send Message</span></a>
        </div>
    </div>
    @endif

    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="org_msg_dlg" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Send Message</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Message</label>
                        <textarea class="form-control" id="inputmsg"></textarea>
                        
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="sendMsg(event,{{session()->get('ssiapp_rec_id')}},{{$jp_obj['js_id']}})">Send</button>
            </div>
        </div>

    </div>
</div>




@endsection

@section('custom_script')

<script type="text/javascript">

    function showAllData(){
        $(".jsdesc-container").css("height","auto");
        $("#btn-readmore").css("display","none");
    }


    function sendMsg(e,from,to){
        e.preventDefault();
        console.log($("#org_msg_dlg #inputmsg").val());
        var msg = $("#org_msg_dlg #inputmsg").val();
        if( msg.trim().length == 0 ){
            alert("Error! Can't send empty message");
            return;
        }

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxsendmsg.post') }}",
            data: {
                data: $("#org_msg_dlg #inputmsg").val(),
                by: from,
                to: to,
            },
            success: function (data) {
                console.log(data);
                if (data.res == 'SUCCESS') {
                    alert("Message Send");
                    $('#org_msg_dlg').modal('hide');
                    $("#org_msg_dlg #inputmsg").val("");
                } else {
                    alert("Error in Sending Message");
                }
            }
        });
    }
</script>

@endsection