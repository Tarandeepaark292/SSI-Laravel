@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">All </span> <span class="titleheading">Fellowship</span> <span
                    class="titleheading">Ads</span></h3>
        </header> --}}
        <div class="row">
            <div class="form-group col-md-6">
                <input type="text" placeholder="Search.." id="filter" onchange="myfunction(event)" class="form-cntrl">
            </div>
            <div class="form-group col-md-6">
                <select name="cate" id="cate" class="form-cntrl " onchange="myfunction(event)"
                style="width:100%;">
                    <option value="">Choose a Fellowship Type</option>
                    @foreach ($cates as $cate)
                    <option value="{{$cate['cate_id']}}">{{$cate['cate_name']}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="row">
            {{-- <div class="col-12">
                <span style="display: block;font-size: 16px;">
                    <p>
                        <br>
                        These are all the Fellowship  ads
                        <br>
                    </p>
                </span>

            </div> --}}





            <div id="search_results" style="width: 100%;" class="paginate">
                <div class="items">
            @isset($fellsearch)
            @foreach($fellsearch as $res)
            
            <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content fell_search_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                            
                                    <div class="col-md-2" style="text-align: center;">
                                        <img style="width:80%" src="{{ asset($res['fell_o_logo']) }}" />
                                    </div>
                                    <div class="col-md-8">
                                        <div class="results" style="font-weight: bold;">
                                            <span class="limittext" style="font-weight: bold;color:#004a99">{{ $res['fell_title'] }}</span></div>
                                        <div id="results">
                                            <span style="font-weight: bold;color:#004a99">{{ $res['fell_o_name'] }}</span>
                                        </div>
                                        <div id="results">
                                            <i class="fa fa-map-marker" aria-hidden="true"
                                                style="color:#007bff;font-size: 18px;"></i> <span
                                                style="">{{$res['fell_loc']}}</span>

                                        </div>
                                        <div id="results">
                                            <i class="fa fa-calendar" aria-hidden="true"
                                                style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                                style="color:#00254d;">{{ $res['fell_end_date'] }}
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-2 my-auto ">
                                        <a href="{{url('/fell/')}}/{{$res['fell_SEO']}}" class="btn btn-newprimary">Details   <i class="fa fa-chevron-right"></i></a>
                                    </div>




                               






                        </div>
                    </div>
                </div>
            </div>
            
            @endforeach
            @endisset
        </div>
        <div class="pager">
            <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
            <div class="pageNumbers"></div>
            <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
        </div>
            </div>

            <!-- </tbody>
                                </table> -->

            <!-- </div> -->
        </div>

    </div>

    </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxfell.post') }}",
            data: {
                search: $('#filter').val(),
                cate: $('#cate').val()            
            },
            success: function (data) {
                // console.log(data);
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    // console.log(data);
                    $('#search_results').html(data.error);
                    // alert(data.error)
                }
            }
        });
    }

</script>


@endsection

@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection