@extends('layouts.home')
@section('content')

<div class="container" style="margin-top: 100px ;padding:100px;">
    <div class="row">
        <div class="col-md-12">



            <div class="card" id="crd" style="background: rgb(48,175,192);
background: linear-gradient(256deg, rgba(48,175,192,1) 0%, rgba(149,214,223,1) 35%);
">
                <div class="card-body">

                    <div class="row mb-5">
                        <div class="col-md-4">
                            <div class="text-right mt-5"><img class="check-sign"
                                    src="{{ asset('img/tik.png') }}" style="height:110px;"></div>
                        </div>
                        <div class="col-md-8 mt-5 card-crd">
                            <h6 class="cc" style="">SUCCESS !</h6>
                            <h6 class="mt-3 payment" style="">Payment Confirmed</h6>
                            <div class="mt-3" style="border:3px solid white; width:80%; border-radius:25px">
                            </div>
                            <div class="row mt-3" style="margin-top:10px">
                                <div class="col-md-8 detail">
                                    <div><span
                                            style="color:white; font-weight:800; font-size:30px margin:0px !important; padding:0px ">Amount:</span><span
                                            class="ml1"
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px "> {{$payment}}</span></div>
                                    <div><span
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px ">Payment
                                            ID:</span><span class="ml2"
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px "> {{$order_id}}</span>
                                    </div>
                                    <div><span
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px ">Name:</span><span
                                            class="ml3"
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px "> {{$name}}</span>
                                    </div>
                                    <div><span
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px ">Date:</span><span
                                            class="ml4"
                                            style="color:white; font-weight:600; font-size:18px margin:0px !important; padding:0px "> {{$createdate}}</span>
                                    </div>

                                </div>
                               
                            </div>
                        </div>





                    </div>


                </div>


            </div>

        </div>
    </div>
</div>


@endsection
