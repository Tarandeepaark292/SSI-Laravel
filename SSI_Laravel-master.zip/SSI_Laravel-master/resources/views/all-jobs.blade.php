@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Jobs</span> </h3>
        </header>




        <div class="container">
            <div class="row" style="padding:20px; ">
                <div class="form-group col-lg-6">
                    <input type="text" name="filter" onchange="myfunction(event)" class="form-cntrl" id="filter"
                        placeholder="Keywords" />
                    <div class="validate"></div>
                </div>
                <div class="form-group col-lg-6">
                    <input type="text" name="location1" onchange="myfunction(event)" class="form-cntrl" id="location1"
                        placeholder="Location" />
                    <div class="validate"></div>
                </div>


                <div class="field required-field col-lg-12">
                    <select name="job_type" id="cat" class="form-cntrl " onchange="myfunction(event)"
                        style="width:100%;">
                        <option value="-1">Choose a Job category… E.g Spotlight, Administration or Research</option>
                        <option>Administration, HR, Management, Accounting/Finance Executive</option>
                        <option>Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                        <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                        <option>Capacity Building, Training, Advocacy</option>
                        <option>Communications, IT, Media, Knowledge Management, Editor</option>
                        <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                        <option>Disaster, Aid, Emergencies, Relief</option>
                        <option>Environment, Climate, Energy, Water, Sanitation</option>
                        <option>Fund-raising Business Development, Grants Writer</option>
                        <option>Field Officers, Field Associates</option>
                        <option>Government / Governance, Reforms, Corruption</option>
                        <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                        <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                        <option>Infrastructure, Technology, Engineering, Science</option>
                        <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                        <option>Private Sector, Corporate Social Responsibility</option>
                        <option>Project Associate, Project leaders, Project Assistant</option>
                        <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                        <option>Research Analysts, Research Associate, Research Assistant</option>
                        <option>Social, Gender, Education, Youth, Child</option>
                        <option>Trade, Finance, Economics, Cooperation, Global</option>
                        <option>Technology Associate, Technical Assistant, </option>
                        <option>Teachers, Teachers Educators, Principal</option>
                    </select>

                    {{-- <ul class="job_types">
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_contribution"
                                class="contribution"><input type="checkbox" name="filter_job_type[]"
                                    value="contribution" checked="checked" id="job_type_contribution">
                                Contribution</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_freelance"
                                class="freelance"><input type="checkbox" name="filter_job_type[]" value="freelance"
                                    checked="checked" id="job_type_freelance"> Freelance</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_full-time"
                                class="full-time"><input type="checkbox" name="filter_job_type[]" value="full-time"
                                    checked="checked" id="job_type_full-time"> Full Time</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_grant"
                                class="grant"><input type="checkbox" name="filter_job_type[]" value="grant"
                                    checked="checked" id="job_type_grant"> Grant</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_internship"
                                class="internship"><input type="checkbox" name="filter_job_type[]" value="internship"
                                    checked="checked" id="job_type_internship"> Internship</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_part-time"
                                class="part-time"><input type="checkbox" name="filter_job_type[]" value="part-time"
                                    checked="checked" id="job_type_part-time"> Part Time</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_temporary"
                                class="temporary"><input type="checkbox" name="filter_job_type[]" value="temporary"
                                    checked="checked" id="job_type_temporary"> Temporary</label></li>
                        <li style="display:inline;padding:10px;font-size:15px;"><label for="job_type_work-from-home"
                                class="work-from-home"><input type="checkbox" name="filter_job_type[]"
                                    value="work-from-home" checked="checked" id="job_type_work-from-home"> Work from
                                Home</label></li>
                    </ul> --}}
                </div>
                <!-- <button type="" onclick="myfunction(event)"><i class="fa fa-search"></i></button> -->

                <div class="col-12">
                    <span style="display: block;font-size: 16px;">
                        <p>
                            <br>
                            {{-- These are all the Jobs --}}
                            <br>
                        </p>
                    </span>

                </div>

                <div id="search_results" style="width: 100%;"  class="paginate">
                    <div class="items">
                    @isset($jobs)
                    @foreach($jobs as $res)


                    <div class="col-12" style="margin-bottom:2rem;">
                        <div class="card content joblist_item" id="results">
                            <div class="card-body" id="results">
                                <div class="row " id="resultss">

                                    <div class="col-md-2" style="text-align: center;">

                                        <img style="width: 80%;" src="{{asset($res['jp_org_logo'])}}" />
                                    </div>
                                    <div class="col-md-8">
                                        <div id="results">
                                            <span class="limittext" style="font-weight: bold;color:#004a99">{{$res['jp_title']}}</span>
                                        </div>
                                        <div id="results" >
                                            <span class="limittext" style="margin-bottom:2px;font-weight: bold;color:#004a99"> {{$res['jp_org_name']}} </span>
                                        </div>
                                        <div id="results">
                                            <span style="font-weight: bold">{{$res['jp_job_type']}}</span>
                                        </div>
                                        <div id="results">
                                            <i class="fa fa-map-marker" aria-hidden="true"
                                                style="color:#007bff;font-size: 18px;"></i> <span
                                                style="">{{$res['jp_loc']}}</br>

                                            </span>
                                        </div>
                                        <div id="results">
                                            <i class="fa fa-calendar" aria-hidden="true"
                                                style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                                style="">{{$res['jp_closing_date']}}
                                            </span>
                                        </div>
                                        {{-- <div id="results">
                                            {{$res['jp_ad_type_area_of_expertise']}}
                                        </div> --}}
                                        
                                    </div>
                                    <div class="col-md-2" style="align-self: center;justify-content: center;">
                                        <a href="{{url('/job-post')}}/{{$res['jp_SEO']}}" class="btn btn-primary">Detail <i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                       

                    </div>
                    <!-- </div>
                   
                </div> -->
                    @endforeach
                    @endisset
                    </div>
                    <div class="pager">
                        <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
                        <div class="pageNumbers"></div>
                        <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {

        e.preventDefault();
        // console.log($('#cat').val());
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxjob.post') }}",
            data: {
                search: $('#filter').val(),
                loca: $('#location1').val(),
                cate: $('#cat').val()
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error)
                }
            }
        });
    }

</script>


<!-- <script>
    function myfunction(e) {

        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxresume.post') }}",
            data: {
                location: $('#location1').val()
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error)
                }
            }
        });
    }
</script> -->

@endsection

@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection
