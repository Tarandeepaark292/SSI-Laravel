@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

        <!-- ======= About Section ======= -->
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}

            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Accounting</span> </h3>
                </header>

                <div class="row about-container">
                    <div class="col-lg-6 background order-lg-1 order-1 wow fadeInUp">
                        <img src="{{asset('img/about-img.svg')}}" style="width:100%" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 content order-lg-2 order-2">

                        <h6 style="font-weight:600;">We are expertise in handling accounts of NGOs, Voluntary Organization, NPOs, Charitable and Education Institution.</h6>
                        <span class="">
                            <p>We provide a full-service solution for early-stage organization that do not have a need for full-time
                                accounting and finance personnel. We become the virtual accounting department for these organizations, providing professional consultants at all experience levels, from accounting staff to controllers to chief financial officers. We provide specialize services in book keeping, day to day accounting etc, helping early-stage organizations with virtually all of their accounting,
                                finance, and administrative needs so management can focus on what matters most to their businesses</p>
                        </span>

                        <b>Our Accountancy services include:</b>
                        <br />
                        <ol style="padding: 1em;">
                            <li>Preparation of Management and Interim Accounts.</li>
                            <li>Budgeting and cash flow planning</li>
                            <li>Maintaining and Providing cost center and dimension reports on every quarter to the management</li>
                            <li>Finalization of Accounts: Preparation of financial year end accounts.</li>
                            <li>Payroll and accounts by a member of our Accountancy Support Services team.</li>
                            <li>Software Managed Service: Maintenance of Accounts and related records on our systems.</li>
                            <li>Preparing performance highlights for the management on which organizations decisions can be based.</li>
                            <li>Compliance support with all periodic statutory requirements</li>
                        </ol>
                        <hr style="color:#007bff;border:3px solid;">
                        <p style="margin-top: 30px; font-size: 1rem;">
                            For any further assistance our experts will get in touch with you and take it forward.
                            <br /><br />
                            Please email us at: <b>Team@SocialServicesIndia.org</b> with subject of the e-mail <b>“Accounting”</b>
                        </p>
                    </div>

                </div>

        </section><!-- End About Section -->


    @endsection