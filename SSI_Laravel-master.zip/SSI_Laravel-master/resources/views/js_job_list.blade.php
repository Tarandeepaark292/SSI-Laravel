@extends('layouts.auth_bend_home')
@section('content')


<main>
    <div class="container-fluid">
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Jobseeker</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Email</th>
                                <th> Name</th>
                                <th>Create Date</th>
                                <th>Area Expertise</th>
                                {{-- <th>location</th> --}}
                                <th>Status</th>
                                    {{-- <th>video</th>
                                    <th>Skills</th>
                                    <th>Status</th>
                                    <th>Edit</th> --}}
                                
                            </tr>
                        </thead>
                        @isset($joblist)
                            <tfoot>
                                <tr>
                                    <th>title</th>
                                    <th>Email</th>
                                    <th>Name</th>
                                    <th>Create Date</th>
                                    <th>Area Expertise</th>
                                    {{-- <th>location</th> --}}
                                    <th>Status</th>
                                    {{-- <th>Video</th>
                                    <th>Skills</th>
                                    <th>Status</th> --}}
                                    {{-- <th>Edit</th> --}}
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($joblist as $noti)
                               
                                    <tr>
                                        <td>{{ $noti['js_p_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['js_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['js_name'] }}</td>
                                        <td>{{ $noti['js_createdate'] }}</td>
                                        <td>{{ $noti['js_area_expertise'] }}</td>
                                        {{-- <td>{{ $noti['js_loc'] }}</td> --}}
                                        <td>{{ $noti['js_status'] }}</td>
                                        {{-- <td>{{ $noti['js_vids'] }}</td>
                                        <td>{{ $noti['js_skills'] }}</td>
                                        <td>{{ $noti['js_status'] }}</td>
                                        <td>
                                        <a href="{{url('/js/show-js-edit')}}/{{$noti['js_id']}}" class="btn btn-danger"> EDIT</a>
                                            
                                        </td>
                                        <td>
                                        <a href="{{url('/preview/job-seeker')}}/{{$noti['js_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                        </td> --}}
                                        <!-- <td>
                                            @if($noti['js_approved'] == '1')
                                            <button class="btn btn-danger">Put on Hold</button>
                                            @else
                                              @endif
                                        </td> -->
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>


<script>

    $('#notidataTable').DataTable();


</script>
@endsection