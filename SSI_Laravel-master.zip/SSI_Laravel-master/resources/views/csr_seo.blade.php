@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    <div class="intro-img" style="">
        {{-- <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>

    <div class="container" style="padding: 1rem;margin-bottom: 5rem;margin-top:5rem; box-shadow: 1px 4px 4px 4px #e9f3fb;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset($csr_obj['csr_logo'])}}" />
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$csr_obj['csr_g_title']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$csr_obj['csr_org']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">{{$csr_obj['csr_g_amt']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <h4><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_1']}},
                            {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}} ({{$js_loc_obj['addr_zip']}})</h4> --}}
                        <span style="font-size: 14px;"><i class="fa fa-map-marker" aria-hidden="true"></i> {{$csr_obj['csr_loc']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <span style="font-size: 14px;">Email : </span> <a style="font-size: 14px;font-weight: bold;" href="mailto:{{$csr_obj['csr_email']}}">{{$csr_obj['csr_email']}}</a>
                        <br/>
                        <span style="font-size: 14px;">Closing Date : </span> <span style="font-size: 14px;"><b>{{$csr_obj['csr_create_date']}}</b></span>
                    </div>
                </div>
                {{-- <div class="row">
                    <div class="col-12">
                        <h5 style="font-weight: bold"><i class="fa fa-clock-o" style="margin-right: 1rem;"  aria-hidden="true"></i><span class="subDetails">Valid till:</span> {{$csr_obj['jp_closing_date']}}</h5>
                    </div>
                </div> --}}

            </div>
           
        </div>

      

        <div class="row" style="margin-top:2rem;">
            <div class="col-md-12" style="font-size: 14px;">
                <h3><b>Description</b></h3>
                <p style="line-height: 1.5rem;text-align: justify;">
                    {!!htmlspecialchars_decode($csr_obj['csr_desc'])!!}
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                @if (isset($csr_obj['csr_upload_doc']) && $csr_obj['csr_upload_doc'] != "")
                <h3><a target="_blank" class="btn btn-primary" href="{{url($csr_obj['csr_upload_doc'])}}">Download Attachment <i class="fa fa-chevron-right"></i></a></h3>    
                @endif
                
                {{-- <h4 style="font-size:15px;"><a target="_blank" href="{{url($jp_obj['jp_files'])}}">Download File <i class="fa fa-download"></i></a></h4> --}}
            </div>
        </div>
    </div>

</section>

@endsection