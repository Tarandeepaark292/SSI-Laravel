@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Job</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Post Job </li>
            </ol>


            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <div class="row" style="text-align: center;">

                    </div>
                    <form action="{{url('/post-jobpost/submit')}}" method="post" enctype="multipart/form-data"
                        onsubmit="validate(event);">

                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Choose Organization </label>
                                        <select class="form-control" name="org_id" id="org_id" required="required">
                                            <option value="-1">N/A</option>
                                            @foreach ($organizationlist as $organization )
                                            <option value="{{$organization['r_id']}}">{{$organization['r_org_name']}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-lg-12">
                                        <label for="name">Your email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email"
                                            placeholder="you@yourdomain.com" />
                                        <div class="validate"></div>
                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name"> Job title</label>
                                        <input type="text" name="jobtitle" class="form-cntrl" id="jobtitle"
                                            placeholder="e.g. United Nations India looking for “Senior Consultants""  />
                                <div class=" validate"></div>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label for="name">Location </label>
                                    <input type="text" name="location" class="form-cntrl" id="location"
                                        placeholder="e.g.Bengaluru" />
                                    <small class="description">Leave this blank if the location is not important</small>
                                    <div class="validate"></div>
                                </div>
                            </div>

                            <label>Job Type</label>
                            <div class="field required-field">
                                <select name="job_type" id="job_type" class="form-cntrl" style="width:100%;">
                                    <option class="level-0" value="3740">Contribution</option>
                                    <option class="level-0" value="42">Freelance</option>
                                    <option class="level-0" value="39" selected="selected">Full Time</option>
                                    {{-- <option class="level-0" value="3649">Grant</option> --}}
                                    <option class="level-0" value="43">Internship</option>
                                    <option class="level-0" value="40">Part Time</option>
                                    <option class="level-0" value="41">Temporary</option>
                                    <option class="level-0" value="3681">Work from Home</option>
                                </select>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for="name">Area of Expertise</label>
                                    <select name="area" id="area" class="form-cntrl">
                                        <option value="-1">Choose a category… E.g Spotlight, Administration or Research
                                        </option>
                                        <option value="admin">Administration, HR, Management, Accounting/Finance
                                            Executive</option>
                                        <option value="sjkd">Agriculture, Livelihoods, Micro finance, Rural, Urban
                                        </option>
                                        <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer
                                        </option>
                                        <option>Capacity Building, Training, Advocacy</option>
                                        <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                        <option>Chairman, President, CEO, Director, Project Director, Deputy Director
                                        </option>
                                        <option>Disaster, Aid, Emergencies, Relief</option>
                                        <option>Environment, Climate, Energy, Water, Sanitation</option>
                                        <option>Fund-raising Business Development, Grants Writer</option>
                                        <option>Field Officers, Field Associates</option>
                                        <option>Government / Governance, Reforms, Corruption</option>
                                        <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                        <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                        <option>Infrastructure, Technology, Engineering, Science</option>
                                        <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                        <option>Private Sector, Corporate Social Responsibility</option>
                                        <option>Project Associate, Project leaders, Project Assistant</option>
                                        <option>Program Manager, Program Officer, Program Associate, Program Assistant
                                        </option>
                                        <option>Research Analysts, Research Associate, Research Assistant</option>
                                        <option>Social, Gender, Education, Youth, Child</option>
                                        <option>Trade, Finance, Economics, Cooperation, Global</option>
                                        <option>Technology Associate, Technical Assistant, </option>
                                        <option>Teachers, Teachers Educators, Principal</option>
                                    </select>
                                    <div class="validate"></div>
                                </div>
                            </div>
                            <div class="form-row" style="margin-top:1rem;">
                                <div class="form-group col-lg-12">
                                    <label for="name">Description</label>
                                    <textarea class="form-cntrl" name="description" id="summernote" placeholder=""
                                        rows="10" style="height: auto;resize: none;"></textarea>
                                    <div class="validate"></div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label for="name">Application email </label>
                                    <input type="text" name="applicationemail" class="form-cntrl" id="applicationemail"
                                        placeholder="Enter valid email id to receive job application" />

                                    <div class="validate"></div>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label for="name">Closing dates </label> <span> (optional)</span>


                                    <input type="date" name="closingdate" class="form-cntrl" id="closingdate"
                                        placeholder="" />
                                    <small class="description">Deadline for receiving application</small>
                                    <div class="validate"></div>
                                </div>

                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label for="job_jd_file">Job description file (pdf)
                                        <small>(optional)</small></label>
                                    <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text"
                                        accept="application/pdf" data-file_types="pdf" name="files" id="files"
                                        placeholder="">
                                </div>
                            </div>


                            <div class="row">

                                <div class="col-12" style="margin-top: 2rem;">
                                    <h2 style="letter-spacing: 2px;"><span
                                            style="font-weight: bold;">ORGANIZATION</span> DETAILS</h2>
                                </div>
                                <div class="col-12" style="margin-top: 2rem;">
                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Organization Name</label>
                                            <input type="text" name="org_name" class="form-cntrl" id="applications"
                                                value="" placeholder="Organization Name" />

                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">Website </label> <span>(optional)</span>
                                            <input type="text" name="website" class="form-cntrl"
                                                value="" id="website"
                                                placeholder="http://" />

                                            <div class="validate"></div>
                                        </div>

                                    </div>



                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Video<span>(optional)</span> </label>
                                            <input type="text" name="video" class="form-cntrl" id="video"
                                                placeholder="A link to a Video about your organization" />

                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">Twitter username<span>(optional)</span> </label>
                                            <input type="text" name="twitterusername" class="form-cntrl"
                                                id="twitterusername" placeholder="@yourCompany" />

                                            <div class="validate"></div>
                                        </div>



                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="company_logo">Logo <small>(optional)</small></label><br>
                                            <input type="file" class="form-cntrl-file"
                                                data-file_types="jpg|jpeg|gif|png" accept="image/png, image/jpeg"
                                                name="logo" id="_logo" placeholder="">
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name"><b>Current Image</b></label>
                                            {{-- <br> --}}

                                            <img src="" class="" name="" height="120px"
                                                width="120px" alt="">
                                            <input type="hidden" name="old_image" value="">

                                            <div class="validate"></div>
                                        </div>
                                     
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 ml-auto">
                                    <button class="btn btn-primary" style="width:100%; margin-top:1rem">Submit Job
                                        Post</button>
                                </div>
                            </div>
                        </div>

                </div>
                </form>
                </div>
            </section>
            <script>
                function validate(event) {
                    var sel = $('#org_id').val();
                    if (sel === "-1") {
                        alert("Please Select Organization");
                        event.preventDefault();
                    }
                }
            </script>
</main>

@endsection