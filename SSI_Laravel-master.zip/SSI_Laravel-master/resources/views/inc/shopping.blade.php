<script>
    function addTocart(ser_id){
        Utils.showLoading("Adding to Cart ...");
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxaddcart.post') }}",
                data:{ser_id:ser_id},
                success:function(data){
                    Utils.hideLoading();
                    if(data.res == 'SUCCESS'){
                        // $('#btn_layer_'+idx).html(data.data);

                    }else{
                        console.log(data);
                        alert('Problem!! in adding item to cart');
                        // console.log(data.error);
                    }
                }
            });
    }

    
    function addResumeTocart(ser_id,resume_id){
        Utils.showLoading("Adding to Cart ...");
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxaddresumetocart.post') }}",
                data:{ser_id:ser_id,resume_js_id:resume_id},
                success:function(data){
                    Utils.hideLoading();
                    if(data.res == 'SUCCESS'){
                        // $('#btn_layer_'+idx).html(data.data);

                    }else{
                        console.log(data);
                        alert('Problem!! in adding item to cart');
                        // console.log(data.error);
                    }
                }
            });
    }
</script>