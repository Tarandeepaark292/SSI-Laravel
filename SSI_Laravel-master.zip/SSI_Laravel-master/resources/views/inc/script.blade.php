<!-- Vendor JS Files -->
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('js/jquery.easing.min.js')}}"></script>
<script src="{{asset('js/validate.js')}}"></script>
<script src="{{asset('js/counterup.min.js')}}"></script>
<script src="{{asset('js/mobile-nav.js')}}"></script>
<script src="{{asset('js/wow.min.js')}}"></script>
<script src="{{asset('js/isotope.pkgd.min.js')}}"></script>
<script src="{{asset('js/owl.carousel.min.js')}}"></script>
<script src="{{asset('js/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('js/venobox.min.js')}}"></script>
<script src="{{asset('js/jquery.blockUI.js')}}"></script>
<script src="{{asset('js/summernote-bs4.js')}}"></script>
<script src="{{asset('js/paginga.jquery.js')}}"></script>
<script src="{{asset('js/readmore.js')}}"></script>

<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
<!-- Template Main JS File -->
<script src="{{asset('js/utils.js')}}"></script>
<script src="{{asset('js/main.js')}}"></script>
<script>
$(document).ready(function() {
    $('#summernote').summernote({
        height: 200,
        toolbar: [
          
          ['font', ['bold', 'underline', 'clear']],
         
          ['para', ['ul', 'ol', 'paragraph']],
          
          ['view', ['codeview']]
        ]
    });
  });

  function onsubs_chkclick() {
      $('#subs_cates').val('');
      chkeles = $('.subs_chk');
      chkeles.each((index, value) => {
          if ($(value).prop('checked') == true) {
              if ($('#subs_cates').val() === '') {
                  $('#subs_cates').val($(value).val());
              } else {
                  $('#subs_cates').val($('#subs_cates').val() + ',' + $(value).val());
              }

          }
      });
      console.log($('#subs_cates').val());
  }

  function usersubsMsg(event) {
      event.preventDefault();
      console.log($("#subs_msg_dlg #subs_fname").val());
      var subs_fname = $("#subs_msg_dlg #subs_fname").val();
      if (subs_fname.trim().length == 0) {
          alert("Error! Can't send empty message");
          return;
      }
      var subs_lname = $("#subs_msg_dlg #subs_lname").val();
      if (subs_lname.trim().length == 0) {
          alert("Error! Can't send empty message");
          return;
      }
      var subs_email = $("#subs_msg_dlg #subs_email").val();
      if (subs_email.trim().length == 0) {
          alert("Error! Can't send empty message");
          return;
      }
      console.log($("#subs_msg_dlg #subs_fname").val());
      console.log($("#subs_msg_dlg #subs_lname").val());
      console.log($("#subs_msg_dlg #subs_email").val());

      $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxcreatesubs.post') }}",
            data: {
              subs_email: subs_email,
              subs_lname: subs_lname,
              subs_fname: subs_fname,
              subs_desc: $('#subs_cates').val()
            },
            success: function (data) {
                console.log(data);
                if (data.res == 'SUCCESS') {
                    alert("Subscribed");
                    $('#subs_msg_dlg').modal('hide');
                    $('#subs_msg_dlg').modal('hide');
                    $("#subs_msg_dlg #subs_fname").val("");
                    $("#subs_msg_dlg #subs_lname").val("");
                    $("#subs_msg_dlg #subs_email").val("");
                    $('.subs_chk').prop('checked', false); // Unchecks it
                    $('#subs_cates').val('');
                } else {
                    alert("Error in Subscribing");
                }
            }
        });
  }
</script>