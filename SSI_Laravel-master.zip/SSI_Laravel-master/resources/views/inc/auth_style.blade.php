
<!-- Vendor CSS Files -->
<link rel="stylesheet" href="{{asset('css/app.css')}}">
{{-- <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet"> --}}
<link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet">
<link href="{{asset('css/animate.min.css')}}" rel="stylesheet">
<link href="{{asset('css/ionicons.css')}}" rel="stylesheet">
<link href="{{asset('css/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('css/venobox.css')}}" rel="stylesheet">
<link href="{{asset('css/style2.css')}}" rel="stylesheet">