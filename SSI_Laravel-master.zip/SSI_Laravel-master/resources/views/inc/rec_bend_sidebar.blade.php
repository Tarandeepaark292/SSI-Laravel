<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <!-- <div class="sb-sidenav-menu-heading">Core</div> -->
                <a class="nav-link" href="{{ url('/recruiter/dashboard') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                
                <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth"
                            aria-expanded="false" aria-controls="pagesCollapseAuth">Authentication
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                        <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne"
                            data-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="login.html">Login</a><a
                                    class="nav-link" href="register.html">Register</a><a class="nav-link"
                                    href="password.html">Forgot Password</a></nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError"
                            aria-expanded="false" aria-controls="pagesCollapseError">Error
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                        <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne"
                            data-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="401.html">401 Page</a><a
                                    class="nav-link" href="404.html">404 Page</a><a class="nav-link" href="500.html">500
                                    Page</a></nav>
                        </div>
                    </nav>
                </div>

                <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                <a class="nav-link" href="{{url('/recruiter/shop-resume')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Shop Resumes
                </a>
                <a class="nav-link" href="{{url('/recruiter/purchased_resume')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Purchased Resumes
                </a>
                <a class="nav-link" href="{{url('/recruiter/resumes')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Resumes
                </a>
                <a class="nav-link" href="{{url('/recruiter/applicantlist')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Applicant List
                </a>
                <a class="nav-link" href="{{ url('/recruiter/items') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa fa-bell"></i></div>
                    SERVICES
                </a>
                {{-- <a class="nav-link" href="{{ url('/recruiter/csr-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa fa-bell"></i></div>
                    CSR
                </a>
                <a class="nav-link" href="{{ url('/recruiter/rfp-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    FC Grant
                </a>
                <a class="nav-link" href="{{ url('/recruiter/fell-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Fellowship
                </a> --}}
 
 
                <a class="nav-link" href="{{ url('/recruiter/post-grant') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                   Register for grants
                </a>
                <a class="nav-link" href="{{ url('/recruiter/change-password') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-lock"></i></div>
                   Change Password
                </a>
                
                {{-- <a class="nav-link" href="{{ url('/recruiter/event-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                   Events
                </a>

 
                <a class="nav-link" href="{{ url('/recruiter/job-post-list')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Job Posts
                </a>


                <a class="nav-link" href="{{ url('/recruiter/post-csr')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post csr
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-fellowship')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Fellowship
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post_scholarship')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Scholarship
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-rfp')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post FC Grant
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-job-post')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Job 
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-event')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Event
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post_award')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Award
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-grant')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Grant
                </a>

                <a class="nav-link" href="{{ url('/recruiter/post-online-course')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Online Course
                </a>
                <a class="nav-link" href="{{ url('/recruiter/post-publication')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Post Publication
                </a> --}}

                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#paymentcollapseLayouts"
                aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-hand-holding-usd"></i></div>
                    Payments
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>


                
                {{-- <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Motivation
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a> --}}
                <div class="collapse" id="paymentcollapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="{{ url('/recruiter/payment-list')}}">Payment list</a>
                        <a class="nav-link" href="{{ url('/recruiter/purchase-list')}}">Purchases</a>
                    </nav>
                </div>
            </div>
        </div>

    </nav>
</div>
