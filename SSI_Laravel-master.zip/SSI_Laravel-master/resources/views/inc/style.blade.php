<link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,400,500,700"
        rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
<!-- Vendor CSS Files -->
<link rel="stylesheet" href="{{asset('css/app.css')}}">
{{-- <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet"> --}}
<link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet">
<link href="{{asset('css/animate.min.css')}}" rel="stylesheet">
<link href="{{asset('css/ionicons.css')}}" rel="stylesheet">
<link href="{{asset('css/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('css/venobox.css')}}" rel="stylesheet">
<link href="{{asset('css/summernote-bs4.css')}}" rel="stylesheet">
<link href="{{asset('css/custombtn.css')}}" rel="stylesheet">
<link href="{{asset('css/readmore.css')}}" rel="stylesheet">

<link href="{{asset('css/paginga.jquery.css')}}" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <!-- Template Main CSS File -->
    
<link href="{{asset('css/style.css')}}" rel="stylesheet">