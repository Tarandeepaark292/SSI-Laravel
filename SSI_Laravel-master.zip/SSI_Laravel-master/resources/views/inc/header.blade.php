
{{-- <header id="header" class="fixed-top" > --}}
<header id="header" class="" >
    <div class="header-top-2" style="background-color: #0b6bd3;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-sm-12 col-12 header-top-right no-padding">
                    @if(session()->has('ssiapp_rec'))
                    {{-- <a href="{{url('/testpay')}}"><i class="fa fa-shopping-cart" style="margin-right: 2rem;color: white; font-size: 20px;"></i></a> --}}
                    {{-- <span style="color: white;font-size: 1rem">Welcome {{session()->get('ssiapp_rec_name')}} <small>(Recruiter)</small></span> --}}
                        <a href="{{url('/recruiter/dashboard')}}" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">My Account</a>
                        <a href="{{ url('/recruiter/logout') }}" target="_blank" rel="noopener noreferrer" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">
                        Logout <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    @elseif(session()->has('ssiapp_js'))
                    {{-- <a href="{{url('/testpay')}}"><i class="fa fa-shopping-cart" style="margin-right: 2rem;color: white; font-size: 20px;"></i></a> --}}
                    {{-- <span style="color: white;font-size: 1rem">Welcome {{session()->get('ssiapp_js_name')}} </span> --}}
                        <a href="{{url('/js/dashboard')}}" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">My Account</a>
                        <a href="{{ url('/js/logout') }}" target="_blank" rel="noopener noreferrer" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">
                        Logout <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    @elseif(session()->has('ssiapp_adm'))
                        <a href="{{url('/admin/dashboard')}}" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">My Account</a>
                        <a href="{{ url('/admin/logout') }}" target="_blank" rel="noopener noreferrer" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">
                        Logout <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    @else
                        <a href="{{url('/login')}}" target="_blank" rel="noopener noreferrer" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">
                            Login <i class="fa fa-arrow-circle-right"></i>
                            </a>
                    @endif
                    <a href="{{url('/organizer-services')}}" target="_blank" rel="noopener noreferrer" style="color: white;padding: .2rem;padding-left: 1rem;font-size: 1rem;">
                        Post Announcement
                    </a>

                    <div class="social-links" style="display: inline-block">
                        <a href="https://twitter.com/write_to_ssi" class="twitter"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/social.services.india/" class="instagram"><i class="fa fa-instagram"></i></a>
                        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="https://t.me/SocialServicesIndia" class="telegram"><i class="fa fa-telegram"></i></a>
                    </div>



                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid" style="padding-top:5px;padding-bottom:5px;justify-content: space-between;display: flex;">

        <div class="logo float-left" style="margin-top: 1rem;">
            <!-- Uncomment below if you prefer to use an text logo -->
            <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
            <a href="{{ url('/') }}"><img src="{{asset('img/ssi_logo.png')}}" style="margin-top: -1rem;" class="custom-logo" alt="SocialServicesIndia.org" itemprop="logo"></a>
        </div>

        <nav class="main-nav float-right d-none d-lg-block" style="padding-top:5px;">
            <ul>
                
                {{-- <li class="drop-down"><a href="{{url('recruiters')}}">Organization</a>
                    <ul>
                    
                        <li><a href="{{url('organizer-services')}}">Services</a></li>
                        <li><a href="{{url('resumes')}}">Resumes</a></li>
                        @if(session()->has('ssiapp_rec'))
                        <li><a href="{{url('recruiter/csr-list')}}">My Account</a></li>
                        @endif
                    </ul>
                </li>
                <li class="drop-down"><a href="{{url('jobseekers')}}">Jobseekers</a>
                    <ul>
                       
                        <li><a href="{{url('broadcast-resume')}}">Broadcast Resume</a></li>
                       
                    </ul>
                </li> --}}

                {{-- <li class="drop-down"> <a href="#">All Posts</a>
                    <ul>
                        <li><a href="{{url('all-ads')}}">All Ads for RFP</a></li>
                        <li><a href="{{url('all-csr-ads')}}">All Ads for CSR</a></li>
                        <li><a href="{{url('all-fellowship')}}">All fellowship Ads</a></li>
                        <li><a href="{{url('all-event-ads')}}">All Event Ads</a></li>
                        <li><a href="{{url('all-scholarship')}}">All Scholarship Ads</a></li>
                        <li><a href="{{url('all-awards')}}">All Award Ads</a></li>
                        <li><a href="{{url('all-grants')}}">All Grant Ads</a></li>
                        
                    </ul>
                </li> --}}
                <li class="drop-down"><a href="#">Jobseekers</a>
                    <ul>
                        <li><a href="{{url('/all-jobs')}}">Jobs</a></li>
                        <li><a href="{{url('/js/broadcastResume')}}">Broadcast Resume</a></li>
                        
                    </ul>
                </li>
                <li><a href="{{url('/resumes')}}">Resumes</a></li>
                <li><a href="{{url('/all-csr-ads')}}">CSR Grants</a></li>
                <li><a href="{{url('/all-fcgrant-ads')}}">FC Grants</a></li>
                {{-- <li><a href="{{url('/all-donate')}}">Donate</a></li> --}}
                <li><a href="{{url('/all-scholarship')}}">Scholarships</a></li>
                <li><a href="{{url('/all-fellowship')}}">Fellowships</a></li>
                <li><a href="{{url('/all-awards')}}">Awards</a></li>
                <li><a href="{{url('/all-event-ads')}}">Events</a></li>
                <li><a href="{{url('/all-admissions')}}">Admissions</a></li>
                <li><a href="{{url('/all-online-course')}}">Online Courses</a></li>
                <li><a href="{{url('/all-callpaper')}}">Call for Papers</a></li>
                <li><a href="{{url('/all-publication')}}">Publications</a></li>

                <li><a href="{{url('/recruiter/post-grant')}}">Register for Grants</a></li>
                
                {{-- <li><a href="{{url('/all-grants')}}">Grants</a></li> --}}

               
                

             
            </ul>

        </nav><!-- .main-nav -->

    </div>
  
</header><!-- #header -->