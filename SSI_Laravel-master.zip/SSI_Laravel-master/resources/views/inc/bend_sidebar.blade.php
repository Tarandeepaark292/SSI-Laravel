<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <!-- <div class="sb-sidenav-menu-heading">Core</div> -->
                <a class="nav-link" href="{{ url('/admin/dashboard') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <!-- <div class="sb-sidenav-menu-heading">Interface</div> -->
                {{-- <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Motivation
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="{{ url('/moti/images') }}">Images</a>
                        <a class="nav-link" href="{{ url('/moti/videos') }}">Videos</a>
                    </nav>
                </div> --}}

                {{-- <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages"
                    ><div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Pages
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                ></a> --}}
                <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth"
                            aria-expanded="false" aria-controls="pagesCollapseAuth">Authentication
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                        <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne"
                            data-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="login.html">Login</a><a
                                    class="nav-link" href="register.html">Register</a><a class="nav-link"
                                    href="password.html">Forgot Password</a></nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError"
                            aria-expanded="false" aria-controls="pagesCollapseError">Error
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                        <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne"
                            data-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="401.html">401 Page</a><a
                                    class="nav-link" href="404.html">404 Page</a><a class="nav-link" href="500.html">500
                                    Page</a></nav>
                        </div>
                    </nav>
                </div>

                <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                <a class="nav-link" href="{{url('/admin/js_job_list')}}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Resumes
                </a>

                <a class="nav-link" href="{{ url('/admin/organisation/register') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Create Organization
                </a>
                
                <a class="nav-link" href="{{ url('/admin/post_csrfunder') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Post CSR funder
                </a>
                <a class="nav-link" href="{{ url('/admin/post_fcrafunder') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-images"></i></div>
                    Post FCRA funder
                </a>
                <a class="nav-link" href="{{ url('/admin/csr-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa fa-bell"></i></div>
                    CSR
                </a>
                <a class="nav-link" href="{{ url('/admin/rfp-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    FC grant
                </a>
                <a class="nav-link" href="{{ url('/admin/csrfunder-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Csrfunder List
                </a>
                <a class="nav-link" href="{{ url('/admin/fcra-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    FCRA Funder List
                </a>
                <a class="nav-link" href="{{ url('/admin/fell-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Fellowship list
                </a>
                <a class="nav-link" href="{{ url('/admin/sch-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Scholarship list
                </a>
                <a class="nav-link" href="{{ url('/admin/reg-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                   Register for grants
                </a>
                <a class="nav-link" href="{{ url('/admin/event-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                   Event list
                </a>
                <a class="nav-link" href="{{ url('/admin/award-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                   Award list
                </a>
                <a class="nav-link" href="{{ url('/admin/recruiter-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-user-friends"></i></div>
                    Recruiters
                </a>
                {{-- <a class="nav-link" href="#">
                    <div class="sb-nav-link-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                    Job Seekers
                </a> --}}
                <a class="nav-link" href="{{ url('/admin/job-post-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Job Posts
                </a>
                <a class="nav-link" href="{{ url('/admin/news_list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    News list
                </a>
                <a class="nav-link" href="{{ url('/admin/post_news') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Post News
                </a>
                <a class="nav-link" href="{{ url('/admin/banner-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Banners
                </a>
                <a class="nav-link" href="{{ url('/admin/applicants-list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Applicants
                </a>
                <a class="nav-link" href="{{ url('/admin/subscriber_list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Subscriber
                </a>
                

                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#SEOcollapseLayouts"
                aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-hand-holding-usd"></i></div>
                    SEO
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="SEOcollapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="{{url('admin/seo-list')}}">SEO list</a>
                    </nav>
                </div>


                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#paymentcollapseLayouts"
                aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-hand-holding-usd"></i></div>
                    Payments
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                {{-- <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Motivation
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a> --}}
                <div class="collapse" id="paymentcollapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="{{url('admin/rec-purchase-list')}}">Recruiter Purchase list</a>
                        <a class="nav-link" href="{{url('admin/rec-payment-list')}}">Recruiter Payment list</a>
                        <a class="nav-link" href="{{url('admin/js-purchase-list')}}">Jobseeker Purchase list</a>
                        <a class="nav-link" href="{{url('admin/js-payment-list')}}">Jobseeker Payment list</a>
                    </nav>
                </div>
            </div>
        </div>

    </nav>
</div>
