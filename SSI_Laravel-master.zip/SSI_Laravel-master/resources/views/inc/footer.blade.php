<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">


                <div class="col-lg-3 col-md-6 footer-info">
                    {{-- <h3>Social Services India</h3> --}}
                    <img src="{{asset('img/ssi_logo_white.png')}}" alt="" style="width:140px;margin-bottom: 15px">
                    <div class="social-links">
                        <a href="https://twitter.com/write_to_ssi" class="twitter"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/social.services.india/" class="instagram"><i class="fa fa-instagram"></i></a>
                        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="https://t.me/SocialServicesIndia" class="telegram"><i class="fa fa-telegram"></i></a>

                    </div>
                    <p>India's only Independent
                        Platform For NGO's, Voluntary Organizations,
                        NPO's Charitable and Education Institutes</p>
                </div>


                <div class="col-lg-3 col-md-6 footer-links ">
                    <h4>Other Services</h4>
                    <ul>
                        <li><a href="{{url('organizer-services')}}">Services</a></li>
                        <li><a href="{{url('financial-services')}}">Financial Services</a></li>
                        <li><a href="{{url('accounting')}}">Accounting</a></li>
                        <li><a href="{{url('auditing')}}">Auditing</a></li>
                        <li><a href="{{url('tax-compliance')}}">Tax Compliance </a>
                        <li><a href="{{url('fcra-services')}}">FCRA Services</a></li>
                        <li><a href="{{url('email-us')}}">Email &amp; SMS Services</a></li>
                        
                        {{-- <li><a href="{{url('costing-list')}}">Costing List</a></li>
                        <li><a href="{{url('statutory')}}">Statutory Obligation</a></li> --}}
                        {{-- <li><a href="{{url('csr-funders')}}">CSR Funders</a></li>
                        <li><a href="{{url('fcra-funders')}}">FCRA Funders</a></li> --}}
                        
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 footer-links ">
                    <h4>About US</h4>
                    <ul>
                        <li><a href="{{url('about')}}">About Us</a></li>
                        <li><a href="{{url('advertise-us')}}">Advertise With Us</a></li>
                        <li><a href="{{url('contact')}}">Contact</a></li>
                        <li><a href="{{url('org-sector-wise')}}">ORG's Sector
                                Wise</a></li>
                        <li><a href="{{url('state-ut')}}">State and UT </a>
                        <li><a href="{{url('faq')}}">FAQ</a></li>
                        <li><a href="{{url('privacy-policy')}}">Privacy Policy</a></li>
                        <li><a href="{{url('terms-condition')}}">Terms And Conditions</a></li>
                    </ul>
                </div>


                {{-- <div class="col-lg-3 col-md-6 footer-contact">
                    <h4>Contact Us</h4>
                    <p>
                        Social Services India (SSI)<br>
                        Elegant Valley, #FF 111 “A”, Block, 1st Floor,<br>
                        BEML Layout, 3rd Stage,<br>
                        Rajarajeshwari Nagar, Bengaluru,<br>
                        Karnataka, 560 098, India<br>
                        Contact: contact@SocialServicesIndia.org<br>
                    </p>
                </div> --}}
                <div class="col-lg-3 col-md-6 footer-links ">
                    <h4>Directory</h4>
                    <ul>
                        <li><a href="{{url('csr-funders')}}">CSR Funders</a></li>
                        <li><a href="{{url('fcra-funders')}}">FCRA Funders</a></li>
                    </ul>

                    <button type="button" style="width: 100%;margin-top: 2rem;" onclick="$('#subs_msg_dlg').modal('show');" class="btn btn-primary">Subscribe With Us</button>
                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong>SSI</strong>. All Rights Reserved
        </div>
        <div class="credits">

            Designed by <a href="https://aarktechub.com/">AARK Tech Hub</a>
        </div>
    </div>
</footer><!-- End Footer -->

<!-- Modal -->
<div class="modal fade" id="subs_msg_dlg" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="background: #004a99;color: white;">

                <h4 class="modal-title">Subscribe With Us</h4>
                <button type="button" style="color: white;" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">First Name</label>
                        <input class="form-control" id="subs_fname"/>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">Last Name</label>
                        <input class="form-control" id="subs_lname"/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Email</label>
                        <input class="form-control" id="subs_email"/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <input type="checkbox" class="subs_chk proposal_chk_job" id="proposal_chk_job" value="Job Alerts" onclick="onsubs_chkclick()">
                        <label for="proposal_chk_job"> Job Alerts </label>
                        <span style="display: block;font-size: .7rem;margin-top:.5rem;">Get Informed: Receive the latest job alerts according to your areas of expertise each week.</span>
                    </div>
                    
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <input type="checkbox" class="subs_chk proposal_chk_fund" id="proposal_chk_fund" value="Funding Alerts" onclick="onsubs_chkclick()">
                        <label for="proposal_chk_fund"> Funding Alerts </label>
                        <span style="display: block;font-size: .7rem;margin-top:.5rem;">Get Funded: Receive notifications when new funding opportunity are released.</span>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <input type="checkbox" class="subs_chk proposal_chk_other" id="proposal_chk_other" value="Other Communications" onclick="onsubs_chkclick()">
                        <label for="proposal_chk_other"> Other Communications </label>
                        <span style="display: block;font-size: .7rem;margin-top:.5rem;">In addition to any other subscription you choose, we will send you other announcements, fellowships, news, events and latest publications.</span>
                    </div>
                </div>
            </div>
            <input type="hidden" id="subs_cates" name="subs_cates" value="" />
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="usersubsMsg(event)">Subscribe</button>
            </div>
        </div>

    </div>
</div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-192153642-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-192153642-1');
</script>
<!-- JSON-LD markup generated by Google Structured Data Markup Helper. -->
<script type="application/ld+json">
    {
        "@context":"https://schema.org",
        "@type":"ItemList",
        "itemListElement":[
          {
            "@type":"ListItem",
            "position":1,
            "url":"https://socialservicesindia.org/all-csr-ads"
          },
          {
            "@type":"ListItem",
            "position":2,
            "url":"https://socialservicesindia.org/all-fcgrant-ads"
          },
          {
            "@type":"ListItem",
            "position":3,
            "url":"https://socialservicesindia.org/faq"
          }
        ]
      }
    </script>