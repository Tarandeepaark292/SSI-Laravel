@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">online course List</li>
        </ol>
        <div class="row justify-content-center">
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">Approved</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">View Details</a>
                        <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-warning text-white mb-4">
                    <div class="card-body">On Hold</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">View Details</a>
                        <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header" style="display: flex;justify-content: space-between;align-items: center;">
                <div>
                    <i class="fas fa-table mr-1"></i>Online Course List
                </div>
                <div>
                    <i class="fas fa-download mr-1"></i><a href="{{url('/admin/onlinecourse/export')}}" style="color: black"> Download </a>
                </div>
            </div>
            <div class="card-body">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                            aria-controls="home" aria-selected="false">UnExpired</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link " id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                            aria-controls="profile" aria-selected="false">Expired</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent" style="margin-top:2rem;">
                    
                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="table-responsive">
                            @isset($onlist)
                            <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Media</th>
                                        <th>Email</th>
                                        <th>Title</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                
                                    <tfoot>
                                        <tr>
                                            <th>Media</th>
                                            <th>Email</th>
                                            <th>Title</th>
                                            <th>End Date</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        @foreach($onlist as $noti)
                                            <tr>
                                                <td style="word-break: break-all;width: 20%;">{{ $noti['on_media'] }}</td>
                                                {{-- <td style="word-break: break-all;"> --}}
         
                                                <td style="word-break: break-all;">
                                                    {{ $noti['on_email'] }}</td>
                                                <td>   
                                                    {{ $noti['on_institute'] }}
                                                </td>
                                                <td>
                                                    {{ $noti['on_apply'] }}
                                                </td>
                                                
                                                <td id="btn_layer_{{$noti['on_id'] }}">
                                                    @if($noti['on_approved'] == '1')
                                                    <button class="btn btn-danger" onclick="disableonline({{$noti['on_id'] }})">Put on Hold</button>
                                                    @else
                                                    <button class="btn btn-primary" onclick="enableonline({{$noti['on_id'] }})">Approve</button>
                                                    @endif
                                                </td>
        
                                                <td>
                                                    <a href="{{url('/admin/onlinedetail/')}}/{{$noti['on_id']}}" class="btn btn-danger">EDIT</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                            </table>
                            @endisset
                        </div>
                        
                    </div>
                   

                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="table-responsive">
                            @isset($exponlist)
                            <table class="table table-bordered" id="notidataTable2" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Media</th>
                                        <th>Email</th>
                                        <th>Title</th>
                                        <th>End Date</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                
                                    <tfoot>
                                        <tr>
                                            <th>Media</th>
                                            <th>Email</th>
                                            <th>Title</th>
                                            <th>End Date</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        @foreach($exponlist as $noti)
                                        <tr>
                                            <td style="width:20%;">{{ $noti['on_media'] }}</td>
                                            {{-- <td style="word-break: break-all;"> --}}
     
                                            <td style="word-break: break-all;">
                                                {{ $noti['on_email'] }}</td>
                                            <td>   
                                                {{ $noti['on_institute'] }}
                                            </td>
                                            <td>
                                                {{ $noti['on_apply'] }}
                                            </td>
                                            
                                            <td id="btn_layer_{{$noti['on_id'] }}">
                                                @if($noti['on_approved'] == '1')
                                                <button class="btn btn-danger" onclick="disableonline({{$noti['on_id'] }})">Put on Hold</button>
                                                @else
                                                <button class="btn btn-primary" onclick="enableonline({{$noti['on_id'] }})">Approve</button>
                                                @endif
                                            </td>
    
                                            <td>
                                                <a href="{{url('/admin/onlinedetail/')}}/{{$noti['on_id']}}" class="btn btn-danger">EDIT</a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>
                    </div>

                </div>

                
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
    $('#notidataTable2').DataTable();
    function enableonline(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxonlineenable.post') }}",
                data:{on_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in enabling CSR');
                        console.log(data.error);
                    }
               }
            });
    }
    
    function disableonline(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxonlinedisable.post') }}",
                data:{on_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in disabling Event');
                        console.log(data.error);
                    }
                }
            });
    }
</script>
<script>
   
</script> 
@endsection
