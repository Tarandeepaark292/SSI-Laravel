@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Edit CSR </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organizer Panel</li>
                <li class="breadcrumb-item active">Update CSR</li>
            </ol>

            <!-- {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post Jobseeker 
            </header> -->
            <!-- </div> --}} -->

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/updatecsr')}}/{{$jp_obj['csr_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Your Organisation </label>
                                        <input type="text" name="org" class="form-cntrl" id="org"
                                            placeholder="Name of  the organisation" style="width:100%;"
                                            value="{{$jp_obj['csr_org']}}" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="loc" class="form-cntrl" id="loc"
                                            placeholder="Grant title" style="width:100%;"
                                            value="{{$jp_obj['csr_loc']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grand Amount</label>
                                        <input type="text" name="amt" class="form-cntrl" id="amt" placeholder=""
                                            style="width:100%;" value="{{$jp_obj['csr_g_amt']}}" />

                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing dates for Proposal</label>

                                        <input type="text" name="date" class="form-cntrl" id="date" placeholder=""
                                            value="{{$jp_obj['csr_close_date']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Applicant Email</label>
                                        <input type="text" class="form-cntrl" name="email" id="email"
                                            placeholder="Address Line 1" data-rule="email"
                                            data-msg="Please enter a valid Address Line 1"
                                            value="{{$jp_obj['csr_email']}}" />
                                    </div>
                                </div>
                                <div class="form-row" style="margin-top:1rem;">
                                    <label for="company_logo">Description of the proposal</label><br>
                                    <textarea class="form-cntrl" name="desc" id="summernote" placeholder="" rows="10" style="height: auto;resize: none;">
                                        {{$jp_obj['csr_desc']}}
                                        </textarea>
                                        {{-- <div class="form-group col-lg-12">
                                            
                                            <input class="form-cntrl" name="desc" id="summernote" placeholder="" rows="10"
                                                value="{{$jp_obj['csr_desc']}}"
                                                style="height: auto;resize: none;"></input>
                                            <div class="validate"></div>
                                        </div> --}}
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    {{-- </div> --}}
                                    <!-- <div class="form-group col-lg-6">
                                        <label for="name">Address Line 2</label>
                                        <input type="text" class="form-cntrl" name="jsaddrline2" id="jsaddrline2"
                                            placeholder="Address Line 2(Optional)" data-rule="email"
                                            data-msg="Please enter a valid Address Line 2" />
                                    </div> -->
                                </div>
                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload Proposal Document</label><br>
                                        <input type="file" class="form-cntrl-file" name="document" id="document"
                                            data-file_types="doc|pdf|text" accept="application/pdf"
                                            placeholder="Add Media" value="{{$jp_obj['csr_upload_doc']}}">
                                        <input type="hidden" name="old_document" value="{{$jp_obj['csr_upload_doc']}}">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation label</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="company_logo" id="img"
                                            placeholder="Add Media" value="{{$jp_obj['csr_logo']}}">
                                        <input type="hidden" name="old_company_logo" value="{{$jp_obj['csr_logo']}}">
                                    </div>
                                </div>

                                <!-- </div> -->



                                <div class="form-row">

                                    <div class="form-group col-lg-6">

                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder=""
                                            value="{{$jp_obj['csr_ref_url']}}" />

                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Your Title </label>
                                        <input type="text" name="title" class="form-cntrl" id="title"
                                            placeholder="Comma seperate a list of relevent skills" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"
                                            value="{{$jp_obj['csr_g_title']}}" />
                                    </div>
                                </div>

                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="{{$jp_obj['csr_category']}}" />
                                </div>
                                @endisset





                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:30%"> Update Data
                                        </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
        <!-- </div> -->
    </section>

    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>


</main>

@endsection
