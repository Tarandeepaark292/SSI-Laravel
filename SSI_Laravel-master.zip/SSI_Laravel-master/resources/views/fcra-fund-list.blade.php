@extends('layouts.home')
@section('content')
        <section id="State and UT" style="">
        {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

    <div class=" container">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">FCRA funder</span> <span class="titleheading">List</span> </h3>
        </header>


        

      
        <!-- <div class="col-12"> -->
            <div class="form-row mt-5">
                <div class="form-group col-lg-6">
                    <form class="searchform">
                        <input type="text" placeholder="Search.." id="filter">
                        {{-- <button type="" onclick="myfunction(event)"><i class="fa fa-search"></i></button> --}}
                    </form>
    
    
                </div>
    
    
    
    
    
                <div class="form-group col-lg-6">
                    @isset($b_f_obj)
                    <!-- if(count($home)>1){ -->
                        <select name="focus Area" id="filters" name="filters" class="form-control">
                            <option value="">Focus Area</option>                    
                        @foreach($b_f_obj as $res)

                        <option value="{{$res['cate_id']}}">{{$res['cate_name']}}</option>
                        {{-- <option></option> --}}
                    @endforeach
                </select>
                    
                    @endisset
    
                </div>
    
                <div class="col-12">
                    <form class="searchform">
                        <button type="" style="width:100%;" onclick="myfunction(event)"><i
                                class="fa fa-search"></i> SEARCH </button>
                    </form>
                </div>
            </div>

 

            <div id="search_results" style="width: 100%;">

            <div class="container"  style="margin-top:2rem;margin-bottom: 5rem;">
               
                <table class="table-responsive-md table-hover"  id="searchtbl" >
                    <thead>
                        <tr>
                            <th scope="col">NO.</th>
                            <th scope="col">Organisation Name</th>
                            <th scope="col">Link</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        
                       
                            
                        @isset($f_f_obj)         
                        @foreach($f_f_obj as $noti)
                        <tr>
                            <td>
                                <strong>{{$loop->index + 1}}</strong>
                            </td>
                            <td>
                               {{$noti['f_f_org_name']}}
                            </td>
                            
                            <td>
                                <a href="{{url("/fcra-funder/")}}/{{$noti['f_f_seo']}}" target="_blank" style="font-weight: bold">Details</a>
                            </td>
                        </tr>
                        @endforeach
                        @endisset
                    </tbody>
                </table>
                {{-- @endisset --}}
            </div>
            </div>
            </div>
        </section>

        <script>
            function myfunction(e) {
                e.preventDefault();
                // alert('gh');
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    dataType: "json",
                    url: "{{ route('ajaxfcrafunder.post') }}",
                    data: {
                        focus: $('#filter').val(),
                        state: $('#filters').val(),
                    },
                    success: function (data) {
                        // alert('');
                        console.log(data);
                        if (data.res == 'SUCCESS') {
                            // alert(data.data);
                            d = data.data;
                            // d = JSON.stringify(d);
                            console.log(d);
                            // alert(d);
                            $('#search_results').html(d);
                            $('#searchtbl').DataTable({
                                "paging":   true,
                                "ordering": false,
                                "info":     false,
                                "pageLength": 20,
                                "lengthChange": false
                            } );
                        } else {
                            $('#search_results').html(data.error);
                            // alert(data.error);
                        }
                    }
                });
            }
        
        </script>
    @endsection

    @section('custom_script')
        <script>
          
    $('#searchtbl').DataTable({
        "paging":   true,
        "ordering": false,
        "info":     false,
        "pageLength": 20,
        "lengthChange": false
    } );

        </script>
    @endsection