@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset($jp_obj['award_upload_banner']) }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div> --}}


    <div class="container" style="padding: 1rem;margin-bottom: 5rem;margin-top:5rem; box-shadow: 1px 4px 4px 4px #e9f3fb;">

        

        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset($on_obj['on_logo'])}}" />
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$on_obj['on_detail']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$on_obj['on_institute']}}</span>
                    </div>
                </div>

                {{-- <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;font-size: 14px;">{{$on_obj['on_url']}}</span>
                    </div>
                </div> --}}
                <div class="row">
                    <div class="col-12">
                        {{-- <h5 style="font-weight: bold"><span class="subDetails">Application Email:</span> {{$csr_obj['jp_app_email']}}</h5> --}}
                        <i class="fa fa-calendar  mr-2" aria-hidden="true"></i> <span style="font-size: 14px;">Closing Date : </span> <span style="font-size: 14px;"><b>{{$on_obj['on_apply']}}</b></span>
                        <br>
                        <i class="fa fa-link ml-1 mr-2" aria-hidden="true"></i> <a style="color: #004a99;margin-bottom: 2px;font-weight: bold;font-size: 14px;" href="{{$on_obj['on_url']}}" target="_blank">{{$on_obj['on_url']}}</a></br>
                    </div>
                </div>
              
                {{-- <div class="row">
                    <div class="col-12">
                        <h5 style="font-weight: bold"><i class="fa fa-clock-o" style="margin-right: 1rem;"  aria-hidden="true"></i><span class="subDetails">Valid till:</span> {{$csr_obj['jp_closing_date']}}</h5>
                    </div>
                </div> --}}

            </div>
           
        </div>

      

        <div class="row" style="margin-top:2rem;">
            <div class="col-md-12" style="font-size: 14px;">
                <h3><b>Description</b></h3>
                <p style="line-height: 1.5rem;text-align: justify;">
                    {!!htmlspecialchars_decode($on_obj['on_display'])!!}
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
               
                @if (isset($on_obj['on_pdf_doc']) && $on_obj['on_pdf_doc'] != "")
                <h3><a target="_blank" class="btn btn-primary" href="{{url($on_obj['on_pdf_doc'])}}">Download Attachment <i class="fa fa-chevron-right"></i></a></h3>
                @endif
                {{-- <h4 style="font-size:15px;"><a target="_blank" href="{{url($jp_obj['jp_files'])}}">Download File <i class="fa fa-download"></i></a></h4> --}}
            </div>
        </div>

    </div>



    


</section>



@endsection
