@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container">
            <h1 class="mt-4">Change Password</h1>

            <section>

                <div class="container" style="margin-bottom: 5rem;">
                    <form action="{{ url('/recruiter/rec_password/update') }}/{{session()->get('ssiapp_rec_id')}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="margin-top: 2rem;">
                            <div class="col-12" style="border: 0;">
                                <div class="tr-single-box">
                                    <div class="tr-single-header">
                                        <h4 class="mt-4"><i class="fas fa-lock"></i> Password</h4>
                                    </div>
                                    <div class="tr-single-body" style="height: auto;">
                                        <div class="form-row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">New Password </label>
                                                <input type="password" name="newpassword" class="form-cntrl" id="name"
                                                    placeholder="" style="width:100%;"
                                                    value=""
                                                    required />
                                               
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <label for="name">Confirm  Password </label>
                                                <input type="password" name="confirmpassword" class="form-cntrl" id="email"
                                                    placeholder="" style="width:100%;"
                                                    value=""
                                                    required />
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="margin-top:1rem;">
                            <div class="col-md-12">
                                <button class="btn btn-primary btn-register" style="width: 100%;background: #006AC7 !important;padding: 1rem;"> Update Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </section>
</main>

@endsection