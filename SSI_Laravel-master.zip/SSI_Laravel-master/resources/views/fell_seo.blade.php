@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    <div class="intro-img" style="">
        {{-- <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>

    <div class="container" style="padding: 1rem;margin-bottom: 5rem;margin-top:5rem; box-shadow: 1px 4px 4px 4px #e9f3fb;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset($jp_obj['fell_o_logo'])}}" />
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12">
                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$jp_obj['fell_title']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <span style="margin-bottom: 2px;font-weight: bold;color: #004a99;font-size: 14px;">{{$jp_obj['fell_o_name']}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <span style="margin-bottom: 2px;font-weight: bold;font-size: 1rem;">{{$jp_obj['rfp_g_amt']}}</span> --}}
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        {{-- <h4><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_1']}},
                            {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}} ({{$js_loc_obj['addr_zip']}})</h4> --}}
                        <span style="font-size: 14px;"><i class="fa fa-map-marker" aria-hidden="true"></i> {{$jp_obj['fell_loc']}}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        {{-- <h5 style="font-weight: bold"><span class="subDetails">Application Email:</span> {{$jp_obj['jp_app_email']}}</h5> --}}
                        <span style="font-size: 14px;">Email : </span> <a style="font-size: 14px;font-weight: bold;" href="mailto:{{$jp_obj['fell_email']}}">{{$jp_obj['fell_email']}}</a>
                        <br>
                        <i class="fa fa-calendar ml-1 mr-2" aria-hidden="true"></i> 
                        Closing Date :  
                        <b>{{$jp_obj['fell_end_date']}}</b> </br>
                        <i class="fa fa-link ml-1 mr-2" aria-hidden="true"></i> <a style="color: #004a99;margin-bottom: 2px;font-weight: bold;font-size: 14px;" href="{{$jp_obj['fell_url']}}" target="_blank">{{$jp_obj['fell_url']}}</a></br>
                    </div>
                </div>
                

            </div>
           
        </div>

       

        <div class="row">
            <div class="col-md-12" style="font-size: 14px;">
                <h3><b>Description</b></h3>
                <p style="line-height: 1.5rem;text-align: justify;">
                    {!!htmlspecialchars_decode($jp_obj['fell_desc'])!!}
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @if (isset($jp_obj['fell_upload_doc']) && $jp_obj['fell_upload_doc'] != "")
                <h3><a target="_blank" class="btn btn-primary" href="{{url($jp_obj['fell_upload_doc'])}}">Download Attachment <i class="fa fa-chevron-right"></i></a></h3>
                {{-- <h4 style="font-size:15px;"><a target="_blank" href="{{url($jp_obj['jp_files'])}}">Download File <i class="fa fa-download"></i></a></h4> --}}
                @endif
            </div>
        </div>

    </div>

</section>

@endsection