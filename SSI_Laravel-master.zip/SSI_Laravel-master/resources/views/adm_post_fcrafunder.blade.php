@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Post FCRA Funder</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Post FCRA Funder</li>
        </ol>
        <div class="row">
            <div class="col-12">

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">


            </div>
        </div>
        <div class="row" style="text-align: center;">
            <div class="col-12">

            </div>

        </div>

        <form action="{{url('/admin/fcrafunder/submit')}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            @csrf


            <div class="row">
                <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;background:#f0f2f4;padding: 1rem;">

                    <div class="form-row">



                        <div class="form-group col">
                            <label for="name">Organisation Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="org_name" placeholder="Organization name"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                    </div>


                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label for="name">Website</label>
                            <input type="text" name="Website" class="form-cntrl" id=""
                                placeholder="Website" data-rule="minlen:4"
                                data-msg="Please enter at least 4 chars" required />
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-12">
                            <label for="name">Organisation Details</label>
                            <textarea id="summernote" class="form-cntrl" name="org_detail" rows="10"
                                style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>

                        </div>
                    </div>



                    @isset($html)
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <h4>Focus Area</h4>
                        </div>
                        {{-- <div class="form-group col-lg-12"> --}}
                        {!! $html !!}
                        {{-- </div> --}}
                        <input type="hidden" id="cates" name="cates" value="" />
                    </div>
                    @endisset

                    <div class="form-row">
                        
                        <div class="form-group col-lg-12">
                            <label for="name">Address</label>
                            <textarea id="summernote2" class="form-cntrl" name="address" rows="5"
                            style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>
                        </div>

                        

{{-- 

                        <div class="col-lg-12">
                            <label for="company_logo">Image</label><br>
                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                accept="image/png, image/jpeg" name="image" id="" placeholder="Add Media">
                        </div> --}}

                        <div class="form-group col-lg-12">
                            <label for="name">Email</label>
                            <input type="text" name="Email" class="form-cntrl" id="" placeholder="Email"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group col-lg-12">
                            <label for="name">Contact</label>
                            <input type="text" name="contact" class="form-cntrl" id="" placeholder="Contact"
                                data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                            <div class="validate"></div>
                        </div>


                    </div>





                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12">

                            <button class="btn btn-primary" style="width:40%">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            function onchkclick(){
                $('#cates').val('');
                chkeles = $('.proposal_chk');
                chkeles.each((index,value)=>{
                    if($(value).prop('checked') == true){
                        if($('#cates').val() === ''){
                            $('#cates').val( $(value).val());
                        }else{
                            $('#cates').val( $('#cates').val() + ',' + $(value).val());
                        }
                        
                    }
                });
                console.log($('#cates').val());
            }
        </script>
</main>
@endsection
