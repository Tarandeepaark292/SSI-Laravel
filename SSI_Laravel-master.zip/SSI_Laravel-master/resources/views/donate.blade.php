@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Donation </span>
        </header>

        <!-- <div class="col-12"> -->
        <div class="form-row mt-5">
            <div class="form-group col-lg-6">

                <select name="state" id="filters" class="form-control">
                    <option value="">Select state</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Chandigarh">Chandigarh</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                    <option value="Daman and Diu">Daman and Diu</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Lakshadweep">Lakshadweep</option>
                    <option value="Puducherry">Puducherry</option>
                    <option value="Goa">Goa</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Mizoram">Mizoram</option>
                    <option value="Nagaland">Nagaland</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Uttarakhand">Uttarakhand</option>
                    <option value="West Bengal">West Bengal</option>
                </select>


            </div>





            <div class="form-group col-lg-6">

                <select name="focus Area" id="filter" class="form-control">

                    <option value="">Focusarea</option>
                    <option value="Womenandgirls">Women and Girls</option>
                    <option value="Health">Health</option>
                    <option value="Environment">Environment</option>
                    <option value="Hunger">Hunger</option>
                    <option value="AnyOther">Any other</option>
                </select>


            </div>

            <div class="col-12">
                <form class="searchform">
                    <button type="" style="width:100%;" onclick="myfunction(event)"><i
                            class="fa fa-search"></i> SEARCH </button>
                </form>
            </div>
        </div>


        <div class="row">

        </div>





        <div id="search_results" style="width: 100%;">
            @isset($donatesearch)
            @foreach($donatesearch as $res)
            <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content fell_search_item" id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">

                            <div class="col-md-2" style="text-align: center;">
                                <img style="width:80%" src="{{ asset($res['donate_logo']) }}" />
                            </div>
                            <div class="col-md-7">
                                <div class="results limittext"  style="font-weight: bold;font-size: 20px;">
                                    {{ $res['donate_solution'] }}</div>
                                <div id="results">
                                    <p class="limittext"> {{ $res['donate_org_detail'] }}</p>
                                </div>
                                <div id="results">
                                    <i class="fa fa-map-marker" aria-hidden="true"
                                        style="color:#007bff;font-size: 18px;"></i> <span
                                        style="font-weight: bold;color:#007bff;font-size:16px;">{{ $res['donate_state'] }}</span>

                                </div>
                                <div id="results">
                                    <span
                                        style="font-weight: bold;color:#007bff;font-size:16px;">{{ $res['donate_foc_Area'] }}</span>

                                </div>
                                
                            </div>
                            <div class="col-md-3 my-auto ">
                                <div id="results" style="color:#293e09;font-size: 18px;">
                                    <a href="{{url('/donate/')}}/{{$res['donate_SEO']}}" class="btn btn-newprimary">Details</a>
                                </div>
                            </div>





                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            @endisset
        </div>







    </div>







    </div>
    </div>
</section>


<script>
    function myfunction(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxDonate.post') }}",
            data: {
                focus: $('#filter').val(),
                state: $('#filters').val(),
            },
            success: function (data) {
                console.log(data);
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error);
                }
            }
        });
    }

</script>
@endsection
