@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    {{-- <div class="intro-img" style="margin-bottom:5rem;">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div> --}}
    

    <div class="container" style="background: #ffffff;padding: 1rem;margin-bottom: 5rem;font-size: 16px;">
        <div class="row">
            {{-- <div class="col-md-4">
                <img style="width: 100%;border:4px solid white;" src="{{asset($news_obj["news_image"])}}"/>
            </div> --}}
            <div class="col-md-12">
                <div class="row">
                    <div class="col-12" style="text-align: center;">
                        <b style="font-size:24px;">{{$f_f_obj["f_f_org_name"]}}</b>
                    </div>
                </div>
                <div class="row" style="margin-top:1rem;">
                    <div class="col-12">
                        <div class="container-fluid" style="padding-top: 1rem;padding-bottom:1rem;padding-left: 0px">
                            <div class="row">
                                <div class="col-12">
                                    {{-- <span>Details of the Organisation</span> --}}
                                    <div style="text-align: left;font-weight: bold">{!!$f_f_obj["f_f_org_detail"]!!}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top:1rem;">
                    <div class="col-12">
                        <span style="font-size: 12pt;"><b>Focus Area</b></span>
                        <p>{{$f_f_obj["f_f_focus_area"]}}</p>
                    </div>
                </div>
                <div class="row" style="margin-top:1rem;">
                    <div class="col-12">
                        <span style="font-size: 12pt;"><b>Website</b></span>
                        <p><i class="fa fa-link" aria-hidden="true"></i> <a style="" href="{{$f_f_obj["f_f_web"]}}" target="_blank"> {{$f_f_obj["f_f_web"]}} </a></p>
                    </div>
                </div>
                <div class="row" style="margin-top:1rem;">
                     <div class="col-6">
                        <span style="font-size: 12pt;"><b>Email</b></span>
                        <p>{{$f_f_obj["f_f_email"]}}</p>
                    </div>
                    <div class="col-6">
                        <span style="font-size: 12pt;"><b>Contact</b></span>
                        <p>{{$f_f_obj["f_f_contact"]}}</p>
                    </div>
                   
                </div>
                
                {{-- <div class="row">
                    <div class="col-12">
                        <span>Website</span>
                        <h6><i class="fa fa-link" aria-hidden="true"></i> <a style="font-weight: bold" href="{{$c_f_obj["c_f_web"]}}" target="_blank"> {{$c_f_obj["c_f_web"]}} </a></h6>
                    </div>
                </div> --}}
            </div>
        </div>
        {{-- <div class="row">
            <div class="col-12">
                <div class="container-fluid" style="padding-top: 1rem;padding-bottom:1rem;padding-left: 0px">
                    <div class="row">
                        <div class="col-12">
                            <span>Details of the Organisation</span>
                            <div style="text-align: left;font-weight: bold">{!!$c_f_obj["c_f_org_detail"]!!}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}
        <div class="row" style="margin-top:1rem;">
            <div class="col-12">
                <span style="font-size: 12pt;"><b>Address</b></span>
                <p>{!!$f_f_obj["f_f_addr"]!!}</p>
            </div>
        </div>
                {{-- <div class="row">
                    <div class="col-12">
                        <span>Focus Area</span>
                        <h6 style="font-weight: bold">{{$f_f_obj["f_f_focus_area"]}}</h6>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <span>Contact</span>
                        <h6 style="font-weight: bold">{{$f_f_obj["f_f_contact"]}}</h6>
                    </div>
                    <div class="col-6">
                        <span>Email</span>
                        <h6 style="font-weight: bold">{{$f_f_obj["f_f_email"]}}</h6>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12">
                        <span>Website</span>
                        <h6><i class="fa fa-link" aria-hidden="true"></i> <a style="font-weight: bold" href="{{$f_f_obj["f_f_web"]}}" target="_blank"> {{$f_f_obj["f_f_web"]}} </a></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="container-fluid" style="padding-top: 1rem;padding-bottom:1rem;padding-left: 0px">
                    <div class="row">
                        <div class="col-12">
                            <span>Details of the Organisation</span>
                            <div style="text-align: left;font-weight: bold">{!!$f_f_obj["f_f_org_detail"]!!}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <span>Address</span>
                <h6 style="font-weight: bold">{!!$f_f_obj["f_f_addr"]!!}</h6>
            </div>
        </div> --}}

    </div>


</section>

@endsection

