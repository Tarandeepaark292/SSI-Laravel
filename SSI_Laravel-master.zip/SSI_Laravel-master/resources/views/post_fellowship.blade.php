@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post Fellowship</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Post Fellowship </li>
        </ol>

        @if(session()->has('ssiapp_rec'))
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">

                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4 style="font-weight: bold;"><span class="titleheading">Post Fellowship Ad </span> </h4>
                    </header>


                    <!-- <form action="#" method="post" id="submit-job-form" class="job-manager-form" enctype="multipart/form-data"></form> -->



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/fellowship/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="name" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Fellowship Title </label>
                                        <input type="text" name="title" class="form-cntrl" id="title"
                                            placeholder="Fellowship Title" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="Location" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">

                                    <div class="form-group col-lg- 12">
                                        <label for="name">Organisation logo</label>
                                        <input type="file" name="org_logo" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" class="form-cntrl" id="file" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6" style="position:relative">
                                        <label for="company_logo">Deadline date</label><br>
                                        <input type="date" class="form-cntrl"  name="deadlinedate" id="deadlinedate"
                                            placeholder="Deadline Date">
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label>Email</label>
                                        <input type="text" class="form-cntrl" name="email" id="email"
                                            placeholder="Enter valid email id to receive Fellowship Application">

                                        <div class="validate"></div>
                                    </div>

                                </div>
                                {{-- <div class="form-group col-lg-12">
                                    <label for="company_logo">Description of the fellowshp</label><br>
                                    <input type="file" data-file_types="doc|pdf|text" accept="application/pdf"
                                        name="file" id="file">
                                </div> --}}
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the fellowship</label><br>
                                        <textarea class="form-cntrl" name="desc_textarea" id="summernote" placeholder=""
                                            rows="10" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Fellowship Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="" />
                                </div>
                            @endisset
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text"
                                            accept="application/pdf" name="upload" id="upload">
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url"
                                            placeholder="Insert Website link" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                {{-- <div class="form-group col-lg-12">
                                    <label name=""> Fellowship Category</label>
                                    <br>
                                    <input class='proposal_chk' type="checkbox" onclick="onchkclick();" id="" value="fellowship">
                                    <label for="vehicle1"> Fellowship</label><br>
                                    <input class='proposal_chk' type="checkbox" id="" onclick="onchkclick();"  value="scholarship">
                                    <label for="vehicle2"> Scholarship</label><br>
                                    <input type="hidden" id="cates" name="cates" value="" />
                                </div> --}}
                                <div class="form-row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">
        
                                        <button class="btn btn-primary  btn-register" style="margin-top:10;">
                                            Submit Fellowship</button>
                                    </div>
                                </div>
                            </div>


                            

                            {{-- <div class="col-lg-12">
                                <label name=""> Fellowship Category</label>
                                <br>
                                <input type="checkbox" id="" name="cates[]" value="fellowship">
                                <label for="vehicle1"> Fellowship</label><br>
                                <input type="checkbox" id="" name="cates[]" value="scholarship">
                                <label for="vehicle2"> Scholarship</label><br>

                            </div> --}}
                        </div>

                        {{-- <div class="row">
                            <div class="col-md-12">
                                <label>Human Check 6+9=</label>

                                <input type="text" name="" class="form-cntrl" id="" placeholder="" />


                            </div>
                        </div> --}}






                        

                    </form>
                </div>



            </section>




        @else
            <div class="row about-container">
                <div class="col-lg-12">

                    <hr style="color:#007bff;border:3px solid;">
                    <p class="card-text"><i>Please login to submit Fellowship Ad.</i> <a
                            href="{{url('/login')}}"
                            class="btn btn-primary">Login</a></p>

                    <p style="margin-top: 30px; font-size: 1rem;">
                        For any further assistance our experts will get in touch with you and take it forward.
                        <br /><br />
                        Please email us at: <b>contact@SocialServicesIndia.com</b> for <b>Queries</b>
                    </p>
                </div>
            </div>
        @endif


    </div>
    </section>
    <script>
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>
</main>

@endsection