@extends('layouts.auth_home')
@section('content')

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            {{-- <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="" /> --}}
            <a href="{{url('/')}}"><img src="{{asset('img/ssi_logo_white.png')}}" alt="" /></a>
            <h3>Welcome</h3>
            
            <a class="pagelink" href="{{url('/register')}}">Sign Up</a><br />
        </div>

        <div class="col-md-9 register-right">
            <div class="row">
                <div class="col-12">
                    <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                        <!-- <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                aria-controls="home" aria-selected="true">Jobseeker</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                aria-controls="profile" aria-selected="false">JobSeeker</a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="tab-content" id="myTabContent">
                
                <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <h3 class="register-heading">Reset Password For an Jobseeker</h3>
                    <form action="{{url('/js/resetpwd')}}" method="post">
                        <div class="row register-form">
                            <div class="col-md-9  mx-auto">
                                {{-- <h3 class="">Login as a Recruiter</h3> --}}
                                <div class="form-group">
                                    <label for="email">Enter Email Associated with the Account</label>
                                    <input type="email" name="email" class="form-control"
                                         placeholder="Your Email *" value="" />
                                         @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>

                                

                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h5 style="color:red">{{$errors->first()}}</h5>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" class="btnRegister" 
                                    value="Submit" />

                            </div> <!-- </div> -->
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection