@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Fellowship List</li>
        </ol>
        
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Fellowship List</div>
            <div class="card-body">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                            aria-controls="home" aria-selected="false">UnExpired</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                        <a class="nav-link " id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                            aria-controls="profile" aria-selected="false">Expired</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent" style="margin-top:2rem;">
                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                        @isset($felllist)
                        <div class="table-responsive">

                            <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Fellowship Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>End Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>

                                <tfoot>
                                    <tr>
                                        <th>Fellowship Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>End Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @foreach($felllist as $noti)
                                    <tr>
                                        <td>{{ $noti['fell_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_o_name'] }}</td>
                                        <td>{{ $noti['fell_end_date'] }}</td>
                                        <td>{{ $noti['fell_submitted_by'] }}</td>
                                        <td>{{ $noti['fell_status'] }}</td>
                                        <td>

                                            <a class="btn btn-outline-secondary"
                                                href="{{url('/admin/felldetail/')}}/{{$noti['fell_id']}}">Edit</a>
                                        </td>
                                        <td id="btn_layer_{{$noti['fell_id'] }}">
                                            @if($noti['fell_approved'] == '1')
                                            <button class="btn btn-danger"
                                                onclick="disableFell({{$noti['fell_id'] }})">Put on Hold</button>
                                            @else
                                            <button class="btn btn-primary"
                                                onclick="enableFell({{$noti['fell_id'] }})">Approve</button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>

                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        @isset($expfelllist)
                        <div class="table-responsive">

                            <table class="table table-bordered" id="notidataTable2" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Fellowship Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>End Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>

                                <tfoot>
                                    <tr>
                                        <th>Fellowship Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>End Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @foreach($expfelllist as $noti)
                                    <tr>
                                        <td>{{ $noti['fell_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['fell_o_name'] }}</td>
                                        <td>{{ $noti['fell_end_date'] }}</td>
                                        <td>{{ $noti['fell_submitted_by'] }}</td>
                                        <td>{{ $noti['fell_status'] }}</td>
                                        <td>

                                            <a class="btn btn-outline-secondary"
                                                href="{{url('/admin/felldetail/')}}/{{$noti['fell_id']}}">Edit</a>
                                        </td>
                                        <td id="btn_layer_{{$noti['fell_id'] }}">
                                            @if($noti['fell_approved'] == '1')
                                            <button class="btn btn-danger"
                                                onclick="disableFell({{$noti['fell_id'] }})">Put on Hold</button>
                                            @else
                                            <button class="btn btn-primary"
                                                onclick="enableFell({{$noti['fell_id'] }})">Approve</button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>





                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
    $('#notidataTable2').DataTable();

    function enableFell(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxFELLenable.post') }}",
                data:{fell_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                        location.reload();
                    }else{
                        alert('Problem!! in enabling CSR');
                        console.log(data.error);
                    }
               }
            });
    }
    
    function disableFell(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxFELLdisable.post') }}",
                data:{fell_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                        location.reload();
                    }else{
                        alert('Problem!! in disabling Event');
                        console.log(data.error);
                    }
                }
            });
    }
    </script>
@endsection
