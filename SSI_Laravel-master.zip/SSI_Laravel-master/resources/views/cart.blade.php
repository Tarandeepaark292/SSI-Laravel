@extends('layouts.home')
@section('content')
<style>
    .razorpay-payment-button{
        background: #2055df!important;
        border: 0;
        box-shadow: #2055df 1px 1px 5px;
        width: 100%;
        color: white;
        border-radius: 3px;
        font-size: 24px;
        font-weight: bold;
        font-variant: all-petite-caps;
        height: 42px;
    }
    .razorpay-payment-button:hover{
        box-shadow:none;
    }
</style>
<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Shopping </span> <span class="titleheading">Cart</span></h3>
        </header>



        @isset($error_data)
        <div class="row">
            <div class="col-md-8 m-auto">
                <div class="card" style="padding:2rem;text-align: center;">
                    {!! $error_data !!}
                </div>
            </div>
        </div>
        @endisset
        
        @isset($cart_items)
        <div class="row">
            <div class="col-md-8">
                
                <div class="row">
                    <div class="col-12">
                        <div class="card" style="border:none;border-radius:0px;">
                            <div class="card-header" style="border:none;border-radius:0px; background-color:#30AFC0;color:white;">
                                <div class="row" >
                                    <div class="col-2">
                                        #
                                    </div>
                                    <div class="col-4">
                                        Service Name
                                    </div>
                                    <div class="col-2">
                                        Qty
                                    </div>
                                    <div class="col-4 text-right">
                                        Total
                                    </div>
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>

                @foreach($cart_items as $noti)
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-2">
                                           {{$loop->index + 1}}
                                        </div>
                                        <div class="col-4">
                                            {{$noti['itm_service']}}
                                        </div>
                                        <div class="col-2">
                                            1
                                        </div>
                                        <div class="col-4 text-right">
                                            {{$noti['itm_amt']}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach



            </div>

           


            <div class="col-md-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header" style="background-color:#30AFC0; color:white;">
                                Total Amount
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        Sub Total
                                    </div>
                                    <div class="col-6" style="text-align: right;">
                                        {{$cart_detail['cart_total']}}
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        Tax
                                    </div>
                                    <div class="col-6" style="text-align: right;">
                                        0
                                    </div>
                                </div>
                                <hr>
                                <div class="row" style="font-weight: bold;">
                                    <div class="col-6">
                                        Total
                                    </div>
                                    <div class="col-6" style="text-align: right;">
                                        
                                        {{$cart_detail['cart_total']}}
                                    </div>
                                </div>
                                <div class="row" style="margin-top:.5rem;">
                                    <div class="col-12">
                                        <!--<button type="button"  style="width: 100%; background-color:#20D015; color:white; margin-top:10px; height:30px; border:none;" onclick='testaddcart(1)' >CheckOut</button>-->
                                        <form action="{{url('/confirm')}}" method="POST" onsubmit='alert("test");'>
                                            @csrf
                                            <script
                                                src="https://checkout.razorpay.com/v1/checkout.js"
                                                data-key="{{$data['key']}}"
                                                data-amount="{{$data['amount']}}"
                                                data-currency="INR"
                                                data-name="{{$data['name']}}"
                                                data-image="{{$data['image']}}"
                                                data-description="{{$data['description']}}"
                                                data-prefill.name="{{$data['prefill']['name']}}"
                                                data-prefill.email="{{$data['prefill']['email']}}"
                                                data-prefill.contact="{{$data['prefill']['contact']}}"
                                                data-notes.shopping_order_id="{{$data['shopping_order_id']}}"
                                                data-order_id="{{$data['order_id']}}"
                                                
                                            >
                                            </script>
                                            <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
                                            <input type="hidden" name="shopping_order_id" value="{{$data['shopping_order_id']}}">
                                            <input type="hidden" name="shopping_amt" value="{{$data['amount']}}">
                                            <span class="paypal-button-text" style="display: block;text-align: center;margin-top: 12px;">Powered by <b>RAZORPAY</b></span>
                                            </form>
                                       
                                    </div>
                                    {{-- <span><img src="{{asset('img/Group 13.png')}}" style="width:100px; height:40px; margin-top:10px;margin-left:120px;"></span> --}}
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <img src="{{asset('img/Group 13.png')}}" style="width:100px; height:40px; margin-top:10px;margin-left:120px;">
                    </div>
                </div>
            </div>

        </div>
        @endisset
    </div>
</section>
<script>
    function testaddcart(ser_id){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxaddcart.post') }}",
                data:{ser_id:ser_id},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        // $('#btn_layer_'+idx).html(data.data);

                    }else{
                        console.log(data);
                        alert('Problem!! in disabling Event');
                        // console.log(data.error);
                    }
                }
            });
    }
  
    var unloadEvent = function (e) {
        var confirmationMessage = "Warning: Leaving this page will result in any unsaved data being lost. Are you sure you wish to continue?";
        // (e || window.event).returnValue = confirmationMessage; //Gecko + IE
        // console.log(confirmationMessage);
        console.log(document.activeElement.href );
        return Utils.showLoading("Processing Payment ...");; //Webkit, Safari, Chrome etc.
    };
    window.addEventListener("beforeunload", unloadEvent);
  
</script>
@endsection