@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    <div class="intro-img" style="margin-bottom:5rem;">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    

    <div class="container" style="background: #e9f3fb;padding: 1rem;margin-bottom: 5rem;">
        <div class="row">
            <div class="col-md-4">
                <img style="width: 100%;border:4px solid white;" src="{{asset($news_obj["news_image"])}}"/>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-12">
                        <h2>{{$news_obj["news_head"]}}</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <span>Date of Release</span>
                        <h6 style="font-weight: bold">{{$news_obj["news_DOR"]}}</h6>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h6><i class="fa fa-video-camera" aria-hidden="true"></i><a style="font-weight: bold" href="{{$news_obj["news_videolink"]}}" target="_blank"> Video Link </a> </h6>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12">
                        
                        <h6><i class="fa fa-link" aria-hidden="true"></i> <a style="font-weight: bold" href="{{$news_obj["news_links"]}}" target="_blank"> News Link </a></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="container-fluid" style="padding-top: 1rem;padding-bottom:1rem;padding-left: 0px">
                    <div class="row">
                        <div class="col-12">
                            <p style="line-height: 1.5rem;text-align: justify;">{{$news_obj["news_body"]}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


</section>

@endsection

