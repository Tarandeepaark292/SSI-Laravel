@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>

    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
        <h3>CSR Preview
            @if( $csr_obj['csr_approved'] == '1')
                ( Approved )
            @else
                ( Waiting Approval )
            @endif


        </h3>
    </header>
    <div id="cv" class="instaFade shadow p-3 mb-5 bg-white mt-5" style="background-color:white !important;">

        <div class="mainDetails" style="background-color:white !important">
            <div class="row">
                <div class="col-md-4">
                    <!-- <div id="headshot" class="quickFade"style="border:2px solid red; max-height:10px;"> -->
                    <img src="{{ asset($csr_obj['csr_logo']) }}" alt="Alan Smith" height="167px"
                        width="167px" style="border-radius: 50%; margin-left:50px;" />
                    <!-- </div> -->
                </div>
                <div class="col-md-8">
                    <div id="name">
                        <h1 class="quickFade delayTwo " style="font-size:30px;">
                            {{ $csr_obj['csr_org'] }}<small class="quickFade delayThree"
                                style="font-size:15px;"> {{ $csr_obj['csr_g_title'] }}</small>
                        </h1>
                        <hr style="width:100%;">
                        <i class="fa fa-envelope-o ml-1 mr-2 " aria-hidden="true"></i> <a
                            href="mailto:{{ $csr_obj['csr_email'] }}" target="_blank">
                            {{ $csr_obj['csr_email'] }}</a></br>
                        <i class="fa fa-money ml-1 mr-2" aria-hidden="true"></i> <a
                            href="{{ $csr_obj['csr_g_amt'] }}" target="_blank">
                            {{ $csr_obj['csr_g_amt'] }}</a></br>

                        <i class="fa fa-map-marker ml-1 mr-3" aria-hidden="true"></i>
                        {{ $csr_obj['csr_loc'] }}
                    </div>

                    <div id="contactDetails" class="quickFade delayFour">
                        <ul>
                            <!-- <li>w: <a href="http://www.bloggs.com">www.bloggs.com</a></li>
                <li>m: 01234567890</li> -->
                        </ul>
                    </div>

                </div>



            </div>
            <hr style="border:1px solid #00000029;">




            <div class="clear"></div>
        </div>

        <div id="mainArea" class="quickFade delayFive">
            <section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Decription of the proposal</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $csr_obj['csr_desc'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>





            <section>
                <div class="sectionTitle">
                </div>
                <h1 style="font-size:1.2em;"><b>closingdate</b></h1>
                {{ $csr_obj['csr_create_date'] }}
                <div class="sectionContent" style="font-size:15px;">
                </div>
                <div class="clear"></div>
            </section>



            <section>
                <div class="sectionTitle">

                </div>
                <h1 style="font-size:1.2em;"><b>location</b></h1>
                <h2 style="font-size:15px;"> {{ $csr_obj['csr_loc'] }}</h2>

                <div class="sectionContent" style="font-size:15px;">
                    <article>

                    </article>
                </div>
                <div class="clear"></div>
            </section>

			<section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Categories</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $csr_obj['csr_cates'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>

            <section>
                <div class="sectionTitle">
                </div>
                <h1 style="font-size:1.2em;"><b> proposal</b></h1>
                <h4 style="font-size:15px;"><a href="#">Download File <i class="fa fa-download"></i></a></h4>

                <div class="sectionContent" style="font-size:15px;">
                    <article>


                    </article>
                </div>
                <div class="clear"></div>
            </section>


        </div>
    </div>
</section>

@endsection
