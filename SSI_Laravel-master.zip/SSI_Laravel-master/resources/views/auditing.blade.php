@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

        <!-- ======= About Section ======= -->
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}

            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Auditing</span> </h3>
                </header>
                <div>
                    <div class="col-lg-12">
                        <h6 style="font-weight:600;">We are expertise in handling audits of NGO’s, Voluntary Organization, NPO’s, Charitable and Education Institution, our audit is scientifically based on:</h6>
                    </div>
                </div>
                <div class="row about-container">
                    <div class="col-lg-6 background order-lg-1 order-1 wow fadeInUp">
                        <ol style="padding: 1em;">
                            <li>Generally Accepted Auditing Principles followed in India</li>
                            <li>Compliance of Indian Income Tax Act</li>
                            <li>Compliance of various Statutory requirements
                            </li>
                            <li>Compliance of various State and Central Laws
                            </li>
                            <li>Payroll and accounts by a member of our Accountancy Support Services team.</li>
                            <li>Software Managed Service: Maintenance of Accounts and related records on our systems.</li>
                            <li>Preparing performance highlights for the management on which organizations decisions can be based.</li>
                            <li>Compliance support with all periodic statutory requirements</li>
                        </ol>
                    </div>
                    <div class="col-lg-6 content order-lg-2 order-2">
                        <b>Our Auditing services include:</b>


                        <br />
                        <ol style="padding: 1em;">
                            <li>Statutory Audit
                            </li>
                            <li>Internal Audit
                            </li>
                            <li>Special Audit for CSR Funding
                            </li>
                            <li>Special Audit for grants released to NGO’s by Donor Agency
                            </li>
                            <li>Management Audit
                            </li>
                            <li>Financial accounting
                            </li>
                            <li>Systems studies and accounting manuals
                            </li>
                            <li>Training programs on audit and accounting matters
                            </li>
                            <li>Income tax scrutiny or any other Audit
                            </li>
                        </ol>

                    </div>

                </div>
                <div class="row about-container">
                    <div class="col-lg-12">
                        <span style="display:block;text-align: justify;">
                            Internal audit departments vary from organization to organization, many organization require internal audit consulting to ensure their departments are developed strategically. This is where we come in. Our professionals work with your internal audit stakeholders to gain consensus on the desired mission for internal audit within the organization. We then help you develop and deploy an effective internal audit model in order to achieve these well-defined objectives. Having great vision is important, but in order to derive any value, the vision needs to be effectively implemented. Our objective advice and guidance can make it easier to arrive at your destination. Using best practices developed over our years of experience and a risk-based, methodology our internal audit teams bring confidence and efficiency to your internal audit development process.
                        </span>
                        <hr style="color:#007bff;border:3px solid;">
                        <p style="margin-top: 30px; font-size: 1rem;">
                            For any further assistance our experts will get in touch with you and take it forward.
                            <br /><br />
                            Please email us at: <b>Team@SocialServicesIndia.org</b> with subject of the e-mail <b>“Accounting”</b>
                        </p>
                    </div>

                </div>

        </section><!-- End About Section -->


    @endsection