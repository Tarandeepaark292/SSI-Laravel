@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Banners</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Banners </li>
            </ol>

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

                    <form action="{{url('/admin/update-banner')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        {{-- <label for="name">Current First Banner</label><br/> --}}
                                       
                                        @isset($banner_arr[0])
                                       
                                        <img  style="width: 100%;" src="{{asset($banner_arr[0]['b_img_name'])}}" /><br/>
                                        @endisset
                                        
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">First Banner </label>
                                                <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" name="upload_banner_1" id="" placeholder="Add Media">
                                                
                                                @isset($banner_arr[0])
                                                <input type="hidden" name="old_banner_1" value="{{$banner_arr[0]['b_img_name']}}">
                                                <input type="hidden" name="banner_1_id" value="{{$banner_arr[0]['b_id']}}">
                                                    
                                                @endisset
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                            
                                                <label for="name">Banner Link</label>
                                                <input type="text" name="banner_1_link" class="form-cntrl" value="{{$banner_arr[0]['b_link']}}" />
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    
                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:100%"> Update Banner 1
                            </button>
                        </div>
                    </form>


                    <form action="{{url('/admin/update-banner')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        {{-- <label for="name">Current First Banner</label><br/> --}}
                                       
                                        @isset($banner_arr[1])
                                       
                                        <img  style="width: 100%;" src="{{asset($banner_arr[1]['b_img_name'])}}" /><br/>
                                        @endisset
                                        
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Second Banner </label>
                                                <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" name="upload_banner_1" id="" placeholder="Add Media">
                                                
                                                @isset($banner_arr[1])
                                                <input type="hidden" name="old_banner_1" value="{{$banner_arr[1]['b_img_name']}}">
                                                <input type="hidden" name="banner_1_id" value="{{$banner_arr[1]['b_id']}}">
                                                    
                                                @endisset
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                            
                                                <label for="name">Banner Link</label>
                                                <input type="text" name="banner_1_link" class="form-cntrl" value="{{$banner_arr[1]['b_link']}}" />
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    
                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:100%"> Update Banner 2
                            </button>
                        </div>
                    </form>


                    <form action="{{url('/admin/update-banner')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        {{-- <label for="name">Current First Banner</label><br/> --}}
                                       
                                        @isset($banner_arr[2])
                                       
                                        <img  style="width: 100%;" src="{{asset($banner_arr[2]['b_img_name'])}}" /><br/>
                                        @endisset
                                        
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Third Banner </label>
                                                <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" name="upload_banner_1" id="" placeholder="Add Media">
                                                
                                                @isset($banner_arr[2])
                                                <input type="hidden" name="old_banner_1" value="{{$banner_arr[2]['b_img_name']}}">
                                                <input type="hidden" name="banner_1_id" value="{{$banner_arr[2]['b_id']}}">
                                                    
                                                @endisset
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                            
                                                <label for="name">Banner Link</label>
                                                <input type="text" name="banner_1_link" class="form-cntrl" value="{{$banner_arr[2]['b_link']}}" />
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    
                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:100%"> Update Banner 3
                            </button>
                        </div>
                    </form>


                    <form action="{{url('/admin/update-banner')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        {{-- <label for="name">Current First Banner</label><br/> --}}
                                       
                                        @isset($banner_arr[3])
                                       
                                        <img  style="width: 100%;" src="{{asset($banner_arr[3]['b_img_name'])}}" /><br/>
                                        @endisset
                                        
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Fourth Banner </label>
                                                <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" name="upload_banner_1" id="" placeholder="Add Media">
                                                
                                                @isset($banner_arr[3])
                                                <input type="hidden" name="old_banner_1" value="{{$banner_arr[3]['b_img_name']}}">
                                                <input type="hidden" name="banner_1_id" value="{{$banner_arr[3]['b_id']}}">
                                                    
                                                @endisset
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                            
                                                <label for="name">Banner Link</label>
                                                <input type="text" name="banner_1_link" class="form-cntrl" value="{{$banner_arr[3]['b_link']}}" />
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    
                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:100%"> Update Banner 4
                            </button>
                        </div>
                    </form>


                    <form action="{{url('/admin/update-banner')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        {{-- <label for="name">Current First Banner</label><br/> --}}
                                       
                                        @isset($banner_arr[4])
                                       
                                        <img  style="width: 100%;" src="{{asset($banner_arr[4]['b_img_name'])}}" /><br/>
                                        @endisset
                                        
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label for="name">Fifth Banner </label>
                                                <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" name="upload_banner_1" id="" placeholder="Add Media">
                                                
                                                @isset($banner_arr[4])
                                                <input type="hidden" name="old_banner_1" value="{{$banner_arr[4]['b_img_name']}}">
                                                <input type="hidden" name="banner_1_id" value="{{$banner_arr[4]['b_id']}}">
                                                    
                                                @endisset
                                                <div class="validate"></div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                            
                                                <label for="name">Banner Link</label>
                                                <input type="text" name="banner_1_link" class="form-cntrl" value="{{$banner_arr[4]['b_link']}}" />
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    
                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                            style="width:100%"> Update Banner 5
                            </button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </section>
</main>
@endsection