@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')



<section style="">
    <div class="intro-img" style="margin-bottom:5rem;">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
        <h3>Event Preview
            @if ( $jp_obj['evt_status'] == '1')
            ( Approved )
            @else
            ( Waiting Approval )
            @endif


        </h3>
    </header>

    <div class="container" style="background: #e9f3fb;padding: 1rem;margin-bottom: 5rem;">
        <div class="row">
            <div class="col-12">
                <h1 style="text-align: center;font-weight: bold;font-variant: petite-caps;">
                    {{ $jp_obj['evt_title'] }} </h1>
            </div>
        </div>
        <div class="row" style="margin-bottom:2rem;">
            <div class="col-md-8">
                <img src="{{ asset($jp_obj['evt_upload_banner']) }}" style="width:100%; "
                    alt="">
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-12">
                        <img src="{{ asset($jp_obj['evt_org_logo']) }}" style="width:100%; "
                            alt="">
                        <h2 style="text-align: center;">{{ $jp_obj['evt_org_name'] }}</h2>
                        <hr>
                        <h5><i class="fa fa-envelope-o" aria-hidden="true"></i> <a
                                href="mailto:{{ $jp_obj['evt_email'] }}" style="font-size:15px;"
                                target="_blank"><b>{{ $jp_obj['evt_email'] }}</b></a></h5>
                        <h5><i class="fa fa-map-marker" aria-hidden="true"></i> <b
                                style="font-size:15px;">{{ $jp_obj['evt_loc'] }}</b></h5>
                        <h5><i class="fa fa-link" aria-hidden="true"></i> <span
                                style="font-weight: bold;font-size:15px;">{{ $jp_obj["evt_ref_url"] }}</span>
                        </h5>
                        <h5><i class="fa fa-download" aria-hidden="true"></i><a
                                style="font-weight: bold;font-size:15px;"
                                href="{{ $jp_obj["evt_upload_doc"] }}" target="_blank"> Proposal
                            </a> </h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h3><b>Detail</b></h3>
                <p style="line-height: 1.5rem;text-align: justify;">{{ $jp_obj['evt_desc'] }}
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h3><b>End Date</b></h3>
                <h5 style="font-weight: bold">{{ $jp_obj['evt_end_date'] }}</h5>
            </div>
        </div>
        {{-- <div class="row">
                    <div class="col-12">
                        <h5><i class="fa fa-download" aria-hidden="true"></i><a style="font-weight: bold" href="{{ $jp_obj["evt_upload_doc"] }}"
        target="_blank"> Proposal </a> </h5>
    </div>
    </div> --}}

    {{-- <div class="row">
                    <div class="col-12">
                        
                       
                    </div>
                </div> --}}




    </div>


</section>



@endsection
