@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Resumes</span> </h3>
        </header>
        <div class="row" style="text-align: center;">
            <div class="col-12">


            </div>
        </div>

        <div class="row">
            <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">
                <div class="form-row">

                    {{-- <div class="form-group col-6">

                        <input type="text" name="name" class="form-cntrl" id="name" placeholder="All resumes" />
                        <div class="validate"></div>
                    </div>
                    <div class="form-group col-6">

                        <input type="text" name="name" class="form-cntrl" id="name" placeholder="Any Location" />
                        <div class="validate"></div>
                    </div> --}}
                </div>
                <div class="form-row">
                    <div class="form-group col-12">
                        <select name="job_type" id="cat" class="form-cntrl " onchange="myfunction(event)"
                            style="width:100%;">
                            <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                            <option>Administration, HR, Management, Accounting/Finance Executive</option>
                            <option>Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                            <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                            <option>Capacity Building, Training, Advocacy</option>
                            <option>Communications, IT, Media, Knowledge Management, Editor</option>
                            <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                            <option>Disaster, Aid, Emergencies, Relief</option>
                            <option>Environment, Climate, Energy, Water, Sanitation</option>
                            <option>Fund-raising Business Development, Grants Writer</option>
                            <option>Field Officers, Field Associates</option>
                            <option>Government / Governance, Reforms, Corruption</option>
                            <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                            <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                            <option>Infrastructure, Technology, Engineering, Science</option>
                            <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                            <option>Private Sector, Corporate Social Responsibility</option>
                            <option>Project Associate, Project leaders, Project Assistant</option>
                            <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                            <option>Research Analysts, Research Associate, Research Assistant</option>
                            <option>Social, Gender, Education, Youth, Child</option>
                            <option>Trade, Finance, Economics, Cooperation, Global</option>
                            <option>Technology Associate, Technical Assistant, </option>
                            <option>Teachers, Teachers Educators, Principal</option>
                        </select>
                        <div class="validate"></div>
                    </div>
                </div>
            </div>
        </div>



        <div id="search_results" class="row" style="">
            @isset($resumesearch)
            @foreach($resumesearch as $res)
            <div class="col-lg-12">
                <div class="card content joblist_item" id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">

                            <div class="col-md-2" style="text-align: center;">

                                <img style="width: 80%;" src="{{asset($res['js_photo'])}}" />
                            </div>
                            <div class="col-md-8">
                                <div>
                                    <span style="font-weight: bold;">
                                        {{$res['js_name']}}
                                    </span>
                                </div>
                                <div id="results">
                                    {{$res['js_p_title']}}
                                </div>
                                <div id="results">
                                    <i class="fa fa-map-marker" aria-hidden="true"
                                        style="color:#007bff;font-size: 18px;"></i> 
                                        <span style="font-weight: bold;color:#007bff;">{{$res['js_loc_obj']['addr_city']}}/{{$res['js_loc_obj']['addr_state']}}</br>

                                    </span>
                                </div>
                                <div id="results">
                                     <span style="font-weight: bold;color:#00254d;">
                                        {{$res['js_area_expertise']}}
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-2" style="align-self: center;justify-content: center;">
                                <a href="{{url('/jobseeker')}}/{{$res['js_SEO']}}" class="btn btn-primary">Detail <i class="fa fa-chevron-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
                
            </div>
            @endforeach
            @endisset
        </div>

    </div>

</section>

<script>
    function myfunction(e){
        e.preventDefault();
        //alert($('#cat').val());
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxresume.post') }}",
            data: {
                
                cate: $('#cat').val()
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error)
                }
            }
        });
    }
</script>
@endsection
