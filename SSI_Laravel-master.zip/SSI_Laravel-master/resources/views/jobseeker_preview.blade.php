@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')




<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;">
    </div>

    <div class="container" style="background: #e9f3fb;padding: 1rem;margin-bottom: 5rem;margin-top:5rem;">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-md-3">
                <img style="width: 100%;border:4px solid white;" src="{{asset('img/profile-avatar.png')}}" />
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-12">
                        <h2>{{$jp_obj['js_name']}}</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <h3 style="font-weight: bold">{{$jp_obj['js_p_title']}}</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h4><i class="fa fa-map-marker" aria-hidden="true"></i> {{$js_loc_obj['addr_1']}},
                            {{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}} ({{$js_loc_obj['addr_zip']}})</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h5 style="font-weight: bold"><i class="fa fa-rupee" style="margin-right: 1rem;" aria-hidden="true"></i><span class="subDetails">Expected Salary:</span> {{$jp_obj['js_sal']}}</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <h5 style="font-weight: bold"><i class="fa fa-clock-o" style="margin-right: 1rem;"  aria-hidden="true"></i><span class="subDetails">Total Experience:</span> {{$jp_obj['js_totexp']}}</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 align-self-center" style="text-align: center;">
                <a href="{{url('/js/broadcastResume')}}" class="btn btn-dark" style="padding-top: 2rem; padding-bottom: 2rem;">Broadcast Resume</a>
            </div>
        </div>

    <div class="row">
        <div class="col-md-12">
            <h3><b>Personal Profile</b></h3>
            <p style="line-height: 1.5rem;text-align: justify;">
                {!!htmlspecialchars_decode($jp_obj['js_personal_info'])!!}
            </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Work Experience</b></h3>
            @foreach($js_exp_obj as $res)
            <article style="border-bottom: 2px dotted #fff;padding-top: 1rem;">
                <h4>{{$res['title']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p>
                
            </article>
            @endforeach
        </div>
    </div>

    <div class="row">
        <div class="col-md-12" style="padding-top:1rem;">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Skills</b></h3>
            {{-- @foreach($js_skill_list_obj as $res) --}}
            <article style="border-bottom: 2px dotted #fff;">
                {{-- <h4>{{$res['title']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p> --}}
                <ul>
                    @foreach($js_skill_list_obj as $res)
                    <li><h5>{{$res['skill']}}</h5></li>
                    @endforeach
                </ul>
            </article>
            {{-- @endforeach --}}
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-briefcase" style="margin-right: 1rem"></i><b>Area of Expertise</b></h3>
            <article>
                <h5>{{$jp_obj['js_area_expertise']}}</h5>
            </article>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h3><i class="fa fa-graduation-cap" style="margin-right: 1rem"></i><b>Education</b></h3>
            @foreach($js_edu_obj as $res)
            <article style="border-bottom: 2px dotted #fff;padding-top: 1rem;">
                <h4>{{$res['degree']}}</h4>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p>
            </article>
            @endforeach
        </div>
    </div>

    </div>
</section>











{{-- <section style="">
<div id="cv" class="instaFade">
	<div class="mainDetails">
		<div id="headshot" class="quickFade">
			<img src="{{asset('img/preview/headshot.jpg')}}" alt="Alan Smith" />
</div>

<div id="name">
    <h1 class="quickFade delayTwo">{{$jp_obj['js_name']}}</h1>
    <h2 class="quickFade delayThree">{{$jp_obj['js_p_title']}}</h2>
</div>

<div id="contactDetails" class="quickFade delayFour">
    <ul>
        <li>e: <a href="mailto:{{$jp_obj['js_email']}}" target="_blank">{{$jp_obj['js_email']}}</a></li>
        <li>Tel: <a href="tel:{{$jp_obj['js_number']}}" target="_blank">{{$jp_obj['js_number']}}</a></li>
        <!-- <li>w: <a href="http://www.bloggs.com">www.bloggs.com</a></li>
				<li>m: 01234567890</li> -->
    </ul>
</div>
<div class="clear"></div>
</div>

<div id="mainArea" class="quickFade delayFive">
    <section>
        <article>
            <div class="sectionTitle">
                <h1>Personal Profile</h1>
            </div>

            <div class="sectionContent">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dolor metus, interdum at scelerisque
                    in, porta at lacus. Maecenas dapibus luctus cursus. Lorem ipsum dolor sit amet, consectetur
                    adipiscing elit. Donec ultricies massa et erat luctus hendrerit. Curabitur non consequat enim.
                    Vestibulum bibendum mattis dignissim. Proin id sapien quis libero interdum porttitor.</p>
            </div>
        </article>
        <div class="clear"></div>
    </section>


    <section>
        <div class="sectionTitle">
            <h1>Work Experience</h1>
        </div>

        <div class="sectionContent">
            @foreach($js_exp_obj as $res)
            <article>
                <h2>Job Title at Company</h2>
                <h5>{{$res['school']}}</h5>
                <p class="subDetails">{{$res['start']}} - {{$res['end']}}</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultricies massa et erat luctus
                    hendrerit. Curabitur non consequat enim. Vestibulum bibendum mattis dignissim. Proin id sapien quis
                    libero interdum porttitor.</p>
            </article>
            @endforeach

        </div>
        <div class="clear"></div>
    </section>


    <section>
        <div class="sectionTitle">
            <h1>Area of Expertise</h1>
        </div>

        <div class="sectionContent">
            {{$jp_obj['js_area_expertise']}}

        </div>
        <div class="clear"></div>
    </section>


    <section>
        <div class="sectionTitle">
            <h1>Education</h1>
        </div>

        <div class="sectionContent">
            @foreach($js_edu_obj as $res)
            <article>
                <h2>{{$res['school']}}</h2>
                <p class="subDetails">Qualification</p>
                <p>From {{$res['start']}} Till {{$res['end']}}</p>
            </article>
            @endforeach

        </div>
        <div class="clear"></div>
    </section>

    <section>
        <div class="sectionTitle">
            <h1>Address</h1>
        </div>
        <div class="sectionContent">
            <article>
                <h2>{{$js_loc_obj['addr_1']}}</h2>
                <p class="subDetails">{{$js_loc_obj['addr_city']}}, {{$js_loc_obj['addr_state']}}
                    ({{$js_loc_obj['addr_zip']}})</p>

            </article>
        </div>
        <div class="clear"></div>
    </section>

    <section>
        <div class="sectionTitle">
            <h1>Resume</h1>
        </div>
        <div class="sectionContent">
            <article>
                <h4><a href="#">Download File <i class="fa fa-download"></i></a></h4>


            </article>
        </div>
        <div class="clear"></div>
    </section>


</div>
</div>
</section> --}}

@endsection
