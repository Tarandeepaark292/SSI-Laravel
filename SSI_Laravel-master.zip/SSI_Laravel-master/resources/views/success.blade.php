@extends('layouts.home')
@section('content')

<div class="container" style="margin-top: 100px ;padding:100px;">
    <div class="row">
        <div class="col-md-12">



            <div id="notfounds">
                <div class="notfounds">
                    <div class="notfound-404s" >
        
        
                        <h1 style="color:#0b6bd3;">Thank You</h1>
        
                    </div>
        @if(isset($msg))
                    <h2>{{ $msg }}</h2>
        @else
                    <h2>YOUR REQUEST IS SUCCESSFULLY SUBMITTED</h2>
        @endif
            <a style="font-size:30px;" href="{{ url('/') }}"><span class="arrows"
                    style="height:16px;width:16px;"></span>Return To Homepage</a>
            </div>
        </div>

        </div>

    </div>


    @endsection