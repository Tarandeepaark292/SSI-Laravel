@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post Event</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Post Event </li>
        </ol>

        

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h3><span class="titleheading">Events Ads </span> </h3>
                    </header> --}}

                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-events/submit')}}" method="post" accept-charset="utf-8" onsubmit="validate(event);"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12 " style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Choose Organization </label>
                                        <select class="form-control" name="org_id" id="org_id" required="required">
                                            <option value="-1">N/A</option>
                                            @foreach ($organizationlist as $organization )
                                                <option value="{{$organization['r_id']}}">{{$organization['r_org_name']}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Title of the Event </label>
                                        <input type="text" name="event_title" class="form-cntrl" id="event"
                                            placeholder="Event Title" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="organisation_name" class="form-cntrl" id="organisation"
                                            placeholder="Organisation Name" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                               
                                    <div class="form-row">
    
                                        <div class="form-group col-lg-6">
                                            <label for="name">Event Banner </label>
                                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="upload_evt_banner" id="" placeholder="Add Media">
                                            <div class="validate"></div>
                                        </div>
                                    </div>
                                

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="loc_name" class="form-cntrl" id="email"
                                            placeholder="India" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing dates of Event</label>
                                        <input type="date" name="proposal_close_date" class="form-cntrl" id="proposal_close_date"
                                            placeholder="" />
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Detail of complete Event Information</label><br>
                                        <textarea class="form-cntrl" name="event_desc" id="summernote" placeholder="" rows="10"
                                            style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Event Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="" />
                                </div>
                            @endisset

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload Event Document</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="upload_evt_doc" id="" placeholder="Add Media">

                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation logo</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="org_logo" id="" placeholder="Add Media">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder="Insert Website link" />

                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label>Application Email</label>
                                        <input type="text" name="email" class="form-cntrl" id="" placeholder="Enter valid email id to receive Event application" />


                                    </div>

                                </div>

                                {{-- <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Terms and Condition</label><br>
                                    </div>
                                </div> --}}
                                <div class="form-row" style="text-align:center;">
                                    <div class="form-group col-lg-12 ml-auto">
                                        <button class="btn btn-primary  btn-register" style="width:30%">Submit
                                            Event</button>
                                    </div>
                                </div>
                            </div>                            
                    </form>
                </div>
            </section>



    </div>
    </section>
    <script>
         function validate(event){
            var sel = $('#org_id').val();
            if(sel === "-1"){
                alert("Please Select Organization");
                event.preventDefault();
            }
        }
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>
</main>

@endsection