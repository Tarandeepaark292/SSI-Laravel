@extends('layouts.home')
@section('content')
<section id="NGO" style="">
    <div class="intro-img" style="">
        {{-- <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

        <div class=" container">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                <h3><span class="titleheading">NGO Foreign Contribution Regulation Act</span>  </h3>
            </header>
        </div>
        <table class="table-responsive-md table-hover">
            <tbody>
                <thead>
                    <tr>
                        <th scope="col">NO.</th>
                        <th scope="col">Format</th>
                        <th scope="col">Link</th>
                        
                    </tr>
                </thead>
                <tr>
                    <td>1</td>
                    <td>Foreign Contribution Regulation Act
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/Foreign-Contribution-Regulation-Act-(FCRA)-DONTs-AND-DOs/1-Foreign-Contribution-Regulation-Act.doc')}}">Download</a></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Don'ts for FCRA
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/Foreign-Contribution-Regulation-Act-(FCRA)-DONTs-AND-DOs/2-Dont’s-for-FCRA.doc')}}">Download</a></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Do's for FCRA 
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/Foreign-Contribution-Regulation-Act-(FCRA)-DONTs-AND-DOs/3-Do’s-for-FCRA.doc')}}">Download</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</section>

@endsection
