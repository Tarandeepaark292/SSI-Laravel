@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Job Post List</li>
        </ol>
        
        <div class="card mb-4">
            <div class="card-header" style="display: flex;justify-content: space-between;align-items: center;">
                <div>
                    <i class="fas fa-table mr-1"></i>Job Post
                </div>
                <div>
                    <i class="fas fa-download mr-1"></i><a href="{{url('/admin/jobpost/export')}}" style="color: black"> Download </a>
                </div>
            </div>
            <div class="card-body">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item waves-effect waves-light">
                      <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">UnExpired</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                      <a class="nav-link " id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Expired</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent" style="margin-top:2rem;">
                    
                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                        @isset($unexpreclist)
                        <div class="table-responsive">
                            <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>Closing Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
        
                                    </tr>
                                </thead>
                                
                                    <tfoot>
                                        <tr>
                                            <th>Job Title</th>
                                            <th>Email</th>
                                            <th>Organization Name</th>
                                            <th>Closing Date</th>
                                            <th>Submitted By</th>
                                            <th>Status</th>
                                            <th></th>
                                            <th></th>
            
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        @foreach($unexpreclist as $noti)
                                        <tr>
                                            <td>{{ $noti['jp_title'] }}</td>
                                            <td style="word-break: break-all;">
                                                {{ $noti['jp_email'] }}</td>
                                            <td style="word-break: break-all;">
                                                {{ $noti['jp_org_name'] }}</td>
                                            <td>{{ $noti['jp_closing_date'] }}</td>
                                            <td>{{ $noti['jp_submitted_by'] }}</td>
                                            <td>{{ $noti['jp_status'] }}</td>
                                            <td>
                                                <a class="btn btn-outline-secondary"
                                                    href="{{url('/admin/job-postdetail/')}}/{{$noti['jp_id']}}">Detail</a>
                                            </td>
            
                                            <td id="btn_layer_{{$noti['jp_id']}}">
                                                @if($noti['jp_approved'] == '1')
                                                <button class="btn btn-danger" onclick="disablejobpost({{$noti['jp_id'] }})">Put on
                                                    Hold</button>
                                                @else
                                                <button class="btn btn-primary"
                                                    onclick="enablejobpost({{$noti['jp_id'] }})">Approve</button>
                                                @endif
                                            </td>
            
                                        </tr>
                                        @endforeach
                                    </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>

                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        @isset($expreclist)
                        <div class="table-responsive">
                            <table class="table table-bordered" id="notidataTable2" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>Closing Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
        
                                    </tr>
                                </thead>
                               
                                <tfoot>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Email</th>
                                        <th>Organization Name</th>
                                        <th>Closing Date</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                        <th></th>
                                        <th></th>
        
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @foreach($expreclist as $noti)
                                    <tr>
                                        <td>{{ $noti['jp_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['jp_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['jp_org_name'] }}</td>
                                        <td>{{ $noti['jp_closing_date'] }}</td>
                                        <td>{{ $noti['jp_submitted_by'] }}</td>
                                        <td>{{ $noti['jp_status'] }}</td>
                                        <td>
                                            <a class="btn btn-outline-secondary"
                                                href="{{url('/admin/job-postdetail/')}}/{{$noti['jp_id']}}">Detail</a>
                                        </td>
        
                                        <td id="btn_layer_{{$noti['jp_id']}}">
                                            @if($noti['jp_approved'] == '1')
                                            <button class="btn btn-danger" onclick="disablejobpost({{$noti['jp_id'] }})">Put on
                                                Hold</button>
                                            @else
                                            <button class="btn btn-primary"
                                                onclick="enablejobpost({{$noti['jp_id'] }})">Approve</button>
                                            @endif
                                        </td>
        
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endisset
                    </div>
                </div>

                {{-- <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item waves-effect waves-light">
                      <a class="nav-link" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Home</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                      <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
                    </li>
                    <li class="nav-item waves-effect waves-light">
                      <a class="nav-link active" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="true">Contact</a>
                    </li>
                  </ul>
                  <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">Raw denim you
                      probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master
                      cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh
                      dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid. Aliquip placeat salvia
                      cillum iphone. Seitan aliquip quis cardigan american apparel, butcher voluptate nisi qui.</div>
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">Food truck fixie
                      locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog
                      sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo
                      booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR. Homo
                      nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica VHS salvia yr, vero
                      magna velit sapiente labore stumptown. Vegan fanny pack odio cillum wes anderson 8-bit, sustainable jean
                      shorts beard ut DIY ethical culpa terry richardson biodiesel. Art party scenester stumptown, tumblr butcher
                      vero sint qui sapiente accusamus tattooed echo park.</div>
                    <div class="tab-pane fade active show" id="contact" role="tabpanel" aria-labelledby="contact-tab">Etsy mixtape wayfarers,
                      ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny pack lo-fi
                      farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone skateboard locavore
                      carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings gentrify squid 8-bit cred
                      pitchfork. Williamsburg banh mi whatever gluten-free, carles pitchfork biodiesel fixie etsy retro mlkshk
                      vice blog. Scenester cred you probably haven't heard of them, vinyl craft beer blog stumptown. Pitchfork
                      sustainable tofu synth chambray yr.</div>
                  </div> --}}

                  
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
    $('#notidataTable2').DataTable();
    function enablejobpost(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxjobpostenable.post') }}",
                data:{jp_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                        location.reload();
                    }else{
                        alert('Problem!! in enabling CSR');
                        console.log(data.error);
                    }
               }
            });
    }
    
    function disablejobpost(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxjobpostdisable.post') }}",
                data:{jp_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                        location.reload();
                    }else{
                        alert('Problem!! in disabling CSR');
                        console.log(data.error);
                    }
                }
            });
    }
    </script>
@endsection
