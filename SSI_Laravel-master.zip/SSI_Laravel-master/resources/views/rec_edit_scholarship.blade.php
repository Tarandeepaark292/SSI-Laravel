@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Edit Scholarship</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Update Scholarship </li>
        </ol>

        

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h3><span class="titleheading">Events Ads </span> </h3>
                    </header> --}}

                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/updatesc/')}}/{{$jp_obj['sc_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="name" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation"  value="{{$jp_obj['sc_name']}}"  />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Scholarship title </label>
                                        <input type="text" name="title" class="form-cntrl" id="title"
                                            placeholder="Scholarship title" value="{{$jp_obj['sc_title']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location" value="{{$jp_obj['sc_loc']}}"
                                            placeholder="Location" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Organisation logo</label>
                                        <input type="file" name="org_logo" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" class="form-cntrl" id="file"  value="{{$jp_obj['sc_logo']}}" />
                                            <input type="hidden" name="old_org_logo" value="{{$jp_obj['sc_logo']}}">
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Current Organisation Logo</label><br/>
                                        <img  style="width: 200px;" src="{{asset($jp_obj['sc_logo'])}}" /><br/>
                                        
                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6" style="position:relative">
                                        <label for="company_logo">Deadline date</label><br>
                                        <input type="date" class="form-cntrl"  name="deadlinedate" id="deadlinedate"
                                            placeholder="Deadline Date"  value="{{$jp_obj['sc_date']}}">
                                    </div>


                                    <div class="form-group col-lg-6">
                                        <label>Email</label>
                                        <input type="text" class="form-cntrl" name="email" id="email" value="{{$jp_obj['sc_email']}}"
                                            placeholder="email">

                                        <div class="validate"></div>
                                    </div>

                                </div>
                                {{-- <div class="form-group col-lg-12">
                                    <label for="company_logo">Description of the fellowshp</label><br>
                                    <input type="file" data-file_types="doc|pdf|text" accept="application/pdf"
                                        name="file" id="file">
                                </div> --}}
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the Scholarship</label><br>
                                        <textarea class="form-cntrl" name="desc_textarea" id="summernote" placeholder=""
                                            rows="10" style="height: auto;resize: none;">{{$jp_obj['sc_description']}}</textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Scholarship Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="{{$jp_obj['sc_category']}}" />
                                </div>
                                @endisset
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload proposal Document</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text"
                                            accept="application/pdf" name="upload" id="upload" value="{{$jp_obj['sc_upload']}}" >
                                            <input type="hidden" name="old_upload" value="{{$jp_obj['sc_upload']}}">
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" value="{{$jp_obj['sc_url']}}"
                                            placeholder="refrenceurl" />

                                        <div class="validate"></div>
                                    </div>
                                </div>

                            
                                <div class="form-row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">
        
                                        <button class="btn btn-primary  btn-register" style="margin-top:10;">
                                            Update Scholarship</button>
                                    </div>
                                </div>
                            </div>


                            

                            {{-- <div class="col-lg-12">
                                <label name=""> Fellowship Category</label>
                                <br>
                                <input type="checkbox" id="" name="cates[]" value="fellowship">
                                <label for="vehicle1"> Fellowship</label><br>
                                <input type="checkbox" id="" name="cates[]" value="scholarship">
                                <label for="vehicle2"> Scholarship</label><br>

                            </div> --}}
                        </div>
                        
                    </form>
                </div>
            </section>

      


    </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>
</main>

@endsection