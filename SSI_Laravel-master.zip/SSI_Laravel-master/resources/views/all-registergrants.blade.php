@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading"> </span> <span class="titleheading">Register Grants</span> 
        </header>
        <div class="row">
            <div class="col-12">
                <form class="searchform">
                    {{-- <input type="text" placeholder="Search.." id="filter">
                    <button type="" onclick="myfunction(event)"><i class="fa fa-search"></i></button> --}}
                </form>
            </div>
            <div class="col-12">
                <span style="display: block;font-size: 16px;">
                    <p>
                        <br>
                        {{-- These are all the RF ads --}}
                        <br>
                    </p>
                </span>


            </div>











            <div id="search_results" style="width: 100%;">
            @isset($registersearch)
                @foreach($registersearch as $res)
                    <div class="col-12 " style="margin-bottom:2rem;">

                        <div class="card content fell_search_item" id="results">
                            <div class="card-body" id="results">
                                <div class="row " id="resultss">

                                   
                                    <div class="col-md-8">
                                        <div class="results" style="font-weight: bold;font-size: 20px;">
                                            {{ $res['reg_v_org'] }}</div>
                                        <div id="results">
                                            {{ $res['reg_o_mission'] }}
                                        </div>
                                        <div id="results">
                                            <i class="" aria-hidden="true"
                                                style="color:#007bff;font-size: 18px;"></i> <span
                                                style="font-weight: bold;color:#007bff;font-size:16px;">{{ $res['reg_o_head'] }}</span>

                                        </div>
                                        <div id="results">
                                            <i class="fa fa-calendar" aria-hidden="true"
                                                style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                                style="font-weight: bold;color:#00254d;font-size:16px;">{{ $res['reg_valid_To'] }}
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-2 my-auto ">
                                        <a href="{{url('/grant/')}}/{{$res['reg_SEO']}}" class="btn btn-newprimary">Details</a>
                                    </div>





                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            @endisset
            </div>


        </div>

    </div>

    </div>
    </div>
    </div>
</section>




@endsection
