@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Edit Publication</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Update Publication </li>
            </ol>

            @if(session()->has('ssiapp_adm'))

                <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                            <div class="col-12">
                                <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                            </div>
                        </header>



                        <div class="row" style="text-align: center;">

                        </div>

                        <form
                            action="{{ url('/admin/publication/update') }}/{{ $jp_obj['pub_id'] }}"
                            method="post" accept-charset="utf-8" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-12 " style="border: 0;">
                                    <div class="form-row">

                                        <div class="form-group col-lg-12">
                                            <label for="name">Name of the Author </label>
                                            <input type="text" name="authorname" class="form-cntrl" id="name"
                                                placeholder="Name of  the author" style=""
                                                value="{{ $jp_obj['pub_name'] }}" />
                                            <div class="validate"></div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-lg-12">

                                                @isset($html)
                                                    <div class="form-row">
                                                        <div class="form-group col-lg-12">
                                                            <label for="name">Publication Type </label>
                                                        </div>
                                                        {{-- <div class="form-group col-lg-12"> --}}
                                                        {!! $html !!}
                                                        {{-- </div> --}}
                                                        <input type="hidden" id="cates" name="cates"
                                                            value="{{ $jp_obj['pub_type'] }}" />
                                                    </div>
                                                @endisset



                                            </div>
                                            <div class="form-group col-lg-12">
                                                @isset($html2)
                                                    <div class="form-row">
                                                        <div class="form-group col-lg-12">
                                                            <label for="name">Focus Area</label>
                                                        </div>
                                                        {{-- <div class="form-group col-lg-12"> --}}
                                                        {!! $html2 !!}
                                                        {{-- </div> --}}
                                                        <input type="hidden" id="focus" name="focus"
                                                            value="{{ $jp_obj['pub_focusarea'] }}" />
                                                    </div>
                                                @endisset
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="name">Document Title </label>
                                            <input type="text" name="documenttitle" class="form-cntrl" id=""
                                                placeholder="" style="width:100%;" maxlength="150"
                                                value="{{ $jp_obj['pub_title'] }} " />
                                            <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                            <div class="validate"></div>
                                        </div>
                                    </div>

                                    <div class="form-row" style="margin-top: 1rem" ;>
                                        <div class="form-group col-lg-12">
                                            <label for="name">Publication Description</label>
                                            <textarea name="publication_desc" class="form-cntrl" id="publication_desc"
                                                placeholder="" row="10"
                                                style="height:auto;width:100%;">{{ $jp_obj['pub_desc'] }}</textarea>
                                            <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                            {{-- <div class="validate"></div> --}}
                                        </div>
                                    </div>

                                    <div class="form-row" style="margin-top:1rem;">
                                        <div class="form-group col-lg-6">


                                            <label for="name">Email</label>

                                            <input type="email" name="email" class="form-cntrl" id="email"
                                                placeholder="" style="width:100%;"
                                                value="{{ $jp_obj['pub_email'] }} " />

                                            <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">Mobile No</label>
                                            <input type="text" name="mobile" class="form-cntrl" id="mobile"
                                                placeholder="mobileno" style="width:100%;"
                                                value="{{ $jp_obj['pub_no'] }} " />

                                            <div class="validate"></div>
                                        </div>
                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="company_logo">Year of Publication</label><br>
                                            <input type="month" name="year" placeholder="2021-01" class="form-cntrl" id="year" placeholder=""
                                                style="width:100%;"
                                                value="{{ $jp_obj['pub_year'] }}" />

                                            <div class="validate"></div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="company_logo">Webiste Address</label><br>
                                            <input type="text" name="website" class="form-cntrl" id="website"
                                                placeholder="" style="width:100%;"
                                                value="{{ $jp_obj['pub_website'] }} " />

                                            <div class="validate"></div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="company_logo">Media Url</label><br>
                                            <input type="text" name="media" class="form-cntrl" id="media" placeholder=""
                                                style="width:100%;"
                                                value="{{ $jp_obj['pub_media'] }} " />

                                            <div class="validate"></div>
                                        </div>
                                    </div>





                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <label for="company_logo"> Please Upload your link Document/Pdf</label><br>
                                            <input type="text" name="doc" class="form-cntrl" id="doc" placeholder=""
                                                style="width:100%;"
                                                value="{{ $jp_obj['pub_upload_word'] }}" />

                                            {{-- <input type="file" class="form-cntrl-file" name="document" id="document" data-file_types="doc|pdf|text" style="width:100%;" 
                                          accept="application/msword" id="" placeholder="Add Media"> --}}
                                        </div>


                                    </div>

                                    <div class="form-row" style="margin-top:1rem;">

                                        <div class="form-group col-lg-6">
                                            <label for="name">Organisation logo</label>
                                            <input type="file" name="image" data-file_types="jpg|jpeg|gif|png"
                                                accept="image/png, image/jpeg" class="form-cntrl" id="image"
                                                value="{{ $jp_obj['pub_upload_image'] }}" />

                                            <div class="validate"></div>
                                        </div>
                                        <div class="form-group col-lg-3">
                                            <!-- <label for="company_logo">Uploaded</label><br> -->
                                            <img src="{{ asset($jp_obj['pub_upload_image']) }}"
                                                class="form-cntrl-file" name="" height="70%" alt="">
                                            <input type="hidden" name="old_image"
                                                value="{{ $jp_obj['pub_upload_image'] }}">
                                        </div>
                                    </div>
                                </div>

                            </div>








                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12 ml-auto">

                                    <button class="btn btn-primary  btn-register" style="width:30%"> Edit
                                        Publication</button>
                                </div>
                            </div>
                        </form>
                    </div>



                </section>


            @endif


        </div>
    </section>

    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }




        function onchkclick2() {
            $('#focus').val('');
            chkeles = $('.proposal_focus_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#focus').val() === '') {
                        $('#focus').val($(value).val());
                    } else {
                        $('#focus').val($('#focus').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#focus').val());
        }

    </script>
</main>

@endsection
