@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')
<section id="State and UT" style="">
    <div class="intro-img" style="">
        {{-- <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

        <div class=" container">
            <header class="section-header">
                <h1><b>Advertise with us</b></h1>
            </header>
            <div class="container">

                <table class="wp-block-table " style="width: 100%;">
                    <tbody>
                        <thead>
                            <tr>
                                <th scope="col">Sl.No</th>
                                <th scope="col">Particulars </th>
                                <th scope="col">Duration</th>
                                <th scope="col">Tariff (INR) Including GST </th>
                            </tr>
                        </thead>
                        <tr>
                            <td>
                                <strong>(1)</strong>
                            </td>
                            <td>
                                Home Page – Main Banner (1930 x 354). Display Advertisement, Announcement and Promotion
                                Plans
                            </td>
                            <td>
                                <strong>7 Days<br>
                                    15 Days<br>
                                    30 Days</strong>
                            </td>
                            <td>
                                8,000/-<br>
                                14,000/-<br>
                                20,000/-<br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(2)</strong>
                            </td>
                            <td>
                                Home Page – Banner Latest News (434 x 317). Display Advertisement, Announcement and
                                latest news
                            </td>
                            <td>
                                <strong>7 Days<br>
                                    15 Days<br>
                                    30 Days</strong>
                            </td>
                            <td>
                                5,000/-<br>
                                8,500/-<br>
                                10,500/-<br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(3)</strong>
                            </td>
                            <td>
                                Jobs Announcement:

                                Single Featured announcement <br>
                                Plan-A – 7 (Seven) Featured announcement in a year<br>
                                Plan-B - Unlimited Featured Announcement in a year<br>
                            </td>
                            <td>
                                <strong>30 Days</strong>
                            </td>
                            <td>
                                999/-<br>
                                5,000/-<br>
                                25,000/-<br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(4)</strong>
                            </td>
                            <td>
                                CSR Grants, FC Grants, Scholarships, Fellowships, Awards, Events, Admissions, Online
                                Courses, Call for Papers and Publications Announcement Plan<br>

                                Single Featured announcement<br>
                                Plan-A – 7 (Seven) Featured announcement in a year<br>
                                Plan-B - Unlimited Featured Announcement in a year<br>
                            </td>
                            <td>
                                <strong>30 Days</strong>
                            </td>
                            <td>
                                2,499/-<br>
                                14,000/-<br>
                                35,000/-<br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(5)</strong>
                            </td>
                            <td>
                                Social Media Promotions<br>

                                Single Post – Instagram and Twitter<br>
                                3-Posts – Instagram and Twitter<br>
                                7- Posts – Instagram and Twitter<br>
                            </td>
                            <td>
                                <strong>One Time</strong>
                            </td>
                            <td>
                                1000/-<br>
                                2000/-<br>
                                3500/-
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(6)</strong>
                            </td>
                            <td>
                                Register for Grants and Crowdfunding (<a target="_blank" href="{{url('/faq')}}">Click here for FAQ’s</a>)
                            </td>
                            <td>
                                <strong>One Time</strong>
                            </td>
                            <td>
                                5499/-
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(7)</strong>
                            </td>email-us
                            <td>
                                Emailer Service (<a target="_blank" href="{{url('/email-us')}}">Click here</a> to check the plans accordingly)
                            </td>
                            <td>
                                <strong>One Time</strong>
                            </td>
                            <td>
                                5000/-
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>(8)</strong>
                            </td>
                            <td>
                                SMS Service (<a target="_blank" href="{{url('/email-us#SMS-service')}}">Click here</a> to check the plans accordingly)
                            </td>
                            <td>
                                <strong>One Time</strong>
                            </td>
                            <td>
                                5000/-
                            </td>
                        </tr>
                        

                    </tbody>
                    
                </table>
                <h5 style="margin-top:2rem;">
                    <b>Terms & Conditions</b> 
                </h5>
                <p style="font-weight: 600">
                    If you want us to post your "Ad" please send us in the word document and email us at – contact@SocialServicesIndia.org. Please mention the "Ad type" in the subject line of your email.	
                    <br>			
For Banners – Design needs to be provided by the client. Please confirm availability of ad space before sending the banner design.	<br>			
For Emailer - Content once approved can’t be changed for an emailer. Content limit max. 800 words and 2 images.		<br>		
For SMS - Content once approved can’t be changed for an SMS. Content limit max. 160 characters.		<br>		
{{-- For- SMS .		<br>		 --}}
<br>
All the above mentioned cost is Including 18% GST		<br>		
Payment needs to be made at the time of booking		<br>		
For more customized plan, clarifications or for more information, send us a email: <a href="mailto:contact@socialservicesindia.org">contact@socialservicesindia.org</a>
                </p>

            </div>
        </div>
</section>
@endsection
