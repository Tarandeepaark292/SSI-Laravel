@extends('layouts.home')
@section('content')
<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3>
                All Organization Services
            </h3>
        </header>

        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-job-post')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/jobs.png')}}" style="width: 100%;" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Job</h5>
                                <h6 style="text-align: center;">Rs 999/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-csr')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/CSR.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post CSR</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-fellowship')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/fellowship.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Fellowship</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-grant')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/grants.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Grant</h5>
                                <h6 style="text-align: center;">Rs 5499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-event')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/Events.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Event</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-rfp')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/RFP.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post RFP</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post_award')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/awards.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Award</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post_scholarship')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/scholarships.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Scholarship</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row" style="margin-top: 2rem;">
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-callpaper')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/call for paper.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Call for Paper</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-publication')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/publication.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Publication</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-online-course')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/online course.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Online Course</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="{{url('/recruiter/post-admission')}}">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{asset('/img/icons/addmission.png')}}" style="width: 100%;"/>
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; padding-top:1rem">Post Admission</h5>
                                <h6 style="text-align: center;">Rs 2499/-</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>
@endsection