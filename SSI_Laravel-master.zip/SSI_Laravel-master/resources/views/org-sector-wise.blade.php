@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')
        <!-- ======= About Section ======= -->
        <section id="ORG" style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

    <div class=" container">
            <header class="section-header">
                <h1><b>Our reach: Sector wise</b></h1>
            </header>
            <div class="container">
                <table class="container" style="width: 100%;">
                    <tbody>
                        <thead>
                            <tr>
                                <th scope="col">NO.</th>
                                <th scope="col">Sector Name</th>
                                <th scope="col">No.</th>
                                <th scope="col">Sector Name</th>
                            </tr>
                        </thead>
                        <tr>
                            <td><strong>(1)</strong></td>
                            <td>Aged/Elderly</td>
                            <td><strong>(2)</strong></td>
                            <td>Agriculture</td>
                        </tr>
                        <tr>
                            <td><strong>(3)</strong></td>
                            <td>Animal Husbandry, Dairying &amp; Fisheries</td>
                            <td><strong>(4)</strong></td>
                            <td>Art &amp; Culture</td>
                        </tr>
                        <tr>
                            <td><strong>(5)</strong></td>
                            <td>Biotechnology</td>
                            <td><strong>(6)</strong></td>
                            <td>Children</td>
                        </tr>
                        <tr>
                            <td><strong>(7)</strong></td>
                            <td>Civic Issues</td>
                            <td><strong>(8)</strong></td>
                            <td>Dalit Upliftment</td>
                        </tr>
                        <tr>
                            <td><strong>(9)</strong></td>
                            <td>Differently Abled</td>
                            <td><strong>(10)</strong></td>
                            <td>Disaster Management</td>
                        </tr>
                        <tr>
                            <td><strong>(11)</strong></td>
                            <td>Drinking Water</td>
                            <td><strong>(12)</strong></td>
                            <td>Education &amp; Literacy</td>
                        </tr>
                        <tr>
                            <td><strong>(13)</strong></td>
                            <td>Environment &amp; Forests</td>
                            <td><strong>(14)</strong></td>
                            <td>Food Processing</td>
                        </tr>
                        <tr>
                            <td><strong>(15)</strong></td>
                            <td>Health &amp; Family Welfare</td>
                            <td><strong>(16)</strong></td>
                            <td>HIV/AIDS</td>
                        </tr>
                        <tr>
                            <td><strong>(17)</strong></td>
                            <td>Housing</td>
                            <td><strong>(18)</strong></td>
                            <td>Human Rights</td>
                        </tr>
                        <tr>
                            <td><strong>(19)</strong></td>
                            <td>Information &amp; Communication Technology</td>
                            <td><strong>(20)</strong></td>
                            <td>Labour &amp; Employment</td>
                        </tr>
                        <tr>
                            <td><strong>(21)</strong></td>
                            <td>Land Resources</td>
                            <td><strong>(22)</strong></td>
                            <td>Legal Awareness &amp; Aid</td>
                        </tr>
                        <tr>
                            <td><strong>(23)</strong></td>
                            <td>Micro Finance SHGs</td>
                            <td><strong>(24)</strong></td>
                            <td>Micro Small &amp; Medium Enterprises</td>
                        </tr>
                        <tr>
                            <td><strong>(25)</strong></td>
                            <td>Minority Issues</td>
                            <td><strong>(26)</strong></td>
                            <td>New &amp; Renewable Energy</td>
                        </tr>
                        <tr>
                            <td><strong>(27)</strong></td>
                            <td>Nutrition</td>
                            <td><strong>(28)</strong></td>
                            <td>Panchayati Raj</td>
                        </tr>
                        <tr>
                            <td><strong>(29)</strong></td>
                            <td>Prisoner’s Issues</td>
                            <td><strong>(30)</strong></td>
                            <td>Right To Information &amp; Advocacy</td>
                        </tr>
                        <tr>
                            <td><strong>(31)</strong></td>
                            <td>Rural Development &amp; Poverty Alleviation</td>
                            <td><strong>(32)</strong></td>
                            <td>Science &amp; Technology</td>
                        </tr>
                        <tr>
                            <td><strong>(33)</strong></td>
                            <td>Scientific &amp; Industrial Research</td>
                            <td><strong>(34)</strong></td>
                            <td>Sports</td>
                        </tr>
                        <tr>
                            <td><strong>(35)</strong></td>
                            <td>Tourism</td>
                            <td><strong>(36)</strong></td>
                            <td>Tribal Affairs</td>
                        </tr>
                        <tr>
                            <td><strong>(37)</strong></td>
                            <td>Urban Development &amp; Poverty Alleviation</td>
                            <td><strong>(38)</strong></td>
                            <td>Vocational Training</td>
                        </tr>
                        <tr>
                            <td><strong>(39)</strong></td>
                            <td>Water Resources</td>
                            <td><strong>(40)</strong></td>
                            <td>Women’s Development &amp; Empowerment</td>
                        </tr>
                        <tr>
                            <td><strong>(41)</strong></td>
                            <td>Youth Affairs</td>
                            <td><strong>(42)</strong></td>
                            <td>Any Other</td>
                        </tr>
                    </tbody>
                </table>

            </div>
            </div>
        </section>


    @endsection