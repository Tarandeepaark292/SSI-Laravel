@extends('layouts.home')
@section('content')
<section id="NGO" style="">
    <div class="intro-img" style="">
        {{-- <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

        <div class=" container">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                <h3><span class="titleheading">NGO BYELAWS</span>  </h3>
            </header>
        </div>
        <table class="table-responsive-md table-hover">
            <tbody>
                <thead>
                    <tr>
                        <th scope="col">NO.</th>
                        <th scope="col">Format</th>
                        <th scope="col">Link</th>
                        
                    </tr>
                </thead>
                <tr>
                    <td>1</td>
                    <td>Society - Memorandum of Association & Byelaws</td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/1-Society-Memorandum-of-Association-Byelaws.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Section – 8 - Memorandum of Association & Articles of Association
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/2-Section-8-Memorandum-of-Association-Articles-of-Association.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Deed of Trust
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/3-Deed-of-Trust.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>General Agenda
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/4-General-Agenda.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Appointment of Auditor
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/5-Appointment-of-auditor.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Minutes of the General Meeting 
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGOs-MoA-AoA-Byelaws/6-Minutes-of-the-General-Meeting.pdf')}}">Download</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</section>

@endsection
