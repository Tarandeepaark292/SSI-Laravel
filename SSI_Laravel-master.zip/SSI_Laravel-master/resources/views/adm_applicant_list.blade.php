@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Applicant List</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header" style="display: flex;justify-content: space-between;align-items: center;">
                <div>
                    <i class="fas fa-table mr-1"></i>Applicant List
                </div>
                <div>
                    {{-- <i class="fas fa-download mr-1"></i><a href="{{url('/admin/award/export')}}" style="color: black"> Download </a> --}}
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Applicant Name</th>
                                <th>Job title</th>
                                <th>Organization name</th>
                                <th>Organization Type</th>
                                <th>Applied date</th>
                                
                                
                            </tr>
                        </thead>
                        @isset($applicants)
                        <tfoot>
                            <tr>
                                <th>Applicant Name</th>
                                <th>Job title</th>
                                <th>Organization name</th>
                                <th>Organization Type</th>
                                <th>Applied date</th>
                               
                            </tr>
                        </tfoot>
                        <tbody>
                            @foreach($applicants as $noti)
                            <tr>
                                <td>{{ $noti['js_name'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['jp_title'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['r_org_name'] }}</td>
                                <td>{{ $noti['r_comp_type'] }}</td>
                                <td>{{ $noti['ja_create_date'] }}</td>
                               
                                
                            </tr>
                            @endforeach
                        </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
</script>

@endsection