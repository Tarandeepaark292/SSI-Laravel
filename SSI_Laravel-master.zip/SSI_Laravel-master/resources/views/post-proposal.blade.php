@extends('layouts.home')
@section('content')

<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading"> FUNDING <span class="titleheading">AGENCY</span> <span class="titleheading">
                        CALL </span> <span class="titleheading"> FOR</span> <span class="titleheading">
                        PROPOSALS.</span></span></h3>




        </header>
        <div class="row" style="padding:20px;">
            <div class="col-12">
                <span class="titleheading">
                    <h6>RFP’s / Call for Proposals get posted immediately on our website for greater visibility and
                        access across India. ></h6>
                </span>
                <span style="display: block;font-size: 16px;">It stays on our homepage for 1 month or until closing date
                    of the proposal as mentioned under the “Closing date of Proposal” section, for maximum visibility
                    and targeted responses</span>
                <br>
                <span style="display: block;font-size: 16px;">+</span>
                <br>
                <span style="display: block;font-size: 16px;">RFP’s / Call for Proposals get circulated with all NGOs
                    and stays in our RFP’s / Call for Proposals newsletter for the next 2 issues.</span>
                <br>
                <span style="display: block;font-size: 16px;">This is at the cost of<b style=color:blue> Rs
                        3499/- 
                        @if(session()->has('ssiapp_rec'))
                        <a href="#" onclick="addTocart(5)">(Add To Cart)</a>
                        @endif
                    </b></span></br>

                <span style="display: block;font-size: 16px;"><b>If you want us to post your “RFP Ad” please email us at
                        –</b> :<a style="color:blue;"
                        href="https://socialservicesindia.com/contact@SocialServicesIndia.com ">contact@SocialServicesIndia.com.
                    </a> <b> Please mention “RFP Ad” and it’s title in the subject line of your </b></span>



            </div>

        </div>
        @if(session()->has('ssiapp_rec'))
            <section style="">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4>Post RFP </h4>

                    </header>





                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-proposal/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="">
                            <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="orgname" class="form-cntrl" id="orgname"
                                            placeholder="Name of  the organisation" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant Title </label>
                                        <input type="text" name="grant_title" class="form-cntrl" id="grant_title"
                                            placeholder="Grant title" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Total Amount </label>
                                        <input type="text" name="total_amt" class="form-cntrl" id="total_amt"
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing date of proposal </label>
                                        <input type="date" name="close_date" class="form-cntrl" id="close_date"
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email" placeholder="" />
                                        <div class="validate"></div>
                                    </div>

                                </div>

                                <div class="form-row">



                                    <div class="form-group col-lg-12">
                                        <label for="name">Description of the proposal </label>
                                        </br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="proposal_desc"
                                            placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label> proposal category</label>
                                        </br>
                                        <input type="file" name="document" class="form-cntrl" data-file_types="doc|pdf|text"
                                            accept="application/pdf">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>organisation logo</label>
                                        </br>
                                        <input type="file" name="company_logo" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg">
                                    </div>


                                </div>
                                @isset($html)
                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <h4>Proposal Category</h4>
                                        </div>
                                        {{-- <div class="form-group col-lg-12"> --}}
                                        {!! $html !!}
                                        {{-- </div> --}}
                                        <input type="hidden" id="cates" name="cates" value="" />
                                    </div>
                                @endisset


                                
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name"> Organisation Achivement </label>

                                        <textarea class="form-cntrl" name="Description" id="Description" placeholder=""
                                            rows="10" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name"> Organisation Achivement</label>
                                        <input type="text" name="organisation_ach" class="form-cntrl"
                                            id="organisation_ach" placeholder="Name of  the organisation" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name"> Organisation PAN No</label>
                                        <input type="text" name="organisation_pan" class="form-cntrl"
                                            id="organisation_pan" placeholder="" />
                                        <div class="validate"></div>
                                    </div>


                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name"> Human Check 2+7=</label>
                                        <input type="text" name="organisation" class="form-cntrl" id=""
                                            placeholder="" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                            </div>

                            {{-- <div class="form-row"">
                                <div class="form-group col-lg-12">
                                    <input type="checkbox" id="terms" name="terms" value="">
                                    <label for="vehicle3"> Terms and condition</label><br>
                                </div>
                            </div> --}}
                        </div>
                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12 ml-auto">
                                    <button class="btn btn-primary  btn-register">Submit RFP</button>
                                </div>
                            </div>
                    </form>
                </div>



            </section>








        @else

            <div class="row about-container">
                <div class="col-lg-12">

                    <hr style="color:#007bff;border:3px solid;">
                    <p class="card-text"><i>Please login to submit RFP/CFPs.</i> <a
                            href="{{url('/login')}}"
                            class="btn btn-primary">Login</a></p>

                    <p style="margin-top: 30px; font-size: 1rem;">
                        For any further assistance our experts will get in touch with you and take it forward.
                        <br /><br />
                        Please email us at: <b>contact@SocialServicesIndia.com</b> for <b>Queries</b>
                    </p>
                </div>

            </div>
        @endif
    </div>

</section>

@endsection
{{-- </div>

        </section>

@endsection--}}
