@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Edit Donate</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Edit Donate </li>
            </ol>

            
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4>Edit Donate </h4>

                    </header>





                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/donation/updates')}}/{{$jp_obj['donate_id']}}" method="post"
                    accept-charset="utf-8" enctype="multipart/form-data">
                            @csrf
                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Donation Title </label>
                                        <input type="text" class="form-cntrl" name="title" id="title"
                                        placeholder="Donation Title"  value="{{$jp_obj['donation_title']}}" required/>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Donation Banner</label>
                                        </br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="banner" id="banner"
                                            placeholder="Add Media" value="{{$jp_obj['donation_banner']}}" >
                                    </div>

                                    
                    <div class="form-group col-md-6">
                        <label for="name"><b>Current banner</b></label>
                        <br>
                        {{-- <input type="text" class="form-cntrl-file" name="image" id="image"  value="{{$jp_obj['p_image']}}" > --}}
                        <img src="{{asset($jp_obj['donation_banner'])}}" class="form-cntrl-file" name="banner" height="70px;" alt="">
                        <input type="hidden" name="old_banner" value="{{$jp_obj['donation_banner']}}" >
                        <div class="validate"></div>
                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Summary </label>
                                        <textarea class="form-cntrl" name="summary" id="summary"
                                            placeholder="Add Summary" rows="5"
                                            style="height: auto;resize: none;"  required>{{$jp_obj['donate_Summary']}}</textarea>

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="name">Goal </label>
                                        <input type="text" name="totalgoals" class="form-cntrl" id="summary"
                                            placeholder="Goal" value="{{$jp_obj['donate_Summary']}}" required/>
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Number of fundraisers </label>
                                        <input type="text" name="fundraisers" class="form-cntrl" id="close_date"
                                            placeholder="Number of fundraisers"  value="{{$jp_obj['donate_fundraiser']}}" required/>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                {{-- <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Remaining </label>
                                        <input type="text" name="remaining" class="form-cntrl" id="remaining"
                                            placeholder="Grant title" />
                                        <div class="validate"></div>
                                    </div>
                                </div> --}}

                                {{-- <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="name">Donors</label>
                                        <input type="text" name="donors" class="form-cntrl" id="location"
                                            placeholder="donors" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Monthly Donors </label>
                                        <input type="text" name="monthlydonors" class="form-cntrl" id="donors"
                                            placeholder="monthlydonors" />
                                        <div class="validate"></div>
                                    </div>


                                </div> --}}

                                {{-- <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="name">fundraisers </label>
                                        <input type="text" name="fundraisers" class="form-cntrl" id="close_date"
                                            placeholder="fundraisers" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">years </label>
                                        <input type="text" name="years" class="form-cntrl" id="" placeholder="years" />
                                        <div class="validate"></div>
                                    </div>

                                </div> --}}

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="challenge">Challenge</label>
                                        </br>
                                        <textarea class="form-cntrl" name="challenge" id="" placeholder="Challenge"
                                            rows="10" style="height: auto;resize: none;"  required>{{$jp_obj['donate_challenge']}}</textarea>
                                        <div class="validate"></div>

                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="name">Long-Term Impact</label>

                                        <textarea class="form-cntrl" name="longterm" id="longterm"
                                            placeholder="Long-Term Impact" rows="10"
                                            style="height: auto;resize: none;" required>{{$jp_obj['donate_long_impact']}}</textarea>
                                        <div class="validate"></div>

                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Solution </label>
                                        {{-- <input type="text" name="solution" class="form-cntrl" id="solution"
                                            placeholder="solution" /> --}}
                                        <textarea class="form-cntrl" name="solution" id="solution"
                                            placeholder="Solution" rows="10"
                                            style="height: auto;resize: none;"  required>{{$jp_obj['donate_solution']}}</textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Additional Documentation</label>

                                        <input type="file" name="document" name="document" class="form-cntrl"
                                            data-file_types="doc|pdf|text" accept="application/pdf" value="{{$jp_obj['donate_additional_documentation']}}" >
                                    </div>



                                    {{-- <div class="form-row"> --}}
                                        <div class="form-group col-lg-6">
                                            <label for="company_logo">Additional Documentation</label><br>
                                            <input type="text" class="form-cntrl-file" name="document" id="document"
                                                data-file_types="doc|pdf|text" accept="application/pdf"
                                                placeholder="Add Media" value="{{$jp_obj['donate_additional_documentation']}}">
                                            <input type="hidden" name="old_document" value="{{$jp_obj['donate_additional_documentation']}}">
                                        </div>


                                </div>


                                <div class="form-row">

                                <div class="form-group col-md-12">
                                    <label>Reference Url</label>
                                    <input type="text" name="referenceurl" class="form-cntrl" id=""
                                        placeholder="Reference Url"value="{{$jp_obj['donate_ref_url']}}" required/>
                                    <div class="validate"></div>

                                </div>
                                </div>

                                {{-- <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Reference Url</label>
                                        <input type="text" name="referenceurl" class="form-cntrl" id=""
                                            placeholder="resources" />
                                        <div class="validate"></div>

                                    </div>
                                </div> --}}



                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Organisation name </label>
                                        <input type="text" class="form-cntrl" name="org_name" id="org_name"
                                        placeholder="Organisation name"  value="{{$jp_obj['donate_org_name']}}"/>
                                        

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Organisation logo</label>
                                        </br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="organisationlogo" id=""
                                            placeholder="Add Media" value="{{$jp_obj['donate_logo']}}">
                                    </div>

                                              
                    <div class="form-group col-md-6">
                        <label for="name"><b>Current Organisation logo</b></label>
                        <br>
                        {{-- <input type="text" class="form-cntrl-file" name="image" id="image"  value="{{$jp_obj['p_image']}}" > --}}
                        <img src="{{asset($jp_obj['donate_logo'])}}" class="form-cntrl-file" name="organisationlogo" height="70px;" alt="">
                        <input type="hidden" name="old_organisationlogo" value="{{$jp_obj['donate_logo']}}" >
                        <div class="validate"></div>
                    </div>


                                    
                                </div>




                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Organisation Detail</label>
                                        {{-- <input type="textarea" name="organisationdetail" class="form-cntrl" id=""
                                            placeholder="OrganisationDetail" /> --}}
                                        <textarea class="form-cntrl" name="organisationdetail" id=""
                                            placeholder="Organisation Detail" rows="10"
                                            style="height: auto;resize: none;" >{{$jp_obj['donate_org_detail']}}</textarea>
                                        <div class="validate"></div>

                                    </div>
                                </div>



                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Address</label>
                                        {{-- <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="Location" /> --}}
                                        <textarea class="form-cntrl" name="location" id="" placeholder="Address Details"
                                            rows="5" style="height: auto;resize: none;" >{{$jp_obj['donate_loc']}}</textarea>
                                        <div class="validate"></div>

                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>Website</label>
                                        <input type="text" name="website" class="form-cntrl" id="website"
                                            placeholder="Website" value="{{$jp_obj['donate_website']}}" />
                                        <div class="validate"></div>

                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label>Checkout Url</label>
                                        <input type="text" name="chkouturl" class="form-cntrl" id="website"
                                            placeholder="Checkout Url"  value="{{$jp_obj['donate_checkout_url']}}"required/>
                                        <div class="validate" ></div>

                                    </div>
                                </div>

                                <div class="form-row">

                                    <!-- <div class="form-group col-md-6"> -->

                                    <div class="form-group col-md-6">
                                        <label>Choose State</label>
                                        <select name="category" id="category" class="form-control" value="{{$jp_obj['donate_state']}}">
                                            <option>Choose State</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Andhra Pradesh") ? 'selected' : '' }} value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Andaman and Nicobar Islands") ? 'selected' : '' }} value="Andaman and Nicobar Islands">Andaman and Nicobar Islands
                                            </option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Arunachal Pradesh") ? 'selected' : '' }} value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Assam") ? 'selected' : '' }} value="Assam">Assam</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Bihar") ? 'selected' : '' }} value="Bihar">Bihar</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Chandigarh") ? 'selected' : '' }} value="Chandigarh">Chandigarh</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Chhattisgarh") ? 'selected' : '' }} value="Chhattisgarh">Chhattisgarh</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Dadar and Nagar Haveli") ? 'selected' : '' }} value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Daman and Diu") ? 'selected' : '' }} value="Daman and Diu">Daman and Diu</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Delhi") ? 'selected' : '' }} value="Delhi">Delhi</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Lakshadweep") ? 'selected' : '' }} value="Lakshadweep">Lakshadweep</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Puducherry") ? 'selected' : '' }} value="Puducherry">Puducherry</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Goa") ? 'selected' : '' }} value="Goa">Goa</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Gujarat") ? 'selected' : '' }} value="Gujarat">Gujarat</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Haryana") ? 'selected' : '' }} value="Haryana">Haryana</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Himachal Pradesh") ? 'selected' : '' }} value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Jammu and Kashmir") ? 'selected' : '' }}value="Jammu and Kashmir">Jammu and Kashmir</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Jharkhand") ? 'selected' : '' }} value="Jharkhand">Jharkhand</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Karnataka") ? 'selected' : '' }} value="Karnataka">Karnataka</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Kerala") ? 'selected' : '' }} value="Kerala">Kerala</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Madhya Pradesh") ? 'selected' : '' }} value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Maharashtra") ? 'selected' : '' }} value="Maharashtra">Maharashtra</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Manipur") ? 'selected' : '' }} value="Manipur">Manipur</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Meghalaya") ? 'selected' : '' }} value="Meghalaya">Meghalaya</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Mizoram") ? 'selected' : '' }} value="Mizoram">Mizoram</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Nagaland") ? 'selected' : '' }} value="Nagaland">Nagaland</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Odisha") ? 'selected' : '' }} value="Odisha">Odisha</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Punjab") ? 'selected' : '' }} value="Punjab">Punjab</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Rajasthan") ? 'selected' : '' }} value="Rajasthan">Rajasthan</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Sikkim") ? 'selected' : '' }} value="Sikkim">Sikkim</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Tamil Nadu") ? 'selected' : '' }} value="Tamil Nadu">Tamil Nadu</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Telangana") ? 'selected' : '' }} value="Telangana">Telangana</option>
                                            <option {{ ( $jp_obj['donate_state'] == "Tripura") ? 'selected' : '' }} value="Tripura">Tripura</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Uttar Pradesh") ? 'selected' : '' }} value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option  {{ ( $jp_obj['donate_state'] == "Uttarakhand") ? 'selected' : '' }} value="Uttarakhand">Uttarakhand</option>
                                            <option {{ ( $jp_obj['donate_state'] == "West Bengal") ? 'selected' : '' }} value="West Bengal">West Bengal</option>
                                        </select>


                                    </div>


                                    <div class="form-group col-md-6">
                                        <label>Focus Area</label>
                                        <select name="focusarea" id="" class="form-control" value="{{$jp_obj['donate_foc_Area']}}">

                                            <option>Focusarea</option>
                                            <option  {{ ( $jp_obj['donate_foc_Area'] == "Womenandgirls") ? 'selected' : '' }} value="Womenandgirls">Women and Girls</option>
                                            <option {{ ( $jp_obj['donate_foc_Area'] == "Health") ? 'selected' : '' }} value="Health">Health</option>
                                            <option  {{ ( $jp_obj['donate_foc_Area'] == "Environment") ? 'selected' : '' }}value="Environment">Environment</option>
                                            <option {{ ( $jp_obj['donate_foc_Area'] == "Hunger") ? 'selected' : '' }} value="Hunger">Hunger</option>
                                            <option {{ ( $jp_obj['donate_foc_Area'] == "AnyOther") ? 'selected' : '' }} value="AnyOther">Any other</option>
                                        </select>

                                    </div>

                                </div>
                                <div class="row" style="text-align:center;">
                                    <div class="col-md-12 ml-auto">
                                        <button class="btn btn-primary  btn-register">Update Donation</button>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>



            </section>








            

        </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script> -->
</main>

@endsection
