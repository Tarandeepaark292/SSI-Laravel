@extends('layouts.auth_bend_home')
@section('content')

<div class="container register">
    <h1 class="mt-4">Admin Panel</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active"> Admin  Organisation Panel</li>
            </ol>
    <div class="row pt-3">
       
        <div class="col-md-12 register-right  ">
           
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    {{-- <h3 class="register-heading text-center mb-3">Apply as a Organisation</h3> --}}
                    <form action="{{url('/admin/organisation/submit')}}" method="post">
                        <div class="row register-form">
                            <div class="col-12 " style="border: 0;">
                            
                                <div class="form-row">
                                    <div class="form-group  col-md-6 ">
                                     <input type="text" name="org_name" class="form-control"
                                        placeholder="Organisation Name *" value="" />
                                        @error('org_name') <p style="color:red">{{$message}}</p>@enderror
                                    </div>
                                    <div class="form-group col-md-6">
                                    <input type="email" name="emailaddress" class="form-control" placeholder="Official Email *"
                                        value="" />
                                        @error('emailaddress') <p style="color:red">{{$message}}</p>@enderror
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <input type="text" maxlength="10" minlength="10" name="mobile" class="form-control"
                                        placeholder="Mobile *" value="" />
                                        @error('mobile') <p style="color:red">{{$message}}</p>@enderror
                                    </div>
                                    <div class="form-group col-md-6">
                                        <input type="" class="form-control" name="officelandline"
                                        placeholder="Office Landline: (Optional) " value="" />
                                        @error('officelandline') <p style="color:red">{{$message}}</p>@enderror

                                     </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                     <input type="password" class="form-control" name="passwd"
                                        placeholder="Create Password: (Optional)" value="" />
                                        @error('passwd') <p style="color:red">{{$message}}</p>@enderror
                                    </div>
                                    <div class="form-group col-md-6">
                                    
                                        <select class="form-control" name="company-type">
                                            <option value="" class="hidden" selected disabled>Company type:*</option>
                                            <option value="Trust registration">Trust registration</option>
                                            <option value="Society registration">Society registration</option>
                                            <option value="Section 8 or 25 company registration">Section 8 or 25 company registration</option>
    
                                        </select>
                                        @error('company-type') <p style="color:red">{{$message}}</p>@enderror
                                    </div>
                                </div>

                          

                           <div class="form-row">
                                <div class="form-group col-md-6">
                                    <input type="text" name="contactperson" class="form-control"
                                        placeholder="Contact Person’s Name: *" value="" />
                                        @error('contactperson') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                               
                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" name="pincode" placeholder="Pincode* " value="" />
                                    @error('pincode') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" name="website" placeholder="Website: (Optional)"
                                        value="" />
                                       
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" name="org_pan" placeholder="Organisation Pan: (Optional)"
                                        value="" />
                                </div>
                            </div>


                            </div>
             
                            <input type="hidden" name="role" value="recruiter" />
                            <input type="hidden" name="from" value="organization_register" />
                            <div class="col-md-12" style="text-align: center;">
                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                               
                                <input type="submit" class="btnRegister mt-3" value="Register"  style="background-color: #006AC7 !important;color:white;font-size: 1.3rem;
                                border-radius: 5px;
                                padding: 2px 14px;width:200px;">
                                
                            </div>
                        </div>
                    </form>



                </div>
            </div>
        </div>
    </div>

</div>
@endsection
