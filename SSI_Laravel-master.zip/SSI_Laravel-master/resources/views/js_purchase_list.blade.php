@extends('layouts.js_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Jobseeker Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Jobseeker Panel</li>
            <li class="breadcrumb-item active">Purchase List</li>
        </ol>

        
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Purchase List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Service Name</th>
                                <th>Service Price</th>
                                <th>Order ID</th>
                                <th>Create Date</th>
                                <th>Purchased By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($purchaselist)
                            <tfoot>
                                <tr>
                                    <th>Service Name</th>
                                    <th>Service Price</th>
                                    <th>Order ID</th>
                                    <th>Create Date</th>
                                    <th>Purchased By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($purchaselist as $noti)
                                    <tr>
                                        <td>{{ $noti['pur_ser_name'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['pur_ser_price'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['order_id'] }}</td>
                                <td>{{ $noti['pur_create_date'] }}</td>
                                <td>{{ $noti['pur_by'] }}</td>
                                <td>{{ $noti['status'] }}</td>
                                        
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>

@endsection
