@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Post Event</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Update Event </li>
        </ol>

       

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h3><span class="titleheading">Events Ads </span> </h3>
                    </header> --}}

                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/updateevent')}}/{{$jp_obj['evt_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12 " style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Title of the event </label>
                                        <input type="text" name="event_title" class="form-cntrl" id="event" value="{{$jp_obj['evt_title']}}"
                                            placeholder="Event Title" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="organisation_name" class="form-cntrl" id="organisation" value="{{$jp_obj['evt_org_name']}}"
                                            placeholder="Organisation name" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                               
                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <label for="name">Current Event Banner</label><br/>
                                            <img  style="width: 200px;" src="{{asset($jp_obj['evt_upload_banner'])}}" /><br/>
                                            
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label for="name">Event Banner </label>
                                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="upload_evt_banner" id="" placeholder="Add Media">
                                            <input type="hidden" name="old_upload_evt_banner" value="{{$jp_obj['evt_upload_banner']}}">
                                            <div class="validate"></div>
                                        </div>
                                    </div>
                                

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="loc_name" class="form-cntrl" id="email" value="{{$jp_obj['evt_loc']}}"
                                            placeholder="" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing dates for proposal</label>
                                        <input type="date" name="proposal_close_date" class="form-cntrl" id="proposal_close_date" value="{{$jp_obj['evt_end_date']}}"
                                            placeholder="" />
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Detail of complete Event Information</label><br>
                                        <textarea class="form-cntrl" name="event_desc" id="summernote" placeholder="" rows="10" 
                                            style="height: auto;resize: none;">{{$jp_obj['evt_desc']}}</textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Event Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="{{$jp_obj['evt_cates']}}" />
                                </div>
                                @endisset

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload Event Document</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="upload_evt_doc" id="" placeholder="Add Media">
                                            <input type="hidden" name="old_upload_evt_doc" value="{{$jp_obj['evt_upload_doc']}}">

                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Current Organization Logo</label><br/>
                                        <img  style="width: 200px;" src="{{asset($jp_obj['evt_org_logo'])}}" /><br/>
                                        
                                    </div>
                                    <div class="form-group col-lg-6">
                                        
                                        <label for="company_logo">Organisation logo</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="org_logo" id="" placeholder="Add Media">
                                            <input type="hidden" name="old_org_logo" value="{{$jp_obj['evt_org_logo']}}">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder=""  value="{{$jp_obj['evt_ref_url']}}" />

                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label>Email</label>
                                        <input type="text" name="email" class="form-cntrl" id="" placeholder=""  value="{{$jp_obj['evt_email']}}" />


                                    </div>

                                </div>

                                {{-- <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Terms and Condition</label><br>
                                    </div>
                                </div> --}}
                                <div class="form-row" style="text-align:center;">
                                    <div class="form-group col-lg-12 ml-auto">
                                        <button class="btn btn-primary  btn-register" style="width:30%">Submit
                                            Event</button>
                                    </div>
                                </div>
                            </div>                            
                    </form>
                </div>
            </section>

       


    </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>
</main>

@endsection