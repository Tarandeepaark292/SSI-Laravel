@extends('layouts.home')
@section('content')
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Events</span></h3>
                </header>
                <div class="row">
                    <div class="col-12">
                        <span style="display: block;font-size: 16px;">Events get posted immediately on our website for
                            greater visibility and access across India.</span> </span>
                        <br>
                        <span style="display: block;font-size: 16px;">Stays at our homepage for 1 month or until closing
                            date of event as mentioned under section “Closing date of Event” for maximum visibility and
                            targeted responses.
                        </span>
                        <br>
                        <span style="display: block;font-size: 16px;">This is at the cost of <span style="color:blue">Rs. 2499/-</span></span>

                        <br>

                        or
                        <br>
                        <br>

                        <span style="display: block;font-size: 16px;"><strong>If you want us to post your “Event Ad”
                                please email us at – <a style="color:blue;" href="https://socialservicesindia.com/contact@SocialServicesIndia.com">contact@SocialServicesIndia.com.
                                </a>Please mention the “Event Ad” and it’s title in the subject line of your
                                email.</strong>
                        </span>


                    </div>
                </div>
                <div class="row about-container">
                    <div class="col-lg-12">

                        <hr style="color:#007bff;border:3px solid;">
                        <p class="card-text"><i>Please login to submit Event.</i> <a href="{{url('/login')}}" class="btn btn-primary">Login</a></p>

                        <p style="margin-top: 30px; font-size: 1rem;">
                            For any further assistance our experts will get in touch with you and take it forward.
                            <br /><br />
                            Please email us at: <b>contact@SocialServicesIndia.com</b> for <b>Queries</b>
                        </p>
                    </div>

                </div>
            </div>
        </section>

    @endsection