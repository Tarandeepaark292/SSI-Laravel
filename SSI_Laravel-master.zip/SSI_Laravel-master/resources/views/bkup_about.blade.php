@extends('layouts.home')
@section('content')

        <!-- ======= About Section ======= -->
        <section style="margin-top: 100px;">
            <div class="intro-img" style="margin-top:5rem;">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div>
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3> <span class="titleheading">About</span> <span class="titleheading">Us</span></h3>
                </header>

                <div class="row about-container">

                    <div class="col-lg-6 content order-lg-1 order-2">
                        <i>
                            <p>
                                The organization was established to help reduce barriers for practitioners at all levels, sizes, and degrees of sophistication in the field.
                                From our humble beginning with a handful of users a few years ago, www.SocialServicesIndia.com is now a leading source of fundraising information and resources for many Charitable Trusts, Societies, NGOs, NPOs and development professionals around the world.
                            </p>
                            <p>
                                Social Services India Premium is the next evolution in fundraising for NGOs.
                                It is India’s best fundraising solution designed specifically for development professionals working in India and around the developing world.
                            </p>
                            <p>Social Services India is an online marketplace that seeks to help Charitable Trusts, Societies, NGOs, NPOs, and Donors work more efficiently.
                                We connect development professionals to the latest information, tools, and resources to fuel what they do best: create a better world.
                            </p>
                        </i>
                    </div>

                    <div class="col-lg-6 background order-lg-2 order-1 wow fadeInUp">
                        <img src="{{asset('img/about-img.svg')}}" class="img-fluid" alt="">
                    </div>
                </div>

                <div class="row about-extra">
                    <div class="col-lg-7 wow fadeInUp">
                        <img src="{{asset('img/about-extra-1.svg')}}" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-5 wow fadeInUp pt-5 pt-lg-0" style="margin-top:5rem;margin-bottom: 5rem;">
                        <h4 style="font-variant-caps: petite-caps;">Our Services</h4>
                        <ul>
                            <li>Jobseekers</li>
                            <li>Recruiters</li>
                            <li>RFP's/Call For Proposals</li>
                            <li>CSR Funding</li>
                            <li>Register for Grants</li>
                            <li>Events</li>
                            <li>Financial Services</li>
                        </ul>
                    </div>
                </div>

                <div class="row about-extra">
                    <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
                        <img src="{{asset('img/about-extra-2.svg')}}" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1" style="margin-top:5rem;margin-bottom: 5rem;">
                        <h4 style="font-variant-caps: petite-caps;">Social Services India is headquarted at:</h4>
                        <p>
                            Social Services India (SSI)<br>
                            Elegant Valley, #FF 111 “A”, Block, 1st Floor,<br>
                            BEML Layout, 3rd Stage,<br>
                            Rajarajeshwari Nagar, Bengaluru,<br>
                            Karnataka, 560 098, India.<br>
                            Contact: contact@SocialServicesIndia.com<br><br><br>
                            We are in process of operating offices in Australia.<br>
                        </p>
                    </div>

                </div>
            <a id="testpdf" href="{{url('/testpdf')}}" style="display: none;">test</a>
            </div>
        </section><!-- End About Section -->

        @section('custom_script')
<script>
$(document).ready(function()
{
    $('#testpdf')[0].click();
});
</script>
@endsection

@endsection
