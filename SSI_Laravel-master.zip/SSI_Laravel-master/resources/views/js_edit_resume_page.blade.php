@extends('layouts.js_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container">
            <form action="{{ url('js/js_resume/update/') }}/{{ $jobseeker['js_id'] }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                @csrf
                <div class="row" style="margin-top: 2rem;">
                    <div class="col-12" style="border: 0;">
                        <div class="tr-single-box">
                            <div class="tr-single-header">
                                <h4 class="mt-4"><i class="fas fa-graduation-cap"></i> Education <a href="#" onclick="showEDUModal(event)" class="btn btn-sm btn-dark" style="margin-left: 1rem;">Add +</a></h4>
                            </div>
                            <div class="tr-single-body">
                                <div class="container">
                                    <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                        <div class="col-4">
                                            Qualification
                                        </div>
                                        <div class="col-2">
                                            Dates
                                        </div>
                                        <div class="col-4">
                                            School / Colleges
                                        </div>
                                        <div class="col-2">
                                            Action
                                        </div>
                                    </div>
                                    <div id="edudiv">
                                    @foreach($js_edu_list_obj as $noti)
                                    <div class="row" id="edurow_{{ $noti['idx'] }}" style="background:floralwhite;padding: 12px 5px;">
                                        <div class="col-4">
                                            {{ $noti['degree'] }}
                                        </div>
                                        <div class="col-2">
                                            {{ $noti['start'] }} - {{ $noti['end'] }}
                                        </div>
                                        <div class="col-4">
                                            {{ $noti['school'] }}
                                        </div>
                                        <div class="col-2" style="text-align: center;">
                                            {{-- <a href="#" style="color:black;"><i class="far fa-edit"></i></a> --}}
                                            <a href="#" onclick="jsfunc.removeEDUobj(event,{{ $noti['idx'] }});" style="color:black;"><i class="far fa-trash-alt"></i></a>
                                        </div>
                                    </div>
                                    @endforeach
                                    </div>
                                </div>
                                <input type="hidden" name="edudivjson" id="edudivjson"
                                value="{{ $jobseeker['js_education'] }}" />

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 2rem;">
                    <div class="col-12" style="border: 0;">
                        <div class="tr-single-box">
                            <div class="tr-single-header">
                                <h4 class="mt-4"><i class="fas fa-briefcase"></i> Experience <a href="#" onclick="showEXPModal(event)" class="btn btn-sm btn-dark" style="margin-left: 1rem;">Add +</a></h4>
                            </div>
                            <div class="tr-single-body">
                                <div class="container">

                                    <div class="row">
                                        <div class="col-md-12" style="padding: 0px;">
                                            <div class="form-row">

                                                <div class="form-group col-lg-6">
                                                    <label for="name">Total Experience</label>
                                                    <input type="text" name="jstotexp" class="form-cntrl" id="video"
                                                        placeholder="eg. 1 yr" data-rule="minlen:4"
                                                        data-msg="Please enter at least 4 chars"
                                                        value="{{$jobseeker['js_totexp']}}" />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label for="name">Expected Salary</label>
                                                    <input type="text" name="jssalary" class="form-cntrl" id="skill"
                                                        placeholder="eg. 10,000" data-rule="minlen:4"
                                                        data-msg="Please enter at least 4 chars"
                                                        value="{{$jobseeker['js_sal']}}" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                        <div class="col-6">
                                            Skills @ Company
                                        </div>
                                        <div class="col-4">
                                            Dates
                                        </div>
                                        <div class="col-2">
                                            Action
                                        </div>
                                    </div>
                                    <div id="expdiv">
                                    @foreach($js_exp_list_obj as $noti)
                                    <div class="row" id="exprow_{{ $noti['idx'] }}" style="background:floralwhite;padding: 12px 5px;">
                                        <div class="col-6">
                                            {{ $noti['title'] }} @ {{ $noti['school'] }}
                                        </div>
                                        <div class="col-4">
                                            {{ $noti['start'] }} - {{ $noti['end'] }}
                                        </div>
                                       
                                        <div class="col-2" style="text-align: center;">
                                            {{-- <a href="#" style="color:black;"><i class="far fa-edit"></i></a> --}}
                                            <a href="#" onclick="jsfunc.removeEXPobj(event,{{ $noti['idx'] }})" style="color:black;"><i class="far fa-trash-alt"></i></a>
                                        </div>
                                    </div>
                                    @endforeach
                                    </div>
                                </div>
                                <input type="hidden" name="expdivjson" id="expdivjson"
                                            value="{{ $jobseeker['js_experience'] }}" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 2rem;">
                    <div class="col-12" style="border: 0;">
                        <div class="tr-single-box">
                            <div class="tr-single-header">
                                <h4 class="mt-4"><i class="fas fa-briefcase"></i> Skill Or Expertise <a href="#" onclick="showSkillModal(event)" class="btn btn-sm btn-dark" style="margin-left: 1rem;">Add +</a></h4>
                            </div>
                            <div class="tr-single-body">
                                <div class="container">
                                    <div class="row" style="background: black; color: white; padding: 12px 5px;">
                                        <div class="col-8">
                                            Skills 
                                        </div>
                                        
                                        <div class="col-4">
                                            Action
                                        </div>
                                    </div>
                                    <div id="skilldiv">
                                    @foreach($js_skill_list_obj as $noti)
                                    <div class="row" id="skillrow_{{$noti['idx']}}" style="background:floralwhite;padding: 12px 5px;">
                                        <div class="col-8">
                                            {{ $noti['skill'] }}
                                        </div>
                                        
                                        <div class="col-4" style="text-align: center;">
                                            {{-- <a href="#" style="color:black;"><i class="far fa-edit"></i></a> --}}
                                            <a href="#" onclick="jsfunc.removeSKILLobj(event,{{$noti['idx']}})" style="color:black;"><i class="far fa-trash-alt"></i></a>
                                        </div>
                                    </div>
                                    @endforeach
                                    </div>
                                </div>
                                <input type="hidden" name="skillsdivjson" id="skillsdivjson"
                                value="{{ $jobseeker['js_skills'] }}" />

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top:1rem;">
                    <div class="col-md-12">
                        <button class="btn btn-primary  btn-register" style="width: 100%;background: #006AC7 !important;padding: 1rem;"> Update Resume Content
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </section>
</main>

<!-- Modal -->
<div class="modal fade" id="mySkillModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Add Skill</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Skill</label>
                        {{-- <input type="text" id="inputSkill" name="name" class="form-cntrl" id="name" placeholder="URL"
                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" /> --}}
                            <select class="form-cntrl" id="inputSkill">
                               <option value="-1"> Select Skill </option>
                               <option value="Negotiation and persuasion, Ability to work under pressure">Negotiation and persuasion, Ability to work under pressure</option>
                               <option value="Confidence, Organisation, Managing ambiguity">Confidence, Organisation, Managing ambiguity</option>
                               <option value="Resilience, Perseverance and motivation, Enterprise and entrepreneurial skills">Resilience, Perseverance and motivation, Enterprise and entrepreneurial skills</option> 
                               <option value="IT skills, Strong work values, MS Office, Word, Power point 2003 & 2007">IT skills, Strong work values, MS Office, Word, Power point 2003 & 2007</option>
                               <option value="Critical thinking, Working well in a team, Self-motivation">Critical thinking, Working well in a team, Self-motivation</option>
                               <option value="Being flexible, Being a quick learner, Good time management">Being flexible, Being a quick learner, Good time management</option>
                               <option value="Leadership/management skills, Commercial awareness , Communication, Teamwork">Leadership/management skills, Commercial awareness , Communication, Teamwork</option>
                               <option value="Interpersonal effectiveness/ Personal management skills">Interpersonal effectiveness/ Personal management skills</option>
                               <option value="Analytical and problem-solving skills">Analytical and problem-solving skills</option>
                               <option value="Software Proficiency Windows XP, Windows 07, Linux">Software Proficiency Windows XP, Windows 07, Linux</option>
                               <option value="Public speaking, Flexibility,  Personal Skills.">Public speaking, Flexibility,  Personal Skills.</option>
                               <option value="Listening, Networking, Persuasion">Listening, Networking, Persuasion</option>
                               <option value="Coding languages, Troubleshooting and testing skills, Operating systems, API design.">Coding languages, Troubleshooting and testing skills, Operating systems, API design.</option>
                               <option value="Database software, UX and UI design, Project management, Web frameworks.">Database software, UX and UI design, Project management, Web frameworks.</option>
                               <option value="Data collection skills, Problem-solving skills, Technical skills, Critical thinking skills.">Data collection skills, Problem-solving skills, Technical skills, Critical thinking skills. </option>
                               <option value="Project management skills, Software proficiency, Data analysis, Attention to detail">Project management skills, Software proficiency, Data analysis, Attention to detail</option>
                              

                            </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addSkill()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myEduModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Add Education</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">School/University Name</label>
                        <input type="text" id="inputEDUname" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" />
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="name">Degree</label>
                        <input type="text" id="inputEDUdegree" name="name" class="form-cntrl" id="name"
                            placeholder="Degree" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="edustartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="eduendyr">
                            <option value="pursuing">Pursuing</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addEDU()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myExpModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Experience</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Company Name</label>
                        <input type="text" id="inputEXPname" name="name" class="form-cntrl" id="name"
                            placeholder="Company Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Job Title</label>
                        <input type="text" id="inputEXPtitlename" name="name" class="form-cntrl" id="name"
                            placeholder="Job Title" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="expstartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="expendyr">
                            <option value="present">Present</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addEXP()">Submit</button>
            </div>
        </div>
    </div>

</div>

<script>

    jsfunc = {
        
        urlarr: {!!$jobseeker['js_urlslist']!!},
        eduarr: {!!$jobseeker['js_education']!!},
        exparr: {!!$jobseeker['js_experience']!!},
        skills: {!!$jobseeker['js_skills']!!},
        removeURLobj: (idx) => {
            // e.preventDefault();
            var pos = 0;
            jsfunc.urlarr.forEach(function (item, index, array) {
                if (item.idx === idx) {
                    pos = index;
                }
            });
            jsfunc.urlarr.splice(pos, 1);
            var res = JSON.stringify(jsfunc.urlarr);
            $('#urlsdivjson').val(res);
            console.log(res);
        },
        removeSKILLobj: (evt,idx) => {
            // e.preventDefault();
            evt.preventDefault();
            var pos = 0;
            jsfunc.skills.forEach(function (item, index, array) {
                if (item.idx === idx) {
                    pos = index;
                }
            });
            jsfunc.skills.splice(pos, 1);
            var res = JSON.stringify(jsfunc.skills);
            $('#skillsdivjson').val(res);
            $('#skillrow_'+idx).remove();
            console.log(res);
        },
        removeEDUobj: (evt,idx) => {
            // e.preventDefault();
            evt.preventDefault();
            var pos = 0;
            jsfunc.eduarr.forEach(function (item, index, array) {
                if (item.idx === idx) {
                    pos = index;
                }
            });
            jsfunc.eduarr.splice(pos, 1);
            var res = JSON.stringify(jsfunc.eduarr);
            $('#edudivjson').val(res);
            $('#edurow_'+idx).remove();
            console.log(res);
        },
        removeEXPobj: (evt,idx) => {
            // e.preventDefault();
            evt.preventDefault();
            var pos = 0;
            jsfunc.exparr.forEach(function (item, index, array) {
                if (item.idx === idx) {
                    pos = index;
                }
            });
            jsfunc.exparr.splice(pos, 1);
            var res = JSON.stringify(jsfunc.exparr);
            $('#expdivjson').val(res);
            $('#exprow_'+idx).remove();
            console.log(res);
        },
        addURLobj: (urlval) => {
            var retval = 0;
            if (jsfunc.urlarr.length > 0) {
                let idx = 0;
                jsfunc.urlarr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.urlarr.push({
                    idx: idx,
                    url: urlval
                });
                retval = idx;
            } else {
                jsfunc.urlarr.push({
                    idx: 1,
                    url: urlval
                });
                retval = 1;
            }
            var res = JSON.stringify(jsfunc.urlarr);
            $('#urlsdivjson').val(res);
            console.log(res);
            return retval;
        },

        addSkillobj: (skillval) => {
            var retval = 0;
            if (jsfunc.skills.length > 0) {
                let idx = 0;
                jsfunc.skills.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.skills.push({
                    idx: idx,
                    skill: skillval
                });
                retval = idx;
            } else {
                jsfunc.skills.push({
                    idx: 1,
                    skill: skillval
                });
                retval = 1;
            }
            var res = JSON.stringify(jsfunc.skills);
            $('#skillsdivjson').val(res);
            console.log(res);
            return retval;
        },
        addEDUobj: (schoolname, startyr, endyr, degree) => {
            if (jsfunc.eduarr.length > 0) {
                let idx = 0;
                jsfunc.eduarr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.eduarr.push({
                    idx: idx,
                    school: schoolname,
                    degree: degree,
                    start: startyr,
                    end: endyr
                });
            } else {
                jsfunc.eduarr.push({
                    idx: 1,
                    school: schoolname,
                    degree: degree,
                    start: startyr,
                    end: endyr
                });
            }
            var res = JSON.stringify(jsfunc.eduarr);
            $('#edudivjson').val(res);
            console.log(res);
        },
        addEXPobj: (schoolname, startyr, endyr, title) => {
            if (jsfunc.exparr.length > 0) {
                let idx = 0;
                jsfunc.exparr.forEach(function (item, index, array) {
                    if (item.idx > idx) {
                        idx = item.idx;
                    }
                });
                idx = idx + 1;
                jsfunc.exparr.push({
                    idx: idx,
                    school: schoolname,
                    title: title,
                    start: startyr,
                    end: endyr
                });
            } else {
                jsfunc.exparr.push({
                    idx: 1,
                    school: schoolname,
                    title: title,
                    start: startyr,
                    end: endyr
                });
            }
            var res = JSON.stringify(jsfunc.exparr);
            $('#expdivjson').val(res);
            console.log(res);
        }

    }


    function showEDUModal(e) {
        e.preventDefault();
        $("#myEduModal").modal('show');
    }

    function showEXPModal(e) {
        e.preventDefault();
        $("#myExpModal").modal('show');
    }
    function showSkillModal(e) {
        e.preventDefault();
        $("#mySkillModal").modal('show');
    }

    function addSkill() {
        if($('#mySkillModal #inputSkill').val() == '-1'){
            alert("Choose Skill");
        }else{
            var idx = jsfunc.addSkillobj($('#mySkillModal #inputSkill').val());
            $("#mySkillModal").modal('hide');

            $('#skilldiv').append(
                '<div class="row" id="skillrow_' + idx + '" style="background:floralwhite;padding: 12px 5px;">'+'<div class="col-8"> '+
                                                $('#mySkillModal #inputSkill').val() +'</div>'+
                                            '<div class="col-4" style="text-align: center;">'+'<a href="#" onclick="jsfunc.removeSKILLobj(event,'+idx+')" style="color:black;"> <i class="far fa-trash-alt"></i></a>'+
                                                '</div>'+'</div>');
            
            $('#mySkillModal #inputSkill').val('-1');
        }
        
    }

    function addEXP() {

        $('#myExpModal').modal('hide');
        var idx = jsfunc.addEXPobj($('#myExpModal #inputEXPname').val(), $('#myExpModal #expstartyr').val(), $(
            '#myExpModal #expendyr').val(), $('#myExpModal #inputEXPtitlename').val());
        $('#expdiv').append(
            '<div class="row" id="exprow_' +idx+ '" style="background:floralwhite;padding: 12px 5px;"><div class="col-6">' +
            $('#myExpModal #inputEXPtitlename').val() + ' @ ' + $('#myExpModal #inputEXPname').val() + '</div><div class="col-4">' + 
            $('#myExpModal #expstartyr').val() + ' - ' + $('#myExpModal #expendyr').val() + '</div><div class="col-2" style="text-align: center;">' +
            ' ' + 
            '<a href="#" onclick="jsfunc.removeEXPobj(event,'+idx+')" style="color:black;"><i class="far fa-trash-alt"></i></a></div></div>'
        );

        // $('#expdiv').append(
        //     '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">' +
        //     $('#myExpModal #inputEXPname').val() + '</span><br/><span style="font-weight: bold">' +
        //     $('#myExpModal #inputEXPtitlename').val() + '</span><br/><span>' + $('#myExpModal #expstartyr').val() +
        //     '</span> TO <span>' + $('#myExpModal #expendyr').val() +
        //     '</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        // );
        
        console.log(jsfunc.eduarr);
        $('#myExpModal #inputEXPname').val('');
        $('#myExpModal #inputEXPtitlename').val('');
    }

    function addEDU() {

        var idx = jsfunc.addEDUobj($('#myEduModal #inputEDUname').val(), $('#myEduModal #edustartyr').val(), $(
            '#myEduModal #eduendyr').val(), $('#myEduModal #inputEDUdegree').val());
        $('#myEduModal').modal('hide');

        $('#edudiv').append(
            '<div class="row" id="edurow_' +idx+ '" style="background:floralwhite;padding: 12px 5px;"><div class="col-4">'+
            $('#myEduModal #inputEDUdegree').val() + '</div><div class="col-2">'+
            $('#myEduModal #edustartyr').val() + ' - ' + $('#myEduModal #eduendyr').val() + '</div>' + '<div class="col-4">' +
            $('#myEduModal #inputEDUname').val() + '</div><div class="col-2" style="text-align: center;">'+ 
            '<a href="#" onclick="jsfunc.removeEDUobj(event,'+idx+')" style="color:black;"> <i class="far fa-trash-alt"></i></a>'+
            '</div></div>'
        );

        // $('#edudiv').append(
        //     '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 64px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">' +
        //     $('#myEduModal #inputEDUname').val() + '</span><br/><span style="font-weight: bold">' +
        //     $('#myEduModal #inputEDUdegree').val() + '</span><br/><span>' + $('#myEduModal #edustartyr').val() +
        //     '</span> TO <span>' + $('#myEduModal #eduendyr').val() +
        //     '</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        // );
        

        console.log(jsfunc.eduarr);
        $('#myEduModal #inputEDUname').val('');
        $('#myEduModal #inputEDUdegree').val('');

    }
</script>
@endsection