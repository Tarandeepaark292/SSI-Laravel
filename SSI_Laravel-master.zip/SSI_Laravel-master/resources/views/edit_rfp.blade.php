@extends('layouts.auth_bend_home')
@section('content')



<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Rfp</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organizer Panel</li>
                <li class="breadcrumb-item active">Update Rfp </li>
            </ol>


            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4> </h4>

                    </header>





                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/updaterfp/')}}/{{$jp_obj['rfp_id']}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="">
                            <div class="col-12"
                                style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;background-color:f0f2f4">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="orgname" class="form-cntrl" id="orgname"
                                            placeholder="Name of  the organisation" value="{{$jp_obj['rfp_org']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant Title </label>
                                        <input type="text" name="grant_title" class="form-cntrl" id="grant_title"
                                            placeholder="Grant title" value="{{$jp_obj['rfp_title']}}" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="" value="{{$jp_obj['rfp_loc']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Total Amount </label>
                                        <input type="text" name="amt" class="form-cntrl" id="amt" placeholder=""
                                            value="{{$jp_obj['rfp_g_amt']}}" />
                                        <div class="validate"></div>
                                    </div>


                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Closing date of proposal </label>
                                        <input type="date" name="close_date" class="form-cntrl" id="close_date"
                                            placeholder="" value="{{$jp_obj['rfp_close_date']}}" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email" placeholder=""
                                            value="{{$jp_obj['rfp_email']}}" />
                                        <div class="validate"></div>
                                    </div>

                                </div>

                                <div class="form-row">



                                    <div class="form-group col-lg-12">
                                        <label for="name">Description of the proposal </label>
                                        </br>
                                        <textarea name="proposal_desc" class="form-control" id="summernote">
                                            {{$jp_obj['rfp_desc']}}
                                        </textarea>
                                        {{-- <input class="form-cntrl" name="proposal_desc" id="proposal_desc"
                                            placeholder="" rows="10" style="height: auto;resize: none;"
                                            value="{{$jp_obj['rfp_desc']}}"></input> --}}
                                        
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-4">
                                        <label for="company_logo">Upload Pdf Document</label><br>
                                        <input type="file" class="form-cntrl-file" name="pdf_doc" id="pdf_doc" data-file_types="doc|pdf|text"
                                          accept="application/pdf"  placeholder="Add Media"  >
                                    </div>

                                    <div class="form-group col-lg-8">
                                        <label for="">Uploaded</label><br>
                                        <span value="" class="form-cntrl" alt=""  style="width:100%; height:60px";>{{$jp_obj['rfp_upload_doc']}}</span>
                                        <input type="hidden" name="pdf_old" value="{{$jp_obj['rfp_upload_doc']}}">
                                    </div>

                                </div>


                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            style="width:100%;" accept="image/png, image/jpeg" name="org_logo"
                                            id="org_logo" placeholder="Add Media" value="{{$jp_obj['rfp_logo']}}">
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                    <label for="">Uploaded</label><br>
                                        <!-- <label for="company_logo">Uploaded</label><br> -->
                                        <img src="{{asset($jp_obj['rfp_logo'])}}" class="form-cntrl-file" name=""
                                            height="70%" alt="">
                                        <input type="hidden" name="old_logo" value="{{$jp_obj['rfp_logo']}}">
                                    </div>

                                    </div>
                                    <div class="form-row">

                                        <div class="form-group col-lg-6">
                                            <label for="name">Organisation Achievment </label>
                                            <input type="text" name="ach" class="form-cntrl" id="ach" placeholder=""
                                                value="{{$jp_obj['rfp_o_ach']}}" />
                                            <div class="validate"></div>
                                        </div>
                                        {{-- <div class="form-group col-lg-6">
                                            <label for="name">Organisation Pan No. </label>
                                            <input type="text" name="total_amt" class="form-cntrl" id="pan"
                                                placeholder="" />
                                            <div class="validate"></div>
                                        </div> --}}


                                    </div>

                                    @isset($html)
                                    <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <h4>Proposal Category</h4>
                                        </div>
                                        {{-- <div class="form-group col-lg-12"> --}}
                                        {!! $html !!}
                                        {{-- </div> --}}
                                        <input type="hidden" id="cates" name="cates" value="{{$jp_obj['rfp_cates']}}" />
                                    </div>
                                    @endisset






                                    {{-- <div class="form-row">
                                        <div class="form-group col-lg-12">
                                            <input type="checkbox" id="terms" name="terms" value="">
                                            <label for="vehicle3"> Terms and condition</label><br>
                                        </div>
                                    </div> --}}
                                </div>
                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">
                                        <button type="submit" class="btn btn-primary  btn-register">Submit RFP</button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>










        </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script>
</main>

@endsection
