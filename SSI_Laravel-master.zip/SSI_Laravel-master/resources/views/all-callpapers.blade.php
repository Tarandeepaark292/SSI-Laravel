@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' =>
$seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        {{-- <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading"> Call Papers <span class="titleheading"> </span> <span class="titleheading">
                    </span> <span class="titleheading">
                    </span> </span></h3>



        </header> --}}


        <div class="container">
            <div class="form-row mt-5">

                <div class="form-group col-lg-6">
                    <select name="area" id="filters" onchange="myfunction(event)" class="form-cntrl">
                        <option value="">All</option>
                        <option value="Aged/Elderly">Aged/Elderly</option>
                        <option value="Animal Husbandry, Dairying & Fisheries">Animal Husbandry,
                            Dairying & Fisheries </option>

                        <option value="Agriculture">Agriculture</option>
                        <option value="Artificial Intelligence and Development">Artificial
                            Intelligence and Development </option>

                        <option value="Biotechnology">Biotechnology</option>
                        <option value="Civic Issues">Civic Issuest</option>
                        <option value="Differently Abled">Differently Abled </option>
                        <option value="Drinking Water">Drinking Water</option>
                        <option value="Development and Democracy ">Development and Democracy
                        </option>
                        <option value="Environment & Forests">Environment & Forests</option>
                        <option value="Health & Family Welfare">Health & Family Welfare</option>
                        <option value="Housing">Housing</option>
                        <option value="Information & Communication Technology (ICT)">Information &
                            Communication Technology (ICT)</option>
                        <option value="Internet governance ">Internet governance </option>
                        <option value="Land Resources"> Land Resources</option>
                        <option value="Micro Finance SHGs">Micro Finance SHGs</option>
                        <option value="Minority Issues">Minority Issues</option>
                        <option value="Nutrition">Nutrition</option>
                        <option value="Prisoner’s Issues">Prisoner’s Issues
                        </option>
                        <option value="Rural Development & Poverty Alleviation">Rural Development &
                            Poverty Alleviation</option>
                        <option value="Scientific & Industrial Research">Scientific & Industrial
                            Research</option>
                        <option value="Tourism">Tourism</option>
                        <option value="Urban Development & Poverty Alleviation">Urban Development &
                            Poverty Alleviation </option>
                        <option value="Water Resources<">Water Resources</option>
                        <option value="Youth Affairs">Youth Affairs</option>
                        <option value="Art & Culture">Art & Culture</option>
                        <option value="Children">Children</option>
                        <option value="Dalit Upliftment">Dalit Upliftment</option>
                        <option value="Disaster Management">Disaster Management</option>
                        <option value="Disability">Disability</option>
                        <option value="Education & Literacy">Education & Literacy</option>

                        <option value="Food Processing">Food Processing</option>
                        <option value="HIV/AIDS">HIV/AIDS</option>
                        <option value="Human Rights">Human Rights</option>
                        <option value="Labour & Employment">Labour & Employment</option>
                        <option value="Legal Awareness & Aid">Legal Awareness & Aid</option>
                        <option value="Micro Small & Medium Enterprises">Micro Small & Medium Enterprises</option>
                        <option value="New & Renewable Energy">New & Renewable Energy</option>
                        <option value="Panchayati Raj">Panchayati Raj</option>
                        <option value="Right To Information & Advocacy">Right To Information & Advocacy</option>
                        <option value="Science & Technology">Science & Technology</option>
                        <option value="Sports">Sports</option>
                        <option value="Tribal Affairs">Tribal Affairs</option>
                        <option value="Vocational Training">Vocational Training</option>
                        <option value="Women’s Development & Empowerment">Women’s Development & Empowerment</option>
                        <option value="Sanitation">Sanitation</option>
                        <option value="Sustainable Development">Sustainable Development</option>
                        <option value="Wildlife">Wildlife</option>
                        <option value="Skill Development">Skill Development</option>
                        <option value="Sustainable Development">Sustainable Development</option>
                        <option value="Financial Inclusion">Financial Inclusion</option>
                        <option value="Entrepreneurship And Innovation">Entrepreneurship And Innovation</option>
                        <option value="Impact Investing">Impact Investing</option>
                        <option value="Any Other">Any Other</option>
                        

                    </select>
                </div>
                <div class="col-lg-6">
                    <form>
                        <input type="text" class="form-cntrl" placeholder="Search.." onchange="myfunction(event)"
                             id="filter">
                        <!-- <button type="" onclick="myfunction(event)" ><i class="fa fa-search"></i></button> -->
                    </form>
                </div>

                <div class="col-lg-12">
                    <form class="searchform">
                        <!-- <input type="text" placeholder="Search.." id="filter"> -->
                        {{-- <button type=""  style="width:100%;" onclick="myfunction(event)" ><i class="fa fa-search"></i></button> --}}
                    </form>
                </div>


            </div>
        </div>

        <div class="col-12">
            <span style="display: block;font-size: 16px;">
                <p>

            </span>

        </div>

        <div id="search_results" style="width: 100%;" class="paginate">
            <div class="items">
            @isset($callsearch)
            @foreach($callsearch as $res)
            <div class="col-12" style="margin-bottom:2rem;">
                <div class="card content joblist_item" id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                            <div class="col-md-2" style="text-align: center;">

                                <img style="width: 80%;" src="{{asset($res['paper_org_logo'])}}" />
                            </div>
                            <div class="col-md-8">
                                <div class="results" style="font-weight: bold;color:#004a99">

                                    <div id="results" class="limittext">
                                        {{$res['paper_title']}}
                                    </div>
                                    <div id="results">
                                        <i class="" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span
                                            style="font-weight: bold;color:#004a99">{{$res['paper_o_name']}}</span>

                                    </div>
                                    <div id="results">
                                        <i class="fa fa-map-marker" aria-hidden="true"
                                            style="color:#007bff;font-size: 18px;"></i> <span>{{$res['paper_loc']}}
                                        </span>
                                    </div>
                                </div>
                                <!-- <div class="col-md-2 "> -->
                                <div id="results" >
                                    <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;"></i> Closing date: {{$res['paper_apply_by']}}
                                    <!-- </div> -->
                                </div>
                            </div>
                            <div class="col-md-2 my-auto ">
                                <a href="{{url('/call-paper/')}}/{{$res['paper_SEO']}}" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            @endforeach
            @endisset
            </div>
            <div class="pager">
                <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
                <div class="pageNumbers"></div>
                <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
            </div>
        </div>



    </div>

    </div>
    </div>
    </div>
</section>



<script>
    function myfunction(e) {

        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajax_search_callpaper.post') }}",
            data: {
                search: $('#filter').val(),
                type: $('#filters').val(),

            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                    $("#search_results").paginga({
                        // use default options
                        itemsPerPage: 20,
                        maxPageNumbers: 10
                    });
                } else {
                    $('#search_results').html('<h1>NO CALL PAPER FOUND</h1>');
                    // alert(data.error)
                }
            }
        });
    }
</script>
@endsection
@section('custom_script')
<script>
    // $(function() {
$(".paginate").paginga({
    // use default options
    itemsPerPage: 20,
    maxPageNumbers: 10
});
    // });
</script>
@endsection