@extends('layouts.auth_home')
@section('content')

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            {{-- <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="" /> --}}
            <a href="{{url('/')}}"><img src="{{asset('img/ssi_logo_white.png')}}" alt="" /></a>
            <h3>Welcome</h3>
            <h3>Admin</h3>
            
        </div>

        <div class="col-md-9 register-right pt-5">
           

            <div  id="home"  >
                    <h3 class="register-heading">Login as a Admin</h3>
                    <form action="{{url('/admin/adminlogin/check')}}" method="post">

                        <div class="row register-form">
                            <div class="col-md-9 mx-auto">
                                {{-- <h3 class="">Login as a Jobseeker</h3> --}}
                                <div class="form-group form">
                                    <input type="email" name="email" class="form-control"
                                        placeholder="Your Email *" value="" />
                                        @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group form">
                                    <input type="password" name="password" class="form-control"
                                        placeholder="Password *" value="" />
                                        @error('password') <p style="color:red">{{$message}}</p>@enderror
                                    <input type="hidden" name="role" value="jobseek"/>
                                </div>

                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" style="" class="btnRegister"
                                    value="Login" />

                            </div>

                        </div>
                    </form>
                </div>



            <!-- <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <h3 class="register-heading">Login as a Jobseeker</h3>
                    <form action="{{url('/userlogin')}}" method="post">

                        <div class="row register-form">
                            <div class="col-md-9 mx-auto">
                                {{-- <h3 class="">Login as a Jobseeker</h3> --}}
                                <div class="form-group form">
                                    <input type="email" name="email" class="form-control"
                                        placeholder="Your Email *" value="" />
                                        @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group form">
                                    <input type="password" name="password" class="form-control"
                                        placeholder="Password *" value="" />
                                        @error('password') <p style="color:red">{{$message}}</p>@enderror
                                    <input type="hidden" name="role" value="jobseek"/>
                                </div>

                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" style="" class="btnRegister"
                                    value="Login" />

                            </div>

                        </div>
                    </form>
                </div>
                <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <h3 class="register-heading">Login as a Recruiter</h3>
                    <form action="{{url('/userlogin')}}" method="post">
                        <div class="row register-form">
                            <div class="col-md-9  mx-auto">
                                {{-- <h3 class="">Login as a Recruiter</h3> --}}
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control"
                                         placeholder="Your Email *" value="" />
                                         @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>

                                <div class="form-group">
                                    <input type="password" name="password" class="form-control"
                                        placeholder="Password *" value="" />
                                        @error('password') <p style="color:red">{{$message}}</p>@enderror
                                    <input type="hidden" name="role" value="recruiter"/>
                                </div>

                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" class="btnRegister" 
                                    value="Login" />

                            </div> <!-- </div> -->
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>

</div>
@endsection