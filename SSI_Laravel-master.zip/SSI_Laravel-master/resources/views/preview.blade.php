@extends('layouts.home')
@section('content')

<section style="">
    {{-- <div class="intro-img" style="">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">





        <div class="row">
            <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">

                <div class="form-row">



                    <div class="form-group col-12">
                        <label for="name">CSR post titile</label>
                        <span name="jobpost" class="form-cntrl" id="jobpost" placeholder="jobposttitle" />
                        
                        </span>
                    </div>
                </div>



                <div class="form-row">



                    <div class="form-group col-8">
                        <label for="name">organisation name</label>
                        <span name="organisation name" class="form-cntrl" id="organisation name"
                            placeholder="organisation name" />


                        </span>
                    </div>


                    <div class="form-group col-4 ">
                        <div class="logo" style="text-align:center;margin-left:250px;">
                            <img class="img" src="{{asset('img/sd.png')}}" height="90px;" alt="aark">
                        </div>
                    </div>
                </div>

                <div class="form-row">


                    <div class="form-group col-6">
                        <label for="name">job type</label>
                        <span name="jobtype" class="form-cntrl" id="jobtype" placeholder="job type" /></span>

                    </div>

                    <div class="form-group col-6">
                        <label for="name">website</label>
                        <span name="website" class="form-cntrl" id="website" placeholder="website" /></span>

                    </div>
                </div>


                <div class="form-row">
                    <div class="col-md-12">
                        <label> Description</label>
                        <span class="form-cntrl" name="description" id="description" style="height:180px;"
                            placeholder="Description" style="height: auto;resize: none;">
                        </span>

                    </div>
                </div>


                <div class="form-row">


                    <div class="form-group col-8">
                        <label for="name">Area of Expertse</label>
                        <span name="expertise" class="form-cntrl" id="expertise" placeholder="area of Expertise" />
                        </span>
                    </div>

                    <div class="form-group col-4">
                        <label for="name">job close date </label>
                        <span name="jobclosedate" class="form-cntrl" id="jobclosedate" placeholder="close date" />
                        </span>
                    </div>
                </div>



                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <span class="form-cntrl" id="Linkedin" placeholder="Linked in" /></span>
                        <span name="video" class="form-cntrl" id="video" placeholder="video" /></span>
                        <span name="twitter" class="form-cntrl" id="twitter" placeholder="twitter" /></span>



                    </div>
                </div>



            </div>

</section>
@endsection
