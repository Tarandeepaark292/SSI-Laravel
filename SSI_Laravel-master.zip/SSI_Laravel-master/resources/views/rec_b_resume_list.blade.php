@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Applicants List</h1>
            <section>
                <div class="container" style="margin-bottom: 5rem;">
                    <div class="row">
                        <div class="col-12 " style="border: 0;">
                            <div class="tr-single-box">
                                <div class="tr-single-header">
                                    <h4 class="mt-4"><i class="fas fa-check"></i> Applicant List</h4>
                                </div>
                                <div class="tr-single-body">
                                    @isset($results)
                                    @foreach($results as $noti)
                                    <div class="manage-list">
											
                                        <div class="mg-list-wrap">
                                            <div class="mg-list-thumb">
                                                @if(isset($noti['jobseeker']['js_photo']))
                                                <img src="{{asset($noti['js_photo'])}}" style="height: 80px;width: 80px;margin: 0 auto;border: 2px solid #eee;border-radius: 5px;"/>
                                                @else
                                                <img src="{{asset('img/profile-avatar.png')}}" style="height: 80px;width: 80px;margin: 0 auto;border: 2px solid #eee;border-radius: 5px;"/>
                                                @endif
                                                {{-- <img src="{{asset($noti['jp_org_logo'])}}" class="mx-auto" alt=""> --}}
                                            </div>
                                            <div class="mg-list-caption">
                                                <h4 class="mg-title"> <b>{{$noti['js_name']}}</b></h4>
                                                <span class="mg-subtitle"><b>{{$noti['js_p_title']}}</b></span>
                                                <span> <b>{{$noti['js_area_expertise']}}</b> </span>
                                            </div>
                                        </div>
                                        
                                        <div class="mg-action">
                                            <div class="btn-group ml-2">
                                                <a href="{{url('/jobseeker')}}/{{$noti['js_SEO']}}" class="btn btn-view" data-toggle="tooltip" data-placement="top" title=""><i class="fas fa-eye"></i></a>
                                            </div>
                                            {{-- <div class="btn-group ml-2">
                                                <a href="#" onclick="" class="btn btn-dark" data-toggle="tooltip" data-placement="top" title="Apply for Job">Apply</a>
                                            </div> --}}
                                        </div>
                                        
                                    </div>
                                    @endforeach
                                    @else
                                    <h2>No Resumes are avaliable</h2>
                                    @endisset
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</main>

@endsection