@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <h1 class="mt-4"></h1>
        <div class="container">
            <form action="{{ url('/recruiter/profile/update/') }}/{{$rec_obj['r_id']}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-12 " style="border: 0;">
                        <div class="tr-single-box">
                            <div class="tr-single-header">
                                <h4 class="mt-4"><i class="fas fa-building"></i> Organization Profile</h4>
                            </div>
                            <div class="tr-single-body">
                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <label for="name">Organization Name </label>
                                        <input type="text" name="org_name" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" style="width:100%;"
                                            value="{{ $rec_obj['r_org_name'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                    {{-- 'r_id' => $res['r_id'],
                                    'r_name' => $res['r_name'],
                                    'r_email' => $res['r_email'],
                                    'r_phone' => $res['r_phone'],
                                    'r_org_name' => $res['r_org_name'],
                                    'r_off_lline_number' => $res['r_off_lline_number'],
                                    'r_off_website' => $res['r_off_website'],
                                    'r_org_pan' => $res['r_org_pan'],
                                    'r_info' => $res['r_info'],
                                    'r_org_logo' => $res['r_org_logo'],
                                    'r_comp_type' => $res['r_comp_type'], --}}
                                    <div class="form-group col-lg-4">
                                        <label for="name">Contact Person Name</label>
                                        <input type="text" name="r_name" class="form-cntrl" id="email"
                                            placeholder="Contact Person Name" style="width:100%;"
                                            value="{{ $rec_obj['r_name'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="name">Mobile Number</label>
                                        <input type="text" name="r_phone" class="form-cntrl" id="email"
                                            placeholder="Mobile Number" style="width:100%;"
                                            value="{{ $rec_obj['r_phone'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                    
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <label for="name">Organization Website </label>
                                        <input type="text" name="website" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" style="width:100%;"
                                            value="{{ $rec_obj['r_off_website'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-4">
                                        <label for="name">Organization Contact Number </label>
                                        <input type="text" name="off_phone" class="form-cntrl" id="email"
                                            placeholder="Office Number" style="width:100%;"
                                            value="{{ $rec_obj['r_off_lline_number'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-4">
                                        <label for="name">Organization Contact Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email"
                                            placeholder="Email" style="width:100%;"
                                            value="{{ $rec_obj['r_email'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Organization Logo</label>
                                        <input type="file" name="r_logo" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" class="form-cntrl" id="file" />
                                        <input type="hidden" name="old_r_logo"
                                            value="{{ $rec_obj['r_org_logo'] }}">
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Current Logo</label><br />
                                        <img style="width: 200px;"
                                            src="{{ asset($rec_obj['r_org_logo']) }}" /><br />

                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Company Type</label><br />
                                        <select class="form-cntrl" name="company-type">
                                            
                                            <option {{ ( $rec_obj['r_comp_type'] == "Trust registration") ? 'selected' : '' }} value="Trust registration">Trust registration</option>
                                            <option {{ ( $rec_obj['r_comp_type'] == "Society registration") ? 'selected' : '' }} value="Society registration">Society registration</option>
                                            <option {{ ( $rec_obj['r_comp_type'] == "Section 8 or 25 company registration") ? 'selected' : '' }} value="Section 8 or 25 company registration">Section 8 or 25 company registration</option>
    
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-3">
                                        <label for="name">Organization Pan </label>
                                        <input type="text" name="r_pan" class="form-cntrl" id="email"
                                            placeholder="Organization Pan" style="width:100%;"
                                            value="{{ $rec_obj['r_org_pan'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-3">
                                        <label for="name">Pin Code </label>
                                        <input type="text" name="r_pin" class="form-cntrl" id="r_pin"
                                            placeholder="Pincode" style="width:100%;"
                                            value="{{ $rec_obj['r_pin'] }}"
                                            required />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">About Organization</label>
                                        <textarea id="summernote"
                                            name="r_info">{{ htmlspecialchars_decode($rec_obj['r_info']) }}</textarea>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="text-align:center;">
                    <div class="col-lg-12 ml-auto">

                        <button class="btn btn-primary  btn-register" style="width:100%"> Update Data
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </section>
</main>

@endsection