@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
        <h3>Register Grant Preview
            @if( $jp_obj['reg_status'] == '1')
                ( Approved )
            @else
                ( Waiting Approval )
            @endif


        </h3>
    </header>
    <div id="cv" class="instaFade shadow p-3 mb-5 bg-white mt-5" style="background-color:white !important;">

        <div class="mainDetails" style="background-color:white !important">
            <div class="row">
                <div class="col-md-4">
                    <!-- <div id="headshot" class="quickFade"style="border:2px solid red; max-height:10px;"> -->
                    <img src="{{ asset('img/export.png') }}" alt="Alan Smith" height="167px"
                        width="167px" style="border-radius: 50%; margin-left:50px;" />
                    <!-- </div> -->
                </div>
                <div class="col-md-8">
                    <div id="name">
                        <h1 class="quickFade delayTwo " style="font-size:30px;">
                            {{ $jp_obj['reg_o_name'] }}<small class="quickFade delayThree"
                                style="font-size:15px;"> </small></h1>
                        <hr style="width:100%;">
                        <i class="fa fa-calendar ml-1 mr-2" aria-hidden="true"></i> <a
                            href="  {{ $jp_obj['reg_valid_from'] }}" target="_blank">
                            {{ $jp_obj['reg_valid_To'] }}</a></br>
                            <i class="fa fa-globe ml-1 mr-2" aria-hidden="true"></i> 
                            {{ $jp_obj['reg_website'] }}</a></br>
                            <i class="fa fa-envelope ml-1 mr-2" aria-hidden="true"></i> 
                            {{ $jp_obj['reg_email'] }}</a></br>
                    </div>

                    <div id="contactDetails" class="quickFade delayFour">
                        <ul>
                            <!-- <li>w: <a href="http://www.bloggs.com">www.bloggs.com</a></li>
                <li>m: 01234567890</li> -->
                        </ul>
                    </div>

                </div>



            </div>
            <hr style="border:1px solid #00000029;">




            <div class="clear"></div>
        </div>

        <div id="mainArea" class="quickFade delayFive">
			<section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Vision Of Organisation</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $jp_obj['reg_v_org'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
			</section>
			<section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Categories</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $jp_obj['reg_cates'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
            <section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Organisation Mission</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $jp_obj['reg_o_mission'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
            <section>
                <article>
                    <div class="sectionTitle">

                    </div>
                    <h1 style="font-size:1.2em;"><b>Organisation Achivement</b></h1>

                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                    <p> {{ $jp_obj['reg_o_ach'] }}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>





            <section>
                <div class="sectionTitle">
                </div>
                <h1 style="font-size:1.2em;"><b>Organisation Name</b></h1>
                {{ $jp_obj['reg_o_name'] }}

                <div class="sectionContent" style="font-size:15px;">
                </div>
                <div class="clear"></div>
            </section>

            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>Head Of the Organisation</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_o_head']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
    
            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>Organisation PAN</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_o_pan']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>

            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>80 Registration No</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_80g']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
    
    
    
            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>FCRA Registration No</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_fcra']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
    
            
    
            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>FCRA valid from</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_valid_from']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>
    
            <section>
                <article>
                    <div class="sectionTitle">
                        
                    </div>
                    <h1 style="font-size:1.2em;"><b>FCRA valid To</b></h1>
                
                    <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p>   {{$jp_obj['reg_valid_To']}}</p>
                    <!-- </div> -->
                </article>
                <div class="clear"></div>
            </section>


            <section>
                <div class="sectionTitle">

                </div>
                <h1 style="font-size:1.2em;"><b>Valid To</b></h1>
                <h2 style="font-size:15px;"> {{ $jp_obj['reg_valid_To'] }}</h2>

                <div class="sectionContent" style="font-size:15px;">
                    <article>

                    </article>
                </div>
                <div class="clear"></div>
            </section>

            <section>
                <div class="sectionTitle">
                </div>
                <h1 style="font-size:1.2em;"><b> Proposal</b></h1>
                <h4 style="font-size:15px;"><a href="#">Download File <i class="fa fa-download"></i></a></h4>

                <div class="sectionContent" style="font-size:15px;">
                    <article>


                    </article>
                </div>
                <div class="clear"></div>
            </section>


        </div>
    </div>
</section>

@endsection
