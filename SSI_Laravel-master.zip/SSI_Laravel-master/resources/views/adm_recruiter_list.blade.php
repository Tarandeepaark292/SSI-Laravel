@extends('layouts.auth_bend_home')
@section('content')

<main>
   
    <div class="container-fluid">
    
<h1 class="mt-4 ">Dashboard</h1>
        <ol class="breadcrumb mb-4 ">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Recruiter</li>
        </ol>
   
    <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Recruiter</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                            <th>org name</th>
                                    <th>email</th>
                                    <th>password</th>
                                    <th>companytype</th>
                                    <th>name</th>
                                   
                                    <th>organisation name</th>
                                    <th>website</th>


                            </tr>
                        </thead>
                        @isset($recruiterlist)
                            <tfoot>
                                <tr>
                                    <th>org name</th>
                                    <th>email</th>
                                    <th>password</th>
                                    <th>companytype</th>
                                    <th> name</th>
                                    <th>organisation name</th>
                                    
                                    <th>website</th>

                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($recruiterlist as $noti)
                                    <tr>


                                        <td>{{ $noti['r_org_name'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['r_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['r_pwd'] }}</td>
                                        <td>{{ $noti['r_comp_type'] }}</td>
                                        <td>{{ $noti['r_name'] }}</td>
                                        <td>{{ $noti['r_org_name'] }}</td>
                                        <td>{{ $noti['r_off_website'] }}</td>
                                        <!-- <td>{{ $noti['r_off_website'] }}</td>
                                        -->
                                       
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>

@endsection
