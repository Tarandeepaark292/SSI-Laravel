@extends('layouts.home')
@section('content')

        <section style="">
            <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}"  alt="" class="img-fluid" style="width: 100%;">
            </div>
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Register </span> <span class="titleheading">for</span> <span class="titleheading">Grants</span></h3>
                </header>
                <div class="row">
                    <div class="col-12">

                        <p style="color: #000000; font-family: georgia, palatino, serif; font-size: 12pt;"><strong>For FAQ please <span style="color: #0000ff;"><a style="color: #0000ff;" href="https://socialservicesindia.com/?page_id=509">click here.</a></span></strong></p></br>
                        <p>Quick updates and advantages of registering your organisation for grants with “Social Services India”</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">

                        <li>Registered organization will receive email notifications for each proposal updated on our website sorted by funding agency, including CSR funding, under their selection of “Areas of Expertise”.<br></li>
                        <li style="margin-top:10px;">We provide a newsletter with the top funding agencies suitable for your organization.<br></span></li>
                        <li style="margin-top:10px;">We provide an independent platform and the prospect of direct links with complete access between the organization and funding agencies. Hence, organization registration details will help us serve you better.<br></li>
                        <li style="margin-top:10px;">We provide access to our donor database.<br></li>
                        <li style="margin-top:10px;">We help the donor agency find their match for funding grants to NGOs and NPOs and take it forward from there.</li>

                        <span style="font-family: georgia, palatino, serif; font-size: 12pt; color: #000000; margin-top:20px;"><strong>This is at the cost of</strong> <strong><span style="color: #0000ff;">Rs. 6,499/- @if(session()->has('ssiapp_rec'))
                            <a href="#" onclick="addTocart(2)">(Add To Cart)</a>
                            @endif</span> </strong></span>
                    </div>
                </div>
                <div class="row" style="text-align: center;">
                    <div class="col-12">
                        <h4><b> Fill the form below before checkout</b></h4><br />

                    </div>
                    <p>Required fields are marked <span class="torro-required-indicator">*</span></p>

                </div>
                
                <form action="{{url('/register-grants/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf


                <div class="row">
                    <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;">
                       
                    <div class="form-row">



                            <div class="form-group col">
                                <label for="name">Name Of the Organistation</label>
                                <input type="text" name="name" class="form-cntrl" id="name" placeholder="Enter Organisation name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name"> vision of Organisation</label>
                                <textarea class="form-cntrl" name="vision" id="vision" placeholder="Vision of organisation" rows="10" style="height: auto;resize: none;"></textarea>
                                <div class="validate"></div>
                            </div>


                            <div class="form-group col-lg-6">
                                <label for="name">Organisation Mission</label>
                                <textarea class="form-cntrl" name="mission" id="mission" placeholder="Organisation mission" rows="10" style="height: auto;resize: none;"></textarea>
                                <div class="validate"></div>
                            </div>

                        </div>


                               

                     <div class="form-row">
                            <div class="form-group col-lg-4">
                                
                                <fieldset id="torro-element-35-wrap" class="torro-element-wrap">

                                    <legend id="torro-element-35-label" class="torro-element-label">
                                        Areas of Work or Expertise </legend>

                                    <div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-1" name="cates[]" class="torro-element-input" value="Aged/Elderly">
                                            <label id="torro-element-35-1-label"class="torro-element-label" for="torro-element-35-1">
                                                Aged/Elderly </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-2" name="cates[]" class="torro-element-input" value="Agriculture">
                                            <label id="torro-element-35-2-label" class="torro-element-label" for="torro-element-35-2">
                                                Agriculture </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-3" name="cates[]" class="torro-element-input" value="AnimalHusbandry, Dairying &amp; Fisheries">
                                            <label id="torro-element-35-3-label" class="torro-element-label" for="torro-element-35-3">
                                                Animal Husbandry, Dairying &amp; Fisheries </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-4"name="cates[]" class="torro-element-input" value="Art &amp; Culture">
                                            <label id="torro-element-35-4-label"  class="torro-element-label" for="torro-element-35-4">
                                                Art &amp; Culture </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-5"name="cates[]" class="torro-element-input" value="Biotechnology">
                                            <label id="torro-element-35-5-label" class="torro-element-label" for="torro-element-35-5">
                                                Biotechnology </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-6" name="cates[]" class="torro-element-input" value="Children ">
                                            <label id="torro-element-35-6-label" class="torro-element-label" for="torro-element-35-6">
                                                Children </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-7" name="cates[]" class="torro-element-input" value="CivicIssues ">
                                            <label id="torro-element-35-7-label" class="torro-element-label" for="torro-element-35-7">
                                                Civic Issues </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-8" name="cates[]" class="torro-element-input" value="DalitUpliftment ">
                                            <label id="torro-element-35-8-label" class="torro-element-label" for="torro-element-35-8">
                                                Dalit Upliftment </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-9" name="cates[]" class="torro-element-input" value="DifferentlyAbled ">
                                            <label id="torro-element-35-9-label"class="torro-element-label" for="torro-element-35-9">
                                                Differently Abled </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-10" name="cates[]" class="torro-element-input" value="DisasterManagement ">
                                            <label id="torro-element-35-10-label" class="torro-element-label" for="torro-element-35-10">
                                                Disaster Management </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-11" name="cates[]"class="torro-element-input" value="DrinkingWater ">
                                            <label id="torro-element-35-11-label" class="torro-element-label" for="torro-element-35-11">
                                                Drinking Water </label>
                                        </div>

                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-12" name="cates[]" class="torro-element-input" value="Education &amp; Literacy ">
                                            <label id="torro-element-35-12-label" class="torro-element-label" for="torro-element-35-12">
                                                Education &amp; Literacy </label>
                                        </div>
                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-13" name="cates[]" class="torro-element-input" value="Environment &amp; Forests ">
                                            <label id="torro-element-35-13-label"class="torro-element-label" for="torro-element-35-13">
                                                Environment &amp; Forests </label>
                                        </div>

                                        <div class="torro-toggle">
                                            <input type="checkbox" id="torro-element-35-14" name="cates[]" class="torro-element-input" value="FoodProcessing ">
                                            <label id="torro-element-35-14-label" class="torro-element-label" for="torro-element-35-14">
                                                Food Processing </label>
                                        </div>

                                </fieldset>
                            </div>
                            <div class="form-group col-lg-4" style="margin-top:40px;">
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-15"name="cates[]" class="torro-element-input" value="Health &amp; Family Welfare ">
                                    <label id="torro-element-35-15-label" class="torro-element-label" for="torro-element-35-15">
                                        Health &amp; Family Welfare </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-16" name="cates[]" class="torro-element-input" value="HIV/AIDS ">
                                    <label id="torro-element-35-16-label" class="torro-element-label" for="torro-element-35-16">
                                        HIV/AIDS </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-17" name="cates[]" class="torro-element-input" value="Housing ">
                                    <label id="torro-element-35-17-label" class="torro-element-label" for="torro-element-35-17">
                                        Housing </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-18" name="cates[]" class="torro-element-input" value="HumanRights ">
                                    <label id="torro-element-35-18-label" class="torro-element-label" for="torro-element-35-18">
                                        Human Rights </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-19" name="cates[]" class="torro-element-input" value="Information &amp; Communication Technology ">
                                    <label id="torro-element-35-19-label" class="torro-element-label" for="torro-element-35-19">
                                        Information &amp; Communication Technology </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-20" name="cates[]" class="torro-element-input" value="Labour &amp; Employment ">
                                    <label id="torro-element-35-20-label" class="torro-element-label" for="torro-element-35-20">
                                        Labour &amp; Employment </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-21" name="cates[]" class="torro-element-input" value="LandResources ">
                                    <label id="torro-element-35-21-label" class="torro-element-label" for="torro-element-35-21">
                                        Land Resources </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-22" name="cates[]" class="torro-element-input" value="LegalAwareness &amp; Aid ">
                                    <label id="torro-element-35-22-label" class="torro-element-label" for="torro-element-35-22">
                                        Legal Awareness &amp; Aid </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-23" name="cates[]" class="torro-element-input" value="MicroFinanceSHGs ">
                                    <label id="torro-element-35-23-label" class="torro-element-label" for="torro-element-35-23">
                                        Micro Finance SHGs </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-24" name="cates[]" class="torro-element-input" value="MicroSmall &amp; Medium Enterprises ">
                                    <label id="torro-element-35-24-label"class="torro-element-label" for="torro-element-35-24">
                                        Micro Small &amp; Medium Enterprises </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-25" name="cates[]" class="torro-element-input" value="MinorityIssues ">
                                    <label id="torro-element-35-25-label" class="torro-element-label" for="torro-element-35-25">
                                        Minority Issues </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-26" name="cates[]" class="torro-element-input" value="New &amp; Renewable Energy ">
                                    <label id="torro-element-35-26-label" class="torro-element-label" for="torro-element-35-26">
                                        New &amp; Renewable Energy </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-27" name="cates[]" class="torro-element-input" value="Nutrition ">
                                    <label id="torro-element-35-27-label" class="torro-element-label" for="torro-element-35-27">
                                        Nutrition </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-28" name="cates[]" class="torro-element-input" value="PanchayatiRaj ">
                                    <label id="torro-element-35-28-label" class="torro-element-label" for="torro-element-35-28">
                                        Panchayati Raj </label>
                                </div>
                            </div>
                            <div class="form-group col-lg-4" style="margin-top:40px;">


                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-29" name="cates[]"class="torro-element-input" value="Prisoner'sIssues ">
                                    <label id="torro-element-35-29-label" class="torro-element-label" for="torro-element-35-29">
                                        Prisoner's Issues </label>
                                </div>

                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-30" name="cates[]" class="torro-element-input" value="Prisoner'sIssues ">
                                    <label id="torro-element-35-30-label" class="torro-element-label" for="torro-element-35-30">
                                        Prisoner's Issues </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-31" name="cates[]"  class="torro-element-input" value="RightToInformation &amp; Advocacy ">
                                    <label id="torro-element-35-31-label"class="torro-element-label" for="torro-element-35-31">
                                        Right To Information &amp; Advocacy </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-32" name="cates[]" class="torro-element-input" value="RuralDevelopment &amp; Poverty Alleviation ">
                                    <label id="torro-element-35-32-label" class="torro-element-label" for="torro-element-35-32">
                                        Rural Development &amp; Poverty Alleviation </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-33"name="cates[]" class="torro-element-input" value="Science &amp; Technology ">
                                    <label id="torro-element-35-33-label" class="torro-element-label" for="torro-element-35-33">
                                        Science &amp; Technology </label>
                                </div>



                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-34" name="cates[]" class="torro-element-input" value="Scientific &amp; Industrial Research ">
                                    <label id="torro-element-35-34-label" class="torro-element-label" for="torro-element-35-34">
                                        Scientific &amp; Industrial Research </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-35" name="cates[]" class="torro-element-input" value="Sports ">
                                    <label id="torro-element-35-35-label" class="torro-element-label" for="torro-element-35-35">
                                        Sports </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-36" name="cates[]" class="torro-element-input" value="Tourism ">
                                    <label id="torro-element-35-36-label" class="torro-element-label" for="torro-element-35-36">
                                        Tourism </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-37" name="cates[]" class="torro-element-input" value="TribalAffairs ">
                                    <label id="torro-element-35-37-label" class="torro-element-label" for="torro-element-35-37">
                                        Tribal Affairs </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-38" name="cates[]"class="torro-element-input" value="UrbanDevelopment &amp; Poverty Alleviation ">
                                    <label id="torro-element-35-38-label" class="torro-element-label" for="torro-element-35-38">
                                        Urban Development &amp; Poverty Alleviation </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-39" name="cates[]" class="torro-element-input" value="VocationalTraining ">
                                    <label id="torro-element-35-39-label" class="torro-element-label" for="torro-element-35-39">
                                        Vocational Training </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-40" name="cates[]" class="torro-element-input" value="WaterResources ">
                                    <label id="torro-element-35-40-label" class="torro-element-label" for="torro-element-35-40">
                                        Water Resources </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-41" name="cates[]" class="torro-element-input" value="YouthAffairs ">
                                    <label id="torro-element-35-41-label"class="torro-element-label" for="torro-element-35-41">
                                        Youth Affairs </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-42" name="cates[]" class="torro-element-input" value="Women'sDevelopment &amp; Empowerment ">
                                    <label id="torro-element-35-42-label" class="torro-element-label" for="torro-element-35-42">
                                        Women's Development &amp; Empowerment </label>
                                </div>
                                <div class="torro-toggle">
                                    <input type="checkbox" id="torro-element-35-43" name="cates[]" class="torro-element-input" value="AnyOther">
                                    <label id="torro-element-35-43-label" class="torro-element-label" for="torro-element-35-43">
                                        Any Other </label>
                                </div>

                            </div>
                        </div> 

                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label for="name">Organisation Achivement</label>
                                <textarea class="form-cntrl" name="achivement"name="cates[]" id="achivement" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                                <div class="validate"></div>
                            </div>
                        </div>


                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Head of the Organisation</label>
                                <input type="text" name="headorganisation"name="cates[]" class="form-cntrl" id="headorganisation" placeholder="head of the organisation" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name"> Organisation PAN</label>
                                <input type="text" name="organisationpan"name="cates[]" class="form-cntrl" id="organisationpan" placeholder="Organisation Pan" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Organisation TAN to</label>
                                <input type="text" name="organisationtan" class="form-cntrl" id="organisationtan" placeholder=" organisation TAN to" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <legend id="torro-element-42-label" class="torro-element-label">
                                    Organisation having 12A </legend>
                                <div>
                                    <div class="torro-toggle">
                                        <input type="radio" id="torro-element-42-1" name="torro_submission[values][42][_main]" class="torro-element-input" value="Yes">
                                        <label id="torro-element-42-1-label" class="torro-element-label" name="cates[]" for="torro-element-42-1">
                                            Yes </label>
                                    </div>
                                    <div class="torro-toggle">
                                        <input type="radio" id="torro-element-42-2" name="torro_submission[values][42][_main]" class="torro-element-input" value="No">
                                        <label id="torro-element-42-2-label"  class="torro-element-label" for="torro-element-42-2">
                                            No </label>
                                    </div>
                                </div>

                            </div>


                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">80 G Registration No</label>
                                <input type="text" name="80gregistrationno" class="form-cntrl" id="80gregistrationno" placeholder="80 G Registration No" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">FCRA Registration No</label>
                                <input type="text" name="fcraregistrationno" class="form-cntrl" id="fcraregistrationno" placeholder="FCRA  Registration No" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                                <div>

                                </div>

                            </div>


                        </div>


                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <div id="torro-element-45-wrap" class="torro-element-wrap">

                                    <label id="torro-element-45-label" class="torro-element-label" for="torro-element-45">
                                        FCRA Valid From </label>

                                    <div>
                                        <input id="torro-element-45" name="validfrom" class="validfrom" type="date" value="">


                                    </div>

                                </div>

                            </div>
                            <div class="form-group col-lg-6">
                                <div id="torro-element-46-wrap" class="torro-element-wrap">

                                    <label id="torro-element-46-label" class="torro-element-label" for="torro-element-46">
                                        FCRA Valid To </label>

                                    <div>
                                        <input id="torro-element-46" name="validto" class="torro-element-input" type="date" value="">


                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Website</label>
                                <input type="text" name="website" class="form-cntrl" id="website" placeholder="website" data-rule="minlen:4" data-msg="" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Email</label>
                                <input type="text" name="email" class="form-cntrl" id="email" placeholder="Enter valid email id to receive grant updates" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                                <div>

                                </div>

                            </div>


                        </div>


                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12">

                                <button class="btn btn-primary" style="width:40%">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
        </section>
        @endsection
