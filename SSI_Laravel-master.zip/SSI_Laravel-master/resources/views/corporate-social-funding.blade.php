@extends('layouts.home')
@section('content')

<main id="main">
    <section style="">
        {{-- <div class="intro-img" style="">
            <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
        </div> --}}
        <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                <h3><span class="titleheading">Call</span> <span class="titleheading"> for"</span> <span
                        class="titleheading">Corpoarate</span> <span class="titleheading">Social</span> <span
                        class="titleheading">Responsibilty" (CSR)</span> <span class="titleheading">Funding</span>
                </h3>
            </header>
            <div class="row">
                <div class="col-12">
                    <span style="display: block;margin-top:30px;font-size: 16px;">Call for “Corporate Social
                        Responsibility” (CSR) Funding get posted immediately on our website for greater visibility
                        and access across India. </span>

                    <span style="display: block;margin-top:30px;font-size: 16px;"> Stays at our homepage for 1 month
                        or until closing date proposal as mentioned under section “Closing date of Proposal” for
                        maximum visibility and targeted responses.</span>

                    <span style="display: block;margin-top:30px;font-size: 16px;"> Call for “Corporate Social
                        Responsibility” (CSR) Funding get circulated with all the NGO’s and stays in our “Corporate
                        Social Responsibility” (CSR) Funding newsletter for the next 2 issues</span>
                    <span style="display: block;margin-top:30px;font-size: 16px;"> This is at cost Of <span
                            style="color:blue;"> Rs 3499/- </span>
                            @if(session()->has('ssiapp_rec'))
                            <a href="#" onclick="addTocart(1)">(Add To Cart)</a>
                            @endif
                        </span>
                    <br>
                    or
                    <br>
                    <br>
                    <strong>
                        If you want us to post your “CSR Ad” please email us at – <a style="color:blue"
                            href="https://socialservicesindia.org/contact@SocialServicesIndia.org">contact@SocialServicesIndia.org.
                        </a>Please mention the “CSR Ad” and its title in the subject line of your email.
                    </strong>
                </div>
            </div>
            @if(session()->has('ssiapp_rec'))
            <section style="">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <div class="col-12">
                        <h4><b> Fill the form below before checkout</b></h4><br />

                    </div>
                    </header>


                    <!-- <form action="#" method="post" id="submit-job-form" class="job-manager-form" enctype="multipart/form-data"></form> -->



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/csr/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="border-bottom: 3px solid #444;">
                            <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Organisation </label>
                                        <input type="text" name="orgname" class="form-cntrl" id="name"
                                            placeholder="Name of  the organisation" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant title </label>
                                        <input type="text" name="grant_title" class="form-cntrl" id="email"
                                            placeholder="Grant title" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Location </label>
                                        <input type="text" name="location" class="form-cntrl" id="email"
                                            placeholder="" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Grant Amount </label>
                                        <input type="text" name="grant_amt" class="form-cntrl" id="amount"
                                            placeholder="" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        
                                        
                                    <label for="name">Closing dates for proposal</label> 

                                        <input type="text" name="close_date" class="form-cntrl" id="amount"
                                            placeholder="" /> 

                                        <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Email</label>
                                        <input type="email" name="email" class="form-cntrl" id="email" placeholder="" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                {{-- <div class="col-lg-12">
                                    <label for="company_logo">Description of the proposal</label><br>
                                    <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                        accept="image/png, image/jpeg" name="" id="" placeholder="Add Media">
                                </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the proposal</label><br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="email" placeholder="" rows="10"
                                            style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">upload proposal Document</label><br>
                                        <input type="file" class="form-cntrl-file" name="document" id="document" data-file_types="doc|pdf|text"
                                          accept="application/pdf" id="" placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation label</label><br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="company_logo" id="" placeholder="Add Media">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Reference Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="url" placeholder="" />

                                        <div class="validate"></div>
                                    </div>
                                </div>
                                @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                    <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                        {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value=""/>
                                </div>
                                @endisset
                               



                                <div class="form-group col-lg-12">
                                    <label for="name">Human Check 7+2=</label>
                                    <input type="text" name="url" class="form-cntrl" id="url" placeholder="" />

                                    <div class="validate"></div>
                                </div>
                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                                    <label for="vehicle3">Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%"> CSR Funding
                                            Ad</button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>




            @else
            <div class="row about-container">
                <div class="col-lg-12">

                    <hr style="color:#007bff;border:3px solid;">
                    <p class="card-text"><i>Please login to submit CSR Funding.</i> <a
                        href="{{url('/login')}}"
                            class="btn btn-primary">Login</a></p>

                    <p style="margin-top: 30px; font-size: 1rem;">
                        For any further assistance our experts will get in touch with you and take it forward.
                        <br /><br />
                        Please email us at: <b>contact@SocialServicesIndia.org</b> for <b>Queries</b>
                    </p>
                </div>

            </div>
            @endif
        </div>
        </div>
    </section>

    <script>
        function onchkclick(){
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index,value)=>{
                if($(value).prop('checked') == true){
                    if($('#cates').val() === ''){
                        $('#cates').val( $(value).val());
                    }else{
                        $('#cates').val( $('#cates').val() + ',' + $(value).val());
                    }
                    
                }
            });
            console.log($('#cates').val());
        }
    </script>

    @endsection

