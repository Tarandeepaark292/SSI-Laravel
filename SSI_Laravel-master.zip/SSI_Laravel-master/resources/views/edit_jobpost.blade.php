@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
    <div class="container-fluid">
        <h1 class="mt-4">Edit Job</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Edit Job </li>
        </ol>

      
        <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <div class="row" style="text-align: center;">

                </div>
                <form action="{{url('/admin/update_jobpost')}}/{{$jp_obj['jp_id']}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">

                @csrf
                <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                        <div class="form-row">

                            <div class="form-group col-lg-12">
                                <label for="name">Your email </label>
                                <input type="text" name="email" class="form-cntrl" id="email" placeholder="you@yourdomain.com"   value="{{$jp_obj['jp_email']}}" />
                                <div class="validate"></div>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name"> Job title</label>
                                <input type="text" name="jobtitle" class="form-cntrl" id="jobtitle" placeholder="e.g. United Nations India looking for “Senior Consultants""   value="{{$jp_obj['jp_title']}}"  />
                                <div class=" validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Location </label>
                            <input type="text" name="location" class="form-cntrl" id="location" placeholder="e.g.Bengaluru" value="{{$jp_obj['jp_loc']}}"/>
                            <small class="description">Leave this blank if the location is not important</small>
                            <div class="validate"></div>
                        </div>
                    </div>

                    <label>job type</label>
                    <div class="field required-field">
                        <select name="type" id="type" class="form-cntrl" style="width:100%;" value="{{$jp_obj['jp_job_type']}}">
                            <option class="level-0" value="3740">Contribution</option>
                            <option class="level-0" value="42">Freelance</option>
                            <option class="level-0" value="39" selected="selected">Full Time</option>
                            <option class="level-0" value="3649">Grant</option>
                            <option class="level-0" value="43">Internship</option>
                            <option class="level-0" value="40">Part Time</option>
                            <option class="level-0" value="41">Temporary</option>
                            <option class="level-0" value="3681">Work from Home</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label for="name" >Area of Expertise</label>
                            <select name="area" id="area" class="form-cntrl" value="{{$jp_obj['jp_ad_type_area_of_expertise']}}">
                                {{-- <option value="Choose a category… E.g Spotlight, Administration or Research">Choose a category… E.g Spotlight, Administration or Research</option>
                                <option value="Administration, HR, Management, Accounting/Finance Executive">Administration, HR, Management, Accounting/Finance Executive</option>
                                <option value="Agriculture, Livelihoods, Micro finance, Rural, Urban">Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                <option value="Auditing, Taxation, Financial accounting/Operations, Payroll officer">Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                <option value="Capacity Building, Training, Advocacy">Capacity Building, Training, Advocacy</option>
                                <option value="Communications, IT, Media, Knowledge Management, Editor">Communications, IT, Media, Knowledge Management, Editor</option>
                                <option value="Chairman, President, CEO, Director, Project Director, Deputy Director">Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                <option value="Disaster, Aid, Emergencies, Relief">Disaster, Aid, Emergencies, Relief</option>
                                <option value="Environment, Climate, Energy, Water, Sanitation">Environment, Climate, Energy, Water, Sanitation</option>
                                <option value="Fund-raising Business Development, Grants Writer">Fund-raising Business Development, Grants Writer</option>
                                <option value="Field Officers, Field Associates">Field Officers, Field Associates</option>
                                <option value="Government / Governance, Reforms, Corruption">Government / Governance, Reforms, Corruption</option>
                                <option value="Health, Doctors, Nurses, HIV / AIDS, Nutrition">Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                <option value="Human Rights, Law, Migration, Conflicts, Justice">Human Rights, Law, Migration, Conflicts, Justice</option>
                                <option value="Infrastructure, Technology, Engineering, Science">Infrastructure, Technology, Engineering, Science</option>
                                <option value="Consultant, Monitoring, Evaluation, Policy, Research">Consultant, Monitoring, Evaluation, Policy, Research</option>
                                <option value="Private Sector, Corporate Social Responsibility">Private Sector, Corporate Social Responsibility</option>
                                <option value="Project Associate, Project leaders, Project Assistant">Project Associate, Project leaders, Project Assistant</option>
                                <option value="Program Manager, Program Officer, Program Associate, Program Assistant">Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                <option value="Research Analysts, Research Associate, Research Assistant">Research Analysts, Research Associate, Research Assistant</option>
                                <option value="Social, Gender, Education, Youth, Child">Social, Gender, Education, Youth, Child</option>
                                <option value="Trade, Finance, Economics, Cooperation, Global">Trade, Finance, Economics, Cooperation, Global</option>
                                <option value="Technology Associate, Technical Assistant">Technology Associate, Technical Assistant</option>
                                <option value="Teachers, Teachers Educators, Principal">Teachers, Teachers Educators, Principal</option> --}}


                                <option
                                                        value="Administration, HR, Management, Accounting/Finance Executive"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Administration, HR, Management, Accounting/Finance Executive") ? 'selected' : '' }}>
                                                        Administration, HR, Management, Accounting/Finance Executive
                                                    </option>
                                                    <option
                                                        value="Agriculture, Livelihoods, Micro finance, Rural, Urban"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Agriculture, Livelihoods, Micro finance, Rural, Urban") ? 'selected' : '' }}>
                                                        Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                                    <option
                                                        value="Auditing, Taxation, Financial accounting/Operations, Payroll officer"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Auditing, Taxation, Financial accounting/Operations, Payroll officer") ? 'selected' : '' }}>
                                                        Auditing, Taxation, Financial accounting/Operations, Payroll
                                                        officer
                                                    </option>
                                                    <option value="Capacity Building, Training, Advocacy"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Capacity Building, Training, Advocacy") ? 'selected' : '' }}>
                                                        Capacity Building, Training, Advocacy</option>
                                                    <option
                                                        value="Communications, IT, Media, Knowledge Management, Editor"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Communications, IT, Media, Knowledge Management, Editor") ? 'selected' : '' }}>
                                                        Communications, IT, Media, Knowledge Management, Editor</option>
                                                    <option
                                                        value="Chairman, President, CEO, Director, Project Director, Deputy Director"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Chairman, President, CEO, Director, Project Director, Deputy Director") ? 'selected' : '' }}>
                                                        Chairman, President, CEO, Director, Project Director, Deputy
                                                        Director
                                                    </option>
                                                    <option value="Disaster, Aid, Emergencies, Relief"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Disaster, Aid, Emergencies, Relief") ? 'selected' : '' }}>
                                                        Disaster, Aid, Emergencies, Relief</option>
                                                    <option value="Environment, Climate, Energy, Water, Sanitation"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Environment, Climate, Energy, Water, Sanitation") ? 'selected' : '' }}>
                                                        Environment, Climate, Energy, Water, Sanitation</option>
                                                    <option value="Fund-raising Business Development, Grants Writer"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Fund-raising Business Development, Grants Writer") ? 'selected' : '' }}>
                                                        Fund-raising Business Development, Grants Writer</option>
                                                    <option value="Field Officers, Field Associates"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Field Officers, Field Associates") ? 'selected' : '' }}>
                                                        Field Officers, Field Associates</option>
                                                    <option value="Government / Governance, Reforms, Corruption"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Government / Governance, Reforms, Corruption") ? 'selected' : '' }}>
                                                        Government / Governance, Reforms, Corruption</option>
                                                    <option value="Health, Doctors, Nurses, HIV / AIDS, Nutrition"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Health, Doctors, Nurses, HIV / AIDS, Nutrition") ? 'selected' : '' }}>
                                                        Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                                    <option value="Human Rights, Law, Migration, Conflicts, Justice"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Human Rights, Law, Migration, Conflicts, Justice") ? 'selected' : '' }}>
                                                        Human Rights, Law, Migration, Conflicts, Justice</option>
                                                    <option value="Infrastructure, Technology, Engineering, Science"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Infrastructure, Technology, Engineering, Science") ? 'selected' : '' }}>
                                                        Infrastructure, Technology, Engineering, Science</option>
                                                    <option value="Consultant, Monitoring, Evaluation, Policy, Research"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Consultant, Monitoring, Evaluation, Policy, Research") ? 'selected' : '' }}>
                                                        Consultant, Monitoring, Evaluation, Policy, Research</option>
                                                    <option value="Private Sector, Corporate Social Responsibility"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Private Sector, Corporate Social Responsibility") ? 'selected' : '' }}>
                                                        Private Sector, Corporate Social Responsibility</option>
                                                    <option
                                                        value="Project Associate, Project leaders, Project Assistant"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Project Associate, Project leaders, Project Assistant") ? 'selected' : '' }}>
                                                        Project Associate, Project leaders, Project Assistant</option>
                                                    <option
                                                        value="Program Manager, Program Officer, Program Associate, Program Assistant"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Program Manager, Program Officer, Program Associate, Program Assistant") ? 'selected' : '' }}>
                                                        Program Manager, Program Officer, Program Associate, Program
                                                        Assistant
                                                    </option>
                                                    <option
                                                        value="Research Analysts, Research Associate, Research Assistant"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Research Analysts, Research Associate, Research Assistant") ? 'selected' : '' }}>
                                                        Research Analysts, Research Associate, Research Assistant
                                                    </option>
                                                    <option value="Social, Gender, Education, Youth, Child"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Social, Gender, Education, Youth, Child") ? 'selected' : '' }}>
                                                        Social, Gender, Education, Youth, Child</option>
                                                    <option value="Trade, Finance, Economics, Cooperation, Global"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Trade, Finance, Economics, Cooperation, Global") ? 'selected' : '' }}>
                                                        Trade, Finance, Economics, Cooperation, Global</option>
                                                    <option value="Technology Associate, Technical Assistant,"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Technology Associate, Technical Assistant,") ? 'selected' : '' }}>
                                                        Technology Associate, Technical Assistant, </option>
                                                    <option value="Teachers, Teachers Educators, Principal"
                                                        {{ ( $jp_obj['jp_ad_type_area_of_expertise'] == "Teachers, Teachers Educators, Principal") ? 'selected' : '' }}>
                                                        Teachers, Teachers Educators, Principal</option>
                                                </select>
                            </select>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:1rem;">
                        <div class="form-group col-lg-12">
                            <label for="name">Description</label>
                            <textarea class="form-cntrl" name="description" id="summernote" placeholder="" rows="10" style="height: auto;resize: none;">
                            {{$jp_obj['jp_desc']}}
                            </textarea>
                            {{-- <input class="form-cntrl" name="description" id="description" placeholder="" rows="10" style="height: auto;resize: none;" value="{{$jp_obj['jp_desc']}}"></input> --}}
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Application email </label>
                            <input type="text" name="applicationemail" class="form-cntrl" id="applicationemail" placeholder="application email" value="{{$jp_obj['jp_app_email']}}" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">closing dates </label> <span> (optional)</span>
                            
                            
                            <input type="text" name="closingdate" class="form-cntrl" id="closingdate" placeholder="" value="{{$jp_obj['jp_closing_date']}}" />
                            <small class="description">Deadline for new applicants</small>
                            <div class="validate"></div>
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="job_jd_file">Job description file (pdf) <small>(optional)</small></label>
                            <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text" accept="application/pdf" data-file_types="pdf" name="pdf_document" id="files" placeholder="" value="{{$jp_obj['jp_files']}}">
                            <input type="hidden" name="old_pdf_document" value="{{$jp_obj['jp_files']}}">
                        </div>    
                    </div>
                
            
            <div class="row">

                <div class="col-12" style="margin-top: 2rem;">
                    <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">ORGANIZATION</span> DETAILS</h2>
                </div>
                <div class="col-12" style="margin-top: 2rem;">
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Organization Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="applications" placeholder="Organization Name" value="{{$jp_obj['jp_org_name']}}"/>

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">website </label> <span>(optional)</span>
                            <input type="text" name="website" class="form-cntrl" id="website" placeholder="http://"  value="{{$jp_obj['jp_org_web']}}"/>

                            <div class="validate"></div>
                        </div>

                    </div>



                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Video<span>(optional)</span> </label>
                            <input type="text" name="video" class="form-cntrl" id="video" placeholder="A link to a Video about your organization" value="{{$jp_obj['jp_org_video']}}" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Twitter username<span>(optional)</span> </label>
                            <input type="text" name="twitter" class="form-cntrl" id="twitter" placeholder="@yourCompany" value="{{$jp_obj['jp_org_twitter']}}" />

                            <div class="validate"></div>
                        </div>



                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="company_logo">Logo <small>(optional)</small></label><br>
                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="logo" id="org_logo" placeholder="" value="{{$jp_obj['jp_org_logo']}}">
                                            <input type="hidden" name="old_org_logo" value="{{$jp_obj['jp_org_logo']}}">
                        </div>
                       
                    </div>
                    
                </div>
            </div>

            <div class="row" >
                    <div class="col-lg-12 ml-auto">
                        <button class="btn btn-primary" style="width:40%">Submit</button>
                    </div>
                </div>
                </div>

                
            

              
              
                <!-- <form action="{{url('recruiters/submit')}}" method="post"  enctype="multipart/form-data"> -->

                @csrf
                <!-- <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                        <div class="form-row">

                            <div class="form-group col-lg-12">
                                <label for="name">Your email </label>
                                <input type="text" name="email" class="form-cntrl" id="email" placeholder="you@yourdomain.com" />
                                <div class="validate"></div>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name"> job title</label>
                                <input type="text" name="jobtitle" class="form-cntrl" id="jobtitle" placeholder="e.g. United Nations India looking for “Senior Consultants""  />
                                <div class=" validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Location </label>
                            <input type="text" name="location" class="form-cntrl" id="location" placeholder="e.g.Bengaluru" />
                            <small class="description">Leave this blank if the location is not important</small>
                            <div class="validate"></div>
                        </div>
                    </div>

                    <label>job type</label>
                    <div class="field required-field">
                        <select name="job_type" id="job_type" class="form-cntrl" style="width:100%;">
                            <option class="level-0" value="3740">Contribution</option>
                            <option class="level-0" value="42">Freelance</option>
                            <option class="level-0" value="39" selected="selected">Full Time</option>
                            <option class="level-0" value="3649">Grant</option>
                            <option class="level-0" value="43">Internship</option>
                            <option class="level-0" value="40">Part Time</option>
                            <option class="level-0" value="41">Temporary</option>
                            <option class="level-0" value="3681">Work from Home</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label for="name" >Area of Expertise</label>
                            <select name="area" id="area" class="form-cntrl">
                                <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                                <option value="admin">Administration, HR, Management, Accounting/Finance Executive</option>
                                <option value="sjkd">Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                <option>Capacity Building, Training, Advocacy</option>
                                <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                <option>Disaster, Aid, Emergencies, Relief</option>
                                <option>Environment, Climate, Energy, Water, Sanitation</option>
                                <option>Fund-raising Business Development, Grants Writer</option>
                                <option>Field Officers, Field Associates</option>
                                <option>Government / Governance, Reforms, Corruption</option>
                                <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                <option>Infrastructure, Technology, Engineering, Science</option>
                                <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                <option>Private Sector, Corporate Social Responsibility</option>
                                <option>Project Associate, Project leaders, Project Assistant</option>
                                <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                <option>Research Analysts, Research Associate, Research Assistant</option>
                                <option>Social, Gender, Education, Youth, Child</option>
                                <option>Trade, Finance, Economics, Cooperation, Global</option>
                                <option>Technology Associate, Technical Assistant, </option>
                                <option>Teachers, Teachers Educators, Principal</option>
                            </select>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:1rem;">
                        <div class="form-group col-lg-12">
                            <label for="name">Description</label>
                            <textarea class="form-cntrl" name="description" id="description" placeholder="" rows="10" style="height: auto;resize: none;"></textarea>
                            <div class="validate"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Application email </label>
                            <input type="text" name="applicationemail" class="form-cntrl" id="applicationemail" placeholder="application email" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">closing dates </label> <span> (optional)</span>
                           
                           
                            <input type="text" name="closingdate" class="form-cntrl" id="closingdate" placeholder="" />
                            <small class="description">Deadline for new applicants</small>
                            <div class="validate"></div>
                        </div>

                    </div>
                    <label for="job_jd_file">Job description file (pdf) <small>(optional)</small></label>
                    <input type="file" class="form-cntrl-file" data-file_types="doc|pdf|text" accept="application/pdf" data-file_types="pdf" name="files" id="files" placeholder="">

                </div> -->
            
            <!-- <div class="row">

                <div class="col-12" style="margin-top: 2rem;">
                    <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">ORGANIZATION</span> DETAILS</h2>
                </div>
                <div class="col-12" style="margin-top: 2rem;">
                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Organization Name</label>
                            <input type="text" name="org_name" class="form-cntrl" id="applications" placeholder="Organization Name" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">website </label> <span>(optional)</span>
                            <input type="text" name="website" class="form-cntrl" id="website" placeholder="http://" />

                            <div class="validate"></div>
                        </div>

                    </div>



                    <div class="form-row">
                        <div class="form-group col-lg-6">
                            <label for="name">Video<span>(optional)</span> </label>
                            <input type="text" name="video" class="form-cntrl" id="video" placeholder="A link to a Video about your organization" />

                            <div class="validate"></div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="name">Twitter username<span>(optional)</span> </label>
                            <input type="text" name="twitterusername" class="form-cntrl" id="twitterusername" placeholder="@yourCompany" />

                            <div class="validate"></div>
                        </div>



                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="company_logo">Logo <small>(optional)</small></label><br>
                            <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="logo" id="_logo" placeholder="">
                        </div>
                        <div class="col-lg-6">
                            <fieldset class="fieldset-recaptcha" style="padding:10px;">
                                <label for="recaptcha">Are you human? Making sure you are not a bot!</label>
                                <div class="field required-field">
                                    <div class="g-recaptcha" data-sitekey="6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7">
                                        <div style="width: 304px; height: 78px;">
                                            <div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LeKLY4UAAAAANrF85Dwbe7o8a8-tJDg_Xp3GpC7&amp;co=aHR0cHM6Ly9zb2NpYWxzZXJ2aWNlc2luZGlhLmNvbTo0NDM.&amp;hl=en&amp;v=r8WWNwsCvXtk22_oRSVCCZx9&amp;size=normal&amp;cb=y1m1p94rndam" width="304" height="78" role="presentation" name="a-g2zv31jg0np" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div> -->
                    
                </div>
            </div>
           
                      
                </div>
            </section>
    </div>
    </section>
</main>

@endsection