@extends('layouts.home')
@section('content')

<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid" style="width: 100%;">
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">News </span>
        </header>

        

        <div class="row">

        </div>





        <div id="search_results" style="width: 100%;">
            @isset($newssearch)
            @foreach($newssearch as $res)
            <div class="col-12 " style="margin-bottom:2rem;">
                <a href="{{$res['news_links']}}" target="_blank">
                <div class="card content fell_search_item" id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">

                            <div class="col-md-4" style="text-align: center;">
                                <img style="width:80%" src="{{ asset($res['news_image']) }}" />
                            </div>
                            <div class="col-md-8">
                                
                                <div id="results">
                                    <h3 style='font-family: "Open Sans", sans-serif;'> {{ $res['news_head'] }}</h3>
                                </div>
                                
                            </div>
                            {{-- <div class="col-md-3 my-auto ">
                                <div id="results" style="color:#293e09;font-size: 18px;">
                                    <a href="{{$res['news_links']}}" class="btn btn-newprimary" target="_blank">Details</a>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                </div>
                </a>
            </div>
            @endforeach
            @endisset
        </div>







    </div>







    </div>
    </div>
</section>


{{-- <script>
    function myfunction(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxDonate.post') }}",
            data: {
                focus: $('#filter').val(),
                state: $('#filters').val(),
            },
            success: function (data) {
                console.log(data);
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error);
                }
            }
        });
    }

</script> --}}
@endsection
