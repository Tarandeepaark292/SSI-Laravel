@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">Recruiter Payment List</li>
        </ol>
        <div class="row justify-content-center">
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">Approved</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">View Details</a>
                        <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-warning text-white mb-4">
                    <div class="card-body">On Hold</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">View Details</a>
                        <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Recruiter Payment List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Recruiter Name</th>
                                <th>Order Number</th>
                                <th>Payment Total</th>
                                <th>Order ID</th>
                                <th>Create Date</th>
                                <th>Transaction Id</th>
                            </tr>
                        </thead>
                        @isset($paylist)
                        <tfoot>
                            <tr>
                                <th>Recruiter Name</th>
                                <th>Order Number</th>
                                <th>Payment Total</th>
                                <th>Order ID</th>
                                <th>Create Date</th>
                                <th>Transaction Id</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            @foreach($paylist as $noti)
                            <tr>
                                <td>{{ $noti['pay_by'] }}</td>
                                <td>{{ $noti['pay_order_id'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['pay_total'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['pay_order_id'] }}</td>
                                <td>{{ $noti['pay_create_date'] }}</td>
                                <td>{{ $noti['pay_provider_trans_id'] }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    function enableEvt(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxEVTenable.post') }}",
                data:{evt_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in enabling CSR');
                        console.log(data.error);
                    }
               }
            });
    }
    
    function disableEvt(idx){
        $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:'POST',
                dataType: "json",
                url:"{{ route('ajaxEVTdisable.post') }}",
                data:{evt_id:idx},
                success:function(data){
                    if(data.res == 'SUCCESS'){
                        $('#btn_layer_'+idx).html(data.data);
                    }else{
                        alert('Problem!! in disabling Event');
                        console.log(data.error);
                    }
                }
            });
    }
    </script>
    
@endsection
