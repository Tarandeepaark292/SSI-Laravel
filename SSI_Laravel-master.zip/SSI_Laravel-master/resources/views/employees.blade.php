@extends('layouts.home')
@section('content')
<section style="">
    <div class="intro-img" style="">
        <img src="{{ asset('img/ssi-temp-banner.jpg') }}" alt="" class="img-fluid"
            style="width: 100%;">
    </div>
    <form action="{{url('/employees/submit')}}" method="post" accept-charset="utf-8"enctype="multipart/form-data">
        @csrf
    <div class="container" style="margin-top:1rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h2>How It <span style="font-weight: bold;">Works</span></h2>
        </header>
        <div class="row" style="text-align: center;font-variant-caps: petite-caps;font-size: 20px;letter-spacing: 2px;">
            <div class="col-12">
                Have an account? <br />
                <a href="#" style="font-weight: bold;">Sign In</a> or If you don’t have an account <a href="#"
                    style="font-weight: bold;">Sign Up</a> by entering your email address. Your account details<br />
                will be confirmed via email
            </div>
        </div>
        <div class="row" style="border-bottom: 3px solid #444;">
            <div class="col-12" style="text-align: center;">
                <img src="{{ asset('img/job-seeker2.png')}}" class=" img-fluid" style="width: 80%;padding-bottom: 1rem;" />
            </div>
        </div>

        <div class="row">
            <div class="col-12" style="margin-top: 2rem;">
                <h2 style="letter-spacing: 2px;">ADD <span style="font-weight: bold;">DETAILS</span></h2>
            </div>
        </div>
        <div class="row" style="border-bottom: 3px solid #444;">
            <div class="col-12" style="margin: 0rem 0rem 2rem 0rem;">
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">Your Name</label>
                        <input type="text" name="jsname" class="form-cntrl" id="name" placeholder="Your Name"
                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                        <div class="validate"></div>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">Your Email</label>
                        <input type="email" class="form-cntrl" name="jsemail" id="jsemail" placeholder="Your Email"
                            data-rule="email" data-msg="Please enter a valid email" />
                        <div class="validate"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Professional Title</label>
                        <input type="text" name="jstitle" class="form-cntrl" id="jstitle" placeholder="Professional Title"
                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                        <div class="validate"></div>
                    </div>
                    {{-- <div class="form-group col-lg-6">
                        <label for="name">Resume File</label>
                        <input type="file" name="jsresumefile" class="form-cntrl-file" id="exampleFormControlFile1">
                        <small>Max. file size: 8 MB</small>
                    </div> --}}
                    <!--
            <div class="form-group col-lg-6">
              <label for="name">Location</label>
              <input type="email" class="form-cntrl" name="email" id="email" placeholder="Location" data-rule="email" data-msg="Please enter a valid email" />
              <div class="validate"></div>
            </div>
            -->
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Resume Content</label>
                        <textarea id="summernote" name="resumedata"></textarea>
                    </div>
                </div>


                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Area of Expertise</label>
                        <!--<input type="text" name="name" class="form-cntrl" id="name" placeholder="Choose a category… E.g Spotlight, Administration or Research" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />-->
                        <select class="form-cntrl" name="jsareaofexpertise">
                            <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                            <option value="Administration, HR, Management, Accounting/Finance Executive">Administration, HR, Management, Accounting/Finance Executive</option>
                            <option value="Agriculture, Livelihoods, Micro finance, Rural, Urban">Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                            <option value="Auditing, Taxation, Financial accounting/Operations, Payroll officer">Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                            <option value="Capacity Building, Training, Advocacy">Capacity Building, Training, Advocacy</option>
                            <option value="Communications, IT, Media, Knowledge Management, Editor">Communications, IT, Media, Knowledge Management, Editor</option>
                            <option value="Chairman, President, CEO, Director, Project Director, Deputy Director">Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                            <option value="Disaster, Aid, Emergencies, Relief">Disaster, Aid, Emergencies, Relief</option>
                            <option value="Environment, Climate, Energy, Water, Sanitation">Environment, Climate, Energy, Water, Sanitation</option>
                            <option value="Fund-raising Business Development, Grants Writer">Fund-raising Business Development, Grants Writer</option>
                            <option value="Field Officers, Field Associates">Field Officers, Field Associates</option>
                            <option value="Government / Governance, Reforms, Corruption">Government / Governance, Reforms, Corruption</option>
                            <option value="Health, Doctors, Nurses, HIV / AIDS, Nutrition">Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                            <option value="Human Rights, Law, Migration, Conflicts, Justice">Human Rights, Law, Migration, Conflicts, Justice</option>
                            <option value="Infrastructure, Technology, Engineering, Science">Infrastructure, Technology, Engineering, Science</option>
                            <option value="Consultant, Monitoring, Evaluation, Policy, Research">Consultant, Monitoring, Evaluation, Policy, Research</option>
                            <option value="Private Sector, Corporate Social Responsibility">Private Sector, Corporate Social Responsibility</option>
                            <option value="Project Associate, Project leaders, Project Assistant">Project Associate, Project leaders, Project Assistant</option>
                            <option value="Program Manager, Program Officer, Program Associate, Program Assistant">Program Manager, Program Officer, Program Associate, Program Assistant</option>
                            <option value="Research Analysts, Research Associate, Research Assistant">Research Analysts, Research Associate, Research Assistant</option>
                            <option value="Social, Gender, Education, Youth, Child">Social, Gender, Education, Youth, Child</option>
                            <option value="Trade, Finance, Economics, Cooperation, Global">Trade, Finance, Economics, Cooperation, Global</option>
                            <option value="Technology Associate, Technical Assistant,">Technology Associate, Technical Assistant, </option>
                            <option value="Teachers, Teachers Educators, Principal">Teachers, Teachers Educators, Principal</option>
                        </select>
                        <div class="validate"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <h3>Location</h3>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">Address Line 1</label>
                        <input type="text" class="form-cntrl" name="jsaddrline1" id="jsaddrline1" placeholder="Address Line 1"
                            data-rule="email" data-msg="Please enter a valid Address Line 1" />
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">Address Line 2</label>
                        <input type="text" class="form-cntrl" name="jsaddrline2" id="jsaddrline2"
                            placeholder="Address Line 2(Optional)" data-rule="email"
                            data-msg="Please enter a valid Address Line 2" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-4">
                        <label for="name">City</label>
                        <input type="text" class="form-cntrl" name="jscity" id="jscity" placeholder="City"
                            data-rule="email" data-msg="Please enter a valid City" />
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="name">State</label>
                        <select class="form-cntrl" name="jsstate">
                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                            <option value="Assam">Assam</option>
                            <option value="Bihar">Bihar</option>
                            <option value="Chandigarh">Chandigarh</option>
                            <option value="Chhattisgarh">Chhattisgarh</option>
                            <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                            <option value="Daman and Diu">Daman and Diu</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Lakshadweep">Lakshadweep</option>
                            <option value="Puducherry">Puducherry</option>
                            <option value="Goa">Goa</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Haryana">Haryana</option>
                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                            <option value="Jharkhand">Jharkhand</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Manipur">Manipur</option>
                            <option value="Meghalaya">Meghalaya</option>
                            <option value="Mizoram">Mizoram</option>
                            <option value="Nagaland">Nagaland</option>
                            <option value="Odisha">Odisha</option>
                            <option value="Punjab">Punjab</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Sikkim">Sikkim</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Telangana">Telangana</option>
                            <option value="Tripura">Tripura</option>
                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                            <option value="Uttarakhand">Uttarakhand</option>
                            <option value="West Bengal">West Bengal</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="name">Zip</label>
                        <input type="text" class="form-cntrl" name="jszip" id="jszip" placeholder="Zip"
                            data-rule="email" data-msg="Please enter a Zip Code" />
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12" style="margin-top: 2rem;">
                <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">OPTIONAL</span> FIELDS</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12" style="margin: 0rem 0rem 2rem 0rem;">
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">Photo</label>
                        <input type="file" name="jsphoto" class="form-cntrl-file" id="exampleFormControlFile1" required>
                        <small>Max. file size: 8 MB</small>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">Resume File</label>
                        <input type="file" name="jsresumefile" class="form-cntrl-file" id="exampleFormControlFile1">
                        <small>Optionally upload your resume for employers to view without your mobile number and
                            address. Max. file size: 8 MB</small>
                    </div>
                </div>
                <div class="form-row">

                    <div class="form-group col-lg-6">
                        <label for="name">Video</label>
                        <input type="text" name="jsvideos" class="form-cntrl" id="name"
                            placeholder="A link to video about yourself" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" />
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">Skills</label>
                        <input type="text" name="jsskills" class="form-cntrl" id="name"
                            placeholder="Comma seperate a list of relevent skills" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" required/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-4">
                        <label for="name" style="display: block;">URL(s)</label>
                        <button style="width:100%" class="btn btn-outline-primary btn-sm" onclick="showURLmodal(event);"> +
                            Add URL </button>
                        <div id="urlsdiv">
                            {{--  --}}
                        </div>
                        <input type="hidden" name="urlsdivjson" id="urlsdivjson"/>

                    </div>
                    <div class="form-group col-lg-4">
                        <label for="name" style="display: block;text-align: center;">Education</label>
                        <button style="width:100%" class="btn btn-outline-primary btn-sm" onclick="showEDUModal(event)"> + Add Education </button>
                        <div id="edudiv">
                            
                        </div>
                        <input type="hidden" name="edudivjson" id="edudivjson"/>

                        
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="name" style="display: block;text-align:right;">Experience</label>
                        <button style="width:100%" class="btn btn-outline-primary btn-sm" onclick="showEXPModal(event)"> + Add Experience </button>
                        <div id="expdiv">
                        </div>
                        <input type="hidden" name="expdivjson" id="expdivjson"/>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="text-align: right;">
            <div class="col-lg-6 ml-auto">
                <button class="btn btn-secondary" style="width:40%">Preview</button>
                <button class="btn btn-primary" style="width:40%">Submit</button>
            </div>
        </div>
    </div>
    </form>
</section>
<!-- Modal -->
<div class="modal fade" id="myURLModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Modal Header</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">URL</label>
                        <input type="text" id="inputURL" name="name" class="form-cntrl" id="name" placeholder="URL"
                            data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addURL()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myEduModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Add Education</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">School/University Name</label>
                        <input type="text" id="inputEDUname" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="edustartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="eduendyr">
                            <option value="pursuing">Pursuing</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addEDU()">Submit</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myExpModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Experience</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-lg-12">
                        <label for="name">Company Name</label>
                        <input type="text" id="inputEXPname" name="name" class="form-cntrl" id="name"
                            placeholder="Company Name" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" />
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <label for="name">From Year</label>
                        <select class="form-cntrl" id="expstartyr">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                        {{-- <input type="text" id="inputURL" name="name" class="form-cntrl" id="name"
                            placeholder="School or University" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" /> --}}
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="name">To Year</label>
                        <select class="form-cntrl" id="expendyr">
                            <option value="present">Present</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary"  onclick="addEXP()">Submit</button>
            </div>
        </div>
    </div>
    
</div>

<script>

jsfunc = {
    urlarr:[],
    eduarr:[],
    exparr:[],
    removeURLobj:(idx)=>{
        // e.preventDefault();
        var pos = 0;
        jsfunc.urlarr.forEach(function(item, index, array) {
                if(item.idx === idx){
                    pos = index;
                }
            });
        jsfunc.urlarr.splice(pos,1);
        var res = JSON.stringify(jsfunc.urlarr);   
        $('#urlsdivjson').val(res);
        console.log(res);
    },
    addURLobj:(urlval)=>{
        var retval = 0;
        if(jsfunc.urlarr.length > 0){
            let idx = 0;
            jsfunc.urlarr.forEach(function(item, index, array) {
                if(item.idx > idx){
                    idx = item.idx;
                }
            });
            idx = idx + 1;
            jsfunc.urlarr.push({idx:idx,url:urlval});
            retval = idx;
        }else{
            jsfunc.urlarr.push({idx:1,url:urlval});
            retval = 1;
        }
        var res = JSON.stringify(jsfunc.urlarr);   
        $('#urlsdivjson').val(res);
        console.log(res);
        return retval;
    },
    addEDUobj:(schoolname, startyr, endyr)=>{
        if(jsfunc.eduarr.length > 0){
            let idx = 0;
            jsfunc.eduarr.forEach(function(item, index, array) {
                if(item.idx > idx){
                    idx = item.idx;
                }
            });
            idx = idx + 1;
            jsfunc.eduarr.push({idx:idx,school:schoolname,start:startyr,end:endyr});
        }else{
            jsfunc.eduarr.push({idx:1,school:schoolname,start:startyr,end:endyr});
        }
        var res = JSON.stringify(jsfunc.eduarr);   
        $('#edudivjson').val(res);
        console.log(res);
    },
    addEXPobj:(schoolname, startyr, endyr)=>{
        if(jsfunc.exparr.length > 0){
            let idx = 0;
            jsfunc.exparr.forEach(function(item, index, array) {
                if(item.idx > idx){
                    idx = item.idx;
                }
            });
            idx = idx + 1;
            jsfunc.exparr.push({idx:idx,school:schoolname,start:startyr,end:endyr});
        }else{
            jsfunc.exparr.push({idx:1,school:schoolname,start:startyr,end:endyr});
        }
        var res = JSON.stringify(jsfunc.exparr);   
        $('#expdivjson').val(res);
        console.log(res);
    }

}

    function showURLmodal(e) {
        e.preventDefault();
        $("#myURLModal").modal('show');
    }
    
    function showEDUModal(e){
        e.preventDefault();
        $("#myEduModal").modal('show');
    }

    function showEXPModal(e){
        e.preventDefault();
        $("#myExpModal").modal('show');
    }

    function addEDU(){
       
        $('#myEduModal').modal('hide');
        $('#edudiv').append(
            '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 52px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">'+$('#myEduModal #inputEDUname').val()+'</span><br/><span>'+$('#myEduModal #edustartyr').val()+'</span> TO <span>'+$('#myEduModal #eduendyr').val()+'</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        );
        jsfunc.addEDUobj($('#myEduModal #inputEDUname').val(),$('#myEduModal #edustartyr').val(),$('#myEduModal #eduendyr').val());

        console.log(jsfunc.eduarr);
        $('#myEduModal #inputEDUname').val('');
    }

    function addURL() {
        if( $('#myURLModal #inputURL').val() !== ""){
            $('#myURLModal').modal('hide');
            let retidx = jsfunc.addURLobj($('#myURLModal #inputURL').val());
            $('#urlsdiv').append(
                '<div id="row_url_'+retidx+'" class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 52px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">'+$('#myURLModal #inputURL').val()+'</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px" onclick=removeURL(event,'+retidx+')></i></div></div>'
            );
            // let retidx = jsfunc.addURLobj($('#myURLModal #inputURL').val());
            console.log(jsfunc.urlarr);
            $('#myURLModal #inputURL').val('');
        }else{
            console.log('error');
        }
    }

    function addEXP(){
       
        $('#myExpModal').modal('hide');
        $('#expdiv').append(
            '<div class="row" style="border: 2px solid #0a5eb8;margin-top: 2px;border-radius: 4px;padding: 5px;margin-left:0px;margin-right:0px;height: 52px;"><div class="col-md-8" style="font-size: 12px;"><span style="font-weight: bold">'+$('#myExpModal #inputEXPname').val()+'</span><br/><span>'+$('#myExpModal #expstartyr').val()+'</span> TO <span>'+$('#myExpModal #expendyr').val()+'</span></div> <div class="col-md-4" style="font-size:20px;text-align: right;"><i class="fa fa-trash" style="margin-right:15px"></i></div></div>'
        );
        jsfunc.addEXPobj($('#myExpModal #inputEXPname').val(),$('#myExpModal #expstartyr').val(),$('#myExpModal #expendyr').val());
            console.log(jsfunc.eduarr);
            $('#myExpModal #inputEXPname').val('');
    }

    function removeURL(e,idx){
        e.preventDefault();
        jsfunc.removeURLobj(idx);
        $('#row_url_'+idx).remove();
    }

</script>
@endsection
