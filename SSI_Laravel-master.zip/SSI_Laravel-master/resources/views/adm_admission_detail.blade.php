@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Admission Edit </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admission Edit Panel</li>
                <li class="breadcrumb-item active"></li>
            </ol>

            <!-- {{-- <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                Post Jobseeker 
            </header> -->
            <!-- </div> --}} -->

            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/admin/admission/update')}}/{{$adnsearch['adn_id']}}" method="post"
                        accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Your Title </label>
                                        <input type="text" name="title" class="form-cntrl" id="title" placeholder=""
                                            style="width:100%;" value="{{$adnsearch['adn_title']}}" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Institution </label>
                                        <input type="text" name="name" class="form-cntrl" id="name" placeholder=""
                                            style="width:100%;" value="{{$adnsearch['adn_inst_name']}}" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By</label>
                                        <input type="date" name="apply" class="form-cntrl" id="apply" placeholder=""
                                            style="width:100%;" value="{{$adnsearch['adn_apply']}}" />

                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Cost Detail</label>

                                        <select class="form-cntrl" style="width:100%;" name="cost" id="cost"
                                            value="{{$adnsearch['adn_cost_details']}}">
                                            <option {{ ( $adnsearch['adn_cost_details'] == "free") ? 'selected' : '' }}
                                                value="free">Free</option>
                                            <option {{ ( $adnsearch['adn_cost_details'] == "paid") ? 'selected' : '' }}
                                                value="paid">paid</option>
                                        </select>
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Thematic Area</label>

                                        <select class="form-cntrl" name="area" id="area" style="width:100%;"
                                            value="{{$adnsearch['adn_area']}}">
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Agriculture ,food and nutrition") ? 'selected' : '' }}
                                                value="Agriculture ,food and nutrition">Agriculture ,food and nutrition
                                            </option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Entrepreneurship") ? 'selected' : '' }}
                                                value="Entrepreneurship">Entrepreneurship</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "CSR and Sustainability") ? 'selected' : '' }}
                                                value="CSR and Sustainability">CSR and Sustainability</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Community Development") ? 'selected' : '' }}
                                                value="Community Development">Community Development</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Disaster Management") ? 'selected' : '' }}
                                                value="Disaster Management">Disaster Management</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Education/Skill Development") ? 'selected' : '' }}
                                                value="Education/Skill Development">Education/Skill Development</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Energy ,Environment and climate change") ? 'selected' : '' }}
                                                value="Energy ,Environment and climate change">Energy ,Environment and
                                                climate change</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Microfinance") ? 'selected' : '' }}
                                                value="Microfinance">Microfinance</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Healthcare") ? 'selected' : '' }}
                                                value="Healthcare">Healthcare</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Human Right") ? 'selected' : '' }}
                                                value="Human Right">Human Right</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Livelihood") ? 'selected' : '' }}
                                                value="Livelihood">Livelihood</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Social Entrepreneurship") ? 'selected' : '' }}
                                                value="Social Entrepreneurship">Social Entrepreneurship</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Social Change") ? 'selected' : '' }}
                                                value="Social Change">Social Change</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Water and sanitation") ? 'selected' : '' }}
                                                value="Water and sanitation">Water and sanitation</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Water and recycling") ? 'selected' : '' }}
                                                value="Water and recycling">Water and recycling</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Gender studies") ? 'selected' : '' }}
                                                value="Gender studies">Gender studies</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Cross-sectrol/others") ? 'selected' : '' }}
                                                value="Cross-sectrol/others">Cross-sectrol/others</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Disablity or specially-abled-related") ? 'selected' : '' }}
                                                value="Disablity or specially-abled-related">Disablity or
                                                specially-abled-related</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Communication/IEC/BCC") ? 'selected' : '' }}
                                                value="Communication/IEC/BCC">Communication/IEC/BCC</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Public policy") ? 'selected' : '' }}
                                                value="Public policy">Public policy</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Technology") ? 'selected' : '' }}
                                                value="Technology">Technology</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Urban policy") ? 'selected' : '' }}
                                                value="Urban policy">Urban policy</option>
                                            <option {{ ( $adnsearch['adn_area'] == "Employability") ? 'selected' : '' }}
                                                value="Employability">Employability</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Women Empowerment") ? 'selected' : '' }}
                                                value="Women Empowerment">Women Empowerment</option>
                                            <option
                                                {{ ( $adnsearch['adn_area'] == "Rural management") ? 'selected' : '' }}
                                                value="Rural management">Rural management</option>
                                        </select>



                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Website URL Address</label>
                                        <input type="text" name="url" class="form-cntrl" id="url"
                                            placeholder="A link to video about yourself" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"
                                            value="{{$adnsearch['adn_website_url']}}" />
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Description</label>
                                        <textarea class="form-cntrl" id="summernote" name="disp" rows="10"
                                            style="height: auto;resize: none;">{{$adnsearch['adn_display_page']}}
                                        </textarea>
                                        {{-- <label for="name">Display Page Complete AD</label>
                                        <input type="text" class="form-cntrl" name="disp" id="disp"
                                            placeholder="Address Line 1" data-rule="email"
                                            data-msg="Please enter a valid Address Line 1"  value="{{$adnsearch['adn_display_page']}}"
                                        /> --}}
                                    </div>


                                </div>
                                <!-- <div class="form-group col-lg-6">
                                        <label for="name">Address Line 2</label>
                                        <input type="text" class="form-cntrl" name="jsaddrline2" id="jsaddrline2"
                                            placeholder="Address Line 2(Optional)" data-rule="email"
                                            data-msg="Please enter a valid Address Line 2" />
                                    </div> -->

                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <label for="name">Email</label>
                                        <input type="text" class="form-cntrl" name="email" id="email" placeholder=""
                                            data-rule="email" data-msg="" value="{{$adnsearch['adn_email']}}" />
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="name">Course State</label>
                                        <select class="form-cntrl" name="state" id="state"
                                            value="{{$adnsearch['adn_state']}}">
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Andhra Pradesh") ? 'selected' : '' }}
                                                value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Andaman and Nicobar Islands") ? 'selected' : '' }}
                                                value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Arunachal Pradesh") ? 'selected' : '' }}
                                                value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Assam") ? 'selected' : '' }}
                                                value="Assam">Assam</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Bihar") ? 'selected' : '' }}
                                                value="Bihar">Bihar</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Chandigarh") ? 'selected' : '' }}
                                                value="Chandigarh">Chandigarh</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Chhattisgarh") ? 'selected' : '' }}
                                                value="Chhattisgarh">Chhattisgarh</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Dadar and Nagar Haveli") ? 'selected' : '' }}
                                                value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Daman and Diu") ? 'selected' : '' }}
                                                value="Daman and Diu">Daman and Diu</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Delhi") ? 'selected' : '' }}
                                                value="Delhi">Delhi</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Lakshadweep") ? 'selected' : '' }}
                                                value="Lakshadweep">Lakshadweep</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Puducherry") ? 'selected' : '' }}
                                                value="Puducherry">Puducherry</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Goa") ? 'selected' : '' }}
                                                value="Goa">Goa</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Gujarat") ? 'selected' : '' }}
                                                value="Gujarat">Gujarat</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Haryana") ? 'selected' : '' }}
                                                value="Haryana">Haryana</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Himachal Pradesh") ? 'selected' : '' }}
                                                value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Jammu and Kashmir") ? 'selected' : '' }}
                                                value="Jammu and Kashmir">Jammu and Kashmir</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Jharkhand") ? 'selected' : '' }}
                                                value="Jharkhand">Jharkhand</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Karnataka") ? 'selected' : '' }}
                                                value="Karnataka">Karnataka</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Kerala") ? 'selected' : '' }}
                                                value="Kerala">Kerala</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Madhya Pradesh") ? 'selected' : '' }}
                                                value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Maharashtra") ? 'selected' : '' }}
                                                value="Maharashtra">Maharashtra</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Manipur") ? 'selected' : '' }}
                                                value="Manipur">Manipur</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Meghalaya") ? 'selected' : '' }}
                                                value="Meghalaya">Meghalaya</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Mizoram") ? 'selected' : '' }}
                                                value="Mizoram">Mizoram</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Nagaland") ? 'selected' : '' }}
                                                value="Nagaland">Nagaland</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Odisha") ? 'selected' : '' }}
                                                value="Odisha">Odisha</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Punjab") ? 'selected' : '' }}
                                                value="Punjab">Punjab</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Rajasthan") ? 'selected' : '' }}
                                                value="Rajasthan">Rajasthan</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Sikkim") ? 'selected' : '' }}
                                                value="Sikkim">Sikkim</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Tamil Nadu") ? 'selected' : '' }}
                                                value="Tamil Nadu">Tamil Nadu</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Telangana") ? 'selected' : '' }}
                                                value="Telangana">Telangana</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Tripura") ? 'selected' : '' }}
                                                value="Tripura">Tripura</option>
                                            <option
                                                {{ ( $adnsearch['adn_state'] == "Uttar Pradesh") ? 'selected' : '' }}
                                                value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option {{ ( $adnsearch['adn_state'] == "Uttarakhand") ? 'selected' : '' }}
                                                value="Uttarakhand">Uttarakhand</option>
                                            <option {{ ( $adnsearch['adn_state'] == "West Bengal") ? 'selected' : '' }}
                                                value="West Bengal">West Bengal</option>


                                        </select>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <label for="name">Academic Year</label>
                                        <input type="text" name="year" class="form-cntrl" id="year " placeholder=""
                                            style="width:100%;" value="{{$adnsearch['adn_year']}}" />
                                        <div class="validate"></div>
                                        {{-- <select class="form-cntrl" name="year" id="year" value="{{$adnsearch['adn_year']}}">
                                        <option {{ ( $adnsearch['adn_year'] == "2000") ? 'selected' : '' }}
                                            value="2000">2000</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2001") ? 'selected' : '' }}
                                            value="2001">2001</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2002") ? 'selected' : '' }}
                                            value="2002">2002</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2003") ? 'selected' : '' }}
                                            value="2003">2003</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2004") ? 'selected' : '' }}
                                            value="2004">2004</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2005") ? 'selected' : '' }}
                                            value="2005">2005</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2006") ? 'selected' : '' }}
                                            value="2006">2006</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2007") ? 'selected' : '' }}
                                            value="2007">2007</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2008") ? 'selected' : '' }}
                                            value="2008">2008</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2009") ? 'selected' : '' }}
                                            value="2009">2009</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2010") ? 'selected' : '' }}
                                            value="2010">2010</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2011") ? 'selected' : '' }}
                                            value="2011">2011</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2012") ? 'selected' : '' }}
                                            value="2012">2012</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2013") ? 'selected' : '' }}
                                            value="2013">2013</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2014") ? 'selected' : '' }}
                                            value="2014">2014</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2015") ? 'selected' : '' }}
                                            value="2015">2015</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2016") ? 'selected' : '' }}
                                            value="2016">2016</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2017") ? 'selected' : '' }}
                                            value="2017">2017</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2018") ? 'selected' : '' }}
                                            value="2018">2018</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2019") ? 'selected' : '' }}
                                            value="2019">2019</option>
                                        <option {{ ( $adnsearch['adn_year'] == "2020") ? 'selected' : '' }}
                                            value="2020">2020</option>
                                        </select> --}}
                                    </div>
                                </div>



                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                            style="width:100%;" accept="image/png, image/jpeg" name="org_logo" id=""
                                            placeholder="Add Media">
                                        <input type="hidden" name="org_old_logo" value="{{$adnsearch['adn_org_logo']}}">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload Pdf Document</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="doc|pdf|text"
                                            style="width:100%;" accept="application/pdf" name="pdf_document" id=""
                                            placeholder="Add Media">
                                        <input type="hidden" name="old_pdf" value="{{$adnsearch['adn_pdf_document']}}">
                                    </div>


                                </div>




                                <div class="form-row">


                                    <div class="form-group col-lg-12">
                                        <label for="name">Media Url</label>
                                        <input type="text" name="media_url" class="form-cntrl" id="media_url"
                                            placeholder="Comma seperate a list of relevent skills" data-rule="minlen:4"
                                            data-msg="Please enter at least 4 chars"
                                            value="{{$adnsearch['adn_mediaurl']}}" />
                                    </div>
                                </div>
                            </div>




                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12 ml-auto">

                                    <button type="submit" class="btn btn-primary   btn-register" name="SUBMIT"
                                        style="width:30%"> Update Data
                                    </button>
                                </div>
                            </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
        <!-- </div> -->
    </section>

</main>

@endsection
