@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Admission Panel</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Admission AD</li>
            </ol>
                   
        
           
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-admission/submit')}}" method="post" accept-charset="utf-8" onsubmit="validate(event);"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Choose Organization </label>
                                        <select class="form-control" name="org_id" id="org_id" required="required">
                                            <option value="-1">N/A</option>
                                            @foreach ($organizationlist as $organization )
                                                <option value="{{$organization['r_id']}}">{{$organization['r_org_name']}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Course Title </label>
                                        <input type="text" name="title" class="form-cntrl"  maxlength="300" id="title"
                                            placeholder="" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of the Institution </label>
                                        <input type="text" name="name_institution" class="form-cntrl" id="name "
                                            placeholder="" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By </label>
                                        <input type="date" name="apply" class="form-cntrl" id="applyby"
                                            placeholder="" style="width:100%;" />

                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Cost Detail</label>
                                      
                                        <select class="form-cntrl" name="costdetails" id="cost">
                                            <option value="free">Free</option>
                                            <option value="paid">Paid</option>
                                        </select>
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Thematic Area</label>
                                        <!-- 
                                        <input type="text" name="close_date" class="form-cntrl" id="amount"
                                            placeholder="" style="width:100%;"  />  -->

                                        <select class="form-cntrl" name="area" id="area">
                                            <option value="Agriculture ,food and nutrition">Agriculture ,food and nutrition</option>
                                            <option value="Entrepreneurship">Entrepreneurship </option>

                                            <option value="CSR and Sustainability">CSR and Sustainability</option>
                                            <option value="Community Development">Community Development </option>

                                            <option value="Disaster Management">Disaster Management</option>
                                            <option value="Education/Skill Development">Education/Skill Development</option>
                                            <option value="Energy ,Environment and climate change">Energy ,Environment and climate change </option>
                                            <option value="AMicrofinance">Microfinance</option>
                                            <option value="Healthcare">Healthcare</option>
                                            <option value="Human Right">Human Right</option>
                                            <option value="Livelihood">Livelihood</option>
                                            <option value="Social Entrepreneurship">Social Entrepreneurship</option>
                                            <option value="Social Change">Social Change</option>
                                            <option value="Water and sanitation">Water and sanitation</option>
                                            <option value="Waste and recycling"> Waste and recycling</option>
                                            <option value="Gender studies">Gender studies</option>
                                            <option value="Cross-sectrol/others">Cross-sectrol/others</option>
                                            <option value="Disablity or specially-abled-related">Disablity or specially-abled-related</option>
                                            <option value="Communication/IEC/BCC">Communication/IEC/BCC
                                            </option>
                                            <option value="Public policy">Public policy</option>
                                            <option value="Technology">Technology</option>
                                            <option value="Urban policy">Urban policy</option>
                                            <option value="Employability">Employability </option>
                                            <option value="Women Empowerment<">Women Empowerment</option>
                                            <option value="Rural management">Rural management</option>
                                        </select>

                                        <!-- <textarea class="form-cntrl" name="closingdate" id="closingdate" placeholder="" rows="10" style="height: auto;resize: none;"></textarea> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Website URL Address</label>
                                        <input type="text" name="website_url" class="form-cntrl" id="url "
                                            placeholder="Website" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Description</label>
                                        <textarea class="form-cntrl" id="summernote" name="display_page" rows="10" style="height: auto;resize: none;">
                                        </textarea>
                                        {{-- <input type="text" name="display_page" class="form-cntrl" id="display"
                                            placeholder="" style="width:100%;" /> --}}

                                        <div class="validate"></div>
                                    </div>
                                </div>



                                <div class="form-row">

                                    <div class="form-group col-lg-4">
                                        <label for="name">Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email"
                                            placeholder="abc@example.com" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-4">
                                        <label for="name">Course State </label>
                                        <!-- <input type="text" name="name_institution" class="form-cntrl" id="name "
                                            placeholder="Grant title" style="width:100%;" /> -->

                                        <select class="form-cntrl" name="state" id="state">
                                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands
                                            </option>
                                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option value="Assam">Assam</option>
                                            <option value="Bihar">Bihar</option>
                                            <option value="Chandigarh">Chandigarh</option>
                                            <option value="Chhattisgarh">Chhattisgarh</option>
                                            <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                            <option value="Daman and Diu">Daman and Diu</option>
                                            <option value="Delhi">Delhi</option>
                                            <option value="Lakshadweep">Lakshadweep</option>
                                            <option value="Puducherry">Puducherry</option>
                                            <option value="Goa">Goa</option>
                                            <option value="Gujarat">Gujarat</option>
                                            <option value="Haryana">Haryana</option>
                                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                            <option value="Jharkhand">Jharkhand</option>
                                            <option value="Karnataka">Karnataka</option>
                                            <option value="Kerala">Kerala</option>
                                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option value="Maharashtra">Maharashtra</option>
                                            <option value="Manipur">Manipur</option>
                                            <option value="Meghalaya">Meghalaya</option>
                                            <option value="Mizoram">Mizoram</option>
                                            <option value="Nagaland">Nagaland</option>
                                            <option value="Odisha">Odisha</option>
                                            <option value="Punjab">Punjab</option>
                                            <option value="Rajasthan">Rajasthan</option>
                                            <option value="Sikkim">Sikkim</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="Telangana">Telangana</option>
                                            <option value="Tripura">Tripura</option>
                                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option value="Uttarakhand">Uttarakhand</option>
                                            <option value="West Bengal">West Bengal</option>
                                        </select>
                                        <div class="validate"></div>
                                    </div>


                                    <div class="form-group col-lg-4">
                                        <label for="name">Academic Year </label>
                                        <input type="text" name="year" class="form-cntrl" id="year "
                                            placeholder="2021-22" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">

                                <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="jpg|jpeg|gif|png" style="width:100%;" 
                                            accept="image/png, image/jpeg" name="org_logo" id="" placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                        <input type="file" class="form-cntrl" data-file_types="doc|pdf|text"
                                            style="width:100%;" accept="application/pdf" name="pdf_document" id=""
                                            placeholder="Add Media">
                                    </div>

                                   
                                </div>
                                <!-- {{-- <div class="col-lg-12">
                                    <label for="company_logo">Description of the proposal</label><br>
                                    <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                        accept="image/png, image/jpeg" name="" id="" placeholder="Add Media" >
                                </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the proposal</label><br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="email" placeholder=""
                                            rows="10" style="height: auto;resize: none;  width:100%;"></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div> -->


                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="name">Media Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="media_url" placeholder="Youtube link or Social Media Link"
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                 
                                </div>



                                <!-- @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="" />
                                </div>
                                @endisset -->





                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="terms" name="terms" value="Boat">
                                    <label for="vehicle3">Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%">Submit
                                            </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>




            
        </div>
        </div>
    </section>
    <script>
         function validate(event){
            var sel = $('#org_id').val();
            if(sel === "-1"){
                alert("Please Select Organization");
                event.preventDefault();
            }
        }

    </script>
    
</main>

@endsection
