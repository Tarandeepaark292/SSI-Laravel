@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Call for Paper</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organization Panel</li>
                <li class="breadcrumb-item active">Call for Paper AD</li>
            </ol>



            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <div class="col-12">
                            <!-- <h4><b> Fill the form below before checkout</b></h4><br /> -->

                        </div>
                    </header>



                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/callpaper/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-12 " style="border: 0;">
                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="name">Paper Title </label>
                                        <input type="text" name="title" class="form-cntrl" maxlength="300" id="title"
                                            placeholder="" style="width:100%;" value="" />
                                        <div class="validate"></div>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="name">Paper Type </label>

                                        <!-- 
                                        <input type="text" name="close_date" class="form-cntrl" id="amount"
                                            placeholder="" style="width:100%;"  />  -->

                                        <select class="form-cntrl" name="type" id="type">
                                            <option value="Aged/Elderly">Aged/Elderly</option>
                                            <option value="Animal Husbandry, Dairying & Fisheries">Animal Husbandry,
                                                Dairying & Fisheries </option>

                                            <option value="Agriculture">Agriculture</option>
                                            <option value="Artificial Intelligence and Development">Artificial
                                                Intelligence and Development </option>

                                            <option value="Biotechnology">Biotechnology</option>
                                            <option value="Civic Issues">Civic Issuest</option>
                                            <option value="Differently Abled">Differently Abled </option>
                                            <option value="Drinking Water">Drinking Water</option>
                                            <option value="Development and Democracy ">Development and Democracy
                                            </option>
                                            <option value="Environment & Forests">Environment & Forests</option>
                                            <option value="Health & Family Welfare">Health & Family Welfare</option>
                                            <option value="Housing">Housing</option>
                                            <option value="Information & Communication Technology (ICT)">Information &
                                                Communication Technology (ICT)</option>
                                            <option value="Internet governance ">Internet governance </option>
                                            <option value="Land Resources"> Land Resources</option>
                                            <option value="Micro Finance SHGs">Micro Finance SHGs</option>
                                            <option value="Minority Issues">Minority Issues</option>
                                            <option value="Nutrition">Nutrition</option>
                                            <option value="Prisoner’s Issues">Prisoner’s Issues
                                            </option>
                                            <option value="Rural Development & Poverty Alleviation">Rural Development &
                                                Poverty Alleviation</option>
                                            <option value="Scientific & Industrial Research">Scientific & Industrial
                                                Research</option>
                                            <option value="Tourism">Tourism</option>
                                            <option value="Urban Development & Poverty Alleviation">Urban Development &
                                                Poverty Alleviation </option>
                                            <option value="Water Resources<">Water Resources</option>
                                            <option value="Youth Affairs">Youth Affairs</option>
                                            <option value="Art & Culture">Art & Culture</option>
                                            <option value="Children">Children</option>
                                            <option value="Dalit Upliftment">Dalit Upliftment</option>
                                            <option value="Disaster Management">Disaster Management</option>
                                            <option value="Disability">Disability</option>
                                            <option value="Education & Literacy">Education & Literacy</option>

                                            <option value="Food Processing">Food Processing</option>
                                            <option value="HIV/AIDS">HIV/AIDS</option>
                                            <option value="Human Rights">Human Rights</option>
                                            <option value="Labour & Employment">Labour & Employment</option>
                                            <option value="Legal Awareness & Aid">Legal Awareness & Aid</option>
                                            <option value="Micro Small & Medium Enterprises">Micro Small & Medium
                                                Enterprises</option>
                                            <option value="New & Renewable Energy">New & Renewable Energy</option>
                                            <option value="Panchayati Raj">Panchayati Raj</option>
                                            <option value="Right To Information & Advocacy">Right To Information &
                                                Advocacy</option>
                                            <option value="Science & Technology">Science & Technology</option>
                                            <option value="Sports">Sports</option>
                                            <option value="Tribal Affairs">Tribal Affairs</option>
                                            <option value="Vocational Training">Vocational Training</option>
                                            <option value="Women’s Development & Empowerment">Women’s Development &
                                                Empowerment</option>
                                            <option value="Sanitation">Sanitation</option>
                                            <option value="Sustainable Development">Sustainable Development</option>
                                            <option value="Wildlife">Wildlife</option>
                                            <option value="Skill Development">Skill Development</option>
                                            <option value="Sustainable Development">Sustainable Development</option>
                                            <option value="Financial Inclusion">Financial Inclusion</option>
                                            <option value="Entrepreneurship And Innovation">Entrepreneurship And
                                                Innovation</option>
                                            <option value="Impact Investing">Impact Investing</option>
                                            <option value="Any Other">Any Other</option>
                                            <option value="All Publications">All Publications</option>
                                        </select>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Name of Organisation </label>
                                        <input type="text" name="org" class="form-cntrl" id="org" placeholder=""
                                            style="width:100%;" />

                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <!-- <div class="form-group col-lg-6"> -->
                                        <label for="name">Location </label>
                                        <input type="text" name="loc" class="form-cntrl" id="loc" placeholder="India"
                                            style="width:100%;" />
                                        <!-- <small class="description">Leave this blank if the location is not important</small> -->
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top:1rem;">

                                    <div class="form-group col-lg-12">
                                        <label for="name">Description</label>
                                        {{-- <input type="text" name="display_page" class="form-cntrl" id="display"
                                            placeholder="" style="width:100%;" /> --}}
                                            <textarea class="form-cntrl" name="display_page" id="summernote" rows="10" style="height: auto;resize: none;">
                                            </textarea>

                                        <div class="validate"></div>
                                    </div>
                                   
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Application Email </label>
                                        <input type="text" name="email" class="form-cntrl" id="email"
                                            placeholder="Enter valid email id to receive application" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Website URL Address</label>
                                        <input type="text" name="website_url" class="form-cntrl" id="url "
                                            placeholder="Website Link" style="width:100%;" />
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Organisation Logo</label><br>

                                        <input type="file" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                            style="width:100%;" accept="image/png, image/jpeg" name="org_logo" id="logo"
                                            placeholder="Add Media">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="company_logo">Upload PDF Document</label><br>
                                 
                                        <input type="file" class="form-cntrl" data-file_types="doc|pdf|text"
                                            style="width:100%;" accept="application/pdf" name="pdf_document" id=""
                                            placeholder="Add Media">
                                    </div>

                                   
                                </div>
                                <!-- {{-- <div class="col-lg-12">
                                    <label for="company_logo">Description of the proposal</label><br>
                                    <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                        accept="image/png, image/jpeg" name="" id="" placeholder="Add Media" >
                                </div> --}}

                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <label for="company_logo">Description of the proposal</label><br>
                                        <textarea class="form-cntrl" name="proposal_desc" id="email" placeholder=""
                                            rows="10" style="height: auto;resize: none;  width:100%;"></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div> -->

                           

                                <div class="form-row">
                                    <div class="form-group col-lg-6">
                                        <label for="name">Media Url</label>
                                        <input type="text" name="url" class="form-cntrl" id="media_url" placeholder="Youtube link or Social Media Link"
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="name">Apply By</label>
                                        <input type="date" name="apply" class="form-cntrl" id="apply" placeholder=""
                                            style="width:100%;" />

                                        <div class="validate"></div>
                                    </div>
                                </div>



                                <!-- @isset($html)
                                <div class="form-row">
                                    <div class="form-group col-lg-12">
                                        <h4>Proposal Category</h4>
                                    </div>
                                    {{-- <div class="form-group col-lg-12"> --}}
                                    {!! $html !!}
                                    {{-- </div> --}}
                                    <input type="hidden" id="cates" name="cates" value="" />
                                </div>
                                @endisset -->





                                {{-- <div class="col-lg-12">

                                    <input type="checkbox" id="terms" name="terms" value="Boat">
                                    <label for="vehicle3">Terms and Condition</label><br>

                                </div> --}}




                                <div class="row" style="text-align:center;">
                                    <div class="col-lg-12 ml-auto">

                                        <button class="btn btn-primary  btn-register" style="width:30%">Submit
                                        </button>
                                    </div>
                                </div>
                    </form>
                </div>



            </section>





        </div>
        </div>
    </section>

</main>

@endsection
