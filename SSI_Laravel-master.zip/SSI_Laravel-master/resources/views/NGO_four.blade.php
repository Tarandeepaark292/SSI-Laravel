@extends('layouts.home')
@section('content')
<section id="NGO" style="">
    <div class="intro-img" style="">
        {{-- <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;"> --}}
    </div>
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">

        <div class=" container">
            <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                <h3><span class="titleheading">NGO Offices Policies & Process</span>  </h3>
            </header>
        </div>

        <table class="table-responsive-md table-hover">
            <tbody>
                <thead>
                    <tr>
                        <th scope="col">NO.</th>
                        <th scope="col">Format</th>
                        <th scope="col">Link</th>
                        
                    </tr>
                </thead>
                <tr>
                    <td>1</td>
                    <td>Office Process
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/1-Office-Process-Some-Tricks-to-help-organise-your-work.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Procurement processes
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/2-Procurement-processes.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Recruitment policy
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/3-Recruitment-policy.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Staff or Consultant Appointment letter
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/4-Staff-Consultant-Appointment-letter.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Terms and Conditions of Engagement - Work responsibilities, period of probation, reporting, performance evaluation, office timings, leaves and holidays and termination of the contract of employment
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/5-Terms-and-Conditions-of-Engagement.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Staff Duties “Administration or Program”-  Employee Induction and Employee Exit process documentation
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/6-Staff Duties-Administration-or-Program-Employee-Induction-and-Employee-Exit-process-documentation.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Employee Exit document
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/7-Employee-Exit-document.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Experience Certificate for Consultant or Staff
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/8-Experience-Certificate-for-Consultant-or-Staff.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Releaving letter for Consultant or Staff
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/9-Relieving-letter-for-Consultant-or-Staff.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Internship Certificate 
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/10-Internship-Certificate.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>Sexual Harassment and Gender Based Discrimination
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/11-Sexual-Harassment-and-Gender-Based-Discrimination.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Finance process manual
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/12-Finance-process-manual.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>Project life cycle
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/13-Project-life-cycle.xls')}}">Download</a></td>
                </tr>
                <tr>
                    <td>14</td>
                    <td>Risk Assessment
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/14-Risk-Assessment.pdf')}}">Download</a></td>
                </tr>
                <tr>
                    <td>15</td>
                    <td>Fixed Asset Register
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/15-Fixed-Asset-Register.xls')}}">Download</a></td>
                </tr>
                <tr>
                    <td>16</td>
                    <td>Staff leave register
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/16-Staff-leave-register.xlsx')}}">Download</a></td>
                </tr>
                <tr>
                    <td>17</td>
                    <td>Payroll Register
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/17-Payroll-Register.xls')}}">Download</a></td>
                </tr>
                <tr>
                    <td>18</td>
                    <td>Investment declaration
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/18-Investment-declaration.xlsx')}}">Download</a></td>
                </tr>
                <tr>
                    <td>19</td>
                    <td>Fixed Deposit Register
                    </td>
                    <td><a href="{{url('/public/NGO-Resources/NGO-Office-Policies-Process-and-formats/19-Fixed-Deposit-Register.xls')}}">Download</a></td>
                </tr>
                
            </tbody>
        </table>
    </div>
</section>

@endsection
