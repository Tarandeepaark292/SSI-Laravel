@extends('layouts.home')
@section('content')

        <section style="">
            {{-- <div class="intro-img" style="">
              <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                  <h3><span class="titleheading">Broadcast</span> <span class="titleheading">Resume</span></h3>
                </header>
                <div class="row">
                    <div class="col-12">
                        <span style="display: block;font-size: 16px;">The advantages of broadcasting your resume on this platform, and signing up for the 3 month value membership are immense:</span>
                        <ol style="line-height: 2rem;padding:1em;">
                          <li>Grabs the attention of employers and recruiters since we promote your strongest skills and accomplishments</li>  
                          <li>Provides access to your resume to more than 50,000 professional organizations across India</li>  
                          <li>Chances of getting hired are much higher compared to other candidates</li>  
                          <li>Provides an independent platform to create links through direct interaction of candidate and employer</li>  
                          <li>Provides all details of candidate (email, contact details etc.) with the employers for quick recruitment closure</li>  
                          <li>List at the top of our website for 1 month to seek attention of potential employers and recruiters</li>  
                          <li>Candidate receives email notifications for each job posted in their preferred field (This is chosen in “Areas of Expertise”)</li>  
                          <li>We also help employers and experts see your resume first while downloading/purchasing resume credits</li>
                        </ol>
                        <span style="display: block;font-size: 16px;"><b>Note</b>: We request the candidates to only disclose email IDs. Delete your mobile numbers and address while uploading or using the broadcast resume service.</span>

                        <span style="display: block;font-size: 16px;margin-top: 2rem;"><b style="text-decoration: underline;">Broadcast resume</b> @ <span
                            class="imp">Rs 499/-</span> 
                            @if(session()->has('ssiapp_js'))
                            <a href="#" onclick="addTocart(11)">(Add To Cart)</a>
                            @endif
                             only</span>
                        

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <hr style="color:#007bff;border:3px solid;">
                        <span style="display: block;font-size: 14px;margin-top: 2rem;">If you want us to “Broadcast resume” please email us at – Contact@SocialServicesIndia.com. Please mention “Broadcast resume” in the subject line of your email.</span>

                        <span style="display: block;font-size: 14px;margin-top: 2rem;">To get the broadcast resume and free 3-month value membership, please click here to create an account and write an email to Contact@SocialServicesIndia.com.</span>

                    </div>
                </div>
            </div>
        </section>

    </main>
    @endsection
