@extends('layouts.auth_home')
@section('content')

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            <a href="{{url('/')}}"><img src="{{asset('img/ssi_logo_white.png')}}" alt="" /></a>
            <h3>Welcome</h3>

            <a class="pagelink" href="{{url('/login')}}">Login</a><br />
        </div>
        <div class="col-md-9 register-right">
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                aria-controls="home" aria-selected="true">Jobseeker Signup</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                aria-controls="profile" aria-selected="false">Organisation Signup</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <h3 class="register-heading ">Apply as a jobseeker</h3>
                    <form method="post" action="{{url('/js/register')}}">
                        <div class="row register-form">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="fname" placeholder="First Name *"
                                        value="" />
                                        @error('fname') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="lname" placeholder="Last Name *"
                                        value="" />
                                        @error('lname') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="text" minlength="10" maxlength="10" name="EmpPhone"
                                        class="form-control" placeholder="Your Phone *" value="" />
                                        @error('EmpPhone') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                
                                <div class="form-group">
                                    <div class="maxl">
                                        <label class="radio inline">
                                            <input type="radio" name="gender" value="male" checked>
                                            <span> Male </span>
                                        </label>
                                        <label class="radio inline">
                                            <input type="radio" name="gender" value="female">
                                            <span>Female </span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Your Email *"
                                        value="" />
                                        @error('email') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Password *"
                                        value="" />
                                        @error('password') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="repassword"
                                        placeholder="Confirm Password *" value="" />
                                </div>
                                
                                <input type="hidden" name="role" value="jobseek" />
                            </div>
                            <div>
                                
                                @if($errors->any())
                                @error('error_reason')
                                <h4>{{$errors->first()}}</h4>
                                @enderror
                                @endif
                            </div>
                            @csrf
                            <div style="text-align:center;width:100%">
                                <input type="submit" class="btnRegister" value="Register" />
                            </div>

                        </div>
                    </form>
                </div>
                <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <h3 class="register-heading">Apply as a Organisation</h3>
                    <form action="{{url('/recruiter/register')}}" method="post">
                        <div class="row register-form">
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <input type="text" name="org_name" class="form-control"
                                        placeholder="Organisation Name *" value="" />
                                        @error('org_name') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="email" name="emailaddress" class="form-control" placeholder="Official Email *"
                                        value="" />
                                        @error('emailaddress') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="text" maxlength="10" minlength="10" name="mobile" class="form-control"
                                        placeholder="Mobile *" value="" />
                                        @error('mobile') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="" class="form-control" name="officelandline"
                                        placeholder="Office Landline: (Optional) " value="" />
                                        @error('officelandline') <p style="color:red">{{$message}}</p>@enderror

                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="passwd"
                                        placeholder="Create Password:" value="" />
                                        @error('passwd') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    
                                        <select class="form-control" name="company-type">
                                            <option value="" class="hidden" selected disabled>Company type:*</option>
                                            <option value="Trust registration">Trust registration</option>
                                            <option value="Society registration">Society registration</option>
                                            <option value="Section 8 or 25 company registration">Section 8 or 25 company registration</option>
    
                                        </select>
                                        @error('company-type') <p style="color:red">{{$message}}</p>@enderror
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="contactperson" class="form-control"
                                        placeholder="Contact Person’s Name: *" value="" />
                                        @error('contactperson') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                {{-- <div class="form-group">
                                    <select class="form-control">
                                        <option class="hidden" selected disabled>Trust Registration </option>
                                        <option>Society registration</option>
                                        <option>Section 8 or 25 company registration</option>

                                    </select>
                                </div> --}}
                                <div class="form-group">
                                    <input type="text" class="form-control" name="pincode" placeholder="Pincode* " value="" />
                                    @error('pincode') <p style="color:red">{{$message}}</p>@enderror
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="website" placeholder="Website: (Optional)"
                                        value="" />
                                       
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="org_pan" placeholder="Organisation Pan: (Optional)"
                                        value="" />
                                </div>


                            </div>
                            <div class="col-md-12">

                                <p>
                                    <input type="checkbox" name="agreeterms" aria-label="Checkbox for following text input"> I agree to
                                    <a target="_blank" href="{{url('/terms-condition')}}"> Terms and Conditions </a> and <a target="_blank" href="{{url('/privacy-policy')}}">Privacy Policy</a></p>
                            </div>
                            <input type="hidden" name="role" value="recruiter" />
                            <input type="hidden" name="from" value="regular_register" />
                            <div class="col-md-12" style="text-align: center;">
                                <div>
                                
                                    @if($errors->any())
                                    @error('error_reason')
                                    <h4>{{$errors->first()}}</h4>
                                    @enderror
                                    @endif
                                </div>
                                @csrf
                                <input type="submit" class="btnRegister" value="Register" />
                            </div>
                        </div>
                    </form>



                </div>
            </div>
        </div>
    </div>

</div>
@endsection
