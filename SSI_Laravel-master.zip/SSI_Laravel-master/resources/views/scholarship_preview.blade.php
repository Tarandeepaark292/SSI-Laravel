@extends('layouts.home')
@section('content')
@include('inc.js_preview_style')

<section style="">
    {{-- <div class="intro-img" style="margin-bottom: 5rem;">
        <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
        <h3>Fellowship Post Preview
            @if ( $jp_obj['sc_status'] == '1')
            ( Approved )
            @else
            ( Waiting Approval )
            @endif


        </h3>
    </header>
    <div class="row">
        <div class="col-8" style="margin:0 auto;">
            <div class="container" style="background: #e9f3fb;padding: 1rem;margin-bottom: 5rem;">

                <div class="row">
                    <div class="col-md-12">
                        <h1 style="text-align: center;font-weight: bold;font-variant: petite-caps;">
                            {{ $jp_obj['sc_title'] }} </h1>
                    </div>
                </div>

                <div class="row" style="margin-bottom:2rem;">
                    <div class="col-md-4">
                        <img src="{{ asset($jp_obj['sc_o_logo']) }}" style="width:100%; " alt="">
                    </div>
                    <div class="col-8">
                        <div id="name">
                            <h2 class="quickFade delayTwo " style="font-size:30px;">
                                {{$jp_obj['sc_o_name']}}
                            </h2>
                            <hr style="width:100%;">
                            <i class="fa fa-envelope-o ml-1 mr-2 " aria-hidden="true"></i> <a
                                href="mailto:{{$jp_obj['sc_email']}}" target="_blank">
                                {{$jp_obj['sc_email']}}</a></br>
                            <i class="fa fa-calendar ml-1 mr-2" aria-hidden="true"></i> <a
                                href="{{$jp_obj['sc_end_date']}} " target="_blank">
                                {{$jp_obj['sc_end_date']}}</a></br>

                            <i class="fa fa-map-marker ml-1 mr-2" aria-hidden="true"></i> {{$jp_obj['sc_loc']}}</br>
                            <a href="#"> Download Proposal <i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h1 style="font-size:1.2em;"><b>Decription of the Fellowship</b></h1>

                        <!-- <div class="sectionContent" style="font-size:15px;"> -->
                        <p style="line-height: 1.5rem;text-align: justify;"> {{$jp_obj['sc_desc']}}</p>
                        <!-- </div> -->
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

@endsection
