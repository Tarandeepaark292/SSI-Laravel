@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Organisation Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Scholarship List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>Scholarship List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Scholarship Title</th>
                                <th>Email</th>
                                <th>Organization Name</th>
                                <th>Validity Date</th>
                                <th>Submitted By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($sclist)
                            <tfoot>
                                <tr>
                                    <th>Scholarship Title</th>
                                    <th>Email</th>
                                    <th>Organization Name</th>
                                    <th>Validity Date</th>
                                    <th>Submitted By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($sclist as $noti)
                                    <tr>
                                        <td>{{ $noti['sc_title'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['sc_email'] }}</td>
                                        <td style="word-break: break-all;">
                                            {{ $noti['sc_o_name'] }}</td>
                                        <td>{{ $noti['sc_end_date'] }}</td>
                                        <td>{{ $noti['sc_submitted_by'] }}</td>
                                        <td>{{ $noti['sc_status'] }}</td>
                                        {{-- <td>
                                            <button class="btn btn-outline-secondary">Details</button>
                                            
                                        </td> --}}
                                        <td>
                                            @if($noti['sc_approved'] == '1')
                                            <a href="{{url('/scholarship')}}/{{$noti['sc_SEO']}}" target="_blank" class = "btn btn-outline-secondary">Live URL</a>
                                            @else
                                            <!-- <button class="btn btn-outline-secondary">Preview</button> -->
                                            <a href="{{url('/preview/sc')}}/{{$noti['sc_enc_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                            @endif
                                        </td>
                                        {{-- <td>
                                            @if($noti['fell_approved'] == '1')
                                            <span>Put on Hold</span>
                                            @else
                                            <span>Approve</span>
                                            @endif
                                        </td> --}}
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();

</script> 
@endsection
