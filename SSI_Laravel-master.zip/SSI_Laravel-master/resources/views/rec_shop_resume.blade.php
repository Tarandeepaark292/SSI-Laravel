@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h2 class="mt-4">Pick Resumes</h2>
        {{-- <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organizer Panel</li>
            <li class="breadcrumb-item active">Services</li>
        </ol> --}}
        

        <div class="row" style="margin-top: 2rem;margin-bottom: 2rem;justify-content: center;">
            <div class="col-md-8">
                <select name="job_type" id="cat" class="form-cntrl " onchange="myfunction(event)"
                        style="width:100%;">
                        <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                        <option>Administration, HR, Management, Accounting/Finance Executive</option>
                        <option>Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                        <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                        <option>Capacity Building, Training, Advocacy</option>
                        <option>Communications, IT, Media, Knowledge Management, Editor</option>
                        <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                        <option>Disaster, Aid, Emergencies, Relief</option>
                        <option>Environment, Climate, Energy, Water, Sanitation</option>
                        <option>Fund-raising Business Development, Grants Writer</option>
                        <option>Field Officers, Field Associates</option>
                        <option>Government / Governance, Reforms, Corruption</option>
                        <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                        <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                        <option>Infrastructure, Technology, Engineering, Science</option>
                        <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                        <option>Private Sector, Corporate Social Responsibility</option>
                        <option>Project Associate, Project leaders, Project Assistant</option>
                        <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                        <option>Research Analysts, Research Associate, Research Assistant</option>
                        <option>Social, Gender, Education, Youth, Child</option>
                        <option>Trade, Finance, Economics, Cooperation, Global</option>
                        <option>Technology Associate, Technical Assistant, </option>
                        <option>Teachers, Teachers Educators, Principal</option>
                    </select>
            </div>
        </div>

        <div class="row" style="margin-top: 2rem;" id="search_results">
            @foreach ($results as $noti)
            <div class="col-md-3" style="margin-top:1rem;" >
                <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;height: 471px;">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            @if(isset($noti['js_photo']))
                            <img src="{{asset($noti['js_photo'])}}" style="width: 275px;
                            height: 286px;" />
                            @else
                            <img src="{{asset('img/profile-avatar.png')}}"  style="width: 275px;
                            height: 286px;"/>
                            @endif
                        </div>
                        <div class="col-md-12">
                            <h5 style="text-align: center; "><b>{{$noti['js_name']}}</b></h5>
                            <h6 style="text-align: center;">{{$noti['js_p_title']}}</h6>
                            <span style="font-size: 14px;display: block;text-align: center;">{{$noti['js_area_expertise']}}</span>
                            <div style="display: flex;justify-content: center;">
                                <a href="#" onclick="addResumeTocart(14,{{$noti['js_id']}})" class="btn btn-info" style="text-align: center;">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>



    </div>
</main> 
<script>
    function myfunction(e) {

        e.preventDefault();
        console.log($('#cat').val());
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxfilterjobseeker.post') }}",
            data: {
                
                cate: $('#cat').val()
            },
            success: function (data) {
                if (data.res == 'SUCCESS') {
                    // alert(data.data);
                    d = data.data;
                    // d = JSON.stringify(d);
                    console.log(d);
                    // alert(d);
                    $('#search_results').html(d);
                } else {
                    $('#search_results').html(data.error);
                    // alert(data.error)
                }
            }
        });
    }

</script>
@endsection
