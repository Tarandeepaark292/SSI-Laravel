@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">DashBoard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>

            <div class="custom-container">
                <div class="box">
                    <h2>01</h2>
                    <h3>News</h3>
                    <p>
                        News : {{$dashObj['totalnews']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post_news')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create News</a></li>
                            <li><a href="{{url('/admin/news_list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> News List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>02</h2>
                    <h3>Donations</h3>
                    <p>
                        Donations : {{$dashObj['totaldonate']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-donate')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Donation</a></li>
                            <li><a href="{{url('/admin/donation_list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Donation List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>03</h2>
                    <h3>FC Grants</h3>
                    <p>
                        Total FC Grant : {{$dashObj['totalrfps']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-fc')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create FC Grant</a></li>
                            <li><a href="{{url('/admin/rfp-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> FC Grant List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>04</h2>
                    <h3>CSRs</h3>
                    <p>
                        Total CSR  : {{$dashObj['totalcsr']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-csr')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create CSR</a></li>
                            <li><a href="{{url('/admin/csr-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> CSR List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>05</h2>
                    <h3>Fellowships</h3>
                    <p>
                        Total Fellowships : {{$dashObj['totalfells']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-fellowship')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Fellowship</a></li>
                            <li><a href="{{url('/admin/fell-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Fellowship List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>06</h2>
                    <h3>Scholarships</h3>
                    <p>
                        Total Scholarships : {{$dashObj['totalscholarships']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-scholarship')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Scholarship</a></li>
                            <li><a href="{{url('/admin/sch-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Scholarship List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>07</h2>
                    <h3>Grants</h3>
                    <p>
                        Total Grants : {{$dashObj['totalgrants']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="#"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Grant</a></li>
                            <li><a href="{{url('/admin/reg-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Grant List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>08</h2>
                    <h3>Events</h3>
                    <p>
                        Total Events : {{$dashObj['totalevts']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-events')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Event</a></li>
                            <li><a href="{{url('/admin/event-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Event List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>09</h2>
                    <h3>Awards</h3>
                    <p>
                        Total Awards : {{$dashObj['totalawards']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-award')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Award</a></li>
                            <li><a href="{{url('/admin/award-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Award List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>10</h2>
                    <h3>Job Posts</h3>
                    <p>
                        Total Job Post : {{$dashObj['totaljps']}} 
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-jobpost')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Job Post</a></li>
                            <li><a href="{{url('/admin/job-post-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Job Post List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>11</h2>
                    <h3>Publications</h3>
                    <p>
                        Total Publications : {{$dashObj['totalpublications']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-publication')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Publication</a></li>
                            <li><a href="{{url('/admin/pub-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Publication List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>12</h2>
                    <h3>Online Courses</h3>
                    <p>
                        Total Courses : {{$dashObj['totalcourses']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-onlinecourse')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Course</a></li>
                            <li><a href="{{url('/admin/online-list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Course List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>13</h2>
                    <h3>Admissions</h3>
                    <p>
                        Total Admissions : {{$dashObj['totaladmissions']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-admission')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Admission</a></li>
                            <li><a href="{{url('/admin/adm_admission_list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Admission List</a></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="box">
                    <h2>14</h2>
                    <h3>Papers</h3>
                    <p>
                        Total Papers : {{$dashObj['totalpapers']}}
                    </p>
                    <div class="">
                        <ul class="btngps">
                            <li><a href="{{url('/admin/post-callpaper')}}"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Paper</a></li>
                            <li><a href="{{url('/admin/adm_call_list')}}"><i class="fa fa-th-list" aria-hidden="true"></i> Paper List</a></li>
                        </ul>
                        
                    </div>
                </div>
            </div>

            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-header"> News </div>
                        <div class="card-body">News : {{$dashObj['totalnews']}}<br>
                            <div><a href="{{url('/admin/post_news')}}" class="btn-sm btn-light"> Create News </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white" href="{{url('/admin/news_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-header"> Donations </div>
                        <div class="card-body">Donations : {{$dashObj['totaldonate']}}<br>
                            <div><a href="{{url('/admin/post-donate')}}" class="btn-sm btn-light"> Create Donation </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/donation_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div> --}}

            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> RFPs </div>
                        <div class="card-body">Total RFPs : {{$dashObj['totalrfps']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/rfp-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> CSRs </div>
                        <div class="card-body">Total CSR  : {{$dashObj['totalcsr']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/csr-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Fellowships </div>
                        <div class="card-body">Total Fellowships : {{$dashObj['totalfells']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/fell-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Scholarships </div>
                        <div class="card-body">Total Scholarships : {{$dashObj['totalscholarships']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/sch-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div> --}}

            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Grants </div>
                        <div class="card-body">Total Grants : {{$dashObj['totalgrants']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/reg-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Events </div>
                        <div class="card-body">Total Events : {{$dashObj['totalevts']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/event-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Awards </div>
                        <div class="card-body">Total Awards : {{$dashObj['totalawards']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/award-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Job Posts </div>
                        <div class="card-body">Total Job Post : {{$dashObj['totaljps']}} </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="{{url('/admin/job-post-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div> --}}

            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Publications </div>
                        <div class="card-body">Total Publications : {{$dashObj['totalpublications']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/pub-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Online Courses </div>
                        <div class="card-body">Total Courses : {{$dashObj['totalcourses']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/online-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Admissions </div>
                        <div class="card-body">Total Admissions : {{$dashObj['totaladmissions']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/adm_admission_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Papers </div>
                        <div class="card-body">Total Papers : {{$dashObj['totalpapers']}}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/adm_call_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div> --}}




        </div>


    </section>
</main>


@endsection
