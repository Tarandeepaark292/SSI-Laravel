{{-- @extends('layouts.home')
@section('content') --}}

@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">

<div id="notfounds">
		<div class="notfounds">
			<div class="notfound-404s" >


				<h1 style="color:#0b6bd3;">Thank You</h1>

			</div>
@if(isset($msg))
			<h2>{{ $msg }}</h2>
@else
			<h2>YOUR REQUEST IS SUCCESSFULLY SUBMITTED</h2>
@endif
	<a style="font-size:30px;" href="{{ url('/') }}"><span class="arrows"
			style="height:16px;width:16px;"></span>Return To Homepage</a>
	</div>
</div>

	</div>
</main>
@endsection
