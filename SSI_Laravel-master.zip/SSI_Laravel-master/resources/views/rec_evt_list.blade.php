@extends('layouts.rec_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Organisation Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Organisation Panel</li>
            <li class="breadcrumb-item active">Event List</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>CSR List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Event title</th>
                                <th>Email</th>
                                <th>Organization name</th>
                                <th>Create Date</th>
                                <th>Submitted By</th>
                                <th>Status</th>
                                {{-- <th></th> --}}
                                <th></th>
                            </tr>
                        </thead>
                        @isset($evtlist)
                            <tfoot>
                                <tr>
                                    <th>Event title</th>
                                    <th>Email</th>
                                    <th>Organization name</th>
                                    <th>Create Date</th>
                                    <th>Submitted By</th>
                                    <th>Status</th>
                                    {{-- <th></th> --}}
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @foreach($evtlist as $noti)
                                    <tr>
                                        <td>{{ $noti['evt_title'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['evt_email'] }}</td>
                                <td style="word-break: break-all;">
                                    {{ $noti['evt_org_name'] }}</td>
                                <td>{{ $noti['evt_end_date'] }}</td>
                                <td>{{ $noti['evt_submitted_by'] }}</td>
                                <td>{{ $noti['evt_status'] }}</td>
                                        {{-- <td>
                                            <button class="btn btn-outline-secondary">Details</button>
                                            
                                        </td> --}}
                                        <td>
                                            @if($noti['evt_approved'] == '1')
                                            <a href="{{url('/evt')}}/{{$noti['evt_SEO']}}" target="_blank" class = "btn btn-outline-secondary">Live URL</a>
                                            @else
                                        <a href="{{url('/preview/evt')}}/{{$noti['evt_enc_id']}}" target="_blank" class = "btn btn-outline-secondary">Preview</a>
                                            @endif
                                        </td>
                                        {{-- <td>
                                            @if($noti['evt_approved'] == '1')
                                            <span>Put on Hold</span>
                                            @else
                                            <span>Approve</span>
                                            @endif
                                        </td> --}}
                                    </tr>
                                @endforeach
                            </tbody>
                </div>
                @endisset
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();

</script> 
@endsection
