@extends('layouts.home')
@section('content')
<style>
    .razorpay-payment-button{
        background: #ef3789!important;
        width: 100%;
        color: white;
        border-radius: 3px;
        font-size: 14px;
        height: 36px;
    }
</style>
<div class="container" style="margin-top: 100px ;padding:100px;">
    <div class="row">
        <div class="col-md-12">



            <div class="card" style="background-color:#B1B3B3FF;">
                <div class="card-body">
                    <form action="{{url('/confirm')}}" method="POST">
                        @csrf
                        <script
                            src="https://checkout.razorpay.com/v1/checkout.js"
                            data-key="{{$data['key']}}"
                            data-amount="{{$data['amount']}}"
                            data-currency="INR"
                            data-name="{{$data['name']}}"
                            data-image="{{$data['image']}}"
                            data-description="{{$data['description']}}"
                            data-prefill.name="{{$data['prefill']['name']}}"
                            data-prefill.email="{{$data['prefill']['email']}}"
                            data-prefill.contact="{{$data['prefill']['contact']}}"
                            data-notes.shopping_order_id="{{$data['shopping_order_id']}}"
                            data-order_id="{{$data['order_id']}}"
                            
                        >
                        </script>
                        <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
                        <input type="hidden" name="shopping_order_id" value="{{$data['shopping_order_id']}}">
                        <span class="paypal-button-text">Powered by <b>RAZORPAY</b></span>
                        </form>

                </div>
            </div>
        </div>
    </div>
</div>

@endsection