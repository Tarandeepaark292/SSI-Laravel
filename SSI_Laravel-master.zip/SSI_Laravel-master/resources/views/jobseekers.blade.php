@extends('layouts.home')
@section('content')
        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:1rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h2>How It <span style="font-weight: bold;">Works</span></h2>
                </header>
                <div class="row" style="text-align: center;font-variant-caps: petite-caps;font-size: 20px;letter-spacing: 2px;">
                    <div class="col-12">
                        Have an account? <br />
                        <a href="#" style="font-weight: bold;">Sign In</a> or If you don’t have an account <a href="#" style="font-weight: bold;">Sign Up</a> by entering your email address. Your account details<br />
                        will be confirmed via email
                    </div>
                </div>
                <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12" style="text-align: center;">
                        <img src="{{ asset('img/job-seeker2.png')}}" class="img-fluid" style="width: 80%;padding-bottom: 1rem;" />
                    </div>
                </div>

                <div class="row">
                    <div class="col-12" style="margin-top: 2rem;">
                        <h2 style="letter-spacing: 2px;">ADD <span style="font-weight: bold;">DETAILS</span></h2>
                    </div>
                </div>
                <div class="row" style="border-bottom: 3px solid #444;">
                    <div class="col-12" style="margin: 0rem 0rem 2rem 0rem;">
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Your Name</label>
                                <input type="text" name="name" class="form-cntrl" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Your Email</label>
                                <input type="email" class="form-cntrl" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                                <div class="validate"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Professional Title</label>
                                <input type="text" name="name" class="form-cntrl" id="name" placeholder="Professional Title" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validate"></div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Resume File</label>
                                <input type="file" class="form-cntrl-file" id="exampleFormControlFile1">
                                <small>Max. file size: 8 MB</small>
                            </div>
                            <!--
            <div class="form-group col-lg-6">
              <label for="name">Location</label>
              <input type="email" class="form-cntrl" name="email" id="email" placeholder="Location" data-rule="email" data-msg="Please enter a valid email" />
              <div class="validate"></div>
            </div>
            -->
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label for="name">Area of Expertise</label>
                                <!--<input type="text" name="name" class="form-cntrl" id="name" placeholder="Choose a category… E.g Spotlight, Administration or Research" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />-->
                                <select class="form-cntrl">
                                    <option value="-1">Choose a category… E.g Spotlight, Administration or Research</option>
                                    <option>Administration, HR, Management, Accounting/Finance Executive</option>
                                    <option>Agriculture, Livelihoods, Micro finance, Rural, Urban</option>
                                    <option>Auditing, Taxation, Financial accounting/Operations, Payroll officer</option>
                                    <option>Capacity Building, Training, Advocacy</option>
                                    <option>Communications, IT, Media, Knowledge Management, Editor</option>
                                    <option>Chairman, President, CEO, Director, Project Director, Deputy Director </option>
                                    <option>Disaster, Aid, Emergencies, Relief</option>
                                    <option>Environment, Climate, Energy, Water, Sanitation</option>
                                    <option>Fund-raising Business Development, Grants Writer</option>
                                    <option>Field Officers, Field Associates</option>
                                    <option>Government / Governance, Reforms, Corruption</option>
                                    <option>Health, Doctors, Nurses, HIV / AIDS, Nutrition</option>
                                    <option>Human Rights, Law, Migration, Conflicts, Justice</option>
                                    <option>Infrastructure, Technology, Engineering, Science</option>
                                    <option>Consultant, Monitoring, Evaluation, Policy, Research</option>
                                    <option>Private Sector, Corporate Social Responsibility</option>
                                    <option>Project Associate, Project leaders, Project Assistant</option>
                                    <option>Program Manager, Program Officer, Program Associate, Program Assistant</option>
                                    <option>Research Analysts, Research Associate, Research Assistant</option>
                                    <option>Social, Gender, Education, Youth, Child</option>
                                    <option>Trade, Finance, Economics, Cooperation, Global</option>
                                    <option>Technology Associate, Technical Assistant, </option>
                                    <option>Teachers, Teachers Educators, Principal</option>
                                </select>
                                <div class="validate"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <h3>Location</h3>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Address Line 1</label>
                                <input type="text" class="form-cntrl" name="email" id="email" placeholder="Address Line 1" data-rule="email" data-msg="Please enter a valid Address Line 1" />
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Address Line 2</label>
                                <input type="text" class="form-cntrl" name="email" id="email" placeholder="Address Line 2(Optional)" data-rule="email" data-msg="Please enter a valid Address Line 2" />
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-4">
                                <label for="name">City</label>
                                <input type="text" class="form-cntrl" name="email" id="email" placeholder="City" data-rule="email" data-msg="Please enter a valid City" />
                            </div>
                            <div class="form-group col-lg-4">
                                <label for="name">State</label>
                                <select class="form-cntrl">
                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chandigarh">Chandigarh</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                    <option value="Daman and Diu">Daman and Diu</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Puducherry">Puducherry</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Karnataka">Karnataka</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Telangana">Telangana</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="West Bengal">West Bengal</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-4">
                                <label for="name">Zip</label>
                                <input type="text" class="form-cntrl" name="email" id="email" placeholder="Zip" data-rule="email" data-msg="Please enter a Zip Code" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12" style="margin-top: 2rem;">
                        <h2 style="letter-spacing: 2px;"><span style="font-weight: bold;">OPTIONAL</span> FIELDS</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12" style="margin: 0rem 0rem 2rem 0rem;">
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label for="name">Photo</label>
                                <input type="file" class="form-cntrl-file" id="exampleFormControlFile1">
                                <small>Max. file size: 8 MB</small>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Resume File</label>
                                <input type="file" class="form-cntrl-file" id="exampleFormControlFile1">
                                <small>Optionally upload your resume for employers to view without your mobile number and address. Max. file size: 8 MB</small>
                            </div>
                        </div>
                        <div class="form-row">

                            <div class="form-group col-lg-6">
                                <label for="name">Video</label>
                                <input type="text" name="name" class="form-cntrl" id="name" placeholder="A link to video about yourself" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="name">Skills</label>
                                <input type="text" name="name" class="form-cntrl" id="name" placeholder="Comma seperate a list of relevent skills" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-4">
                                <label for="name" style="display: block;">URL(s)</label>
                                <button style="width:100%" class="btn btn-outline-primary btn-sm"> + Add URL </button>
                                <div></div>
                            </div>
                            <div class="form-group col-lg-4">
                                <label for="name" style="display: block;text-align: center;">Education</label>
                                <button style="width:100%" class="btn btn-outline-primary btn-sm"> + Add Education </button>
                                <div></div>
                            </div>
                            <div class="form-group col-lg-4">
                                <label for="name" style="display: block;text-align:right;">Experience</label>
                                <button style="width:100%" class="btn btn-outline-primary btn-sm"> + Add Experience </button>
                                <div></div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row" style="text-align: right;">
                    <div class="col-lg-6 ml-auto">
                        <button class="btn btn-secondary" style="width:40%">Preview</button>
                        <button class="btn btn-primary" style="width:40%">Submit</button>
                    </div>
                </div>
            </div>
        </section>
        @endsection
