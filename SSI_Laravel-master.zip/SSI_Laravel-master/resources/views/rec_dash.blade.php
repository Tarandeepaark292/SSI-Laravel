@extends('layouts.rec_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">DashBoard</h1>
            {{-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Organization Panel</li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> --}}

            <div class="row justify-content-center" style="margin-top:2rem;">
                <div class="col-md-3" style="padding: 0;">
                    <div class="card" style="border:0;text-align: center;border-radius: 6px;border: 1px solid #eceef3; padding: 1em;height:341px;">
                        @if(isset($rec_obj['r_org_logo']))
                        <img src="{{asset($rec_obj['r_org_logo'])}}" style="height: 200px;width: 200px;margin: 0 auto;border: 10px solid #eee;border-radius: 5px;"/>
                        @else
                        <img src="{{asset('img/organization_profile.png')}}" style="height: 200px;width: 200px;margin: 0 auto;border: 10px solid #eee;border-radius: 5px;"/>
                        @endif

                        <h4 class="mb-1 mt-1" style="font-weight: 700;">{{session()->get('ssiapp_rec_name')}}</h4>
                        <span class="text-info">{{$rec_obj['r_org_name']}} ( {{$rec_obj['r_email']}})</span>
                        <div style="margin-top:.75rem;"><a href="{{url('/recruiter/profile')}}" style="color:#17a2b8 !important;font-weight:bold;margin-top:.5rem"><i class="fas fa-user-edit" style="margin-right:.1rem;"></i> Edit Profile</a></div>

                    </div>
                    <div class="tr-single-box" style="margin-top: 2rem;">
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Organization Detail</h4>
                        </div>
                        
                        <div class="tr-single-body" style="height: 390px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Company Type</strong>
                                            {{$rec_obj['r_comp_type']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-at"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Organization Email</strong>
                                            {{$rec_obj['r_email']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-globe"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Website</strong>
                                            {{$rec_obj['r_off_website']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-phone"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Phone</strong>
                                            {{$rec_obj['r_phone']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-desktop"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Organization Pan</strong>
                                            {{$rec_obj['r_org_pan']}}
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Jobs </h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Jobs </strong>
                                            {{$dashObj['totaljps']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/job-post-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-job-post')}}"> Post Job</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Scholarships</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Scholarships</strong>
                                            {{$dashObj['totalscholarships']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/sc-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post_scholarship')}}"> Post Scholarship</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Events</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Events</strong>
                                            {{$dashObj['totalevts']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/event-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-event')}}"> Post Event</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Call for Papers</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Papers</strong>
                                            {{$dashObj['totalpapers']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/call-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-callpaper')}}"> Post Call for Paper</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> CSRs</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total CSRs</strong>
                                            {{$dashObj['totalcsr']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/csr-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-csr')}}"> Post CSR</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Fellowship</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Fellowships</strong>
                                            {{$dashObj['totalfells']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/fell-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-fellowship')}}"> Post Fellowship</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>


                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Admissions</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Admissions</strong>
                                            {{$dashObj['totaladmissions']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/admission-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-admission')}}"> Post Admission</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Publications</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Publications</strong>
                                            {{$dashObj['totalpublications']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/pub-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-publication')}}"> Post Publication</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> FC Grants</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total FC Grants</strong>
                                            {{$dashObj['totalrfps']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/rfp-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-rfp')}}"> Post FC Grant</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Awards</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Awards</strong>
                                            {{$dashObj['totalawards']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/award-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post_award')}}"> Post Award</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Online Courses</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Courses</strong>
                                            {{$dashObj['totalcourses']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/onlinecourse-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-online-course')}}"> Post Course</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tr-single-box" >
                        <div class="tr-single-header">
                            <h4><i class="fas fa-desktop"></i> Register for GRANTs</h4>
                        </div>
                        <div class="tr-single-body" style="height: 250px;overflow: auto;">
                            <ul class="extra-service" style="list-style: none;padding: 0;">
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="far fa-building"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Total Register for GRANTs</strong>
                                            {{$dashObj['totalgrants']}}
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-asterisk"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem" href="{{url('/recruiter/reg-list')}}">View Details</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="pb-4">
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block"><a class="text-black " style="color:#17a2b8 !important;font-size: 1rem"  href="{{url('/recruiter/post-grant')}}"> Post Grant</a></strong>
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            


            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-header"> News </div>
                        <div class="card-body">News : {{$dashObj['totalnews']}}<br>
                            <div><a href="{{url('/admin/post_news')}}" class="btn-sm btn-light"> Create News </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white" href="{{url('/admin/news_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-header"> Donations </div>
                        <div class="card-body">Donations : {{$dashObj['totaldonate']}}<br>
                            <div><a href="{{url('/admin/post-donate')}}" class="btn-sm btn-light"> Create Donation </a></div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/admin/donation_list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div> --}}

            {{-- <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> RFPs </div>
                        <div class="card-body">Total RFPs : {{$dashObj['totalrfps']}}<br/>
                            <a class="small text-white " href="{{url('/recruiter/post-rfp')}}"> Post Rfp</a>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/rfp-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> CSRs </div>
                        <div class="card-body">Total CSR  : {{$dashObj['totalcsr']}}<br/>
                            <a class="small text-white " href="{{url('/recruiter/post-csr')}}"> Post CSR</a>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/csr-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Fellowships </div>
                        <div class="card-body">Total Fellowships : {{$dashObj['totalfells']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-fellowship')}}"> Post Fellowship</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/fell-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Scholarships </div>
                        <div class="card-body">Total Scholarships : {{$dashObj['totalscholarships']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post_scholarship')}}"> Post Scholarship</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/sc-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Grants </div>
                        <div class="card-body">Total Grants : {{$dashObj['totalgrants']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-grant')}}"> Post Grant</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/reg-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Events </div>
                        <div class="card-body">Total Events : {{$dashObj['totalevts']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-event')}}"> Post Event</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/event-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Awards </div>
                        <div class="card-body">Total Awards : {{$dashObj['totalawards']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post_award')}}"> Post Award</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/award-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Job Posts </div>
                        <div class="card-body">Total Job Post : {{$dashObj['totaljps']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-job-post')}}"> Post Job</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/job-post-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Publications </div>
                        <div class="card-body">Total Publications : {{$dashObj['totalpublications']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-publication')}}"> Post Publication</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/pub-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Online Courses </div>
                        <div class="card-body">Total Courses : {{$dashObj['totalcourses']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-online-course')}}"> Post Course</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/onlinecourse-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Admissions </div>
                        <div class="card-body">Total Admissions : {{$dashObj['totaladmissions']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-admission')}}"> Post Admission</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="{{url('/recruiter/admission-list')}}">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-3">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-header"> Papers </div>
                        <div class="card-body">Total Papers : {{$dashObj['totalpapers']}} <br/>
                            <a class="small text-white " href="{{url('/recruiter/post-callpaper')}}"> Post Paper</a></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white " href="#">View Details</a>
                            <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> --></div>
                        </div>
                    </div>
                </div> --}}
            </div>




        </div>


    </section>
</main>


@endsection
