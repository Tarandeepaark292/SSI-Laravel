@extends('layouts.js_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container">
            <h1 class="mt-4">Received Messages</h1>

            <section>
                <div class="container" style="margin-bottom: 5rem;">
                    <div class="row">
                        <div class="col-12 " style="border: 0;">
                            <div class="tr-single-box">
                                <div class="tr-single-header">
                                    {{-- <h4 class="mt-4"><i class="fas fa-check"></i> Short List</h4> --}}
                                </div>
                                <div class="tr-single-body">
                                    @if(count($msgs) > 0)
                                    @foreach($msgs as $noti)
                                    <div class="manage-list">
											
                                        <div class="mg-list-wrap">
                                            <div class="mg-list-thumb">
                                                <img src="{{asset('img/icons/msg-icon.png')}}" class="mx-auto" alt="">
                                            </div>
                                            <div class="mg-list-caption">
                                                <h4 class="mg-title">{{$noti['org_name']}}</h4>
                                                <span class="mg-subtitle">{{$noti['msg_data']}}</span>
                                                <span><em>Date</em> <b>{{$noti['msg_date']}}</b> </span>
                                                
                                            </div>
                                        </div>
                                        
                                        {{-- <div class="mg-action">
                                            <div class="btn-group ml-2">
                                                <a href="{{url('/job-post')}}/{{$noti['jp_SEO']}}" class="btn btn-view" data-toggle="tooltip" data-placement="top" title="View Job"><i class="fas fa-eye"></i></a>
                                            </div>
                                            <div class="btn-group ml-2">
                                                <a href="#" onclick="apply({{$noti['jp_id']}},{{$noti['jp_submitted_by']}})" class="btn btn-dark" data-toggle="tooltip" data-placement="top" title="Apply for Job">Apply</a>
                                            </div>
                                        </div> --}}
                                        
                                    </div>
                                    @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</main>

@endsection