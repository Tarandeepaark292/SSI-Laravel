@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' => $seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

        <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Tax</span> <span class="titleheading">Compliance</span> </h3>
                </header>
                <div>
                    <div class="col-lg-12">
                        <h6 style="font-weight:600;text-align: center;">We are expertise in handling of NGO's,Voluntary
                            Organisation,NPO's,Charitable and Education Institution.</h6>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 content order-lg-1 order-1">

                        <b>Our Tax Compliance service include. </b>
                        <ol style="padding: 1em;">
                            <li>Preparation, review and filing of quarterly TDS and GST returns.</li>
                            <li>Monthly filing of Professional Tax, Provident Fund and Filing of Income tax e-returns.
                            </li>
                            <li>Withholding Tax (TDS) compliance services</li>
                            <li>Appearance before Income Tax authorities.</li>
                            <li>Representation before judicial authorities in assessments and appeals.</li>
                            <li>Assistance in preparing submissions.</li>
                            <li>Candidate receives email notifications for each job posted in their preferred field
                                (This is chosen in “Areas of Expertise”)</li>
                            <li>Assistance in availing exemption certificates and approvals.</li>
                        </ol>
                    </div>
                    <div class="col-6 content order-lg-2 order-2">

                        <b>Personal Taxation Services</b><br />
                        <b>Compliance review for matters arising out of the following Indian laws:</b>
                        <ol style="padding: 1em;">
                            <li>Taxation planning advisory services with a Chartered Accountant in person</li>
                            <li>Tax saving recommendations and identifying potential mistakes.</li>
                            <li>Complete review of your bank statements, income and assets by a team of CAs.</li>
                            <li>Assistance with paying your taxes due online by our team of CAs</li>
                            <li>Filing of Income tax returns for Individual and Organisations.</li>
                            <li>Support on Income tax, such as tracking refunds, respond to income tax notices, filing
                                revised return and any other matter arising.</li>
                        </ol>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">

                        <hr style="color:#007bff;border:3px solid;">
                        <p style="margin-top: 30px; font-size: 1rem;">
                            For any further assistance our experts will get in touch with you and take it forward.
                            <br /><br />
                            Please email us at: <b>Team@SocialServicesIndia.org</b> with subject of the e-mail
                            <b>“Accounting”</b>
                        </p>
                    </div>
                </div>
            </div>
        </section>

   @endsection