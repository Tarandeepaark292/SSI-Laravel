@extends('layouts.home')
@section('content')

      <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">Bulk</span> <span class="titleheading">Job</span> <span class="titleheading">Posting</span></h3>
                </header>
                <div class="row">
                <div class="col-12">
                        <h4>Do you hire throughout the year? Create an account to start bulk posting <a href="#">here</a> and choose from below services.</h4>

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;">Jobs get posted immediately in <span class="imp">“Spotlight Section”</span> for greater visibility and access across India.</span>

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;">Stays at our homepage for 1 month or until the date of close of application as mentioned under section (apply by) for maximum visibility and targeted responses.</span>

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;">Buy a 15 <span class="imp">“Spotlight Jobs”</span> bulk package. There is no expiration date – buy a new package only when all the jobs are used up.</span>

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;">15 “Spotlight Jobs” – Rs 12,999 <a href="#">(Job Ad)</a>
                            @if(session()->has('ssiapp_rec'))
                            <a href="#" onclick="addTocart(7)">(Add To Cart)</a>
                            @endif 
                        </span> 

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;">Once the 15 “Spotlight Jobs” bulk package payment is done, please email us at: contact@SocialServicesIndia.com</span>

                        <span style="display: block;font-size: 16px;margin-top: 1.2rem;margin-bottom: 2rem;">Also to see all bulk jobs packages, please click here.</span>

                        <h4>Purchase professional resume credits</h4>
                        <ul>
                            <li><a href="#">35 Resumes access: Rs 5,000</a> 
                                @if(session()->has('ssiapp_rec'))
                                <a href="#" onclick="addTocart(8)">(Add To Cart)</a>
                                @endif
                            </li>
                            <li><a href="#">50 Resumes access: Rs 6,000</a>
                                @if(session()->has('ssiapp_rec'))
                                <a href="#" onclick="addTocart(9)">(Add To Cart)</a>
                                @endif 
                            </li>
                            <li><a href="#">85 Resumes access: Rs 10,000</a>
                                @if(session()->has('ssiapp_rec'))
                                <a href="#" onclick="addTocart(10)">(Add To Cart)</a>
                                @endif 
                            </li>
                        </ul>

                        
                    </div>
                </div>
                <div class="row about-container">
                    <div class="col-lg-12">

                        <hr style="color:#007bff;border:3px solid;">
                        
                        <p style="margin-top: 30px; font-size: 1rem;">
                        <span style="display: block;font-size: 16px;">
                            To see all available resume credit packages, please <b>click here</b>.<br/>
                            Queries: Please email us at: <b>contact@SocialServicesIndia.com</b>
                        </span>
                        </p>
                    </div>

                </div>
            </div>
        </section>
        @endsection
