@extends('layouts.home',['title' => $seodata['seotitle'],'metadescription' => $seodata['seodesc'],'metaimg' =>
$seodata['seoimg'],'seokeywords' => $seodata['seokeywords']])
@section('content')

<section id="FAQ" style="">
    {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
    </div> --}}
    <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
        <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
            <h3><span class="titleheading">Frequently</span> <span class="titleheading">Asked</span> <span
                    class="titleheading">Questions</span></h3>
        </header>

        <h3 class="ml-3 mt-4 mb-1"><span ><b>Register For Grant -Frequently Asked Questions</b></span></h3>
        <div class="accordion">
            <div class="accordion-item">
                <span class="link_anchor"><b>REGISTER YOUR ORGINISATION FOR UPDATES, CALL/REQUEST FOR PROPOSALS, CSR AND
                        OTHER GOVERNMENT GRANTS:</b></span>
                <div class="content">
                    <p>
                        Quick updates and advantages of registering your organisation for grants with “Social Services
                        India”<br>
                        Registered Organisation will receive email notification on every proposal updated on our website
                        by funding agency
                        including CSR funding under their selection of “Areas of Expertise”.<br>
                    </p>
                    <ul>
                        <li>We provide newsletter with top funding agency suitable for your organisation.</li>
                        <li>We provide an independent platform and direct link with complete access between the
                            organisation and funding agencies.
                            Hence organisation registration details will help us serve you better.</li>
                        <li>We provide access to donor database.</li>
                        <li>We help the donor agency find their match for funding grants to NGO’s and NPO’s and take it
                            forward from their.</li>
                    </ul>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Other Value added Services:</b></span>
                <div class="content">
                    <ul>
                        <li>The Social Services India team also provides a detailed set of reminders, on prior notice,
                            for filing all your statutory requirements as per the Indian Judiciary requirements for NGOs
                            and NPOs. Tax deducted at Sources (TDS), Goods and Services Tax (GST), Professional Tax
                            (PT), Provident fund (EPF),
                            Intimation of Quarterly Receipt of Foreign Contribution received by organizations, Annual
                            filing of FCRA returns, Closure of Audited accounts,
                            Filing of Income tax return, conduct of Annual general meeting (AGM), Filing with registrar
                            of societies (ROS) and other bodies.</li>
                        <li>Keeping the organization updated with any changes brought in accounting for NGOs, NPOs, and
                            under the Foreign Contribution Regulation Act (FCRA).</li>
                    </ul>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Other FAQ's</b></span>
                <div class="content">
                    <p><b>Will my organization start receiving grants after I sign up with Social Services India
                            Premium?</b><br>
                        When you sign up for Social Services India Premium, you will not be receiving any grants –
                        neither from us nor from any donor agency around the world. The objective of our membership
                        service is to increase the capacity of NGOs to independently raise funds by providing them with
                        a set of relevant skills, knowledge and information.
                        We provide resources so that our members can fundraise more efficiently and save time on
                        research and development.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Validity and Is it necessary to auto-renew the membership?</b></span>
                <div class="content">
                    <p>All registration will be valid for 2 years and there after to renew yearly. Auto-renewal of your
                        Social Services India Premium is completely optional. However, we recommend members to
                        auto-renew their membership as it ensures seamless service. Besides, you will continue to
                        receive loyalty discounts,
                        special offers and same-rate for lifetime if you keep your auto-renewal process on.
                    </p>
                </div>
            </div>

            <h3 class="ml-3 mt-4 mb-1"><span ><b>Job Seekers -Frequently Asked Questions</b></span></h3>
            <div class="accordion-item">
                <span class="link_anchor"><b>What kinds of jobs are listed on SSI website?</b></span>
                <div class="content">
                    <p>
                        SSI is an Independent Platform for all NGOs, Voluntary Organization, NPOs, Charitable and
                        Education Institution. Only Social Services Sector related jobs will be posted on our website.
                        SSI includes full time, part-time, freelance, temporary and Internships opportunities.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I apply for jobs on SSI?</b></span>
                <div class="content">
                    <p>
                        First you need to have an account, you can create one below by entering your email address. Your
                        account details will be confirmed via email. Each employer decides how it wants you to apply for
                        jobs through SSI. Employers can set up the job post to allow you to apply through SSI, or
                        require you to apply directly from the careers page on their websites.
                        Some organizations may request that you e-mail your resume and cover letter instead of applying
                        through SSI or their own system. When this happens, the company’s e-mail address will be
                        provided in the job listing on SSI.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I search for work – full time, part-time, freelance, temporary and
                        Internships requirements?</b></span>
                <div class="content">
                    <p>
                        To search for positions on our site, we recommend using the keyword search, which is available
                        across the top of the site. The keyword search is set to search our database for related jobs
                        with that title or qualification. We do recommend putting in your location with your keyword to
                        ensure you see all positions that can be done locally, nationally, and internationally from your
                        location.
                        Additionally, once a keyword search is run, you will have the option to tailor your search
                        further with location information, job type, flexibility preference, and more

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How can I search by multiple search criteria ? </b></span>
                <div class="content">
                    <p>
                        We recommend using the Advanced Search to search by job types, location, areas of interest,
                        schedules, and more. You can select multiple criteria to find the best jobs to match your skill
                        sets and the type of flexibility you are seeking.

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Are the jobs on SSI legitimate ? </b></span>
                <div class="content">
                    <p>
                        Yes! Our amazing job research team hand-screens every single job and organization added to our
                        site, so you will only find jobs and companies that are legitimate, professional, and offer at
                        least one type of flexibility.
                        We do not post positions that we find questionable or anything from organization that do not
                        meet our criteria for legitimacy. Our purpose is to help job seekers find legitimate flexible
                        jobs and to make the job search experience a better, safer, and faster one. We do the hard work
                        of researching every single position, so that our subscribers can apply without fear of scams,
                        identity theft, fraud, or other issues.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Are there jobs I can do in addition to my full-time position ? </b></span>
                <div class="content">
                    <p>
                        Yes! SSI jobs are ideal for many job seekers who are looking to make additional money while
                        maintaining their full-time position. Jobs that offer part-time schedules or are supplemental
                        income opportunities, or those with flexible schedules, or remote work options can be done
                        around a 40-hour job. SSI does specialize in professional jobs, so many of these positions do
                        still require education or experience to perform them and oftentimes do have time requirements.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Are jobs removed from the SSI database when they are filled ? </b></span>
                <div class="content">
                    <p>
                        We hand-clean our database regularly to keep our listings as current and accurate as possible.
                        We remove filled positions on a daily basis. In the unfortunate case that you ever come across a
                        listing that has a broken link or is closed, please use the “Contact” link at the bottom of the
                        listing and we will research the listing and respond to let you know if the job is expired or if
                        the website was just experiencing issues.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>If I am living abroad, but am a Indian. citizen, can I apply for jobs ?
                    </b></span>
                <div class="content">
                    <p>
                        We frequently hear from Indian citizens who are living abroad who are interested in remote jobs
                        with Indian organization. There are certainly some employers that can hire internationally and
                        even some of the Indian national positions may consider working with a Indian citizen abroad,
                        but it is up to each individual employer to make that decision. Location requirements on remote
                        jobs can vary from employer to employer, as can their flexibility with international hires
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>If I am not a Indian citizen, can I apply for jobs in India ?
                    </b></span>
                <div class="content">
                    <p>
                        If you are not a Indian citizen, but are living in the U.S, U.K, AUS or any other country, or if
                        you are planning to move to the India and are looking for jobs that can sponsor you, it is up to
                        each individual employer on how it handles international candidates. Some employers are more
                        than willing to consider hiring a job candidate who requires a work visa, and others do not have
                        the capacity to hire anyone who is not a Indian citizen. There are also many international
                        companies hiring on SSI.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Why isn’t salary listed on a job posting ?
                    </b></span>
                <div class="content">
                    <p>
                        Unfortunately, nowadays it is increasingly rare to have employers include salary/pay rate
                        information upfront in job postings. And since it is entirely up to each individual employer to
                        decide if it is going to include that information in a job posting, you will only be able to see
                        what employers want to share. It is typical for employers to discuss salary and pay scale during
                        or after the first round of interviews.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Will I need to download any software to use SSI ?
                    </b></span>
                <div class="content">
                    <p>
                        No, SSI does not require any software, other than an Internet browser, to be purchased or
                        downloaded onto your computer to use our service.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Does SSI guarantee that I’ll get hired ?
                    </b></span>
                <div class="content">
                    <p>
                        SSI does not guarantee job placement. While we do the research on all the jobs we publish, the
                        hiring process is all handled by the employer directly. However, SSI does guarantee that you’ll
                        find only hand-screened, professional job leads with no ads, scams, or other junk on our site.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What if my question isn’t answered here ?
                    </b></span>
                <div class="content">
                    <p>
                        Please contact us! We are committed to providing the easiest, fastest way to find reliable
                        flexible jobs and certainly welcome questions to our Client Services department. We’ll always
                        try to help you as best we can! You can get in touch with us via email through <a
                            href="">Contact@SocialServicesIndia.org</a> Monday through Friday from 9:00 a.m. to 6:00
                        p.m. Indian Standard Time.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Can I hide my resume profile, so that my current employer can’t find it ?
                    </b></span>
                <div class="content">
                    <p>
                        Your privacy is very important to us. Once you create and complete a resume profile, your data
                        is secured. To apply for jobs you will need to login to your registered login account and submit
                        your resume.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Do I have to pay to see the full job listings ?
                    </b></span>
                <div class="content">
                    <p>
                        No you don’t have to pay any amount. SSI offers a wide variety of full job listing access. Free
                        visitors to the site can view all current job listings to get an actual sense of what is
                        available.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Is my satisfaction guaranteed ?
                    </b></span>
                <div class="content">
                    <p>
                        Yes! SSI states that if you are not satisfied with the quality of our service for any reason,
                        simply delete your account with us. The bottom line is that we want you to be happy with our
                        service, and we’ll do whatever we can to make that happen.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>I am requesting a password reset and not receiving it. What’s going on ?
                    </b></span>
                <div class="content">
                    <p>
                        If you submit a password reset from the system and you do not receive it, please check your
                        spam/junk folder in your email. Unfortunately, some email providers will block or file those
                        notices automatically. If still not resolved you can write to us @ <a
                            href="">Contact@SocialServicesIndia.org</a> with email of the subject being “Password Reset”
                        and we can manually update your password for you.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What are the advantages of Broadcasting resume ?
                    </b></span>
                <div class="content">
                    <h2>The Advantages of “Broadcasting Resume” @ SSI are as follows.</h2>
                    <p>
                        • Grabs the attention of employers and recruiters. Promotes your strongest skills and
                        accomplishments.
                        • Provides access to your resume to more than 50,000 professional organisations.
                        • Chances of getting hired are much higher compared to other candidates.
                        • Provides an independent platform and direct link with complete access between the candidate
                        and employer.
                        • Provides all details of candidate (Email, contact details etc) with the employers for quick
                        recruitment closure.
                        • List top on our website for 1 month to seek attention of potential employers and recruiters.
                        • Candidate receives email notification on every jobs posted on any their selection on “Areas of
                        Expertise”
                        • We also help employers and experts see your resume first while downloading/purchase resume
                        credits.
                        • Note: We request the candidates to only disclose “E-mail id’s”. Delete mobile numbers and
                        address while uploading or using broadcast resume service.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What
                        are the charges for Broadcasting resume ?
                    </b></span>
                <div class="content">
                    <p>
                        Rs 499/- (Four Hundred and Ninety Nine Only. This Includes all taxes)
                        Can you post and Broadcast my resume on behalf of me?
                        Yes. If you want us to “Broadcast your Resume” please email us all your details at – <a
                            href="">contact@SocialServicesIndia.org</a> . Please mention the “Broadcast resume” in the
                        subject line of your email.
                    </p>
                </div>
            </div>
            
                
            
            <div class="accordion-item">
                <span class="link_anchor"><b>Do I need an objective on my resume ?
                    </b></span>
                <div class="content">
                    <p>
                        It is a good idea to include an objective on your resume so that a potential employer is clear
                        about what you are looking for from the beginning. It’s not required, but an objective is useful
                        for focusing the resume and the reader. Employers often say that they prefer resumes with
                        objectives and they want them to be fairly specific. Not only do they not have time to try to
                        figure out which of their many positions you might fit into; they also prefer to know what you
                        are really interested in.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What’s the difference between a resume and a curriculum vitae ?
                    </b></span>
                <div class="content">
                    <p>
                        A curriculum vitae (CV) is an academic resume and is used for research and college/university
                        teaching positions. A resume is brief – usually one page – and focuses on work experience. A CV
                        can be as long as it takes to state one’s qualifications, publications, papers presented, etc.
                        Sometimes employers ask for a CV when they really want a resume. Be sure to check with the
                        employers requesting it to be certain you are using the correct version for that position.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Can a resume be more than one page ?
                    </b></span>
                <div class="content">
                    <p>
                        Yes, a resume can be more than one page, but it shouldn’t be unless you have extensive
                        experience related to your job objective. Most resumes for college students and recent graduates
                        should fit onto one page if you clearly and concisely describe your experiences.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What’s the best format: chronological or skills/functional ?
                    </b></span>
                <div class="content">
                    <p>
                        There is no “best” format for all resumes–it depends on what you have done and what you are
                        trying to accomplish. Usually, if you are applying to a more conservative industry (e.g.
                        banking) or continuing along a prescribed career path in which you have gained some experience
                        (engineering, for example), you’ll want to use a chronological resume. A skills/functional
                        resume works well if you have little work experience, are entering a career that is very
                        different from your educational path, or are changing careers.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Should I include jobs I’ve had that don’t relate to the job I’m seeking?
                    </b></span>
                <div class="content">
                    <p>
                        Your resume should include sufficient experience to demonstrate your ability to do the job that
                        you are applying for and to show yourself as a person with experience in the working world.
                        Directly related experience is considered most valuable, but unrelated jobs can also help you to
                        show that you have acquired necessary skills.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Should I include my volunteer experience on my resume ?
                    </b></span>
                <div class="content">
                    <p>
                        Yes! Volunteer work allows you to acquire hands on experience and develop skills in the same way
                        that paid positions do. Future employers want to see that you have developed skills and
                        demonstrated them in a working environment. It is not important that you were paid for your
                        work, only that you can do it. Volunteer positions do not need to be designated as “volunteer”
                        nor do they need to be listed separately.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Do I include personal information, such as interests and hobbies ?
                    </b></span>
                <div class="content">
                    <p>
                        Placing your interests and hobbies on your resume can help an employer get an idea about who you
                        are as an individual. However, this is not an essential part of most resumes and is one of the
                        first sections to be removed if you run out of room. Most important are activities in which you
                        were actively involved that allowed you to develop and demonstrate transferable skills such as
                        leadership, event organization, or financial management. Be specific about what you did while
                        participating in these activities and avoid a “laundry list” of organizations.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Must I include my GPA on my resume ?
                    </b></span>
                <div class="content">
                    <p>
                        As a student or recent graduate your academic achievement will be one of your most important
                        assets. The basic rule of thumb is “if you’ve got it, flaunt it;” it is appropriate to include
                        your GPA on your resume if it is 5.0 or above.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>I keep sending out my resume, but nothing is happening. Any tips ?
                    </b></span>
                <div class="content">
                    <p>
                        Your resume may need to do a better job selling your strengths. You need to recheck to make your
                        resume stronger. Also, you may need more effective ideas.
                        You’ll need to convince employers that what you’ve done in the past relates to their needs.
                        Identify your transferable skills and communicate your accomplishments.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Is it okay to use a testimonial in my resume, or is that inappropriate ?
                    </b></span>
                <div class="content">
                    <p>
                        Your resume is a sales document that sells you, so a testimonial can work well. Be sure to ask
                        for permission first.
                    </p>
                </div>
            </div>
            <h3 class="ml-3 mt-4 mb-1"><span ><b>Organisations -Frequently Asked Questions</b></span></h3>
            <div class="accordion-item">
                <span class="link_anchor"><b>How is Social Services India(SSI) different from other job boards ?
                    </b></span>
                <div class="content">
                    <p>
                        SSI is different from other online job boards in many ways.
                        First, you won’t find job scams, too-good-to-be-true business opportunities, ads,
                        commission-only jobs, or junk jobs on SSI.
                        Second, SSI jobs are the entire focus of our job board. And every SSI job we post is first
                        vetted by a real person who spends as much as 30 minutes per job making sure it meets our
                        rigorous criteria before we serve it up to you.
                        Third, you don’t have to spend hours browsing through job listings looking for keywords like
                        “full time” or “Part time.” We do all the legwork for you, so all you have to do is log in to
                        find the best, most full time, part-time, freelance, Internships and other SSI jobs available

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Is SSI an employment agency or recruiting service ?
                    </b></span>
                <div class="content">
                    <p>
                        No, SSI is not like an employment agency, staffing service, temp firm, or headhunter. We do not
                        place people into positions, nor do we manage the payment process between an employer and the
                        employees or freelancers who they might hire through our site.
                        SSI is a job service that curates flexible, professional, and legitimate job opportunities and
                        puts them into one easy place for you to find them (and also allows pre-screened, approved
                        employers to find candidates who fit their hiring needs and then reach out to them directly).
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Why can’t I sign in to my recruiter account ?
                    </b></span>
                <div class="content">
                    <p>
                        If you’re having trouble signing in, you should follow these steps:
                        1. Make sure you’re using SSI recruiter site, rather than the site for jobseekers. SSI site for
                        recruiters is <a href="">https://socialservicesindia.org</a>
                        2. Make sure you’re using the correct username and password. Your username will usually be your
                        email address.
                        3. If you have forgotten your password, you can request a password reset email.
                        4. If you still cant access your account we request you to email us at <a
                            href="">Contact@SocialServicesIndia.org </a>
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I get a GST receipt for online payment ?
                    </b></span>
                <div class="content">
                    <p>
                        Once payment is received our SSI team shall send you the Invoice through email.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I advertise a job on www.SocialServicesIndia.org ?
                    </b></span>
                <div class="content">
                    <p>
                        From your signed in homepage or from the ‘Jobs & Applications’ page, click ‘Post a Job Advert’.
                        It’s then a simple case of choosing an advert type and completing the advert details.
                        Your advert will go live immediately once you’ve paid for the advert or, if you have chosen to
                        buy job advert credits in advance, as soon as you click ‘Post a Job Advert’.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I edit or make change in a job advert after posting ?
                    </b></span>
                <div class="content">
                    <p>
                        To make a change or edit to a job advert, you can get in touch with SSI team, we will make the
                        changes immediately.
                        Please note: You’ll NOT be charged.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Do I get the best response from my job advert ?
                    </b></span>
                <div class="content">
                    <p>
                        Your job advert needs to encourage the best matching candidates to apply, whilst minimising the
                        number of irrelevant candidates. Follow SSI steps, details asked on creating a perfect job
                        advert, and make sure that you use the applicant screening questions to filter out irrelevant
                        candidates.
                        It is also possible to add required skills and expertise to your job advert.
                        Adding skills will allow candidates to find your job on our website and help them make an
                        informed decision on if they are right for the vacancy you are advertising.
                        If you have added skills to your job advert you will also be able to use our Best Match feature
                        when you come to short-listing candidates.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I identify the most suitable applicants ?
                    </b></span>
                <div class="content">
                    <p>
                        If you have added skills to your job advert you will be able to use our Best Match feature. This
                        will rank candidates, based on keywords in their CV, whether they’ve attached a covering letter,
                        screening questions answered correctly, location, and salary. This is a quick and efficient way
                        to shortlist your applicants against your specific requirements.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I invite colleagues to my account ?
                    </b></span>
                <div class="content">
                    <p>
                        If you’re an administrator for your account, you can invite colleagues to join it by sharing
                        your user ID.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>I have forgotten my password or am having trouble logging in. ?
                    </b></span>
                <div class="content">
                    <p>Please click on the ‘Sign in’ button and select the ‘Forgotten password’ link. You will be
                        prompted to provide the email address you registered with and you will then receive an email
                        with instructions on how to reset your password. Please note that we do not require separate
                        logins for our jobseeker and recruiter services.
                        If you still have trouble logging please reach out to our team at <a
                            href="">Contact@SocialServicesIndia.org</a>
                        If you’re an administrator for your account, you can invite colleagues to join it by sharing
                        your user ID.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How long will my job advertisement(s) appear on the site ?
                    </b></span>
                <div class="content">
                    <p>
                        The maximum length of time a job advert can be live on the site is for 30 days.
                        You can also set a closing date if required so that the job expires before the maximum 30 day
                        period.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How long do my bulk job credits last for ?
                    </b></span>
                <div class="content">
                    <p>
                        When you buy a bulk job, you have unlimited validity to post it.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What are the charges for job advertisement(s) ?
                    </b></span>
                <div class="content">
                    <p>
                        for a single job advert Rs 999/- (Nine Hundred and Ninety Nine Only. This Includes all taxes)
                        for 07 no’s of job advert Rs 5,000/- (Five Thousand Only. This Includes all taxes).
                        for unlimited job advert Rs 25,000/- (Twenty Five Thousand Only. This Includes all taxes).
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What are the charges for job advertisement(s) ?
                    </b></span>
                <div class="content">
                    <p>
                        for a single job advert Rs 999/- (Nine Hundred and Ninety Nine Only. This Includes all taxes)
                        for 07 no’s of job advert Rs 5,000/- (Five Thousand Only. This Includes all taxes).
                        for unlimited job advert Rs 25,000/- (Twenty Five Thousand Only. This Includes all taxes).
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Can you post our Recruitment Ad on behalf of us ?
                    </b></span>
                <div class="content">
                    <p>
                        Yes. If you want us to post your “Job Ad” please email us at – <a
                            href="">contact@SocialServicesIndia.org.</a> Please mention the “Position” in the subject
                        line of your email.
                       
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>Why can’t I sign in to my RFP’s and CSR posting account ?
                    </b></span>
                <div class="content">
                    <p>
                        If you’re having trouble signing in, you should follow these steps:
                        1. Make sure you’re using SSI FC Grant or CSR Grant TAB, rather than the site for recruiter.
                        2. Make sure you’re using the correct username and password. Your username will usually be your
                        email address.
                        3. If you have forgotten your password, you can request a password reset email.
                        4. If you still cant access your account we request you to email us at <a
                            href="">Contact@SocialServicesIndia.org</a>
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I get a GST receipt for online payment ?
                    </b></span>
                <div class="content">
                    <p>
                        Once payment is received our SSI team shall send you the Invoice through email.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I advertise a FC or CSR Ad on www.SocialServicesIndia.org ?
                    </b></span>
                <div class="content">
                    <p>
                        From your signed in homepage or from the <a href="">‘FC Grant’</a> page or <a href="">‘CSR
                            Grant</a>. Click. It’s then a simple case of choosing an advert type and completing the
                        advert details.
                        Your advert will go live immediately once you’ve paid for the advert.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I edit or make change in a FC or CSR advert after posting ?
                    </b></span>
                <div class="content">
                    <p>
                        To make a change or edit to a FC or CSR advert, you can get in touch with SSI team, we will make
                        the changes immediately.
                        Please note: You’ll NOT be charged.

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I get the best response from my FC or CSR advert ?
                    </b></span>
                <div class="content">
                    <p>
                        Your FC or CSR advert needs to encourage the best matching organizations to apply. Follow SSI
                        steps, details asked on creating a FC or CSR advert.
                        It is also possible to add required proposal category and expertise to your FC or CSR advert.
                        Adding proposal category will allow organizations to find your FC or CSR Ad on our website and
                        help them make an informed decision on if they are right for applying.

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How do I invite colleagues to my account ?
                    </b></span>
                <div class="content">
                    <p>If you’re an administrator for your account, you can invite colleagues to join it by sharing your
                        user ID.

                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>I have forgotten my password or am having trouble logging in. ?
                    </b></span>
                <div class="content">
                    <p>Please click on the ‘Sign in’ button and select the ‘Forgotten password’ link. You will be
                        prompted to provide the email address you registered with and you will then receive an email
                        with instructions on how to reset your password. Please note that we do not require separate
                        logins for each tab on our website.
                        If you still have trouble logging please reach out to our team at <a
                            href="">Contact@SocialServicesIndia.org</a>
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>How long will my FC or CSR advertisement(s) appear on the site ?
                    </b></span>
                <div class="content">
                    <p>Stays at our homepage for 1 month or until closing date proposal as mentioned under section
                        (Closing date of Proposal) for maximum visibility and targeted responses.
                        You can also set a closing date if required so that the RFP’s or CSR expires before the maximum
                        30 day period.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What are the charges for FC or CSR advertisement(s) ?
                    </b></span>
                <div class="content">
                    <p>for a single RFP’s or CSR advert Rs 2,499/- (Two Thousand Four Hundred and Ninety Nine Only. This
                        Includes all taxes).
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>What are the other benefits of posting FC or CSR advertisement(s) on SSI ?
                    </b></span>
                <div class="content">
                    <p>We have a database exceeding 50,000 registered organisations across India. SSI team ensures that
                        FC and CSR Proposals also get circulated with all the NGO’s in our newsletter for the next 2
                        issues.
                    </p>
                </div>
            </div>
            <div class="accordion-item">
                <span class="link_anchor"><b>When does the newsletter get circulated ?
                    </b></span>
                <div class="content">
                    <p>SSI news letter gets circulated across India to all NGOs, NPO’s and Voluntary organisation
                        fortnightly (Once in two weeks).
                        Can you post our FC or CSR Fund Ad on behalf of us?
                        Yes. If you want us to post your “ FCor CSR Ad” please email us at – <a
                            href="">contact@SocialServicesIndia.org.</a> Please mention the “Title of the FC or CSR Ad”
                        in the subject line of your email.
                    </p>
                </div>
            </div>
        </div>
    </div>

</section>

<script>
    const items = document.querySelectorAll(".accordion .link_anchor");

    function toggleAccordion() {
        this.classList.toggle('active');
        this.nextElementSibling.classList.toggle('active');
    }

    items.forEach(item => item.addEventListener('click', toggleAccordion));

</script>
@endsection
