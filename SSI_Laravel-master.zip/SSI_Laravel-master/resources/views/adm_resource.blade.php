@extends('layouts.auth_bend_home')
@section('content')

<main>
    <div class="container-fluid">
        <h1 class="mt-4">NGO Resource name</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Admin Panel</li>
            <li class="breadcrumb-item active">NGO Resource name</li>
        </ol>

        <div class="row">
            <div class="col-md-12">
                <form action="{{url('/admin/submitadm_ngo_info')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                    @csrf


                    <div class="row">
                        <div class="col-12 card" style="margin: 2rem 2rem 2rem 0rem;background:#f0f2f4;padding: 1rem;">


                            <input type="hidden" name="ngo_resource_id" value="{{$ngolist['ngo_r_id']}}"/>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for="name">NGO Resource Title</label>
                                    <input type="text" name="title" class="form-cntrl" id="" placeholder=""
                                        data-rule="minlen:4" data-msg="Please enter at least 4 chars" value="{{$ngolist['ngo_r_title']}}"
                                        required />
                                    <div class="validate"></div>
                                </div>



                                <div class="form-group col-lg-6">
                                    <label for="company_logo">NGO Resource Image</label><br>
                                    <input type="file" class="form-cntrl" data-file_types="jpg|jpeg|gif|png"
                                        style="width:100%;" accept="image/png, image/jpeg" name="image" id=""
                                        placeholder="" />
                                    <input type="hidden" name="old_image" value="{{$ngolist['ngo_r_img']}}">
                                </div>
                                <div class="form-group col-lg-6">
                                    <img src="{{ asset($ngolist['ngo_r_img']) }}" style="width:50%;" alt="" />
                                </div>
                            </div>



                            <div class="row" style="text-align:center;">
                                <div class="col-lg-12">

                                    <button class="btn btn-primary" style="width:40%">SUBMIT</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>


        <form action="{{url('/admin/submitadm_ngo_docs')}}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            @csrf
            <div class="card" style="margin: 2rem 2rem 2rem 0rem;background:#f0f2f4;padding: 1rem;">
                <input type="hidden" name="ngo_resource_id" value="{{$ngolist['ngo_r_id']}}"/>
                <div class="row">
                    <div class="form-group col-lg-6">
                        <label for="company_logo">Upload Document Name</label><br>
                        <input type="text" name="title" class="form-cntrl" id="" placeholder="" data-rule="minlen:4"
                            data-msg="Please enter at least 4 chars" value="" required />
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="company_logo">Upload Document</label><br>
                        <input type="file" class="form-cntrl" data-file_types="doc|pdf|text" style="width:100%;"
                            accept="application/pdf" name="ngo_doc" id="" placeholder="">
                    </div>
                </div>
                <div class="row" style="text-align:center;">
                    <div class="col-lg-12">

                        <button class="btn btn-primary" style="width:40%">Submit Document</button>
                    </div>
                </div>
            </div>
        </form>

</main>



<main>
    <div class="container-fluid">
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>NGO Resource List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="notidataTable" width="100%">
                        <thead>
                            <tr>
                                <th>NGO title</th>

                                <th></th>

                                <th>Action</th>

                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>NGO title</th>

                                <th></th>

                                <th>Action</th>


                            </tr>
                        </tfoot>
                        <tbody>
                            @foreach($ngolist['ngo_r_data'] as $noti)
                            <tr>
                                <td>
                                    {{$noti['title']}}
                                </td>
                                <td>
                                    <a href="{{url($noti['doc'])}}">link</a>
                                </td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>      
                            @endforeach
                        </tbody>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $('#notidataTable').DataTable();
</script>
@endsection


