@extends('layouts.auth_bend_home')
@section('content')

<main id="main">
    <section>
        <div class="container-fluid">
            <h1 class="mt-4">Post Donate</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Admin Panel</li>
                <li class="breadcrumb-item active">Post Donate </li>
            </ol>

            
            <section style="background:#f0f2f4;padding-top:5px;padding-bottom:5px;">
                <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                    <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                        <h4>Post Donate </h4>

                    </header>





                    <div class="row" style="text-align: center;">

                    </div>

                    <form action="{{url('/post-donate/submit')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row" style="">
                            <div class="col-12" style="margin: 2rem 2rem 2rem 0rem;padding: 1rem;border: 0;">
                                
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Donation Title </label>
                                        <input type="text" class="form-cntrl" name="title" id="title"
                                        placeholder="Donation Title" required/>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Donation Banner</label>
                                        </br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="banner" id="banner"
                                            placeholder="Add Media" required>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Summary </label>
                                        <textarea class="form-cntrl" name="summary" id="summary"
                                            placeholder="Add Summary" rows="5"
                                            style="height: auto;resize: none;" required></textarea>

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="name">Goal </label>
                                        <input type="text" name="totalgoals" class="form-cntrl" id="summary"
                                            placeholder="Goal" required/>
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Number of fundraisers </label>
                                        <input type="text" name="fundraisers" class="form-cntrl" id="close_date"
                                            placeholder="Number of fundraisers " required/>
                                        <div class="validate"></div>
                                    </div>
                                </div>

                                {{-- <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Remaining </label>
                                        <input type="text" name="remaining" class="form-cntrl" id="remaining"
                                            placeholder="Grant title" />
                                        <div class="validate"></div>
                                    </div>
                                </div> --}}

                                {{-- <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="name">Donors</label>
                                        <input type="text" name="donors" class="form-cntrl" id="location"
                                            placeholder="donors" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Monthly Donors </label>
                                        <input type="text" name="monthlydonors" class="form-cntrl" id="donors"
                                            placeholder="monthlydonors" />
                                        <div class="validate"></div>
                                    </div>


                                </div> --}}

                                {{-- <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="name">fundraisers </label>
                                        <input type="text" name="fundraisers" class="form-cntrl" id="close_date"
                                            placeholder="fundraisers" />
                                        <div class="validate"></div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">years </label>
                                        <input type="text" name="years" class="form-cntrl" id="" placeholder="years" />
                                        <div class="validate"></div>
                                    </div>

                                </div> --}}

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label for="challenge">Challenge</label>
                                        </br>
                                        <textarea class="form-cntrl" name="challenge" id="" placeholder="Challenge"
                                            rows="10" style="height: auto;resize: none;" required></textarea>
                                        <div class="validate"></div>

                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="name">Long-Term Impact</label>

                                        <textarea class="form-cntrl" name="longterm" id="longterm"
                                            placeholder="Long-Term Impact" rows="10"
                                            style="height: auto;resize: none;" required></textarea>
                                        <div class="validate"></div>

                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Solution </label>
                                        {{-- <input type="text" name="solution" class="form-cntrl" id="solution"
                                            placeholder="solution" /> --}}
                                        <textarea class="form-cntrl" name="solution" id="solution"
                                            placeholder="Solution" rows="10"
                                            style="height: auto;resize: none;" required></textarea>
                                        <div class="validate"></div>
                                    </div>
                                </div>


                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Additional Documentation</label>

                                        <input type="file" name="document" name="document" class="form-cntrl"
                                            data-file_types="doc|pdf|text" accept="application/pdf" required>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>Reference Url</label>
                                        <input type="text" name="referenceurl" class="form-cntrl" id=""
                                            placeholder="Reference Url" required/>
                                        <div class="validate"></div>

                                    </div>
                                </div>


                                {{-- <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Reference Url</label>
                                        <input type="text" name="referenceurl" class="form-cntrl" id=""
                                            placeholder="resources" />
                                        <div class="validate"></div>

                                    </div>
                                </div> --}}



                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="name">Organisation name </label>
                                        <input type="text" class="form-cntrl" name="org_name" id="org_name"
                                        placeholder="Organisation name" />
                                        

                                        <div class="validate"></div>
                                    </div>
                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Organisation logo</label>
                                        </br>
                                        <input type="file" class="form-cntrl-file" data-file_types="jpg|jpeg|gif|png"
                                            accept="image/png, image/jpeg" name="organisationlogo" id=""
                                            placeholder="Add Media">
                                    </div>
                                </div>




                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>Organisation Detail</label>
                                        {{-- <input type="textarea" name="organisationdetail" class="form-cntrl" id=""
                                            placeholder="OrganisationDetail" /> --}}
                                        <textarea class="form-cntrl" name="organisationdetail" id=""
                                            placeholder="Organisation Detail" rows="10"
                                            style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>

                                    </div>
                                </div>



                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label>Address</label>
                                        {{-- <input type="text" name="location" class="form-cntrl" id="location"
                                            placeholder="Location" /> --}}
                                        <textarea class="form-cntrl" name="location" id="" placeholder="Address Details"
                                            rows="5" style="height: auto;resize: none;"></textarea>
                                        <div class="validate"></div>

                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>Website</label>
                                        <input type="text" name="website" class="form-cntrl" id="website"
                                            placeholder="Website" />
                                        <div class="validate"></div>

                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label>Checkout Url</label>
                                        <input type="text" name="chkouturl" class="form-cntrl" id="website"
                                            placeholder="Checkout Url" required/>
                                        <div class="validate" ></div>

                                    </div>
                                </div>

                                <div class="form-row">

                                    <!-- <div class="form-group col-md-6"> -->

                                    <div class="form-group col-md-6">
                                        <label>Choose State</label>
                                        <select name="category" id="category" class="form-control">
                                            <option>Choose State</option>
                                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands
                                            </option>
                                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option value="Assam">Assam</option>
                                            <option value="Bihar">Bihar</option>
                                            <option value="Chandigarh">Chandigarh</option>
                                            <option value="Chhattisgarh">Chhattisgarh</option>
                                            <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                            <option value="Daman and Diu">Daman and Diu</option>
                                            <option value="Delhi">Delhi</option>
                                            <option value="Lakshadweep">Lakshadweep</option>
                                            <option value="Puducherry">Puducherry</option>
                                            <option value="Goa">Goa</option>
                                            <option value="Gujarat">Gujarat</option>
                                            <option value="Haryana">Haryana</option>
                                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                            <option value="Jharkhand">Jharkhand</option>
                                            <option value="Karnataka">Karnataka</option>
                                            <option value="Kerala">Kerala</option>
                                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option value="Maharashtra">Maharashtra</option>
                                            <option value="Manipur">Manipur</option>
                                            <option value="Meghalaya">Meghalaya</option>
                                            <option value="Mizoram">Mizoram</option>
                                            <option value="Nagaland">Nagaland</option>
                                            <option value="Odisha">Odisha</option>
                                            <option value="Punjab">Punjab</option>
                                            <option value="Rajasthan">Rajasthan</option>
                                            <option value="Sikkim">Sikkim</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="Telangana">Telangana</option>
                                            <option value="Tripura">Tripura</option>
                                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option value="Uttarakhand">Uttarakhand</option>
                                            <option value="West Bengal">West Bengal</option>
                                        </select>


                                    </div>


                                    <div class="form-group col-md-6">
                                        <label>Focus Area</label>
                                        <select name="focusarea" id="" class="form-control">

                                            <option>Focusarea</option>
                                            <option value="Womenandgirls">Women and Girls</option>
                                            <option value="Health">Health</option>
                                            <option value="Environment">Environment</option>
                                            <option value="Hunger">Hunger</option>
                                            <option value="AnyOther">Any other</option>
                                        </select>

                                    </div>

                                </div>
                                <div class="row" style="text-align:center;">
                                    <div class="col-md-12 ml-auto">
                                        <button class="btn btn-primary  btn-register">Create Donation</button>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>



            </section>








            

        </div>
    </section>
    <script>
        function onchkclick() {
            $('#cates').val('');
            chkeles = $('.proposal_chk');
            chkeles.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#cates').val() === '') {
                        $('#cates').val($(value).val());
                    } else {
                        $('#cates').val($('#cates').val() + ',' + $(value).val());
                    }

                }
            });
            console.log($('#cates').val());
        }

    </script> -->
</main>

@endsection
