@extends('layouts.home')
@section('content')
      <section style="">
            {{-- <div class="intro-img" style="">
                <img src="{{asset('img/ssi-temp-banner.jpg')}}" alt="" class="img-fluid" style="width: 100%;">
            </div> --}}
            <div class="container" style="margin-top:5rem;margin-bottom: 5rem;">
                <header class="section-header" style="text-align: center;font-variant-caps: petite-caps;">
                    <h3><span class="titleheading">financial-services</span></h3>
                </header>
                <div class="row">
                    <div class="col-12">
                        <span style="display: block;font-size: 16px;">Social Services India, (SSI) is a leading Indian Accountants organisation in Bangalore, the silicon valley of India, led by skilled and experienced Accountants in “Social Service” sector. The organisation as made great efforts to achieve with the mission to provide a comprehensive range of financial and consulting services to its clients. We offer a wide spectrum of services and provide “A Practical Approach to Taxation and Accounting of Charitable Trusts, Society, NGOs and NPOs.</span> </span>
                        <br>
                        <span style="display: block;font-size: 16px;">Our philosophy and our history ”We work for you to reach your aims and targets”.
                        
                        <br>
                        <span style="display: block;font-size: 16px;">
                        We provide below Financial services:
                        <br>

                        
                       

                    </div>
                </div>

                <ol >
  <li > <a style="color:blue;" href="accounting">Accounting</a></li>
 
  <li ><a style="color:blue;" href="auditing">Auditing</a></li>
  <li ><a style="color:blue;" href="tax-compliance">Tax Compliance</a></li>
  <li ><a style="color:blue;" href="fcra-services">Foreign Contribution Regulation Act (FCRA) Services</a></li>
</ol> 

                </div>
            


        </section>
@endsection