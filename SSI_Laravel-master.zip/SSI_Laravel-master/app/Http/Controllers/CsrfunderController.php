<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CsrfunderController extends Controller
{
    //

    public function csrfundlist(Request $request)
    {
        // dd($request);
        $sel_query = "SELECT * from CSR_funder_search ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            //$res = $res_query[0];
            // $time = strtotime($res['news_create']);
            // $tempdate = date("M d Y", $time);

            // $DOR_time = strtotime($res['news_DOR']);
            // $DOR_date = date("M d Y", $DOR_time);
            foreach ($res_query as $res) {
                $c_f_obj[] = array(
                    'c_f_id' => $res['c_f_id'],
                    'c_f_org_name' => $res['c_f_org_name'],
                    'c_f_org_detail' => $res['c_f_org_detail'],
                    'c_f_focus_area' => GeneralUtils::getCateNames($res['c_f_focus_area']),
                    'c_f_web' => $res['c_f_web'],
                    'c_f_addr' => $res['c_f_addr'],
                    'c_f_contact' => $res['c_f_contact'],
                    'c_f_email' => $res['c_f_email'],
                    'c_f_seo' => $res['c_f_seo'],
                );
            }
        } else {
            $c_f_obj = null;
        }

        $sel_query = "SELECT * from category";
        //    dd($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $b_f_obj[] = array(

                    'cate_name' => $res['cate_name'],
                    'cate_id' => $res['cate_id'],
                    // 'gi_price' => $res['gi_price'],
                    // 'gi_create_date' => $tempdate,

                );
            }
        } else {
            $b_f_obj = array();
        }
        return view('csr-fund-list', compact(['c_f_obj', 'b_f_obj']));
    }


    public function submitCSRfunder(Request $request)
    {
        $org_name = $request->input('org_name');
        $Website = $request->input('Website');
        $org_detail = $request->input('org_detail');
        $cates = $request->input('cates');
        $address = $request->input('address');
        $Email = $request->input('Email');
        $contact = $request->input('contact');
        // $videolinks = $request->input('videolink');

        $csr_seo = str_replace(" ", "-", $org_name);
        $csr_seo = $csr_seo . "-" . time();


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('CSR_funder_search')->insert([
            'c_f_org_name' => $org_name,
            'c_f_org_detail' => $org_detail,
            'c_f_focus_area' => $cates,
            'c_f_web' => $Website,
            'c_f_addr' => $address,
            'c_f_contact' => $contact,
            'c_f_email' => $Email,
            'c_f_seo' => GeneralUtils::CreateSEO($org_name),
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }




    public function ajaxcsrfunders(Request $request)
    {
        $body = $request->all();
        $sel_query = "SELECT * from CSR_funder_search where c_f_org_name LIKE   '%" . $body['focus'] . "%'   and c_f_focus_area LIKE   '%" . $body['state'] . "%'";

        error_log($sel_query);

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));
        $htmldata = "";
        $thead = '<div style="width: 100%;">

            <div class="container" style="margin-top:2rem;margin-bottom: 5rem;">

                <table class="table-responsive-md table-hover"  id="searchtbl" >
                    
                        <thead>
                            <tr>
                                <th scope="col">NO.</th>
                                <th scope="col">Organisation Name</th>
                                <th scope="col">Link</th>

                            </tr>
                        </thead>
                        <tbody>';

        $tfoot = '</tbody>
                </table>

                </div>
                </div>';
        $count = 1;
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // if ($res['donate_approved'] == 1) {

                $data = '


                <tr>


                    <td>
                        ' . $count . '

                    </td>



                    <td>
                        ' . $res['c_f_org_name'] . '

                    </td>

                    <td>
                        <a href="' . url("/csr-funder") . '/' . $res['c_f_seo'] . '" target="_blank" style="font-weight: bold">Details</a>
                                    </td>
                                </tr>
                              
                            
                                     ' ;


                $htmldata = $htmldata . $data;
                $count++;
               
            }
            error_log($data);
            $htmldata = $thead . $htmldata . $tfoot;
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }


    public function csrfunderlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from CSR_funder_search ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $csrfunderlist[] = array(
                    'c_f_id' => $res['c_f_id'],
                    'c_f_org_name' => $res['c_f_org_name'],
                    'c_f_org_detail' => $res['c_f_org_detail'],
                    'c_f_focus_area' => GeneralUtils::getCateNames($res['c_f_focus_area']),

                    'c_f_web' => $res['c_f_web'],
                    'c_f_addr' => $res['c_f_addr'],

                    'c_f_contact' => $res['c_f_contact'],

                    'c_f_email' => $res['c_f_email'],

                    'c_f_seo' => $res['c_f_seo'],
                );
            }
        } else {
            $csrfunderlist = array();
        }
        return view('adm_csr_funder_list', compact(['csrfunderlist']));
    }


    public function show_csrfunder_Detail(Request $request, $encid)
    {
        try {

            $sel_query = "SELECT * from CSR_funder_search where CSR_funder_search.c_f_id  = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];


                $jp_obj = array(
                    'c_f_id' => $res['c_f_id'],
                    'c_f_org_name' => $res['c_f_org_name'],
                    'c_f_org_detail' => $res['c_f_org_detail'],
                    'c_f_focus_area' => $res['c_f_focus_area'],
                    // 'fell_end_date' => $tempdate,
                    'c_f_web' => $res['c_f_web'],

                    // 'fell_status' => $status,

                    'c_f_addr' => $res['c_f_addr'],
                    'c_f_contact' => $res['c_f_contact'],
                    'c_f_email' => $res['c_f_email'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['c_f_focus_area']);
            } else {
                //  $csrlist = array();
                //errorView
            }

            return view('adm_csr_funder_edit', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }


    public function update_csrfunder(Request $request, $encid)
    {
        $org_name = $request->input('org_name');
        $Website = $request->input('Website');
        $org_detail = $request->input('org_detail');
        $cates = $request->input('cates');
        $address = $request->input('address');
        $Email = $request->input('Email');
        $contact = $request->input('contact');




        DB::beginTransaction();

        try {
            DB::table('CSR_funder_search')->where('c_f_id', $encid)->update([
                'c_f_org_name' => $org_name,
                'c_f_org_detail' => $org_detail,
                'c_f_focus_area' => $cates,
                'c_f_web' => $Website,
                'c_f_addr' => $address,
                'c_f_contact' => $contact,
                'c_f_email' => $Email,

                //'fell_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                //'fell_cate' =>$cates,
                // 'evt_upload_banner' => $db_name_banner,
            ]);
            DB::commit();
            return \redirect('/admin/csrfunder-list');
        } catch (\Exception $ex) {
            dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }
}
