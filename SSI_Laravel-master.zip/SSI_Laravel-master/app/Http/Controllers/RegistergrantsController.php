<?php

namespace App\Http\Controllers;
use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RegistergrantsController extends Controller
{
    public function getGrants(Request $request)
    {
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        error_log($html);
        return view('register-grants', compact(['html']));

    }

    public function submitGrants(Request $request)
    {
        $body = $request->all();
        $organisation_name = $request->input('name');
        $vision = $request->input('vision');
        $organisationmission = $request->input('mission');
        $organisationachivement = $request->input('achivement');
        $headorganisation = $request->input('headorganisation');
        $organisationpan = $request->input('organisationpan');
        $organisationtan = $request->input('organisationtan');
        $registrationno = $request->input('80gregistrationno');
        $fcraregistrationno = $request->input('fcraregistrationno');
        $organisation12A = $request->input('organisation12A');
        $reg_seo = str_replace(" ", "-", $organisation_name);
        $reg_seo = $reg_seo . "-" . time();
        $reg_cates = $request->input('cates');

        $fcravalidfrom = $request->input('validfrom');
        $fcravalidto = $request->input('validto');
        $website = $request->input('website');
        $email = $request->input('email');

        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('register_grants')->insert([
            'reg_o_name' => $organisation_name,
            'reg_v_org' => $vision,
            'reg_o_mission' => $organisationmission,
            'reg_o_ach' => $organisationachivement,
            'reg_o_head' => $headorganisation,
            'reg_o_pan' => $organisationpan,
            'reg_o_tan' => $organisationtan,
            'reg_80g' => $registrationno,
            'reg_fcra' => $fcraregistrationno,
            'reg_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'reg_approved' => 0,
            'reg_valid_from' => $fcravalidfrom,
            'reg_valid_To' => $fcravalidto,
            'reg_website' => $website,
            'reg_email' => $email,
            'reg_SEO' => $reg_seo,
            'reg_create' => $createdate,
            'reg_category' => $reg_cates,
            'reg_org_12a' => $organisation12A,
        ]);

        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/success');
    }


    public function show_registergrants_Detail(Request $request,$pbcid){
        try {

            $sel_query = "SELECT * from register_grants where register_grants.reg_grant_id  = " . $pbcid ;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                if ($res['reg_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'reg_grant_id' => $res['reg_grant_id'],
                   
                    'reg_o_name' => $res['reg_o_name'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_o_mission' => $res['reg_o_mission'],
                    'reg_o_ach' => $res['reg_o_ach'],
                    
                    'reg_status' => $status,
                   
                    'reg_org12a' => $res['reg_org_12a'],
                    'reg_o_head' => $res['reg_o_head'],
                    'reg_o_pan' => $res['reg_o_pan'],
                    'reg_o_tan' => $res['reg_o_tan'],
                    'reg_80g' => $res['reg_80g'],
                    'reg_fcra' => $res['reg_fcra'],

                    'reg_submitted_by' => $res['reg_submitted_by'],
                  
                    'reg_approved' => $res['reg_approved'],
                    'reg_website' => $res['reg_website'],
                    'reg_email' => $res['reg_email'],

               
                    
                    'reg_category' => $res['reg_category'],
                    'reg_valid_from' => $res['reg_valid_from'],
                    'reg_valid_To' => $res['reg_valid_To'],
               
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['reg_category']);

            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('/adm_reg_edit', compact(['jp_obj','html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    public function update_register(Request $request,$pbcid){
        $name = $request->input('name');
        $vision = $request->input('vision');
        $mission = $request->input('mission');
        $area = $request->input('cates');
        $achivement= $request->input('achivement');
        $head = $request->input('headorganisation');

        $pan = $request->input('organisationpan');
    
        $tan = $request->input('organisationtan');
        // $twelveA = $request->input('organisationtwelve');
        


        $eighty = $request->input('80gregistrationno');

        $fcra = $request->input('fcraregistrationno');
        $validfrom = $request->input('validfrom');


        
        $validto = $request->input('validto');

        $website = $request->input('website');
        $email = $request->input('email');

        $cates = $request->input('cate');


        DB::beginTransaction();

        try{
            DB::table('register_grants')->where('reg_grant_id', $pbcid)->update([
                'reg_o_name' =>$name,
                'reg_v_org' =>$vision,
                'reg_o_mission' =>$mission,
                'reg_category' =>$area,
                'reg_o_ach' =>$achivement,
                'reg_o_head' =>$head,
                //'reg_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                'reg_o_pan' => $pan,
                'reg_website' =>$website,
                'reg_o_tan' => $tan,
                // 'reg_org12a' => $twelveA,
                'reg_80g' =>$eighty,
                'reg_fcra' => $fcra,
                'reg_valid_from' => $validfrom,
                'reg_valid_To' => $validto,
                'reg_website' => $website,
                'reg_email' => $email,
              //  'reg_category' => $cates,

                
                ]);
                DB::commit();
                return \redirect('/admin/reg-list');
       
            }catch(\Exception $ex){
            DB::rollback();
            dd($ex);
  
            return \redirect('/error-page');
            
        }
    }

}
