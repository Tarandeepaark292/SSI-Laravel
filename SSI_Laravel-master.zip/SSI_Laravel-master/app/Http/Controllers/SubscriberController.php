<?php

namespace App\Http\Controllers;

use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubscriberController extends Controller
{
    //

    public function showSubsList(Request $request){
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM subscribers;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if(count($res_query)){
            foreach ($res_query as $res) {
                $time = strtotime($res['subs_create_date']);
                $tempdate = date("Y-m-d", $time);
                $subslist[] =array(
                    'subs_email' => $res['subs_email'],
                    'subs_fname' => $res['subs_fname'],
                    'subs_lname' => $res['subs_lname'],
                    'subs_desc' => $res['subs_desc'],
                    'subs_create_date' => $tempdate,
                );
            }
        }else{
            $subslist = null;
        }
        
        return view('adm_subscriber_list', compact(['subslist']));
    }

    public function createSubscriber(Request $request)
    {
        $input = $request->all();
        try{
            DB::beginTransaction();
            $createdate = date("Y-m-d H:i:s");
            DB::table('subscribers')->insert([
                'subs_email' => $input['subs_email'],
                'subs_fname' => $input['subs_fname'],
                'subs_lname' => $input['subs_lname'],
                'subs_desc' => $input['subs_desc'],
                'subs_create_date' => $createdate,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            return response()->json(array('res' => 'SUCCESS', 'data' => "Subscribed Successfully"));
        }catch(\Exception $ex){
            error_log($ex->getMessage());
            return response()->json(array('res' => 'FAIL', 'data' => "Unable to Subscribe"));
        }
    }
}
