<?php

namespace App\Http\Controllers;

use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MiscController extends Controller
{

    public function testpdf(Request $request)
    {
        GeneralUtils::testpdf();
        return view('about');
    }
    //
    public function getCSRfunding(Request $request)
    {
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        error_log($html);
        return view('corporate-social-funding', compact(['html']));

    }

    // public function  postcsrfunding(Request $request)
    // {
    //     $sel_query = "SELECT * FROM category;";
    //     $res_query = DBraw::select($sel_query);
    //     $res_query = json_decode(json_encode($res_query), true);
    //     $total_cate = count($res_query) + 1;
    //     error_log(round($total_cate / 3));
    //     $division = round($total_cate / 3);
    //     $count = 0;
    //     $div_beg = '<div class="form-group col-lg-4">';
    //     $div_end = '</div>';
    //     $html = "";
    //     $temp_html = "";
    //     if (count($res_query)) {
    //         foreach ($res_query as $res) {
    //             $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
    //             <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
    //             $count++;
    //             if ($count == $division) {
    //                 $html .= $div_beg . $temp_html . $div_end;
    //                 $temp_html = '';
    //                 $count = 0;
    //             }
    //         }
    //     }
    //     error_log($html);
    //     return view('post_csr', compact(['html']));

    // }

    public function submitCSR(Request $request)
    {
        $email = $request->input('email');
        $org_name = $request->input('orgname');
        $grant_title = $request->input('grant_title');
        $csr_seo = str_replace(" ", "-", $grant_title);
        $csr_seo = $csr_seo . "-" . time();
        $location = $request->input('location');
        $grant_amt = $request->input('grant_amt');
        $closedate = $request->input('close_date');
        $descproposal = $request->input('proposal_desc');
        $closingdate = $request->input('close_date');
        $ref_url = $request->input('url');
        $cates = $request->input('cates');
        $file = $request->file('company_logo');
        

        if($request->hasFile('document')){
            $document = $request->file('document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('csr')->insert([
            'csr_org' => $org_name,
            'csr_loc' => $location,
            'csr_g_amt' => $grant_amt,
            'csr_close_date' => $closingdate,
            'csr_email' => $email,
            'csr_desc' => $descproposal,
            'csr_upload_doc' => $document,
            'csr_logo' => $db_name_logo,
            'csr_category' => $cates,
            'csr_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'csr_approved' => 0,
            'csr_g_title' => $grant_title,
            'csr_create_date' => $createdate,
            'csr_ref_url' => $ref_url,
            'csr_SEO' => GeneralUtils::CreateSEO($grant_title),
            //'csr_document'=>$document,

            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();

        if(GeneralUtils::addtoCartaftersubmit($request,1)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
        //return \redirect('/recruiter/dashboard');
    }

    // public function postCSR(Request $request)
    // {
    //     $email = $request->input('email');
    //     $org_name = $request->input('orgname');
    //     $grant_title = $request->input('grant_title');

    //     $location = $request->input('location');
    //     $grant_amt = $request->input('grant_amt');
    //     $closedate = $request->input('close_date');
    //     $descproposal = $request->input('proposal_desc');
    //     $closingdate = $request->input('close_date');
    //     $ref_url = $request->input('url');
    //     // $cates = $request->input('cates');
    //     $cate = $request->input('proposal_chk');
    //     $cates = implode(',',$cate);
    //     // dd($cates);
    //     $file = $request->file('company_logo');
    //     $document = $request->file('document');

    //     error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
    //     $src_document = date('YmdHis') . $document->getClientOriginalName();
    //     $dest_document = public_path() . "/document/";
    //     $document->move(public_path() . "/document/", date('YmdHis') . $document->getClientOriginalName());
    //     $document = $dest_document . $src_document;

    //     error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
    //     $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
    //     $dest_file_logo = public_path() . "/Images/";
    //     $file->move(public_path() . "/Images/", date('YmdHis') . $file->getClientOriginalName());
    //     $db_name_logo = $dest_file_logo . $src_file_logo;
    //     DB::beginTransaction();
    //     $createdate = date("Y-m-d H:i:s");
    //     DB::table('csr')->insert([
    //         'csr_org' => $org_name,
    //         'csr_loc' => $location,
    //         'csr_g_amt' => $grant_amt,
    //         'csr_close_date' => $closingdate,
    //         'csr_email' => $email,
    //         'csr_desc' => $descproposal,
    //         'csr_upload_doc' => $document,
    //         'csr_logo' => $db_name_logo,
    //         'csr_category' => $cates,
    //         'csr_submitted_by' => $request->session()->get('ssiapp_rec_id'),
    //         'csr_approved' => 0,
    //         'csr_g_title' => $grant_title,
    //         'csr_create_date' => $createdate,
    //         'csr_ref_url' => $ref_url,
    //         //'csr_document'=>$document,

    //         // 'file_date'=>date("Y-m-d H:i:s"),

    //     ]);
    //     $id = DB::getPdo()->lastInsertId();
    //     DB::commit();
    //     return \redirect('/successpage');
    // }

    public function submitEVENT(Request $request)
    {
        $event_title = $request->input('event_title');
        $event_seo = str_replace(" ", "-", $event_title);
        $event_seo = $event_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('event_desc');
        $cates = $request->input('cates');
        // $closedate = $request->input('close_date');
        //$descproposal = $request->input('proposal_desc');
        // $closingdate = $request->input('closingdate');
        $ref_url = $request->input('url');
        // $cates = $request->input('cates');
        $org_file = $request->file('org_logo');
        
        $banner = $request->file('upload_evt_banner');

        if($request->hasFile('upload_evt_doc')){
            $document = $request->file('upload_evt_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;

        $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
        $dest_file_banner = public_path() . "/Images/";
        $banner->move(public_path() . "/Images/", $src_file_banner);
        $db_name_banner = "/public/Images/" . $src_file_banner;

        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('events')->insert([
            'evt_org_name' => $organisation_name,
            'evt_loc' => $loc_name,
            'evt_title' => $event_title,
            'evt_end_date' => $proposal_close_date,
            'evt_email' => $email,
            'evt_desc' => $event_desc,
            'evt_org_logo' => $db_name_logo,
            'evt_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'evt_approved' => 0,
            'evt_create_date' => $createdate,
            'evt_ref_url' => $ref_url,
            'evt_upload_doc' => $document,
            'evt_upload_banner' => $db_name_banner,
            'evt_SEO' => GeneralUtils::CreateSEO($event_title),
            'evt_cate' => $cates,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,4)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }
    public function csrads(Request $request)
    {

        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from csr where csr_approved = 1 and csr_close_date > '$today' order by csr_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                error_log(json_encode($res));
                $time = strtotime($res['csr_close_date']);
                $tempdate = date("F d Y, l", $time);
                $csrsearch[] = array(
                    'csr_org' => $res['csr_org'],
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_close_date' => $tempdate,
                    'csr_logo' => $res['csr_logo'],
                    'csr_loc' => $res['csr_loc'],
                    'csr_seo' => $res['csr_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $csrsearch = array();
        }
        $cates = GeneralUtils::getDBCates();
        $sel_query = "SELECT seo_data from SEO where seo_id = 17;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-csr-ads', compact(['csrsearch','cates','seodata']));

    }

    public function ajaxcsr(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from csr where csr_org  LIKE   '%" . $body['search'] . "%' and csr_category LIKE '%". $body['cate']."%' and csr_close_date > '$today';";
        
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $mydata = null;
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['csr_approved'] == 1) {
                    $time = strtotime($res['csr_close_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '

                    <div class="col-12" style="margin-bottom:2rem;">
                        <div class="card content joblist_item" id="results">
                            <div class="card-body" id="results">
                                <div class="row " id="resultss">
                                    <div class="col-md-2" style="text-align: center;">

                                        <img style="width: 80%;" src="'.asset($res['csr_logo']).'" />
                                    </div>
                                    <div class="col-md-8">
                                        <div class="results" style="font-weight: bold;">
                                            '.$res['csr_org'].'</div>
                                        <div id="results" class="limittext">
                                            '.$res['csr_g_title'].'
                                        </div>
                                        <div id="results">
                                            <i class="fa fa-map-marker" aria-hidden="true"
                                                style="color:#007bff;font-size: 18px;"></i> <span
                                                style="font-weight: bold;color:#007bff;">'.$res['csr_loc'].'</span>

                                        </div>
                                        <div id="results">
                                            <i class="fa fa-calendar" aria-hidden="true"
                                                style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                                style="font-weight: bold;color:#00254d;">'.$res['csr_close_date'].'
                                            </span>
                                        </div>
                                        <div id="results" style="color:#293e09;">
                                            <i class="fa fa-money" aria-hidden="true"></i> <span
                                                style="font-weight: bold;">'.$res['csr_g_amt'].'</span>
                                        </div>
                                    </div>
                                    <div class="col-md-2 my-auto ">
                                        <a href="'.url('/csr/').'/'.$res['csr_SEO'].'" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                                        ';

                    error_log($data);

                    $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));

                } else {
                    $res['error'] = '
                    <div class="col-md-12">
                <div class="resultss" style="font-weight: bold;font-size: 20px;">you have no csr ads</div>';
                    $mydata = response()->json($res);
                }

            }
            return $mydata;
        } else {
            // $rfpsearch = array();
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }

    // return view('all-ads',compact(['rfpsearch']));

    public function evtads(Request $request)
    {

        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from events where evt_approved = 1 and evt_end_date >= '$today' order by evt_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("F d Y, l", $time);
                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                error_log(json_encode($res));
                $evtsearch[] = array(
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_title' => $res['evt_title'],
                    'evt_loc' => $res['evt_loc'],
                    'evt_org_logo' => $res['evt_org_logo'],
                    'evt_end_date' => $tempdate,
                    'evt_seo' => $res['evt_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $evtsearch = array();
        }
        $cates = GeneralUtils::getDBCates();


        $sel_query = "SELECT seo_data from SEO where seo_id = 14;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-event-ads', compact(['evtsearch','cates','seodata']));

    }

    public function ajaxevt(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from  events where evt_title   LIKE   '%" . $body['search'] . "%'and evt_cate LIKE '%". $body['cate']."%' and evt_end_date > '$today';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // error_log(json_encode($res_query));
        $img = asset('img/ssi_logo.svg');
        $mydata = null;
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['evt_approved'] == 1) {
                    $time = strtotime($res['evt_end_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content fell_search_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                    <div class="col-md-2  results" style="text-align: center;">
                    <img style="width:80%" src=' . asset($res['evt_org_logo']) . ' />
                    </div>
                    <div class="col-md-8">
                    <div class="results" style="font-weight: bold;color:#004a99">' . $res['evt_org_name'] . '</div>
                    <div id="results" style="font-weight: bold;color:#004a99" class="limittext">
                    ' . $res['evt_title'] . '
                    </div>
                    <div id="results">
                        <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;" >' . $res['evt_loc'] . '</span>

                    </div>
                    <div id="results">
              
                        <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <span style="font-weight: bold;color:#00254d;">' . $tempdate . ' </span>
                    </div>
                </div>
                <div class="col-md-2 my-auto ">
                                   
                <a href="' .url('/evt/') .'/'. $res['evt_SEO']. '" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
            </div>
                <div class="col-md-2 my-auto " >

                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            ';

                    error_log($data);

                    $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));

                } else {
                    $res['error'] = '<div class="col-md-2  results" style="text-align: center;">
                        <img src=' . $img . ' />
                        </div>
                        <div class="col-md-8">
                    <div class="resultss" style="font-weight: bold;font-size: 20px;">you have no csr ads</div>';
                    $mydata = response()->json($res);
                }

            }
            return $mydata;
        } else {
            // $rfpsearch = array();
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }

    public function successPage(Request $request, $message = null)
    {
        if ($message == 'RFP') {
            $msg = "Your RFP REQUEST IS SUCCESSFULLY SUBMITTED";
            return view('successpage', compact(['msg']));
        } elseif ($message == 'CSR') {
            $msg = "Your CSR REQUEST IS SUCCESSFULLY SUBMITTED";
            return view('successpage', compact(['msg']));
        } elseif ($message == 'EVENT') {
            $msg = "Your EVENT REQUEST IS SUCCESSFULLY SUBMITTED";
            return view('successpage', compact(['msg']));
        } elseif ($message == 'FELLOWSHIP') {
            $msg = "Your FELLOWSHIP REQUEST IS SUCCESSFULLY SUBMITTED";
            return view('successpage', compact(['msg']));
        } elseif ($message == 'GRANT') {
            $msg = "Your GRANT REQUEST IS SUCCESSFULLY SUBMITTED";
            return view('successpage', compact(['msg']));
        } else {
            return view('successpage');
        }
    }

    public function errorPage(Request $request, $message = null)
    {
        if (is_null($message)) {
            return view('error');
        } else {
            return view('error', compact(['msg']));
        }
        // if ($message == 'RFP') {
        //     $msg = "Your RFP REQUEST IS SUCCESSFULLY SUBMITTED";
        //     return view('successpage', compact(['msg']));
        // } elseif ($message == 'CSR') {
        //     $msg = "Your CSR REQUEST IS SUCCESSFULLY SUBMITTED";
        //     return view('successpage', compact(['msg']));
        // } elseif ($message == 'EVENT') {
        //     $msg = "Your EVENT REQUEST IS SUCCESSFULLY SUBMITTED";
        //     return view('successpage', compact(['msg']));
        // } elseif ($message == 'FELLOWSHIP') {
        //     $msg = "Your FELLOWSHIP REQUEST IS SUCCESSFULLY SUBMITTED";
        //     return view('successpage', compact(['msg']));
        // } elseif ($message == 'GRANT') {
        //     $msg = "Your GRANT REQUEST IS SUCCESSFULLY SUBMITTED";
        //     return view('successpage', compact(['msg']));
        // } else {
        //     return view('successpage');
        // }
    }

    public function home(Request $request)
    {

        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from events where evt_approved=1 and evt_end_date > '$today'   order by evt_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // dd($res_query);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['evt_create_date']);
                $tempdate = date("M d Y", $time);
                $time = strtotime($res['evt_end_date']);
                $tempenddate = date("M d Y", $time);
                // error_log(json_encode($res));
                $homesearch[] = array(
                    'evt_title' => $res['evt_title'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_email' => $res['evt_email'],
                    'evt_create_date' => $tempdate,
                    'evt_loc' => $res['evt_loc'],
                    'evt_SEO' => $res['evt_SEO'],
                    'evt_org_logo' => $res['evt_org_logo'],
                    'evt_end_date' => $tempenddate,

                );
                //  error_log($homesearch);
            }

        } else {
            $homesearch = null;

        }


        $sel_query = "SELECT * from news order by news_create desc LIMIT 3";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['news_create']);
                $tempdate = date("M d Y", $time);

                // error_log(json_encode($res));
                $news[] = array(
                    'news_id' => $res['news_id'],
                    'news_body' => $res['news_body'],
                    'news_image' => $res['news_image'],
                    'news_head' => $res['news_head'],
                    'news_link' => $res['news_links'],
                    'news_create' => $tempdate,
                    'news_SEO' => $res['news_SEO'],

                );
            }
        } else {
            //$news[] = array();
            $news = null;
        }


        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from rfp where rfp_approved = 1  and rfp_close_date > '$today'  order by rfp_id desc";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);

                // error_log(json_encode($res));
                $rfps[] = array(
                    'rfp_org' => $res['rfp_org'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_logo' => $res['rfp_logo'],
                    'rfp_close_date' => $tempdate,
                    'rfp_SEO' => $res['rfp_SEO'],

                );
            }
        } else {
            $rfps = null;
        }
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from job_post where jp_approved = 1 and jp_closing_date > '$today' order by jp_id DESC";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);

                // error_log(json_encode($res));
                $jobs[] = array(

                    'jp_loc' => $res['jp_loc'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_title' => $res['jp_title'],
                    'jp_closing_date' => $tempdate,
                    'jp_app_email' => $res['jp_app_email'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    'jp_SEO' => $res['jp_SEO'],
                );
            }
        } else {
            // $fellowships[] = array();
            $jobs = null;
        }

        $sel_query = "SELECT * from awards where award_approved = 1 order by award_id desc";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['fell_end_date']);
                // $tempdate = date("M d Y", $time);

                error_log(json_encode($res));
                $awards[] = array(

                    'award_loc' => $res['award_loc'],
                    'award_org_name' => $res['award_org_name'],
                    'award_title' => $res['award_title'],
                    'award_ref_url' => $res['award_ref_url'],
                    'award_org_logo' => $res['award_org_logo'],
                    'award_SEO' => $res['award_SEO'],

                );
            }
        } else {
            $awards = null;
        }

        $sel_query = "SELECT * from banners";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['fell_end_date']);
                // $tempdate = date("M d Y", $time);

                error_log(json_encode($res));
                $banners[] = array(

                    'b_img_name' => $res['b_img_name'],
                    'b_link' => $res['b_link'],
                   

                );
            }
        } else {
            $banners = null;
        }

        
        $sel_query = "SELECT seo_data from SEO where seo_id = 1;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }


        return view('homeupload', compact(['homesearch', 'rfps', 'jobs', 'awards','news','banners','seodata']));

    }

    public function resumeads(Request $request)
    {

        $sel_query = "SELECT * from job_seeker where js_broadcast_resume = 1 order by js_id desc;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['js_createdate']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $resumesearch[] = array(
                    'js_photo' => $res['js_photo'],
                    'js_p_title' => $res['js_p_title'],
                    'js_loc' => $res['js_loc'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_createdate' => $tempdate,
                    'js_loc_obj' => json_decode($res['js_loc'], true),
                    'js_name' => $res['js_name'],
                    'js_SEO' => $res['js_SEO'],
                    // 'rfp_loc' => $res['rfp_loc'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
                $js_loc_obj = json_decode($res['js_loc'], true);
                // dd($js_loc_obj);
            }
        } else {
            $resumesearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 21;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('resumes', compact(['resumesearch','seodata']));
    }

    public function ajaxresume(Request $request)
    {
        try {
            $body = $request->all();
            error_log($body['cate']);
            $cate = $body['cate'];
            $sel_query = "SELECT * from job_seeker where js_area_expertise ='$cate' AND js_broadcast_resume = 1";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log($sel_query);
            error_log(json_encode($res_query));

            $img = asset('img/ssi_logo.svg');
            $data = '';
            if (count($res_query)) {
                foreach ($res_query as $res) {
                    error_log(json_encode($res));
                    // $time = strtotime($res['js_createdate']);
                    // $tempdate = date("F d Y, l", $time);
                    // error_log($tempdate);
                    $js_loc_obj = json_decode($res['js_loc'], true);
                    $data = $data . '
                    <div class="col-lg-12">
                    <div class="card content joblist_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">
                                <div class="col-md-2" style="text-align: center;">
                                    <img style="width: 80%;" src="' . asset($res['js_photo']) . '" />
                                </div>
                                <div class="col-md-8">
                                    <div>
                                        <span style="font-weight: bold;">
                                            ' . $res['js_name'] . '
                                        </span>
                                    </div>
                                    <div id="results">
                                        ' . $res['js_p_title'] . '
                                    </div>
                                    <div id="results">
                                        <i class="fa fa-map-marker" aria-hidden="true"
                                            style="color:#007bff;font-size: 18px;"></i>
                                            <span style="font-weight: bold;color:#007bff;">' . $js_loc_obj['addr_state'] . '</br>

                                        </span>
                                    </div>
                                    <div id="results">
                                         <span style="font-weight: bold;color:#00254d;">
                                            ' . $res['js_area_expertise'] . '
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-2" style="align-self: center;justify-content: center;">
                                    <a href="' . url('/jobseeker') . '/' . $res['js_SEO'] . '" class="btn btn-primary">Detail <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';

                }
                //$mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));
                error_log($data);
                return response()->json(array('res' => 'SUCCESS', 'data' => $data));
            } else {
                // $rfpsearch = array();
                $res['res'] = 'FAIL';
                $res['error'] = '
            <div class="col-md-12">
            <div class="resultss" style="font-weight: bold;font-size: 20px;">No Job Seeker Resumes avaliable</div>
            </div>';
                return response()->json($res);
            }
        } catch (\Exception $ex) {
            error_log($ex->getMessage());
            $res['res'] = 'FAIL';
            return response()->json($res);
        }
    }

    public function ajaxjob(Request $request)
    {
        $body = $request->all();
        error_log(json_encode($body));
        // error_log($body['search']);
        // error_log($body['location']);
        $notfound = false;
        if ($body['cate'] != '-1') {
            $today = date("Y-m-d") . " 00:00:00";
            $sel_query = "SELECT * from job_post where jp_ad_type_area_of_expertise  LIKE   '%" . $body['cate'] . "%' and jp_closing_date > '$today' order by jp_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }
        if ($body['search']) {
            // error_log("asdf");
            $today = date("Y-m-d") . " 00:00:00";
            $sel_query = "SELECT * from job_post where jp_title  LIKE   '%" . $body['search'] . "%' and jp_closing_date > '$today' order by jp_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }
        if ($body['loca']) {
            // error_log("qwe");
            $today = date("Y-m-d") . " 00:00:00";
            $sel_query = "SELECT * from job_post where jp_loc  LIKE   '%" . $body['loca'] . "%' and jp_closing_date > '$today' order by jp_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }

        if(!$notfound){
            $sel_query = "SELECT * from job_post where jp_closing_date > '$today'  order by jp_id DESC;";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
        }

        // error_log(json_encode($res['js_loc']));
        $img = asset('img/ssi_logo.svg');
        $data = '';
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $loca = $res['jp_loc'];
                // error_log(json_decode(json_encode($res['js_loc']),true));
                // $loca = json_decode($res['js_loc'], true);

                if ($res['jp_approved'] == 1) {
                    $time = strtotime($res['jp_closing_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = $data . '<div class="col-12" style="margin-bottom:2rem;">
                    <div class="card content joblist_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">

                                <div class="col-md-2" style="text-align: center;">

                                    <img style="width: 80%;" src="'.asset($res['jp_org_logo']).'" />
                                </div>
                                <div class="col-md-8">
                                    <div id="results">
                                        '.$res['jp_title'].'
                                        </div>
                                    <div id="results" class="limittext">
                                        <span class="limittext" style="margin-bottom:2px;font-weight: bold;color:#004a99"> '.$res['jp_org_name'].' </span>
                                    </div>
                                    <div id="results">
                                        <i class="fa fa-map-marker" aria-hidden="true"
                                            style="color:#007bff;font-size: 18px;"></i> <span
                                            style="font-weight: bold;color:#007bff;font-size:16px;">'.$res['jp_loc'].'</br>

                                        </span>
                                    </div>
                                    <div id="results">
                                        <i class="fa fa-calendar" aria-hidden="true"
                                            style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                            style="font-weight: bold;color:#00254d;font-size:16px;">'.$tempdate.'
                                        </span>
                                    </div>
                                    <div id="results">
                                        '.$res['jp_ad_type_area_of_expertise'].'
                                    </div>
                                </div>
                                <div class="col-md-2" style="align-self: center;justify-content: center;">
                                    <a href="'.url('/job-post').'/'.$res['jp_SEO'].'" class="btn btn-primary">Detail  <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>

                        </div>
                    </div>
                    </div>';

                    // error_log($data);

                    // $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));
                }
            }
            return response()->json(array('res' => 'SUCCESS', 'data' => $data));
        } else {
            // $rfpsearch = array();
            $res['res'] = 'FAIL';
            $res['error'] = '
        <div class="col-md-12">
        <div class="resultss" style="font-weight: bold;font-size: 20px;">No Job found</div>
        </div>';
            return response()->json($res);
        }

        // return view('all-ads',compact(['rfpsearch']));

    }

    public function searchregistergrants(Request $request)
    {
        $sel_query = "SELECT * from register_grants where reg_approved = 1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['reg_valid_To']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $registersearch[] = array(
                    'reg_email' => $res['reg_email'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_o_mission' => $res['reg_o_mission'],
                    'reg_o_head' => $res['reg_o_head'],
                    'reg_valid_To' => $tempdate,
                    'reg_website' => $res['reg_website'],
                    'reg_SEO' => $res['reg_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );

            }

        } else {
            $registersearch = array();

        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 16;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-registergrants', compact(['registersearch','seodata']));
    }

    public function alljobs(Request $request)
    {
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from job_post where jp_approved = 1 and jp_closing_date > '$today' order by jp_id DESC; ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $jobs[] = array(
                    'jp_title' => $res['jp_title'],
                    'jp_job_type' => GeneralUtils::getJobType($res['jp_job_type']),
                    'jp_ad_type_area_of_expertise' => $res['jp_ad_type_area_of_expertise'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    'jp_loc' => $res['jp_loc'],
                    'jp_SEO' => $res['jp_SEO'],
                    'jp_closing_date' => $tempdate,
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $jobs = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 25;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-jobs', compact(['jobs','seodata']));
    }

    public function about(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 2;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('about', compact(['seodata']));
    }

    public function accountingview(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 3;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('accounting', compact(['seodata']));
    }

    public function contact(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 4;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('contact', compact(['seodata']));
    }

    public function orgSectorwise(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 5;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('org-sector-wise', compact(['seodata']));
    }

    public function stateUt(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 6;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('state-ut', compact(['seodata']));
    }

    public function faq(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 7;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('faq', compact(['seodata']));
    }

    public function privacypolicy(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 8;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('privacy-policy', compact(['seodata']));
    }

    public function termscondition(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 9;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('terms-condition', compact(['seodata']));
    }

    public function fcraservices(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 10;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('fcra-services', compact(['seodata']));
    }

    public function taxcompilance(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 11;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('tax-compliance', compact(['seodata']));
    }

    public function auditing(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 12;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('auditing', compact(['seodata']));
    }

    public function advertiseWithUs(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 20;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }

        return view('advertise_us',compact(['seodata']));
    }

    /**
     * 
     */
    public function downloaddb(Request $request)
    {
        //dd($request->ip());
        if($request->ip() != "124.123.80.226" && $request->ip() != "103.133.59.90"){
            abort(404);
        }
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $host = "ls-e85becdd7e8dccb622058614de9518b290ab5111.ck1ltfgs4nq3.ap-south-1.rds.amazonaws.com";
        $databaseName = "ssi_app";
        $userName = "dbmasteruser";
        $password = "iSo?rQk2Wh.h*Mi6.Iv)986|u3R?e*en";
        $pathToFile = public_path() . "/DUMPS/sql-".date('YmdHis')."-bkup.sql";
        
        \Spatie\DbDumper\Databases\MySql::create()
            ->setHost($host)
            ->setDbName($databaseName)
            ->setUserName($userName)
            ->setPassword($password)
            
            ->dumpToFile($pathToFile);

        return response()->download($pathToFile);
    }
}
