<?php

namespace App\Http\Controllers;

use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Defines\SecurityDefines;

class EmployeeController extends Controller
{
    //Employer Panel


    public function csr_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_rec_token'));
        // $q = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        // error_log($q);
        $sel_query = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['csr_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['csr_id'],$request->session()->get('ssiapp_rec_token'),SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $csrlist[] = array(
                    'csr_id' => $res['csr_id'],
                    'csr_enc_id' => $enc_id,
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_org' => $res['csr_org'],
                    'csr_create_date' => $tempdate,
                    'csr_submitted_by' => $res['r_name'],
                    'csr_status' => $status,
                    'csr_approved' => $res['csr_approved'],
                );
            }
        } else {
            $csrlist = array();
        }
        return view('emp_csr_list', compact(['csrlist']));
    }


    public function fell_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from fellowship inner join recruiter on fellowship.fell_submitted_by = recruiter.r_id  where fellowship.fell_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['fell_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $felllist[] = array(
                    'fell_id' => $res['fell_id'],
                    'fell_title' => $res['fell_title'],
                    'fell_email' => $res['fell_email'],
                    'fell_o_name' => $res['fell_o_name'],
                    'fell_end_date' => $tempdate,
                    'fell_submitted_by' => $res['r_name'],
                    'fell_status' => $status,
                    'fell_approved' => $res['fell_approved'],
                );
            }
        } else {
            $felllist = array();
        }
        return view('emp_fell_list', compact(['felllist']));
    }


    public function evt_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from events inner join recruiter on events.evt_submitted_by = recruiter.r_id where events.evt_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['evt_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $evtlist[] = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_email' => $res['evt_email'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_create_date' => $tempdate,
                    'evt_submitted_by' => $res['r_name'],
                    'evt_status' => $status,
                    'evt_approved' => $res['evt_approved'],
                );
            }
        } else {
            $evtlist = array();
        }
        return view('emp_evt_list', compact(['evtlist']));
    }


    public function rfp_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from rfp inner join recruiter on rfp.rfp_submitted_by = recruiter.r_id where rfp.rfp_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // error_log(json_encode($res_query));

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $rfplist[] = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_close_date' => $tempdate,
                    'rfp_submitted_by' => $res['r_name'],
                    'rfp_status' => $status,
                    'rfp_approved' => $res['rfp_approved'],
                );
            }
        } else {
            $rfplist = array();
        }
        return view('emp_rfp_list', compact(['rfplist']));
    }

    public function rgrant_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from register_grants inner join recruiter on register_grants.reg_submitted_by = recruiter.r_id where register_grants.reg_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['reg_valid_To']);
                $tempdate = date("M d Y", $time);
                if ($res['reg_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $reglist[] = array(
                    'reg_grant_id' => $res['reg_grant_id'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_email' => $res['reg_email'],
                    'reg_website' => $res['reg_website'],
                    'reg_valid_To' => $tempdate,
                    'reg_submitted_by' => $res['r_name'],
                    'reg_status' => $status,
                    'reg_approved' => $res['reg_approved'],
                );
            }
        } else {
            $reglist = array();
        }
        return view('emp_reg_list', compact(['reglist']));
    }


    public function job_post_list1(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name  from job_post inner join recruiter on job_post.jp_submitted_by = recruiter.r_id where job_post.jp_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['jp_id'],$request->session()->get('ssiapp_rec_token'),SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $reclist[] = array(
                    'jp_id' => $res['jp_id'],
                    'jp_enc_id' => $enc_id,
                    'jp_title' => $res['jp_title'],
                    'jp_email' => $res['jp_email'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_close_date' => $tempdate,
                    'jp_submitted_by' => $res['r_name'],
                    'jp_status' => $status,
                    'jp_approved' => $res['jp_approved'],
                );
            }
        } else {
            $reclist = array();
        }
        return view('emp_jobpost_list', compact(['reclist']));
    }

}
