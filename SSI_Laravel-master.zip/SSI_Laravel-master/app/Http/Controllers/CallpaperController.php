<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CallpaperController extends Controller
{
    public function submitCallPaper(Request $request)
    {
        // dd($request->session()->get('ssiapp_adm')); 
        $title = $request->input('title');
        $papertype = $request->input('type');
        $org_name = $request->input('org');
        $apply_by = $request->input('apply');
        $location = $request->input('loc');

        $displaypage = $request->input('display_page');
        $email = $request->input('email');

        $web_url = $request->input('website_url');
        $media_url = $request->input('url');

        $file = $request->file('org_logo');
        // dd($file);
        if ($request->hasFile('pdf_document')) {
            $document = $request->file('pdf_document');
            // $document_word = $request->file('document1');

            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }
        // error_log("--->>" . $document_word->getClientOriginalExtension() . public_path() . $document_word->getClientOriginalName());
        // $src_document = date('YmdHis') . $document_word->getClientOriginalName();
        // $dest_document = public_path() . "/document/";
        // $document_word->move(public_path() . "/document/", $src_document);
        // $document_word = "/public/document/" . $src_document;

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('call_paper')->insert([
            'paper_title' => $title,
            'paper_type' => $papertype,
            'paper_o_name' => $org_name,
            'paper_apply_by' => $apply_by,

            'paper_loc' => $location,
            'paper_disp' => $displaypage,
            'paper_email' => (isset($email) ? $email : ""),

            'paper_web_url' => $web_url,
            'paper_url' => $media_url,
            'paper_pdf_doc' => $document,
            // 'paper_word_document' => $document_word,
            'paper_org_logo' => $file,

            'paper_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'paper_approved' => 0,
            'paper_SEO' => GeneralUtils::CreateSEO($title),


        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,15)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function update_call(Request $request, $encid)
    {
        // dd($request);
        $title = $request->input('title');
        $papertype = $request->input('type');
        $org_name = $request->input('org');
        $apply_by = $request->input('apply');
        $location = $request->input('loc');
        $displaypage = $request->input('display_page');
        $email = $request->input('Email');
        // $loc_state = $request->input('state');
        // $academic_year = $request->input('year');
        $web_url = $request->input('website_url');
        $media_url = $request->input('url');
        // $terms_conditions = $request->input('terms');
        // $ref_url = $request->input('url');

        if ($request->hasFile('org_logo')) {
            $file = $request->file('org_logo');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $file = "/public/Images/" . $src_file_logo;
        } else {
            $file = $request->input('org_old_logo');
        }

        if ($request->hasFile('pdf_document')) {
            $document = $request->file('pdf_document');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('pdf_old');
        }
        if ($request->hasFile('document1')) {
            $document_word = $request->file('document1');
            $src_document = date('YmdHis') . $document_word->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document_word->move(public_path() . "/document/", $src_document);
            $document_word = "/public/document/" . $src_document;
        } else {
            $document_word = $request->input('doc_old');
        }



        DB::beginTransaction();

        try {
            DB::table('call_paper')->where('paper_id', $encid)->update([
                'paper_title' => $title,
                'paper_type' => $papertype,
                'paper_o_name' => $org_name,
                'paper_apply_by' => $apply_by,
                'paper_loc' => $location,
                'paper_disp' => $displaypage,
                'paper_email' => $email,

                'paper_web_url' => $web_url,
                'paper_url' => $media_url,
                'paper_pdf_doc' => isset($document) ? $document : "",
                'paper_word_document' => $document_word,
                'paper_org_logo' => $file,

            ]);

            DB::commit();
            return \redirect('/admin/adm_call_list');
        } catch (\Exception $ex) {
            // dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function show_call_Detail(Request $request, $encid)
    {
        try {
            // $body = $request->all();
            // dd($request);
            $sel_query = "SELECT * from call_paper where call_paper.paper_id = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            // dd($res_query);
            if (count($res_query)) {
                $res = $res_query[0];
                if ($res['paper_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'paper_id' => $res['paper_id'],
                    'paper_title' => $res['paper_title'],
                    'paper_type' => $res['paper_type'],
                    'paper_o_name' => $res['paper_o_name'],
                    'paper_loc' => $res['paper_loc'],
                    'paper_org_logo' => $res['paper_org_logo'],
                    'paper_disp' => $res['paper_disp'],
                    'paper_email' => $res['paper_email'],
                    'paper_apply_by' => $res['paper_apply_by'],
                    'paper_web_url' => $res['paper_web_url'],
                    'paper_url' => $res['paper_url'],
                    'paper_word_document' => $res['paper_word_document'],
                    'paper_pdf_doc' => $res['paper_pdf_doc'],
                    'paper_approved' => $res['paper_approved'],

                );
            } else {
            }
            return view('adm_show_callpaper_detail', compact(['jp_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function callpaperads(Request $request)
    {

        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from call_paper where paper_approved = 1 and paper_apply_by > '$today' order by paper_id desc";        
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                error_log(json_encode($res));
                $time = strtotime($res['paper_apply_by']);
                $tempdate = date("F d Y, l", $time);
                $callsearch[] = array(
                    'paper_id' => $res['paper_id'],
                    'paper_title' => $res['paper_title'],
                    'paper_apply_by' => $tempdate,
                    'paper_o_name' => $res['paper_o_name'],
                    'paper_loc' => $res['paper_loc'],
                    'paper_type' => $res['paper_type'],
                    'paper_org_logo' => $res['paper_org_logo'],
                    'paper_SEO' => $res['paper_SEO'],
                );
            }
        } else {
            $callsearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 27;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-callpapers', compact(['callsearch','seodata']));
    }

    public function reccallpaperlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from call_paper where paper_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $time = strtotime($res['js_createdate']);
               
                if ($res['paper_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log(json_encode($res));
                $callsearch[] = array(
                    'paper_id' => $res['paper_id'],
                    'paper_title' => $res['paper_title'],
                    'paper_type' => $res['paper_type'],
                    'paper_o_name' => $res['paper_o_name'],
                    'paper_loc' => $res['paper_loc'],
                    // 'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    'paper_org_logo' =>$res['paper_org_logo'],
                    'paper_disp' =>$res['paper_disp'],
                    'paper_email' => $res['paper_email'],
                    'paper_apply_by'=>$res['paper_apply_by'],
                    'paper_web_url' => $res['paper_web_url'],
                    'paper_url' => $res['paper_url'],
                    'paper_pdf_doc' => $res['paper_pdf_doc'],
                    'paper_word_document' => $res['paper_word_document'],
                    'paper_approved' => $res['paper_approved'],
                   
                );
               
            }
        } else {
            $callsearch = array();
        }
        return view('rec_call_list', compact(['callsearch']));
    }

    public function ajax_search_callpaper(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";

        $sel_query = "SELECT * from call_paper where paper_title  LIKE   '%" . $body['search'] . "%' and paper_type  LIKE   '%" . $body['type'] . "%' and paper_apply_by > '$today' ";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);


        $img = asset('img/ssi_logo.svg');
        $htmldata = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['paper_apply_by']);
                $tempdate = date("F d Y, l", $time);
                if ($res['paper_approved'] == 1) {
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content joblist_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                <div class="col-md-2  results" style="text-align: center;">
                <img style="width:80%" src=' . asset($res['paper_org_logo']) . ' />
                </div>
                <div class="col-md-8">
                
                <div id="results" style="font-weight: bold;color:#004a99" class="limittext">
                ' . $res['paper_title'] . '
                </div>
                <div id="results">
                    <i class="" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#004a99" >' . $res['paper_o_name'] . '</span>

                </div>
                <div id="results">
                    <i class="fa fa-map-marker" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i>  <span style="font-weight: bold;color:#004a99">' . $res['paper_loc'] . ' </span>
                </div>
                <div id="results" style="">
                <i class="" aria-hidden="true"></i> <span style="font-weight: bold;">' . $tempdate . '</span>
            </div>
                </div>
            <div class="col-md-2 my-auto " >
            <a href="'.url('/call-paper/').'/'.$res['paper_SEO'].'" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        ';



                    $htmldata = $htmldata . $data;
                }
            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }
}
