<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Support\Facades\DB;

class CronController extends Controller
{
    //

    /**
     * 
     */
    public function FixJPSEO(Request $request)
    {
        try{
            $sel_query = "SELECT * FROM job_post;"; 
            error_log($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                DB::beginTransaction();
                foreach ($res_query as $res){
                    DB::table('job_post')->where('jp_id', $res['jp_id'])->update([
                        'jp_SEO' => GeneralUtils::CreateSEO($res['jp_title']),
                    ]);
                }
                DB::commit();
                $result['outputObj'] = "Job Posts Fixed";
                return response()->json($result);

            }


        }catch(\Exception $ex){
            DB::rollback();
            $res['error'] = $ex->getMessage();
            return response()->json($res);
        }
    }

    /**
     * 
     */
    public function FixPUBSEO(Request $request)
    {
        try{
            $sel_query = "SELECT * FROM publication;"; 
            error_log($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                DB::beginTransaction();
                foreach ($res_query as $res){
                    DB::table('publication')->where('pub_id', $res['pub_id'])->update([
                        'pub_SEO' => GeneralUtils::CreateSEO($res['pub_title']),
                    ]);
                }
                DB::commit();
                $result['outputObj'] = "Publications Fixed";
                return response()->json($result);

            }


        }catch(\Exception $ex){
            DB::rollback();
            $res['error'] = $ex->getMessage();
            return response()->json($res);
        }
    }

    /**
     * 
     */
    public function subscriptionUpdates(Request $request){
        try{
            $today = date("Y-m-d") . " 00:00:00";
            $sel_query = "SELECT * FROM job_post where jp_approved=1 AND jp_closing_date > '$today;"; 
            error_log($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            $htmldata = "";

            if (count($res_query)) {
                $htmldata = $htmldata . "<h2>Latest Jobs</h2><hr>";
                foreach ($res_query as $res) {
                    $htmldata = $htmldata . '<table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                        <tr>
                            <td width="30%"><img src="'.asset($res['jp_org_logo']).'" alt="" style="width: 100%; max-width: 600px; height: auto; margin: auto; display: block;">
                            </td>
                            <td width="70%">
                                <table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                                    <tr>
                                        <td>
                                            <b>Global Youth Participation Specialist</b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Johnson & Johnson
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="'.url($res['jp_SEO']).'" target="_blank">View Detail</a>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>';
                }
            }
/*
<h2>Latest Jobs</h2>
                        <hr>
                        <table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                            <tr>
                                <td width="30%">
                                    <img src="{{asset('public/Images/2021060105235760b46562b7542.png')}}" alt="" style="width: 100%; max-width: 600px; height: auto; margin: auto; display: block;">
                                </td>
                                <td width="70%">
                                    <table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                                        <tr>
                                            <td>
                                                <b>Global Youth Participation Specialist</b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Johnson & Johnson
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <a href="{{url('/login')}}" target="_blank">View Detail</a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
*/

        }catch(\Exception $ex){
            DB::rollback();
            $res['error'] = $ex->getMessage();
            return response()->json($res);
        }
    }
}
