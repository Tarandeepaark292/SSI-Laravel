<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;

class PreviewController extends Controller
{
    //

    public function js_preview(Request $request, $url)
    {
        //dd($url);
        // if (!$request->session()->has('ssiapp_js_id')) {
        //     return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        // }
        try {
            // $keyfordecode = $request->session()->get('ssiapp_js_token');
            $js_obj = $url;
            // $js_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            // error_log($js_obj);
            $sel_query = "SELECT * from job_seeker where job_seeker.js_id = " . $js_obj;

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    'js_approved' => $res['js_approved'],
                    //  'js_adline' => $res['js_adline'],
                    //  'js_city' => $res['js_city'],
                    //  'js_state' => $res['js_state'],
                    //  'js_zip' => $res['js_zip'],
                    'js_number' => $res['js_number'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                    'js_sal' => is_null($res['js_salary']) ? "Not Set" : $res['js_salary'],
                    'js_totexp' => is_null($res['js_tot_exp']) ? "Not Set" : $res['js_tot_exp'],
                    'js_personal_info' => $res['js_personal_info'],                    
                );

                $js_loc_obj = json_decode($res['js_loc'], true);
                $js_edu_obj = json_decode($res['js_education'], true);
                $js_exp_obj = json_decode($res['js_experience'], true);
                if (!is_null($res['js_skills'])) {
                    $js_skill_list_obj = json_decode($res['js_skills'], true);//explode(',',$res['js_skills']);
                } else {
                    $js_skill_list_obj = [];
                }
                error_log($js_obj);
                //error_log($js_loc_obj[0]['addr_1']);
            }
            return view('jobseeker_preview', compact(['jp_obj', 'js_loc_obj', 'js_exp_obj', 'js_edu_obj','js_skill_list_obj']));

        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }

    }

    public function rec_jobpost_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $keyfordecode = $request->session()->get('ssiapp_rec_token');
        $jp_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
        error_log($jp_id);
        $sel_query = "SELECT * from job_post where job_post.jp_id = " . $jp_id;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);

            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'jp_id' => $res['jp_id'],
                    'jp_title' => $res['jp_title'],
                    'jp_loc' => $res['jp_loc'],
                    'jp_job_type' => $res['jp_job_type'],
                    'jp_ad_type_area_of_expertise' => $res['jp_ad_type_area_of_expertise'],
                    'jp_desc' => $res['jp_desc'],
                    'jp_app_email' => $res['jp_app_email'],
                    'jp_email' => $res['jp_email'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_org_twitter' => $res['jp_org_twitter'],
                    'jp_org_video' => $res['jp_org_video'],
                    'jp_closing_date' => $tempdate,
                    'jp_org_web' => $res['jp_org_web'],
                    'jp_status' => $status,
                    'jp_approved' => $res['jp_approved'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    
                );
            }
        return view('jobpost_preview',compact(['jp_obj']));
    }
    public function rfp_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $keyfordecode = $request->session()->get('ssiapp_rec_token');
        error_log($keyfordecode);
        // $jp_id = $url;
        $jp_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
        error_log($jp_id);
        $sel_query = "SELECT * from rfp where rfp_id = " . $jp_id;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);

            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_loc' => $res['rfp_loc'],
                    // 'rfp_job_type' => $res['rfp_job_type'],
                    // 'rfp_ad_type_area_of_expertise' => $res['rfp_ad_type_area_of_expertise'],
                    'rfp_desc' => $res['rfp_desc'],
                    'rfp_o_ach' => $res['rfp_o_ach'],
                    'rfp_email' => $res['rfp_email'],
                    'rfp_logo' => $res['rfp_logo'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_close_date' => $tempdate,
                    // 'rfp_close_date' => $res['rfp_close_date'],
                    // 'rfp_org_web' => $res['rfp_org_web'],
                    'rfp_status' => $status,
                    'rfp_cates' => GeneralUtils::getCateNames($res['rfp_category']),
                    
                );
            }
            // dd($jp_obj);
        return view('rfp_preview',compact(['jp_obj']));
    }

    public function fell_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $keyfordecode = $request->session()->get('ssiapp_rec_token');
        $jp_id = $url;
        $jp_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
        error_log($jp_id);
        $sel_query = "SELECT * from fellowship where fell_id = " . $jp_id;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['fell_end_date']);
            $tempdate = date("M d Y", $time);
            if ($res['fell_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'fell_id' => $res['fell_id'],
                'fell_o_name' => $res['fell_o_name'],
                'fell_title' => $res['fell_title'],
                // 'fell_job_type' => $res['fell_job_type'],
                // 'fell_ad_type_area_of_expertise' => $res['fell_ad_type_area_of_expertise'],
                // 'fell_end_date' => $res['fell_end_date'],
                'fell_end_date' => $tempdate,
                'fell_email' => $res['fell_email'],
                'fell_desc' => $res['fell_desc'],
                'fell_loc' => $res['fell_loc'],
                'fell_o_logo' => $res['fell_o_logo'],
                'fell_close_date' => $res['fell_end_date'],
                // 'fell_org_web' => $res['fell_org_web'],
                'fell_status' => $status,
                'fell_url' => $res['fell_url'],
                // 'fell_submitted_by' => $res['fell_submitted_by'],

            );
        }
        // dd($jp_obj);
        return view('fell_preview', compact(['jp_obj']));
    }

    public function scholarship_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $keyfordecode = $request->session()->get('ssiapp_rec_token');
        $jp_id = $url;
        $jp_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
        error_log($jp_id);
        $sel_query = "SELECT * from scholarship where sc_id = " . $jp_id;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['sc_end_date']);
            $tempdate = date("M d Y", $time);
            if ($res['sc_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'sc_id' => $res['sc_id'],
                'sc_o_name' => $res['sc_o_name'],
                'sc_title' => $res['sc_title'],
                
                'sc_end_date' => $tempdate,
                'sc_email' => $res['sc_email'],
                'sc_desc' => $res['sc_desc'],
                'sc_loc' => $res['sc_loc'],
                'sc_o_logo' => $res['sc_o_logo'],
                'sc_close_date' => $res['sc_end_date'],
                // 'fell_org_web' => $res['fell_org_web'],
                'sc_status' => $status,
                'sc_url' => $res['sc_url'],
                // 'fell_submitted_by' => $res['fell_submitted_by'],

            );
        }
        // dd($jp_obj);
        return view('scholarship_preview', compact(['jp_obj']));
    }

    public function grant_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $keyfordecode = $request->session()->get('ssiapp_rec_token');
        $jp_id = $url;
        $jp_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
        error_log($jp_id);
        $sel_query = "SELECT * from register_grants where reg_grant_id = " . $jp_id;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['reg_valid_To']);
            $tempdate = date("M d Y", $time);
            if ($res['reg_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'reg_grant_id' => $res['reg_grant_id'],
                'reg_o_name' => $res['reg_o_name'],
                // 'reg_title' => $res['reg_title'],
                'reg_v_org' => $res['reg_v_org'],
                'reg_o_mission' => $res['reg_o_mission'],
                'reg_o_ach' => $res['reg_o_ach'],
                'reg_o_head' => $res['reg_o_head'],
                'reg_o_pan' => $res['reg_o_pan'],
                'reg_o_tan' => $res['reg_o_tan'],
                'reg_80g' => $res['reg_80g'],
                'reg_fcra' => $res['reg_fcra'],
                'reg_website' => $res['reg_website'],
                'reg_valid_from' => $res['reg_valid_from'],
                // 'reg_valid_To' => $res['reg_valid_To'],
                'reg_valid_To' => $tempdate,
                'reg_cates' => GeneralUtils::getCateNames($res['reg_category']),
                'reg_email' => $res['reg_email'],

                'reg_status' => $status,
                // 'reg_submitted_by' => $res['reg_submitted_by'],

            );
        }
        // dd($jp_obj);
        return view('reg_preview', compact(['jp_obj']));
    }

    public function rec_csr_preview(Request $request, $url)
    {
        //dd($url);
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        try {
            $keyfordecode = $request->session()->get('ssiapp_rec_token');
            $csr_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            error_log($csr_id);
            $sel_query = "SELECT * from csr where csr.csr_id = " . $csr_id;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['csr_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                /*
                `csr_id` BIGINT(20) NOT NULL AUTO_INCREMENT,
                `csr_org` TEXT NOT NULL DEFAULT '0',
                `csr_loc` TEXT NOT NULL DEFAULT '0',
                `csr_g_amt` VARCHAR(127) NOT NULL DEFAULT '0',
                `csr_close_date` DATETIME NULL DEFAULT NULL,
                `csr_email` VARCHAR(255) NOT NULL DEFAULT '0',
                `csr_desc` TEXT NOT NULL DEFAULT '0',
                `csr_upload_doc` TEXT NOT NULL DEFAULT '0',
                `csr_logo` TEXT NOT NULL DEFAULT '0',
                `csr_category` TEXT NOT NULL DEFAULT '0',
                `csr_submitted_by` BIGINT(20) NOT NULL DEFAULT 0,
                `csr_approved` INT(11) NOT NULL DEFAULT 0,
                `csr_g_title` TEXT NOT NULL DEFAULT '0',
                `csr_ref_url` VARCHAR(255) NULL DEFAULT '',
                `csr_create_date` DATETIME NULL DEFAULT NULL,
                 */

                $csr_obj = array(
                    'csr_id' => $res['csr_id'],
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_org' => $res['csr_org'],
                    'csr_create_date' => $tempdate,
                    'csr_category' => $res['csr_category'],
                    'csr_status' => $status,
                    'csr_ref_url' => $res['csr_ref_url'],
                    'csr_logo' => $res['csr_logo'],
                    'csr_desc' => $res['csr_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'csr_approved' => $res['csr_approved'],
                    'csr_email' => $res['csr_email'],
                    'csr_loc' => $res['csr_loc'],
                    'csr_upload_doc' => $res['csr_upload_doc'],
                    'csr_cates' => GeneralUtils::getCateNames($res['csr_category']),
                );

            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('csr_preview', compact(['csr_obj']));

        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }

    }

    public function rec_rfp_preview(Request $request, $url)
    {
        //dd($url);
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        try {
            $keyfordecode = $request->session()->get('ssiapp_rec_token');
            $csr_id = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            error_log($csr_id);
            $sel_query = "SELECT * from rfp where rfp.rfp_id = " . $csr_id;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                // `rfp_id` BIGINT(20) NOT NULL AUTO_INCREMENT,
                // `rfp_org` TEXT NOT NULL DEFAULT '0',
                // `rfp_title` TEXT NOT NULL DEFAULT '0',
                // `rfp_loc` TEXT NOT NULL DEFAULT '0',
                // `rfp_g_amt` VARCHAR(127) NOT NULL DEFAULT '0',
                // `rfp_close_date` DATETIME NULL DEFAULT NULL,
                // `rfp_email` VARCHAR(255) NOT NULL DEFAULT '0',
                // `rfp_desc` TEXT NOT NULL DEFAULT '0',
                // `rfp_upload_doc` TEXT NOT NULL DEFAULT '0',
                // `rfp_logo` TEXT NOT NULL DEFAULT '0',
                // `rfp_category` TEXT NOT NULL DEFAULT '0',
                // `rfp_o_ach` TEXT NOT NULL DEFAULT '0',
                // `rfp_submitted_by` BIGINT(20) NOT NULL DEFAULT 0,
                // `rfp_approved` INT(11) NOT NULL DEFAULT 0,
                // `rfp_create_date` DATETIME NULL DEFAULT NULL,

                $jp_obj = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_loc' => $res['rfp_loc'],
                    'rfp_close_date' => $tempdate,
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_status' => $status,
                    'rfp_category' => $res['rfp_category'],
                    'rfp_email' => $res['rfp_email'],
                    'rfp_desc' => $res['rfp_desc'],
                    'rfp_o_ach' => $res['rfp_o_ach'],
                    'rfp_upload_doc' => $res['rfp_upload_doc'],
                    'rfp_logo' => $res['rfp_logo'],
                );

            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('rfp_preview', compact(['jp_obj']));

        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }

    }

    public function evt_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        try {
            $keyfordecode = $request->session()->get('ssiapp_rec_token');
            $jp_obj = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            error_log($jp_obj);
            $sel_query = "SELECT * from events where events.evt_id = " . $jp_obj;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_loc' => $res['evt_loc'],
                    'evt_end_date' => $tempdate,
                    // 'csr_category' => $res['csr_category'],
                    'evt_status' => $status,
                    // 'csr_ref_url' => $res['csr_ref_url'],
                    // 'csr_logo' => $res['csr_logo'],
                    'evt_desc' => $res['evt_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'evt_approved' => $res['evt_approved'],
                    'evt_email' => $res['evt_email'],
                    'evt_upload_banner' => $res['evt_upload_banner'],
                    'evt_org_logo' => $res['evt_org_logo'],
                    'evt_upload_doc' => $res['evt_upload_doc'],
                    'evt_ref_url' => $res['evt_ref_url'],
                );

            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('evt_preview', compact(['jp_obj']));

        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function awd_preview(Request $request, $url)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        try {
            $keyfordecode = $request->session()->get('ssiapp_rec_token');
            $jp_obj = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            error_log($jp_obj);
            $sel_query = "SELECT * from awards where awards.award_id = " . $jp_obj;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['award_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['award_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'award_id' => $res['award_id'],
                    'award_title' => $res['award_title'],
                    'award_org_name' => $res['award_org_name'],
                    'award_loc' => $res['award_loc'],
                    'award_end_date' => $tempdate,
                    // 'csr_category' => $res['csr_category'],
                    'award_status' => $status,
                    // 'csr_ref_url' => $res['csr_ref_url'],
                    // 'csr_logo' => $res['csr_logo'],
                    'award_desc' => $res['award_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'award_approved' => $res['award_approved'],
                    'award_email' => $res['award_email'],
                    'award_upload_banner' => $res['award_upload_banner'],
                    'award_org_logo' => $res['award_org_logo'],
                    'award_upload_doc' => $res['award_upload_doc'],
                    'award_ref_url' => $res['award_ref_url'],
                );

            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('award_preview', compact(['jp_obj']));

        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }
}
