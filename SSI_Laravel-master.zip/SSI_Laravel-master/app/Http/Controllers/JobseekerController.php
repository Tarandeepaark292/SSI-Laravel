<?php

namespace App\Http\Controllers;

use App\Utils\GeneralUtils;
use App\Utils\EmailUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Defines\CartDefines;
use App\Defines\RazorPayDefines;
use Exception;

class JobseekerController extends Controller
{
    //

    public function preview(Request $request)
    {
        return view('jobseeker_preview');
    }

    public function showDashboard(Request $request)
    {
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from job_seeker where job_seeker.js_id =" . $request->session()->get('ssiapp_js_id') . " ;";
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['js_bc_end_date']);
            $tempdate = date("F d Y, l", $time);
            $jsobj = array(
                'js_id' => $res['js_id'],
                'js_name' => $res['js_name'],
                'js_broadcast_resume' => $res['js_broadcast_resume'],
                'js_p_title' => $res['js_p_title'],
                'js_bc_end_date' => $tempdate,
                'js_photo' => $res['js_photo'],
                'js_id' => $res['js_id'],
                'js_sal' => is_null($res['js_salary']) ? "Not Set" : $res['js_salary'],
                'js_totexp' => is_null($res['js_tot_exp']) ? "Not Set" : $res['js_tot_exp'],
                'js_skills' => $res['js_skills'],
                'js_urlslist' => $res['js_urlslist'],
                'js_education' => $res['js_education'],
                'js_experience' => $res['js_experience'],
                'js_personal_info' => $res['js_personal_info'],
                'js_SEO' => $res['js_SEO'],
            );

            if (!is_null($res['js_urlslist'])) {
                $js_url_list_obj = json_decode($res['js_urlslist'], true);
            } else {
                $js_url_list_obj = [];
            }
            if (!is_null($res['js_education'])) {
                $js_edu_list_obj = json_decode($res['js_education'], true);
            } else {
                $js_edu_list_obj = [];
            }

            if (!is_null($res['js_experience'])) {
                $js_exp_list_obj = json_decode($res['js_experience'], true);
            } else {
                $js_exp_list_obj = [];
            }

            if (!is_null($res['js_skills'])) {
                $js_skill_list_obj = json_decode($res['js_skills'], true);//explode(',',$res['js_skills']);
            } else {
                $js_skill_list_obj = [];
            }
        } else {
            $jsobj = array();
        }



        return view('js_dash',compact(['jsobj','js_url_list_obj', 'js_edu_list_obj', 'js_exp_list_obj','js_skill_list_obj']));
    }

    public function broadcastResume(Request $request)
    {
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        //add item to shopping cart
        //then go to cart
        $service_data = GeneralUtils::getServiceDetail(11);
        $data['items'][] = $service_data;

        if ($request->session()->has('ssiapp_js_id')) {
            $data['utype'] = CartDefines::CART_USER_TYPE_JS;
            $result = GeneralUtils::createcart($request->session()->get('ssiapp_js_id'), $data);
        }

        if ($result != -1) {
            $request->session()->put('ssiapp_cart_id', $result);
            return \redirect('/js/showcart');
        } else {
            //error message
            error_log("dcsdvsfdvfsdvfsvfvfd");
        }
    }

    public function logout(Request $request)
    {
        $request->session()->forget(['ssiapp_js', 'ssiapp_js_id', 'ssiapp_js_token', 'ssiapp_js_name', 'ssiapp_cart_id']);
        return \redirect('/login');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'fname' => 'required',
            'email' => 'required|email',
            'lname' => 'required',
            'EmpPhone' => 'required|numeric',
            'password' => 'required',
            'repassword' => 'required',
        ]);
        $email = $request->input('email');
        $passwd = $request->input('password');
        $EmpPhone = $request->input('EmpPhone');
        $name = $request->input('fname') . ' ' . $request->input('lname');
        if (GeneralUtils::checkJobseekerExistEmail($email)) {
            $res['error'] = "Student not registered in the System";
            return \Redirect::back()->withErrors(['error_reason' => 'Account already exist']);
        }
        try {
            $js_seo = str_replace(" ", "-", $name);
            $js_seo = $js_seo . "-" . time();
            $createdate = date("Y-m-d H:i:s");
            DB::table('job_seeker')->insert([
                'js_name' => $name,
                'js_email' => $email,
                'js_number' => $EmpPhone,
                'js_pwd' => $passwd,
                'js_createdate' => $createdate,
                'js_SEO' => GeneralUtils::CreateSEO($name),
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            $data = array("js_name"=>$name, "js_email"=>$email,"js_pwd"=>$passwd,'js_phone'=>$EmpPhone);
            EmailUtils::NewAccountCreated($data,'JS',$email);
            return \redirect('/login');
        } catch (\Exception $ex) {
            DB::rollback();
            $res['error'] = "Can't login to System";
            error_log($ex);
            return \Redirect::back()->withErrors(['error_reason' => 'Problem in creating account']);
        }
    }



    public function jobseekerSubmit(Request $request)
    {
        error_log(json_encode($request));
        $jsname = $request->input('jsname');
        $jsemail = $request->input('jsemail');
        $jstitle = $request->input('jstitle');
        $jsareaofexpertise = $request->input('jsareaofexpertise');
        $jsaddrline1 = $request->input('jsaddrline1');
        $jsaddrline2 = $request->input('jsaddrline2');
        $jscity = $request->input('jscity');
        $jsstate = $request->input('jsstate');
        $jszip = $request->input('jszip');
        $jsvideos = $request->input('jsvideos');
        $jsskills = $request->input('jsskills');
        $expdivjson = $request->input('expdivjson');
        $edudivjson = $request->input('edudivjson');
        $urlsdivjson = $request->input('urlsdivjson');

        $personal = $request->input('resumedata');
        $personal = htmlspecialchars($personal);
        error_log(htmlspecialchars($personal));
        $location = array();
        $location['addr_1'] = $jsaddrline1;
        $location['addr_2'] = $jsaddrline2;
        $location['addr_city'] = $jscity;
        $location['addr_state'] = $jsstate;
        $location['addr_zip'] = $jszip;

        $locationstr = json_encode($location);

        // $jsresumefile = $request->file('jsresumefile');
        $jsphoto = $request->file('jsphoto');

        

        $src_photo = date('YmdHis') . $jsphoto->getClientOriginalName();
        //$dest_file_logo = public_path() . "/Images/";
        $jsphoto->move(public_path() . "/Images/", $src_photo);
        $dbjsphoto = "/public/Images/" . $src_photo;


        error_log("dsdsvsfv>>>>>>>" . json_encode($urlsdivjson));
        DB::beginTransaction();
        try {
            DB::update("update job_seeker set js_name='$jsname', js_photo='$dbjsphoto',js_personal_info = '$personal',
            js_p_title='$jstitle', js_loc='$locationstr', js_area_expertise='$jsareaofexpertise', js_vids = '$jsvideos',
            js_skills='$jsskills', js_education='$edudivjson', js_experience='$expdivjson', js_urlslist='$urlsdivjson'
             where js_id =" . $request->session()->get('ssiapp_js_id'));

            DB::commit();
        } catch (\Exception $ex) {
            DB::rollback();
            return \Redirect::back()->withErrors(['error_reason' => 'Can\'t Save information in System']);
        }

        return \redirect('/success');
    }

    public function paymentList(Request $request)
    {
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        //
        error_log($request->session()->get('ssiapp_js_id'));
        $sel_query = "SELECT *,job_seeker.js_name as r_name FROM payments INNER JOIN job_seeker on payments.pay_user_id = job_seeker.js_id WHERE payments.pay_user_type = 1 and payments.pay_user_id=" . $request->session()->get('ssiapp_js_id') . " ;";
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['pay_create_date']);
                $tempdate = date("M d Y", $time);
                $paylist[] = array(
                    'pay_id' => $res['pay_id'],
                    'pay_total' => $res['pay_total'],
                    'pay_provider_trans_id' => $res['pay_provider_trans_id'],
                    'pay_order_id' => $res['pay_order_id'],
                    'pay_create_date' => $tempdate,
                    'pay_by' => $res['r_name'],
                );
            }
        } else {
            $paylist = array();
        }

        return view('js_payment_list', compact(['paylist']));
    }

    public function purchaseList(Request $request)
    {
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_rec_token'));
        $sel_query = "SELECT *,job_seeker.js_name as r_name, payments.pay_order_id AS pay_order_id from purchases inner JOIN job_seeker on purchases.pur_user = job_seeker.js_id INNER JOIN payments ON payments.pay_id=purchases.pur_payment_id where purchases.pur_user =" . $request->session()->get('ssiapp_js_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['pur_used'] == 1) {
                    $status = 'Used';
                } else {
                    $status = 'Not Used';
                }
                $time = strtotime($res['pur_create_date']);
                $tempdate = date("M d Y", $time);
                $purchaselist[] = array(
                    'pur_id' => $res['pur_id'],
                    'pur_ser_name' => $res['pur_ser_name'],
                    'pur_ser_price' => $res['pur_ser_price'],
                    'status' => $status,
                    'order_id' => $res['pay_order_id'],
                    'pur_create_date' => $tempdate,
                    'pur_by' => $res['r_name'],
                );
            }
        } else {

            $purchaselist = array();
        }

        return view('js_purchase_list', compact(['purchaselist']));
    }

    public function JOB(Request $request)
    {
        $sel_query = "SELECT * from job_seeker;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log(json_encode($res));
                $joblist[] = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    'js_status' => $status,
                    'js_approved' => $res['js_approved'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                );
            }
        } else {
            $joblist = array();
        }
        return view('js_job_list', compact(['joblist']));
    }

    public function admJobListEdit(Request $request, $jspid)
    {
        $id = $jspid;
        $sel_query = "SELECT * from job_seeker where js_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $joblist = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    //  'js_adline' => $res['js_adline'],
                    //  'js_city' => $res['js_city'],
                    //  'js_state' => $res['js_state'],
                    //  'js_zip' => $res['js_zip'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                );
            }
        } else {
            $joblist = array();
        }
        return view('jobeditpage', compact(['joblist']));
    }



    public function updateResumeContent(Request $request, $jspid){
        $input = $request->all();
        $jspid = $jspid;

        \error_log(json_encode($input));
        DB::beginTransaction();
        try {
            $expdivjson = $request->input('expdivjson');
            $edudivjson = $request->input('edudivjson');
            $urlsdivjson = $request->input('urlsdivjson');
            $jsskills = $request->input('skillsdivjson');
            $jssalary = $request->input('jssalary');
            $jstotexp = $request->input('jstotexp');

            DB::table('job_seeker')->where('js_id', $jspid)->update([
                'js_education' => $edudivjson,
                'js_experience' => $expdivjson,
                'js_urlslist' => $urlsdivjson,
                'js_skills' => $jsskills,
                'js_salary' => $jssalary,
                'js_tot_exp' => $jstotexp,
            ]);
            //$id = DB::getPdo()->lastInsertId();
            DB::commit();
            return redirect('/js/dashboard');
        }catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();
            return response()->json($res);
        }
    }


   

    public function admJobListupdate(Request $request, $jspid)
    {

        $input = $request->all();
        $jspid = $jspid;

        \error_log(json_encode($input));
        DB::beginTransaction();
        try {
            $mgmtdate = date("Y-m-d H:i:s");

            // $expdivjson = $request->input('expdivjson');
            // $edudivjson = $request->input('edudivjson');
            // $urlsdivjson = $request->input('urlsdivjson');
            $jsaddrline1 = $request->input('jsaddrline1');
            $jsaddrline2 = $request->input('jsaddrline2');
            $jscity = $request->input('jscity');
            $jsstate = $request->input('jsstate');
            $jszip = $request->input('jszip');

            $jsvideos = $request->input('jsvideos');
            //$jsskills = $request->input('jsskills');
            $personal = $request->input('resumedata');
            $personal = htmlspecialchars($personal);
            $location = array();
            $location['addr_1'] = $jsaddrline1;
            $location['addr_2'] = $jsaddrline2;
            $location['addr_city'] = $jscity;
            $location['addr_state'] = $jsstate;
            $location['addr_zip'] = $jszip;
            $locationstr = json_encode($location);

            if ($request->hasFile('jsphoto')) {
                $logo = $request->file('jsphoto');
                error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
                $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
                $dest_file_logo = public_path() . "/Images/";
                $logo->move(public_path() . "/Images/", $src_file_logo);
                $db_name_jsphoto = "/public/Images/" . $src_file_logo;
            } else {
                $db_name_jsphoto = $request->input('old_jsphoto');
            }

            if ($request->hasFile('jsresume')) {
                $resume = $request->file('jsresume');
                $src_file_resume = date('YmdHis') . $resume->getClientOriginalName();
                $resume->move(public_path() . "/Resumes/", $src_file_resume);
                $db_name_jsresume = "/public/Resumes/" . $src_file_resume;
            }else{
                $db_name_jsresume = $request->input('old_jsresume');
            }



            DB::table('job_seeker')->where('js_id', $jspid)->update([
                'js_p_title' => $input['title'],
                'js_email' => $input['email'],
                'js_name' => $input['name'],
                // 'js_createdate' => $mgmtdate,
                'js_area_expertise' => $input['area'],
                'js_loc' => $locationstr,
                'js_photo' => $db_name_jsphoto,
                'js_vids' => $jsvideos,
                'js_resume_doc' => $db_name_jsresume,
                //'js_education' => $edudivjson,
                //'js_experience' => $expdivjson,
                //'js_urlslist' => $urlsdivjson,
                //'js_skills' => $jsskills,
                'js_personal_info' => $personal,

            ]);
            //$id = DB::getPdo()->lastInsertId();
            DB::commit();

            return redirect('/js/dashboard');
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }





        ////////////////////////////////////////////////////////////////
        // error_log(json_encode($request));
        // $jsname = $request->input('jsname');
        // $jsemail = $request->input('jsemail');
        // $jstitle = $request->input('jstitle');
        // $jsareaofexpertise = $request->input('jsareaofexpertise');
        // $jsaddrline1 = $request->input('jsaddrline1');
        // $jsaddrline2 = $request->input('jsaddrline2');
        // $jscity = $request->input('jscity');
        // $jsstate = $request->input('jsstate');
        // $jszip = $request->input('jszip');
        // $jsvideos = $request->input('jsvideos');
        // $jsskills = $request->input('jsskills');
        // $expdivjson = $request->input('expdivjson');
        // $edudivjson = $request->input('edudivjson');
        // $urlsdivjson = $request->input('urlsdivjson');

        // $personal = $request->input('resumedata');
        // $personal = htmlspecialchars($personal); 
        // error_log(htmlspecialchars($personal));
        // $location = array();
        // $location['addr_1'] = $jsaddrline1;
        // $location['addr_2'] = $jsaddrline2;
        // $location['addr_city'] = $jscity;
        // $location['addr_state'] = $jsstate;
        // $location['addr_zip'] = $jszip;

        // $locationstr = json_encode($location);

        // // $jsresumefile = $request->file('jsresumefile');
        // $jsphoto = $request->file('jsphoto');



        // $src_photo = date('YmdHis') . $jsphoto->getClientOriginalName();
        // //$dest_file_logo = public_path() . "/Images/";
        // $jsphoto->move(public_path() . "/Images/", $src_photo);
        // $dbjsphoto = "/public/Images/" . $src_photo;


        // error_log("dsdsvsfv>>>>>>>" . json_encode($urlsdivjson));
        // DB::beginTransaction();
        // try {
        //     DB::update("update job_seeker set js_name='$jsname', js_photo='$dbjsphoto',js_personal_info = '$personal',
        //     js_p_title='$jstitle', js_loc='$locationstr', js_area_expertise='$jsareaofexpertise', js_vids = '$jsvideos',
        //     js_skills='$jsskills', js_education='$edudivjson', js_experience='$expdivjson', js_urlslist='$urlsdivjson'
        //      where js_id =" . $request->session()->get('ssiapp_js_id'));

        //     DB::commit();
        // } catch (\Exception $ex) {
        //     DB::rollback();
        //     return \Redirect::back()->withErrors(['error_reason' => 'Can\'t Save information in System']);
        // }

        // return \redirect('/success');

    }

    public function show_change_password(Request $request){
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('js_change_password_page');
    }

    public function updatePassword(Request $request,$jspid){
        $id = $jspid;
        $input = $request->all();
        DB::beginTransaction();
        try{
            DB::table('job_seeker')->where('js_id', $jspid)->update([
                'js_pwd' => $input['newpassword'],
            ]);
            DB::commit();

            return redirect('/js/dashboard');
        }catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
        
    }

    public function show_shortlist_jobs(Request $request){
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT js_area_expertise from job_seeker where js_id=" . $request->session()->get('ssiapp_js_id');
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res_expertise = $res_query[0];

            $sel_query2 = "select * from job_post where job_post.jp_ad_type_area_of_expertise='" . $res_expertise['js_area_expertise'] ."' AND job_post.jp_approved = 1;";
            $res_query2 = DBraw::select($sel_query2);
            $res_query2 = json_decode(json_encode($res_query2), true);
            if (count($res_query2)) {
                foreach ($res_query2 as $res) {
                    $joblist[] = array(
                    'jp_id' => $res['jp_id'],
                    'jp_title' => $res['jp_title'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    'jp_SEO' => $res['jp_SEO'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_job_type' => $res['jp_job_type'],
                    'jp_job_type_str' => GeneralUtils::getJobType($res['jp_job_type']),
                    'jp_submitted_by' => $res['jp_submitted_by'],
                    );
                }
            }else{
                $joblist = array();
            }
            return view('js_shortlist',compact(['joblist']));
        }
    }

    public function applyjob(Request $request){
        $body = $request->all();
        $js_id = $request->session()->get('ssiapp_js_id');
        $jp_id = $body['job_id'];
        $r_id = $body['r_id'];
        try{
            
            $sel_query = "SELECT * from job_seeker where js_id = " . $js_id ;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $resjs = $res_query[0];
                if( is_null($resjs['js_resume_doc'])){
                    $res['res'] = 'FAIL';
                    $res['error'] ="Please Upload Resume to Apply for Job";
                    return response()->json($res);
                }
            }
            
            $sel_query = "SELECT * from job_apply where ja_js_id = " . $js_id . ' AND ja_job_id = ' . $jp_id ;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);

            if (count($res_query)) {
                $res['res'] = 'FAIL';
                $res['error'] ="Already Applied for Job";
                return response()->json($res);
            }
            DB::beginTransaction();
            $mgmtdate = date("Y-m-d H:i:s");
            DB::table('job_apply')->insert([
                'ja_js_id' => $js_id,
                'ja_job_id' => $jp_id,
                'ja_r_id' => $r_id,
                'ja_create_date' => $mgmtdate,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            return response()->json(array('res' => 'SUCCESS'));
        }catch(\Exception $ex){
            error_log($ex->getMessage());
            $res['res'] = 'FAIL';
            $res['error'] ="Problem in applying for job";
            return response()->json($res);
        }


    }

    public function show_job_resume_edit(Request $request, $jspid){
        $id = $jspid;
        $sel_query = "SELECT * from job_seeker where js_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];

            $jobseeker = array(
                'js_id' => $res['js_id'],
                'js_sal' => $res['js_salary'],
                'js_totexp' => $res['js_tot_exp'],
                'js_skills' => is_null($res['js_skills']) ? "[]" : $res['js_skills'],
                'js_urlslist' => is_null($res['js_urlslist']) ? "[]" : $res['js_urlslist'],
                'js_education' => is_null($res['js_education']) ? "[]" : $res['js_education'],
                'js_experience' => is_null($res['js_experience']) ? "[]" : $res['js_experience'],
            );

            if (!is_null($res['js_urlslist'])) {
                $js_url_list_obj = json_decode($res['js_urlslist'], true);
            } else {
                $js_url_list_obj = [];
            }
            if (!is_null($res['js_education'])) {
                $js_edu_list_obj = json_decode($res['js_education'], true);
            } else {
                $js_edu_list_obj = [];
            }

            if (!is_null($res['js_experience'])) {
                $js_exp_list_obj = json_decode($res['js_experience'], true);
            } else {
                $js_exp_list_obj = [];
            }

            if (!is_null($res['js_skills'])) {
                $js_skill_list_obj = json_decode($res['js_skills'], true);//explode(',',$res['js_skills']);
            } else {
                $js_skill_list_obj = [];
            }


        }
        return view('js_edit_resume_page', compact(['jobseeker','js_url_list_obj', 'js_edu_list_obj', 'js_exp_list_obj','js_skill_list_obj']));
    }


    public function show_rece_msgs(Request $request){
        if (!$request->session()->has('ssiapp_js_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        try{
            $msgs = GeneralUtils::getJSMEssages($request->session()->get('ssiapp_js_id'));
            return view('js_rec_msgs',compact(['msgs']));
        }catch(Exception $ex){
            dd($ex);
        }
    }

    public function show_job_edit(Request $request, $jspid)
    {
        $id = $jspid;
        $sel_query = "SELECT * from job_seeker where js_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $joblist = array(
                    'js_id' => $res['js_id'],
                    'js_name' => $res['js_name'],
                    'js_email' => $res['js_email'],
                    'js_p_title' => $res['js_p_title'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    // 'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    // 'js_resume_doc' => $res['js_resume_doc'],
                    'js_photo' => $res['js_photo'],
                    'js_status' => $status,
                    'js_approved' => $res['js_approved'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                    'js_urlslist' => is_null($res['js_urlslist']) ? "[]" : $res['js_urlslist'],
                    'js_education' => is_null($res['js_education']) ? "[]" : $res['js_education'],
                    'js_experience' => is_null($res['js_experience']) ? "[]" : $res['js_experience'],
                    'js_loc_obj' => json_decode($res['js_loc'], true),
                    'js_number' => $res['js_number'],
                    'js_personal_info' => $res['js_personal_info'],
                    'js_resume_doc' => $res['js_resume_doc'],
                    // 'js_id' => $res['js_id'],
                    // 'js_p_title' => $res['js_p_title'],
                    // 'js_email' => $res['js_email'],
                    // 'js_name' => $res['js_name'],
                    // 'js_createdate' => $tempdate,
                    //  'js_area_expertise' => $res['js_area_expertise'],
                    //  'js_loc' =>$res['js_loc'],
                    // //  'js_adline' => $res['js_adline'],
                    // //  'js_city' => $res['js_city'],
                    // //  'js_state' => $res['js_state'],
                    // //  'js_zip' => $res['js_zip'],
                    //  'js_vids' => $res['js_vids'],
                    // 'js_skills' => $res['js_skills'],
                );
                if (!is_null($res['js_loc'])) {
                    $js_loc_obj = json_decode($res['js_loc'], true);
                } else {
                    $js_loc_obj = array('addr_1' => '', 'addr_city' => '', 'addr_state' => '', 'addr_zip' => '');
                }
                //$js_loc_obj= json_decode($res['js_loc'],true);
                if (!is_null($res['js_urlslist'])) {
                    $js_url_list_obj = json_decode($res['js_urlslist'], true);
                } else {
                    $js_url_list_obj = [];
                }
                //$js_url_list_obj = json_decode($res['js_urlslist'],true);
                if (!is_null($res['js_education'])) {
                    $js_edu_list_obj = json_decode($res['js_education'], true);
                } else {
                    $js_edu_list_obj = [];
                }
                //$js_edu_list_obj = json_decode($res['js_education'],true);

                if (!is_null($res['js_experience'])) {
                    $js_exp_list_obj = json_decode($res['js_experience'], true);
                } else {
                    $js_exp_list_obj = [];
                }

                //$js_exp_list_obj = json_decode($res['js_experience'],true);

            }
        } else {
            $joblist = array();
        }
        return view('js_edit_page', compact(['joblist', 'js_loc_obj', 'js_url_list_obj', 'js_edu_list_obj', 'js_exp_list_obj']));
    }
}
