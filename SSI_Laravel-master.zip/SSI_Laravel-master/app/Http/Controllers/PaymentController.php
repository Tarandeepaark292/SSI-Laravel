<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\DB;
use DB as DBraw;
use App\Utils\GeneralUtils;
use App\Defines\CartDefines;
use App\Defines\RazorPayDefines;

class PaymentController extends Controller
{
    //
    public function testpay(Request $request)
    {
        $recruiter_detail = null;
        $js_detail = null;
        $user_details = array();
        if (!$request->session()->has('ssiapp_cart_id') ) {
            // return \redirect('error-page');
            $error_data = "<h1 style='font-size:32px;font-variant:all-petite-caps;'>The cart is Empty</h1>";
            return view('cart',compact(['error_data']));
        }
        
        if ($request->session()->has('ssiapp_rec_id') ) {
            $recruiter_detail = GeneralUtils::getRecruiterDetail($request->session()->get('ssiapp_rec_id'));
            $user_details['name'] = $recruiter_detail['r_name'];
            $user_details['email'] = $recruiter_detail['r_email'];
            $user_details['phone'] = $recruiter_detail['r_phone'];
        }else if($request->session()->has('ssiapp_js_id')){
            $js_detail = GeneralUtils::getJobseekerDetail($request->session()->has('ssiapp_js_id'));
            $user_details['name'] = $js_detail['js_name'];
            $user_details['email'] = $js_detail['js_email'];
            $user_details['phone'] = $js_detail['js_number'];
        }else{
            return \redirect('error-page');
        }
        
        $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
        $cart_items = json_decode($cart_detail['cart_data'],true);
        //$recruiter_detail = GeneralUtils::getRecruiterDetail(3);
        $rpaykey = RazorPayDefines::RP_KEY;
        $rpaysecret = RazorPayDefines::RP_SECRET;
        $api = new Api($rpaykey, $rpaysecret);
        $orderData = [
            'receipt' => uniqid(),
            'amount' => $cart_detail['cart_total'] * 100, // 2000 rupees in paise
            'currency' => 'INR',
            'payment_capture' => 1, // auto capture
        ];
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        error_log($razorpayOrderId);
        
        $data = [
            "key"               => $rpaykey,
            "amount"            => $cart_detail['cart_total'],
            "name"              => "SSI Service",
            "description"       => "SSI cart",
            "image"             => asset('/img/ssi_logo.svg'),
            "prefill"           => [
                "name"              => $user_details['name'],
                "email"             => $user_details['email'],
                "contact"           => $user_details['phone'],
            ],
            "notes"             => [
                "address"           => "Hello World",
                "merchant_order_id" => "cartId",
            ],
            "theme"             => [
                "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
            "shopping_order_id" => uniqid("SSI-"),
        ];
        

        //return view('tttt',compact(['data','cart_detail','cart_items']));
        return view('cart',compact(['data','cart_detail','cart_items']));

        //return \redirect('/success');
    }


    public function Postconfirmation(Request $request){
        error_log(json_encode($request->all()));
        error_log($_POST['razorpay_payment_id']);
//$cart_id,$user_id,$user_type,$orderid,$rpay_id
        
        if ($request->session()->has('ssiapp_rec_id') ) {
            $user_type = CartDefines::CART_USER_TYPE_REC;
            $user_id = $request->session()->get('ssiapp_rec_id');
        }else if( $request->session()->has('ssiapp_js_id') ){
            $user_type = CartDefines::CART_USER_TYPE_JS;
            $user_id = $request->session()->get('ssiapp_js_id');
        }
        $payid = GeneralUtils::createPaymentEntry($request->session()->get('ssiapp_cart_id'),$user_id,$user_type,$_POST['shopping_order_id'],$_POST['razorpay_payment_id'],$_POST['razorpay_order_id'],$_POST['shopping_amt']);
        if($payid != -1){
            return \redirect("/confirmation". '/' . $payid. '/' .$_POST['shopping_order_id']);
        }else{
            return \redirect('/error-page');
        }
        //return \redirect('/success');
/*
{"_token":"US37V5rnNiB2FIrHvdYaYPfEg8DrM8tTskDc47ns","shopping_order_id":"SSI-5f4d7b6be60b5","razorpay_payment_id":"pay_FXXMOINTlKjw1n","razorpay_order_id":"order_FXXM3W3HE0QIpv","razorpay_signature":"c1d9f8e60e6ee501df1b9af609fb8f9c3117806473035bb8f0591087a53b215a"}
[Tue Sep  1 04:06:49 2020] pay_FXXMOINTlKjw1n
*/


    }

    public function confirmation(Request $request,$purchaseid,$order_id){
        $cart_detail = [];
        if ($request->session()->has('ssiapp_cart_id') ) {
            $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
        }
        
        if ($request->session()->has('ssiapp_rec_id') ) {
            $user_type = CartDefines::CART_USER_TYPE_REC;
            $user_id = $request->session()->get('ssiapp_rec_id');
            $name = $request->session()->get('ssiapp_rec_name');
        }else if( $request->session()->has('ssiapp_js_id') ){
            $user_type = CartDefines::CART_USER_TYPE_JS;
            $user_id = $request->session()->get('ssiapp_js_id');
            $name = $request->session()->get('ssiapp_js_name');
        }

        $idarr = GeneralUtils::createPurchases($purchaseid, json_decode($cart_detail['cart_data'],true),$user_id,$user_type);

        if($request->session()->has('ssiapp_rec_id')){
            $purchased_items = json_decode($cart_detail['cart_data'],true);
            foreach($purchased_items as $ser){
                if($ser['itm_id'] == 14){
                    $pr_id = GeneralUtils::createPurchaseResumeEntry($ser['itm_resume_id'],$request->session()->get('ssiapp_rec_id'));
                    error_log("Purchased Resume Id ->".$pr_id);
                }else{
                    error_log("Not Purchase Resume ->".$ser['itm_id']);
                }
            }
        }

        error_log(json_encode($idarr));
        $request->session()->forget(['ssiapp_cart_id']);
        $payment = $cart_detail['cart_total'];
        $createdate = date("M d Y");
        
        return view('paymentconfirmation',compact(['payment','order_id','name','createdate']));
        //return \redirect('/success');
        //return \redirect('/success');
    }


    public function jsPostconfirmation(Request $request){
        error_log(json_encode($request->all()));
        error_log($_POST['razorpay_payment_id']);
//$cart_id,$user_id,$user_type,$orderid,$rpay_id
        
        if ($request->session()->has('ssiapp_rec_id') ) {
            $user_type = CartDefines::CART_USER_TYPE_REC;
            $user_id = $request->session()->get('ssiapp_rec_id');
        }else if( $request->session()->has('ssiapp_js_id') ){
            $user_type = CartDefines::CART_USER_TYPE_JS;
            $user_id = $request->session()->get('ssiapp_js_id');
        }
        $payid = GeneralUtils::createPaymentEntry($request->session()->get('ssiapp_cart_id'),$user_id,$user_type,$_POST['shopping_order_id'],$_POST['razorpay_payment_id'],$_POST['razorpay_order_id'],$_POST['shopping_amt']);
        if($payid != -1){
            return \redirect("/js/confirmation". '/' . $payid. '/' .$_POST['shopping_order_id']);
        }else{
            return \redirect('/error-page');
        }
      
    }

    public function js_confirmation(Request $request,$purchaseid,$order_id){
        $cart_detail = [];
        if ($request->session()->has('ssiapp_cart_id') ) {
            $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
        }
        
        if ($request->session()->has('ssiapp_js_id') ){
            $user_type = CartDefines::CART_USER_TYPE_JS;
            $user_id = $request->session()->get('ssiapp_js_id');
            $name = $request->session()->get('ssiapp_js_name');
        }

        $idarr = GeneralUtils::createPurchases($purchaseid, json_decode($cart_detail['cart_data'],true),$user_id,$user_type);
        error_log(json_encode($idarr));
        if(GeneralUtils::consumeBroadcastResume($user_id)){
            error_log("BroadcastSuccessfully");
        }
        $request->session()->forget(['ssiapp_cart_id']);
        $payment = $cart_detail['cart_total'];
        $createdate = date("M d Y");
        
        return view('paymentconfirmation',compact(['payment','order_id','name','createdate']));
        //return \redirect('/success');
        //return \redirect('/success');
    }


    // public function showcart(Request $request)
    // {
    //     if ($request->session()->has('ssiapp_cart_id') ) {
    //         $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
    //         $cart_items = json_decode($cart_detail['cart_data'],true);
    //         return view('cart',compact(['cart_detail','cart_items']));
    //     }
    // }

    public function showorganizercart(Request $request)
    {
        $recruiter_detail = null;
        $js_detail = null;
        $user_details = array();
        if (!$request->session()->has('ssiapp_cart_id') ) {
            // return \redirect('error-page');
            $error_data = "<h1 style='font-size:32px;font-variant:all-petite-caps;'>The cart is Empty</h1>";
            return view('organizer_cart',compact(['error_data']));
        }
        
        if ($request->session()->has('ssiapp_rec_id') ) {
            $recruiter_detail = GeneralUtils::getRecruiterDetail($request->session()->get('ssiapp_rec_id'));
            $user_details['name'] = $recruiter_detail['r_name'];
            $user_details['email'] = $recruiter_detail['r_email'];
            $user_details['phone'] = $recruiter_detail['r_phone'];
        }else if($request->session()->has('ssiapp_js_id')){
            // $js_detail = GeneralUtils::getJobseekerDetail($request->session()->has('ssiapp_js_id'));
            // $user_details['name'] = $js_detail['js_name'];
            // $user_details['email'] = $js_detail['js_email'];
            // $user_details['phone'] = $js_detail['js_number'];
            return \redirect('error-page');
        }else{
            return \redirect('error-page');
        }
        
        $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
        $cart_items = json_decode($cart_detail['cart_data'],true);
        //$recruiter_detail = GeneralUtils::getRecruiterDetail(3);
        $rpaykey = RazorPayDefines::RP_KEY;
        $rpaysecret = RazorPayDefines::RP_SECRET;
        $api = new Api($rpaykey, $rpaysecret);
        $orderData = [
            'receipt' => uniqid(),
            'amount' => $cart_detail['cart_total'] * 100, // 2000 rupees in paise
            'currency' => 'INR',
            'payment_capture' => 1, // auto capture
        ];
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        error_log($razorpayOrderId);
        
        $data = [
            "key"               => $rpaykey,
            "amount"            => $cart_detail['cart_total'],
            "name"              => "SSI Service",
            "description"       => "SSI cart",
            "image"             => asset('/img/ssi_logo.svg'),
            "prefill"           => [
                "name"              => $user_details['name'],
                "email"             => $user_details['email'],
                "contact"           => $user_details['phone'],
            ],
            "notes"             => [
                "address"           => "Hello World",
                "merchant_order_id" => "cartId",
            ],
            "theme"             => [
                "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
            "shopping_order_id" => uniqid("SSI-"),
        ];
        

        //return view('tttt',compact(['data','cart_detail','cart_items']));
        return view('organizer_cart',compact(['data','cart_detail','cart_items']));
    }

    public function showjscart(Request $request)
    {
        $recruiter_detail = null;
        $js_detail = null;
        $user_details = array();
        if (!$request->session()->has('ssiapp_cart_id') ) {
            // return \redirect('error-page');
            $error_data = "<h1 style='font-size:32px;font-variant:all-petite-caps;'>The cart is Empty</h1>";
            return view('cart',compact(['error_data']));
        }
        
        if($request->session()->has('ssiapp_js_id')){
            $js_detail = GeneralUtils::getJobseekerDetail($request->session()->has('ssiapp_js_id'));
            $user_details['name'] = $js_detail['js_name'];
            $user_details['email'] = $js_detail['js_email'];
            $user_details['phone'] = $js_detail['js_number'];
        }else{
            return \redirect('error-page');
        }
        
        $cart_detail = GeneralUtils::getCartDetails($request->session()->get('ssiapp_cart_id'));
        $cart_items = json_decode($cart_detail['cart_data'],true);
        //$recruiter_detail = GeneralUtils::getRecruiterDetail(3);
        $rpaykey = RazorPayDefines::RP_KEY;
        $rpaysecret = RazorPayDefines::RP_SECRET;
        $api = new Api($rpaykey, $rpaysecret);
        $orderData = [
            'receipt' => uniqid(),
            'amount' => $cart_detail['cart_total'] * 100, // 2000 rupees in paise
            'currency' => 'INR',
            'payment_capture' => 1, // auto capture
        ];
        $razorpayOrder = $api->order->create($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        error_log($razorpayOrderId);
        
        $data = [
            "key"               => $rpaykey,
            "amount"            => $cart_detail['cart_total'],
            "name"              => "SSI Service",
            "description"       => "SSI cart",
            "image"             => asset('/img/ssi_logo.svg'),
            "prefill"           => [
                "name"              => $user_details['name'],
                "email"             => $user_details['email'],
                "contact"           => $user_details['phone'],
            ],
            "notes"             => [
                "address"           => "Hello World",
                "merchant_order_id" => "cartId",
            ],
            "theme"             => [
                "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
            "shopping_order_id" => uniqid("SSI-"),
        ];
        

        //return view('tttt',compact(['data','cart_detail','cart_items']));
        return view('js_cart',compact(['data','cart_detail','cart_items']));
    }







    //ajax
    public function addtoCart(Request $request){
       
        $input = $request->all();
       
        if (!$request->session()->has('ssiapp_cart_id') ) {
            //generate cart
            $service_data = GeneralUtils::getServiceDetail($input['ser_id']);
            $data['items'][] = $service_data;

            $result = -1;
            if ($request->session()->has('ssiapp_rec_id') ) {
                $data['utype'] = CartDefines::CART_USER_TYPE_REC;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_rec_id'),$data);
            }else if( $request->session()->has('ssiapp_js_id') ){
                $data['utype'] = CartDefines::CART_USER_TYPE_JS;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_js_id'),$data);
            }
           
            error_log($result);
            if($result == -1){
                $res['res'] = 'FAIL';
                $res['error'] = "Cart not generated";
    
                return response()->json($res);
            }else{
                $request->session()->put('ssiapp_cart_id', $result);
                return response()->json(array('res'=>'SUCCESS','data'=>$result)); 
            }
            
        }else{
            //update cart
            error_log('UPDATE  dvdsvd CART ->>>' . $request->session()->get('ssiapp_cart_id'));
            $service_data = GeneralUtils::getServiceDetail($input['ser_id']);
            $data['items'][] = $service_data;
            $result = GeneralUtils::updatecart($request->session()->get('ssiapp_cart_id'),$data);
            if($result == -1){
                $res['res'] = 'FAIL';
                $res['error'] = "Cart not Updated";
    
                return response()->json($res);
            }else{
                return response()->json(array('res'=>'SUCCESS','data'=>$result)); 
            }
        }


    }


    public function addResumetoCart(Request $request){
       
        $input = $request->all();
       
        if (!$request->session()->has('ssiapp_cart_id') ) {
            //generate cart
            $service_data = GeneralUtils::getServiceDetail($input['ser_id']);
            $resume_id = $input['resume_js_id'];
            error_log("resumeid-> ". $resume_id);
            $data['items'][] = $service_data;

            $result = -1;
            if ($request->session()->has('ssiapp_rec_id') ) {
                $data['utype'] = CartDefines::CART_USER_TYPE_REC;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_rec_id'),$data,$resume_id);
            }else if( $request->session()->has('ssiapp_js_id') ){
                $data['utype'] = CartDefines::CART_USER_TYPE_JS;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_js_id'),$data,$resume_id);
            }
           
            error_log($result);
            if($result == -1){
                $res['res'] = 'FAIL';
                $res['error'] = "Cart not generated";
    
                return response()->json($res);
            }else{
                $request->session()->put('ssiapp_cart_id', $result);
                return response()->json(array('res'=>'SUCCESS','data'=>$result)); 
            }
            
        }else{
            //update cart
            error_log('UPDATE ResumeCART ->>>' . $request->session()->get('ssiapp_cart_id'));
            $service_data = GeneralUtils::getServiceDetail($input['ser_id']);
            $resume_id = $input['resume_js_id'];
            error_log("resumeid-> ". $resume_id);
            $data['items'][] = $service_data;
            $result = GeneralUtils::updatecart($request->session()->get('ssiapp_cart_id'),$data,$resume_id);
            if($result == -1){
                $res['res'] = 'FAIL';
                $res['error'] = "Cart not Updated";
    
                return response()->json($res);
            }else{
                return response()->json(array('res'=>'SUCCESS','data'=>$result)); 
            }
        }


    }

}
