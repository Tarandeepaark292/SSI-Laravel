<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BannerController extends Controller
{
    //

    public function submitBanner1(Request $request)
    {
        try{
            $link = $request->input('banner_1_link');
            $bid = $request->input('banner_1_id');
            if($request->hasFile('upload_banner_1')){
                $org_banner = $request->file('upload_banner_1');
                error_log("--->>" . $org_banner->getClientOriginalExtension() . public_path() . $org_banner->getClientOriginalName());
                $src_file_banner = date('YmdHis') . $org_banner->getClientOriginalName();
                $dest_file_banner = public_path() . "/Images/";
                $org_banner->move(public_path() . "/Images/", $src_file_banner);
                $banner = "/public/Images/". $src_file_banner;
    
            }else{
                $banner = $request->input('old_banner_1'); 
            }
            DB::beginTransaction();
            error_log('update banners set b_img_name="'.$banner.'",b_link="'.$link.'" where b_id ='.$bid);
            DB::update('update banners set b_img_name="'.$banner.'",b_link="'.$link.'" where b_id ='.$bid);
            DB::commit();
            return \redirect('/admin/banner-list');
        }catch(\Exception $ex){
            DB::rollback();
            error_log('exception' . $ex->getMessage());
        }

        

    }

    public function submitBanner2(Request $request)
    {

    }

    public function submitBanner3(Request $request)
    {

    }

    public function submitBanner4(Request $request)
    {

    }

    public function submitBanner5(Request $request)
    {

    }

    public function showBanners_View(Request $request)
    {
        try{
            $sel_query = "SELECT * from banners";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);

            /*
            `b_id`
	        `b_img_name` 
	        `b_link
            */
            if (count($res_query)) {
                foreach ($res_query as $res) {
                    $banner_arr[] = array(
                        'b_id' => $res['b_id'],
                        'b_img_name' => $res['b_img_name'],
                        'b_link' => $res['b_link'],
                    );
                }
            }else{
                $banner_arr = null;
            }

            return view('adm-all-banners', compact(['banner_arr']));

        }catch(\Exception $ex){
            error_log('exception' . $ex->getMessage());
        }
    }
}
