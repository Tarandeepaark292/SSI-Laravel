<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use App\Utils\EmailUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RecruiterController extends Controller
{
    public function show_change_password(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('rec_forgot_pwd');
    }

    public function show_edit_info(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT * FROM recruiter WHERE recruiter.r_id = " . $request->session()->get('ssiapp_rec_id');
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];

            $rec_obj = array(
                'r_id' => $res['r_id'],
                'r_name' => $res['r_name'],
                'r_email' => $res['r_email'],
                'r_phone' => $res['r_phone'],
                'r_org_name' => $res['r_org_name'],
                'r_off_lline_number' => $res['r_off_lline_number'],
                'r_off_website' => $res['r_off_website'],
                'r_org_pan' => $res['r_org_pan'],
                'r_info' => $res['r_info'],
                'r_org_logo' => $res['r_org_logo'],
                'r_pin' => $res['r_pin'],
                'r_comp_type' => $res['r_comp_type'],
            );
        }else{
            $rec_obj = array();
        }
        return view('rec_edit_info',compact(['rec_obj']));
    }

    public function updatePassword(Request $request,$recid){
        $id = $recid;
        $input = $request->all();
        DB::beginTransaction();
        try{
            DB::table('recruiter')->where('r_id', $recid)->update([
                'r_pwd' => $input['newpassword'],
            ]);
            DB::commit();

            return redirect('/recruiter/dashboard');
        }catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
        
    }

    public function updateProfile(Request $request,$recid){
        $input = $request->all();
        DB::beginTransaction();

        if ($request->hasFile('r_logo')) {
            $logo = $request->file('r_logo');
            error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $logo->move(public_path() . "/Images/", $src_file_logo);
            $db_name_jsphoto = "/public/Images/" . $src_file_logo;
        } else {
            $db_name_jsphoto = $request->input('old_r_logo');
        }
        try{
            DB::table('recruiter')->where('r_id', $recid)->update([
                
                'r_name' => $input['r_name'],
                'r_email' => $input['email'],
                'r_phone' => $input['r_phone'],
                'r_org_name' => $input['org_name'],
                'r_off_lline_number' => $input['off_phone'],
                'r_off_website' => $input['website'],
                'r_org_pan' => $input['r_pan'],
                'r_info' => htmlspecialchars($input['r_info']),
                'r_org_logo' => $db_name_jsphoto,
                'r_pin' => $input['r_pin'],
                'r_comp_type' => $input['company-type'],
            ]);
            DB::commit();

            return redirect('/recruiter/dashboard');
        }catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function logout(Request $request)
    {
        $request->session()->forget(['ssiapp_rec', 'ssiapp_rec_id', 'ssiapp_rec_token', 'ssiapp_rec_name', 'ssiapp_cart_id']);
        return \redirect('/organization/login');
    }

    public function paymentList(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        //
        error_log($request->session()->get('ssiapp_rec_token'));
        $sel_query = "SELECT *,recruiter.r_name as r_name FROM payments INNER JOIN recruiter on payments.pay_user_id = recruiter.r_id WHERE payments.pay_user_type = 2 and payments.pay_user_id=" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['pay_create_date']);
                $tempdate = date("M d Y", $time);
                $paylist[] = array(
                    'pay_id' => $res['pay_id'],
                    'pay_total' => $res['pay_total'],
                    'pay_provider_trans_id' => $res['pay_provider_trans_id'],
                    'pay_order_id' => $res['pay_order_id'],
                    'pay_create_date' => $tempdate,
                    'pay_by' => $res['r_name'],
                );
            }
        }else {
            $paylist = array();
        }

        return view('rec_payment_list', compact(['paylist']));
    }

    public function purchaseList(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_rec_token'));
        $sel_query = "SELECT *,recruiter.r_name as r_name, payments.pay_order_id AS pay_order_id from purchases inner JOIN recruiter on purchases.pur_user = recruiter.r_id INNER JOIN payments ON payments.pay_id=purchases.pur_payment_id where purchases.pur_user =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['pur_used'] == 1) {
                    $status = 'Used';
                } else {
                    $status = 'Not Used';
                }
                $time = strtotime($res['pur_create_date']);
                $tempdate = date("M d Y", $time);
                $purchaselist[] = array(
                    'pur_id' => $res['pur_id'],
                    'pur_ser_name' => $res['pur_ser_name'],
                    'pur_ser_price' => $res['pur_ser_price'],
                    'status' => $status,
                    'order_id' => $res['pay_order_id'],
                    'pur_create_date' => $tempdate,
                    'pur_by' => $res['r_name'],
                );
            }
        } else {

            $purchaselist = array();

        }

        return view('rec_purchase_list', compact(['purchaselist']));
    }

    public function csr_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_rec_token'));
        // $q = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        // error_log($q);
        $sel_query = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['csr_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['csr_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $csrlist[] = array(
                    'csr_id' => $res['csr_id'],
                    'csr_enc_id' => $enc_id,
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_org' => $res['csr_org'],
                    'csr_create_date' => $tempdate,
                    'csr_submitted_by' => $res['r_name'],
                    'csr_status' => $status,
                    'csr_approved' => $res['csr_approved'],
                    'csr_SEO' => $res['csr_SEO'],
                );
            }
        } else {
            $csrlist = array();
        }
        return view('rec_csr_list', compact(['csrlist']));
    }

    public function fell_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from fellowship inner join recruiter on fellowship.fell_submitted_by = recruiter.r_id  where fellowship.fell_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['fell_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['fell_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $felllist[] = array(
                    'fell_id' => $res['fell_id'],
                    'fell_title' => $res['fell_title'],
                    'fell_email' => $res['fell_email'],
                    'fell_o_name' => $res['fell_o_name'],
                    'fell_end_date' => $tempdate,
                    'fell_submitted_by' => $res['r_name'],
                    'fell_status' => $status,
                    'fell_enc_id' => $enc_id,
                    'fell_approved' => $res['fell_approved'],
                    'fell_SEO' => $res['fell_SEO'],

                    
                );
            }
        } else {
            $felllist = array();
        }
        return view('rec_fell_list', compact(['felllist']));
    }

    public function sc_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from scholarship inner join recruiter on scholarship.sc_submitted_by = recruiter.r_id  where scholarship.sc_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['sc_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['sc_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['sc_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $sclist[] = array(
                    'sc_id' => $res['sc_id'],
                    'sc_title' => $res['sc_title'],
                    'sc_email' => $res['sc_email'],
                    'sc_o_name' => $res['sc_o_name'],
                    'sc_end_date' => $tempdate,
                    'sc_submitted_by' => $res['r_name'],
                    'sc_status' => $status,
                    'sc_enc_id' => $enc_id,
                    'sc_approved' => $res['sc_approved'],
                    'sc_SEO' => $res['sc_SEO'],
                );
            }
        } else {
            $sclist = array();
        }
        return view('rec_sc_list', compact(['sclist']));
    }

    public function evt_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from events inner join recruiter on events.evt_submitted_by = recruiter.r_id where events.evt_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['evt_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $evtlist[] = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_email' => $res['evt_email'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_end_date' => $tempdate,
                    'evt_submitted_by' => $res['r_name'],
                    'evt_enc_id' => $enc_id,
                    'evt_status' => $status,
                    'evt_approved' => $res['evt_approved'],
                    'evt_SEO' => $res['evt_SEO'],
                );
            }
        } else {
            $evtlist = array();
        }
        return view('rec_evt_list', compact(['evtlist']));
    }

    public function awd_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from awards inner join recruiter on awards.award_submitted_by = recruiter.r_id where awards.award_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['award_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['award_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['award_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $awardlist[] = array(
                    'award_id' => $res['award_id'],
                    'award_title' => $res['award_title'],
                    'award_email' => $res['award_email'],
                    'award_org_name' => $res['award_org_name'],
                    'award_end_date' => $tempdate,
                    'award_submitted_by' => $res['r_name'],
                    'award_enc_id' => $enc_id,
                    'award_status' => $status,
                    'award_loc' => $res['award_loc'],
                    'award_approved' => $res['award_approved'],
                    'award_SEO' => $res['award_SEO'],
                );
            }
        } else {
            $awardlist = array();
        }
        return view('rec_award_list', compact(['awardlist']));
    }

    public function rfp_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from rfp inner join recruiter on rfp.rfp_submitted_by = recruiter.r_id where rfp.rfp_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['rfp_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $rfplist[] = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_close_date' => $tempdate,
                    'rfp_enc_id' => $enc_id,
                    'rfp_submitted_by' => $res['r_name'],
                    'rfp_status' => $status,
                    'rfp_approved' => $res['rfp_approved'],
                    'rfp_SEO' => $res['rfp_SEO'],
                );
            }
        } else {
            $rfplist = array();
        }
        return view('rec_rfp_list', compact(['rfplist']));
    }

    public function rgrant_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from register_grants inner join recruiter on register_grants.reg_submitted_by = recruiter.r_id where register_grants.reg_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['reg_valid_To']);
                $tempdate = date("M d Y", $time);
                if ($res['reg_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['reg_grant_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $reglist[] = array(
                    'reg_grant_id' => $res['reg_grant_id'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_email' => $res['reg_email'],
                    'reg_website' => $res['reg_website'],
                    'reg_o_name' => $res['reg_o_name'],
                    'reg_valid_To' => $tempdate,
                    'reg_submitted_by' => $res['r_name'],
                    'reg_enc_id' => $enc_id, 
                    'reg_status' => $status,
                    'reg_approved' => $res['reg_approved'],
                    'reg_SEO' => $res['reg_SEO'],
                );
            }
        } else {
            $reglist = array();
        }
        return view('rec_reg_list', compact(['reglist']));
    }

    public function job_post_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name  from job_post inner join recruiter on job_post.jp_submitted_by = recruiter.r_id where job_post.jp_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['jp_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $reclist[] = array(
                    'jp_id' => $res['jp_id'],
                    'jp_enc_id' => $enc_id,
                    'jp_title' => $res['jp_title'],
                    'jp_email' => $res['jp_email'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_close_date' => $tempdate,
                    'jp_submitted_by' => $res['r_name'],
                    'jp_status' => $status,
                    'jp_approved' => $res['jp_approved'],
                    'jp_SEO' => $res['jp_SEO'],
                );
            }
        } else {
            $reclist = array();
        }
        return view('rec_jobpost_list', compact(['reclist']));
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'org_name' => 'required',
            'emailaddress' => 'required|email',
            'contactperson' => 'required',
            'mobile' => 'required|numeric',
            'passwd' => 'required',
            'company-type' => 'required',
            'pincode' => 'required',
        ]);
        $email = $request->input('emailaddress');
        $passwd = $request->input('passwd');
        $EmpPhone = $request->input('mobile');
        $name = $request->input('contactperson');
        $org_name = $request->input('contactperson');
        $pincode = $request->input('pincode');
        $website = $request->input('website');
        $org_pan = $request->input('org_pan');
        $officelandline = $request->input('officelandline');
        $company_type = $request->input('company-type');

        $from = $request->input('from');

        if (GeneralUtils::checkRecruiterExistEmail($email)) {
            $res['error'] = "Account already exist";
            return \Redirect::back()->withErrors(['error_reason' => 'Account already exist']);
        }
        try {

            $createdate = date("Y-m-d H:i:s");
            DB::table('recruiter')->insert([
                'r_name' => $name,
                'r_email' => $email,
                'r_phone' => $EmpPhone,
                'r_pwd' => $passwd,
                'r_createdate' => $createdate,
                'r_org_name' => $org_name,
                'r_org_pan' => $org_pan,
                'r_pin' => $pincode,
                'r_off_website' => $website,
                'r_off_lline_number' => $officelandline,
                'r_comp_type' => $company_type,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            $data = array("org_name"=>$name, "org_email"=>$email,"org_pwd"=>$passwd,'org_phone'=>$EmpPhone);
            EmailUtils::NewAccountCreated($data,'ORG',$email);
            if($from == "organization_register"){
                return \redirect('/organization/login');
            }else{
                return \redirect('/login');
            }
            
        } catch (\Exception $ex) {
            DB::rollback();
            $res['error'] = "Can't login to System";
            return \Redirect::back()->withErrors(['error_reason' => 'Problem in creating account']);
        }
    }

    // public function logout(Request $request){
    //     $request->session()->forget(['ssiapp_rec', 'ssiapp_rec_id', 'ssiapp_rec_token']);
    //     return \redirect('/login');
    // }

    //Employer Panel

    public function csr_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_rec_token'));
        // $q = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" .$request->session()->get('ssiapp_rec_id')." ;";
        // error_log($q);
        $sel_query = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id where csr.csr_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['csr_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['csr_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $csrlist[] = array(
                    'csr_id' => $res['csr_id'],
                    'csr_enc_id' => $enc_id,
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_org' => $res['csr_org'],
                    'csr_create_date' => $tempdate,
                    'csr_submitted_by' => $res['r_name'],
                    'csr_status' => $status,
                    'csr_approved' => $res['csr_approved'],
                );
            }
        } else {
            $csrlist = array();
        }
        return view('emp_csr_list', compact(['csrlist']));
    }

    public function fell_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from fellowship inner join recruiter on fellowship.fell_submitted_by = recruiter.r_id  where fellowship.fell_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['fell_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $felllist[] = array(
                    'fell_id' => $res['fell_id'],
                    'fell_title' => $res['fell_title'],
                    'fell_email' => $res['fell_email'],
                    'fell_o_name' => $res['fell_o_name'],
                    'fell_end_date' => $tempdate,
                    'fell_submitted_by' => $res['r_name'],
                    'fell_status' => $status,
                    'fell_approved' => $res['fell_approved'],
                );
            }
        } else {
            $felllist = array();
        }
        return view('emp_fell_list', compact(['felllist']));
    }


    public function jobapp_list(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $r_id = $request->session()->get('ssiapp_rec_id');
        $sel_query = "SELECT * from job_apply where ja_r_id = " . $r_id ;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        
        if (count($res_query)) {
            $results = [];
            foreach ($res_query as $res) {
                $jobseekerDetail = GeneralUtils::getJobseekerDetail($res['ja_js_id']);
                $jobDetail = GeneralUtils::getJobDetail($res['ja_job_id']);
                $results[] = array(
                    'job' => $jobDetail,
                    'jobseeker' => $jobseekerDetail
                );
            }
        } else {
            $results = null;
        }
        error_log(json_encode($results));
        return view('rec_applicant_list', compact(['results']));

    }

    public function resumes_list(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $r_id = $request->session()->get('ssiapp_rec_id');
        $sel_query = "SELECT * from job_seeker where js_broadcast_resume = 1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        
        if (count($res_query)) {
            $results = [];
            foreach ($res_query as $res) {
                $results[] = array(
                    'js_id' => $res['js_id'],
                    'js_name' => $res['js_name'],
                    'js_email' => $res['js_email'],
                    'js_resume_doc' => $res['js_resume_doc'],
                    'js_number' => $res['js_number'],
                    'js_photo' => $res['js_photo'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_p_title' => $res['js_p_title'],
                    'js_SEO' => $res['js_SEO'],
                    );
            }
        } else {
            $results = null;
        }
        error_log(json_encode($results));
        return view('rec_b_resume_list', compact(['results']));

    }

    public function purchased_resume_view(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $r_id = $request->session()->get('ssiapp_rec_id');
        $sel_query = "select * from purchased_resumes INNER join job_seeker on job_seeker.js_id = purchased_resumes.p_r_js_id where purchased_resumes.p_r_rec_id = " . $r_id;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        
        if (count($res_query)) {
            $results = [];
            foreach ($res_query as $res) {
                $time = strtotime($res['p_r_exp_date']);
                $tempdate = date("M d Y", $time);
                $enc_SEO = GeneralUtils::encrypt_id($res['js_SEO'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                $results[] = array(
                    'js_id' => $res['js_id'],
                    'js_name' => $res['js_name'],
                    'js_email' => $res['js_email'],
                    'js_resume_doc' => $res['js_resume_doc'],
                    'js_number' => $res['js_number'],
                    'js_photo' => $res['js_photo'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_p_title' => $res['js_p_title'],
                    'js_SEO' => $enc_SEO,//$res['js_SEO'],
                    'p_r_exp_date' => $tempdate
                    );
            }
        } else {
            $results = null;
        }
        error_log(json_encode($results));
        return view('rec_purchased_resume', compact(['results']));

    

    }

    public function shop_resume_view(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        
        $sel_query = "SELECT * from job_seeker;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $results = [];
            foreach ($res_query as $res) {
                
                $results[] = array(
                    'js_id' => $res['js_id'],
                    'js_name' => $res['js_name'],
                    'js_email' => $res['js_email'],
                    'js_resume_doc' => $res['js_resume_doc'],
                    'js_number' => $res['js_number'],
                    'js_photo' => $res['js_photo'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_p_title' => $res['js_p_title'],
                    'js_SEO' => $res['js_SEO'],
                    );
            }
        } else {
            $results = null;
        }
        error_log(json_encode($results));
        return view('rec_shop_resume', compact(['results']));

    }

    public function ajaxfilterjobseeker(Request $request)
    {
        try{
        $body = $request->all();
        error_log(json_encode($body));
        // error_log($body['search']);
        // error_log($body['location']);
        $notfound = false;
        if ($body['cate'] != '-1') {
            // error_log("qwe");
            $sel_query = "SELECT * from job_seeker where js_area_expertise  LIKE   '%" . $body['cate'] . "%'";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }
        
        if(!$notfound){
            $sel_query = "SELECT * from job_seeker;";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
        }

        // error_log(json_encode($res['js_loc']));
        $img = asset('img/ssi_logo.svg');
        $data = '';
        if (count($res_query)) {
            foreach ($res_query as $res) {
                
                // error_log(json_decode(json_encode($res['js_loc']),true));
                // $loca = json_decode($res['js_loc'], true);

                
                    $time = strtotime($res['js_createdate']);
                    $tempdate = date("F d Y, l", $time);
                    $img = isset($res['js_photo']) ? $res['js_photo'] : 'img/profile-avatar.png';
                    $data = $data . '<div class="col-md-3" style="margin-top:1rem;">
                    <div class="card" style="box-shadow: #b7b6bb 2px 2px 5px;height: 471px;">
                        <div class="row">
                            <div class="col-md-12" style="text-align: center;">
                                <img src="'.asset($img).'" style="width: 275px;
                                height: 286px;" />
                            </div>
                            <div class="col-md-12">
                                <h5 style="text-align: center; "><b>'.$res['js_name'].'</b></h5>
                                <h6 style="text-align: center;">'.$res['js_p_title'].'</h6>
                                <span style="font-size: 14px;display: block;text-align: center;">'.$res['js_area_expertise'].'</span>
                                <div style="display: flex;justify-content: center;">
                                    <a href="#" onclick="addResumeTocart(14,'.$res['js_id'].')" class="btn btn-info" style="text-align: center;">Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';

                     error_log($data);

                
            }
            return response()->json(array('res' => 'SUCCESS', 'data' => $data));
        } else {
            // $rfpsearch = array();
            $res['res'] = 'FAIL';
            $res['error'] = '
        <div class="col-md-12">
        <div class="resultss" style="font-weight: bold;font-size: 20px;">No Resumes found</div>
        </div>';
            return response()->json($res);
        }
    }catch (\Exception $ex) {
        error_log($ex->getMessage());
        $res['res'] = 'FAIL';
        return response()->json($res);
    }

        // return view('all-ads',compact(['rfpsearch']));

    }

    public function evt_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from events inner join recruiter on events.evt_submitted_by = recruiter.r_id where events.evt_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['evt_create_date']);
                $tempdate = date("M d Y", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $evtlist[] = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_email' => $res['evt_email'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_create_date' => $tempdate,
                    'evt_submitted_by' => $res['r_name'],
                    'evt_status' => $status,
                    'evt_approved' => $res['evt_approved'],
                );
            }
        } else {
            $evtlist = array();
        }
        return view('emp_evt_list', compact(['evtlist']));
    }

    public function rfp_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from rfp inner join recruiter on rfp.rfp_submitted_by = recruiter.r_id where rfp.rfp_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // error_log(json_encode($res_query));

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $rfplist[] = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_close_date' => $tempdate,
                    'rfp_submitted_by' => $res['r_name'],
                    'rfp_status' => $status,
                    'rfp_approved' => $res['rfp_approved'],
                );
            }
        } else {
            $rfplist = array();
        }
        return view('emp_rfp_list', compact(['rfplist']));
    }



    public function online_courselist(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from  onlinecourse where onlinecourse.on_submitted_by =" . $request->session()->get('ssiapp_rec_id');
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['rfp_close_date']);
                // $tempdate = date("M d Y", $time);
                if ($res['on_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $onlist[] = array(
                    'on_id' => $res['on_id'],
                    'status' => $status,
                    'on_media' => $res['on_media'],
                    'on_email' => $res['on_email'],
                    'on_institute' => $res['on_institute'],
                    'on_approved' => $res['on_approved'],

                );
            }
        } else {
            $onlist = array();
        }
        return view('rec_online_course_list', compact(['onlist']));
    }


    public function pub_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT * from  publication";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['rfp_close_date']);
                // $tempdate = date("M d Y", $time);
                if ($res['pub_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $publist[] = array(
                    'pub_id' => $res['pub_id'],
                    'pub_name' => $res['pub_name'],
                    'pub_focusarea' => $res['pub_focusarea'],
                    'pub_media' => $res['pub_media'],
                    'pub_title' => $res['pub_title'],
                    'pub_email' => $res['pub_email'],
                    'pub_approved' => $res['pub_approved'],
                    // 'rfp_close_date' => $tempdate,
                    'pub_submitted_by' => $res['pub_submitted_by'],
                    // 'rfp_status' => $status,
                    // 'rfp_approved' => $res['rfp_approved'],
                );
            }
        } else {
            $publist = array();
        }
        return view('rec_pub_list', compact(['publist']));
    }

    public function rgrant_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name from register_grants inner join recruiter on register_grants.reg_submitted_by = recruiter.r_id where register_grants.reg_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['reg_valid_To']);
                $tempdate = date("M d Y", $time);
                if ($res['reg_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $reglist[] = array(
                    'reg_grant_id' => $res['reg_grant_id'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_email' => $res['reg_email'],
                    'reg_website' => $res['reg_website'],
                    'reg_valid_To' => $tempdate,
                    'reg_submitted_by' => $res['r_name'],
                    'reg_status' => $status,
                    'reg_approved' => $res['reg_approved'],
                );
            }
        } else {
            $reglist = array();
        }
        return view('emp_reg_list', compact(['reglist']));
    }

    public function job_post_list1(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT *,recruiter.r_name as r_name  from job_post inner join recruiter on job_post.jp_submitted_by = recruiter.r_id where job_post.jp_submitted_by =" . $request->session()->get('ssiapp_rec_id') . " ;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $enc_id = GeneralUtils::encrypt_id($res['jp_id'], $request->session()->get('ssiapp_rec_token'), SecurityDefines::MANAGEMENT_ID_CIPHER);
                error_log($enc_id);
                $reclist[] = array(
                    'jp_id' => $res['jp_id'],
                    'jp_enc_id' => $enc_id,
                    'jp_title' => $res['jp_title'],
                    'jp_email' => $res['jp_email'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_close_date' => $tempdate,
                    'jp_submitted_by' => $res['r_name'],
                    'jp_status' => $status,
                    'jp_approved' => $res['jp_approved'],
                );
            }
        } else {
            $reclist = array();
        }
        return view('emp_jobpost_list', compact(['reclist']));
    }

    public function post_csr(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('post_csr', compact(['html']));
    }

    public function post_event(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('post_event', compact(['html']));
    }

    public function post_fellowship(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        
        return view('post_fellowship', compact(['html']));
    }

    public function post_RFP(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('post_rfp', compact(['html']));
    }

    public function post_reg_grant(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate/3));
        $division = round($total_cate/3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html.='<input type="checkbox" class="proposal_chk" id="proposal_chk'.$res['cate_id'].'" name="proposal_chk[]" value="'.$res['cate_id'].'" onclick="onchkclick();">
                <label for="proposal_chk'.$res['cate_id'].'"> '.$res['cate_name'].'</label><br>';
                $count ++;
                $total_count--;
                if($count == $division){
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('post_grant', compact(['html']));
    }

    public function post_JobPost(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        
        $sel_query = "SELECT * from recruiter where  r_id=".session()->get('ssiapp_rec_id')." ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];
            // if ($res['pb_approved'] == 1) {
            //     $status = 'Approved';
            // } else {
            //     $status = 'On Hold';
            // }

            $jp_obj = array(
                'r_id' => $res['r_id'],

                'r_org_ame' => $res['r_org_name'],
                'r_off_website' => $res['r_off_website'],
                'r_org_logo' => $res['r_org_logo'],
                // 'r_off_website' => $res['r_off_website'],


            );
        } else {
        }

        return view('post_jobpost',compact(['jp_obj']));
    }

    public function purchasableitems(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('rec_items');
    }

    public function post_donate(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('post_donate');
    }

    public function post_award(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('rec_post_award', compact(['html']));
    }

    public function post_scholarship(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('rec_post_scholarship', compact(['html']));
    }

    public function post_onlinecourse(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('rec_online_course');
    }

    public function post_publication(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM publication_category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        
        
        //error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['p_cat_id'] . '" name="proposal_chk[]" value="' . $res['p_cat_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['p_cat_id'] . '"> ' . $res['p_cat_name'] . '</label><br>';
                $count++;
                $total_count --;
                if ($count == $division) {
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }

        $sel_query = "SELECT * FROM publication_focus;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html2 = "";
        $temp_html2 = "";
        $total_count = count($res_query);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html2 .= '<input type="checkbox" class="proposal_focus_chk" id="proposal_focus_chk' . $res['p_f_id'] . '" name="proposal_focus_chk[]" value="' . $res['p_f_id'] . '" onclick="onchkclick2();">
                <label for="proposal_focus_chk' . $res['p_f_id'] . '"> ' . $res['p_f_name'] . '</label><br>';
                $count++;
                $total_count --;
                if ($count == $division) {
                    $html2 .= $div_beg . $temp_html2 . $div_end;
                    $temp_html2 = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html2 .= $div_beg . $temp_html2 . $div_end;
                    //error_log($html);
                    $temp_html2 = '';
                }
            }
        }

        return view('rec_post_publication', compact(['html','html2']));
        //return view('rec_post_publication', compact(['html']));
    }

    public function post_admission(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('rec_post_admission');
    }

    public function post_callpaper(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('rec_post_callpaper');
    }

    public function loadDashboard(Request $request){
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT (SELECT COUNT(*) FROM rfp where rfp_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalrfps,
        (SELECT COUNT(*) FROM csr where csr_submitted_by = " . $request->session()->get('ssiapp_rec_id') . " ) AS totalcsr,
        (SELECT COUNT(*) FROM fellowship where fell_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalfells,
        (SELECT COUNT(*) FROM scholarship where sc_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalscholarships,
        (SELECT COUNT(*) FROM events where evt_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalevts,
        (SELECT COUNT(*) FROM awards where award_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalawards,
        (SELECT COUNT(*) FROM register_grants where reg_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalgrants,
        (SELECT COUNT(*) FROM admission where adn_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totaladmissions,
        (SELECT COUNT(*) FROM call_paper where paper_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalpapers,
        (SELECT COUNT(*) FROM onlinecourse where on_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalcourses,
        (SELECT COUNT(*) FROM publication where pub_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totalpublications,

        (SELECT COUNT(*) FROM job_post where jp_submitted_by = " . $request->session()->get('ssiapp_rec_id') . ") AS totaljps";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $dashObj = array(
                'totalrfps'=>$res['totalrfps'],
                'totalcsr'=>$res['totalcsr'],
                'totalfells'=>$res['totalfells'],
                'totalscholarships'=>$res['totalscholarships'],
                'totalevts'=>$res['totalevts'],
                'totalawards'=>$res['totalawards'],
                'totalgrants'=>$res['totalgrants'],
                'totaladmissions'=>$res['totaladmissions'],
                'totalpapers'=>$res['totalpapers'],
                'totalcourses'=>$res['totalcourses'],
                'totalpublications'=>$res['totalpublications'],
                'totaljps'=>$res['totaljps'],

            );
        }

        $sel_query2 = "SELECT * FROM recruiter where r_id = " . $request->session()->get('ssiapp_rec_id') . ";";
        $res_query2 = DBraw::select($sel_query2);
        $res_query2 = json_decode(json_encode($res_query2), true);
        if (count($res_query2)) {
            $res = $res_query2[0];
            $rec_obj = array(
                'r_org_name' => $res['r_org_name'],
                'r_email' => $res['r_email'],
                'r_name' => $res['r_name'],
                'r_phone' => $res['r_phone'],
                'r_comp_type' => $res['r_comp_type'],
                'r_off_website' => is_null($res['r_off_website']) ? "Not Set" : $res['r_off_website'],
                'r_org_pan' => is_null($res['r_org_pan']) ? "Not Set" : $res['r_org_pan'],
                'r_id' => $res['r_id'],
                'r_org_logo' => $res['r_org_logo'],
                'r_off_lline_number' => is_null($res['r_off_lline_number']) ? "Not Set" : $res['r_off_lline_number'],
            );
        }else{
            $rec_obj = array();
        }

        return view('rec_dash', compact(['dashObj','rec_obj']));
    }

    public function rec_admission_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_rec_id')) {
            return \redirect('/organization/login')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from admission where adn_submitted_by = " . $request->session()->get('ssiapp_rec_id') ;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $time = strtotime($res['js_createdate']);
               
                if ($res['adn_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log(json_encode($res));
                $adnsearch[] = array(
                    'adn_id' => $res['adn_id'],
                    'adn_title' => $res['adn_title'],
                    'adn_inst_name' => $res['adn_inst_name'],
                    'adn_apply' => $res['adn_apply'],
                    'adn_cost_details' => $res['adn_cost_details'],
                    // 'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    'adn_area' =>$res['adn_area'],
                    'adn_display_page' =>$res['adn_display_page'],
                    'adn_email' => $res['adn_email'],
                    'adn_state' => $res['adn_state'],
                    'adn_year' => $res['adn_year'],
                    'adn_website_url' => $res['adn_website_url'],
                    'adn_mediaurl' => $res['adn_mediaurl'],
                    'adn_submitted_by' => $res['adn_submitted_by'],
                    'adn_approved' => $res['adn_approved'],
                   
                );
               
            }
        } else {
            $adnsearch = array();
        }
        return view('rec_admission_list', compact(['adnsearch']));
    }

    public function allrecruiters(Request $request){
        $sel_query = "SELECT seo_data from SEO where seo_id = 23;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('recruiters', compact(['seodata']));
    }

    public function sendMsg(Request $request){
        $input = $request->all();
        $msg_data = array("data" => $input['data'],"by" => $input['by'], "to" => $input['to']);

        if(GeneralUtils::saveMsgFromRecruiter($msg_data)){
            return response()->json(array('res' => 'SUCCESS', 'data' => "Message Send Successfully"));
        }
        return response()->json(array('res' => 'FAIL', 'data' => "Unable to send Message"));
    }
}
