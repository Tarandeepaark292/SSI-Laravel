<?php

namespace App\Http\Controllers;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Utils\GeneralUtils;
class FellowshipController extends Controller
{
    public function getFellowship(Request $request)
    {
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        error_log($html);
        return view('post-fellowship', compact(['html']));

    }

    public function submitFellowship(Request $request)
    {
        $body = $request->all();
        $fellowship_title = $request->input('title');
        $org_logo = $request->file('org_logo');
        $fell_seo = str_replace(" ","-",$fellowship_title);
        $fell_seo = $fell_seo . "-" . time();

        $email = $request->input('email');
        $org_name = $request->input('name');
        
        $location = $request->input('location');
        $dead_date = $request->input('deadlinedate');
        $desc_textarea = $request->input('desc_textarea');
        $document = $request->file('upload');
        $url = $request->input('url');
        $cates = $request->input('cates');
        // $closingdate = $request->input('closingdate');
        // $ref_url = $request->input('url');
        // $cates = $request->input('cates');
        if($request->has('upload'))
        {
            $document = $request->file('upload');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }


        error_log("--->>" . $org_logo->getClientOriginalExtension() . public_path() . $org_logo->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_logo->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_logo->move(public_path() . "/Images/", $src_file_logo);
        $image = "/public/Images/" . $src_file_logo;

        // $cate_text = "";
        // foreach ($body['cates'] as $cates) {
        //     $cate_text = $cate_text . ',';
        // }
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('fellowship')->insert([
            'fell_o_name' => $org_name,
            'fell_loc' => $location,
            'fell_title' => $fellowship_title,
            'fell_o_logo' => $image,
            'fell_email' => $email,
            'fell_end_date' => $dead_date,
            'fell_desc' => $desc_textarea,
            'fell_cate' => $cates,
            'fell_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'fell_approved' => 0,
            'fell_upload_doc' => $document,
            'fell_url' => $url,
            'fell_SEO' => GeneralUtils::CreateSEO($fellowship_title),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,3)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function fellads(Request $request)
    {
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from fellowship where fell_approved = 1 and fell_end_date > '$today'  order by fell_id DESC";
        //$sel_query = "SELECT * from fellowship where fell_approved = 1 order by fell_id DESC";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                error_log(json_encode($res));
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("F d Y, l", $time);
                $fellsearch[] = array(
                    'fell_o_name' => $res['fell_o_name'],
                    'fell_title' => $res['fell_title'],
                    'fell_loc' => $res['fell_loc'],
                    'fell_o_logo' => $res['fell_o_logo'],
                    // 'rfp_g_amt' => $res['rfp_g_amt'],
                    'fell_end_date' => $tempdate,
                    'fell_SEO' => $res['fell_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $fellsearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 15;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        $cates = GeneralUtils::getDBCates();
        return view('all-fellowship', compact(['fellsearch','seodata','cates']));
    }

    public function ajaxfell(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from fellowship where fell_title  LIKE   '%" . $body['search'] . "%' or fell_o_name  LIKE   '%" . $body['search'] . "%' and fell_cate LIKE '%". $body['cate']."%' and fell_end_date > '$today';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['fell_approved'] == 1) {
                    $time = strtotime($res['fell_end_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content fell_search_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                <div class="col-md-2  results" style="text-align: center;">
                <img style="width:80%" src=' . asset($res['fell_o_logo']) . ' />
                </div>
                <div class="col-md-8">
                <div class="results limittext" style="font-weight: bold;color:#004a99">' . $res['fell_title'] . '</div>
                <div id="results" style="font-weight: bold;color:#004a99">
                ' . $res['fell_o_name'] . '
                </div>
                <div id="results">
                    <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;" >' . $res['fell_loc'] . '</span>

                </div>
                <div id="results">
                    <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <span style="font-weight: bold;color:#00254d;">' . $tempdate . ' </span>
                </div>
            </div>
            <div class="col-md-2 my-auto ">
                                   
            <a href="' .url('/fell/') .'/'. $res['fell_SEO']. '" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
        </div>
            <div class="col-md-2 my-auto " >

                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        
                                        ';

                                        $htmldata = $htmldata . $data;
                }

            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }

    //                 error_log($data);

    //                 $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));

    //             } else {
    //                 $res['error'] = '<div class="col-md-2  results" style="text-align: center;">
    //                 <img src=' . $img . ' />
    //                 </div>
    //                 <div class="col-md-8">
    //             <div class="resultss" style="font-weight: bold;font-size: 20px;">you have no Fellowship ads</div>';
    //                 $mydata = response()->json($res);
    //             }

    //         }
    //         return $mydata;
    //     } else {
    //         // $rfpsearch = array();
    //         $res['res'] = 'fail';
    //         return response()->json($res);
    //     }
    // }

}
