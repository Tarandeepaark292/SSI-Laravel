<?php

namespace App\Http\Controllers;


use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DonateController extends Controller
{
    //
    public function Donate(Request $request)
    {
        $summary = $request->input('summary');
        $totalgoals = $request->input('totalgoals');
        $title = $request->input('title');
        $org_name = $request->input('org_name');
        $remaining = $request->input('remaining');
        //$donors = $request->input('donors');
        //$monthlydonors = $request->input('monthlydonors');
        $fundraisers = $request->input('fundraisers');
        //$years = $request->input('years');
        $challenge = $request->input('challenge');
        $solution = $request->input('solution');
        $longterm = $request->input('longterm');
        $document = $request->file('document');
        $referenceurl = $request->input('referenceurl');
        $organisationlogo = $request->file('organisationlogo');
        $organisationdetail = $request->input('organisationdetail');
        $location = $request->input('location');
        $website = $request->input('website');
        $category = $request->input('category'); //state
        $focusarea = $request->input('focusarea');
        $banner = $request->file('banner');
        $chkouturl = $request->input('chkouturl');
        // $file = $request->file('company_logo');

        //error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
        $src_document = date('YmdHis') . $document->getClientOriginalName();
        //$dest_document = public_path() . "/document/";
        $document->move(public_path() . "/document/", $src_document);
        $document = "/public/document/" . $src_document;

        //error_log("--->>" . $organisationlogo->getClientOriginalExtension() . public_path() . $organisationlogo->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $organisationlogo->getClientOriginalName();
        //$dest_file_logo = public_path() . "/Images/";
        $organisationlogo->move(public_path() . "/Images/", $src_file_logo);
        $organisationlogo = "/public/Images/" . $src_file_logo;

        error_log("--->>" . $banner->getClientOriginalExtension() . public_path() . $banner->getClientOriginalName());
        $src_banner_logo = date('YmdHis') . $banner->getClientOriginalName();
        //$dest_file_logo = public_path() . "/Images/";
        $banner->move(public_path() . "/Images/", $src_banner_logo);
        $banner = "/public/Images/" . $src_banner_logo;
        $donate_seo = str_replace(" ", "-", $title);
        $donate_seo = $donate_seo . "-" . time();
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('donate')->insert([
            'donate_summary' => $summary,
            'donate_total_goal' => $totalgoals,
            'donate_remaining' => $remaining,
            'donate_fundraiser' => $fundraisers,
            'donation_title' => $title,
            'donate_org_name' => $org_name,
            'donate_challenge' => $challenge,
            'donate_solution' => $solution,
            'donate_long_impact' => $longterm,
            'donate_additional_documentation' => $document,
            'donate_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'donate_approved' => 0,
            'donate_ref_url' => $referenceurl,
            'donate_logo' => $organisationlogo,
            'donate_org_detail' => $organisationdetail,
            'donate_loc' => $location,
            'donate_website' => $website,
            'donation_banner' => $banner,
            'donate_state' => $category,
            'donate_foc_area' => $focusarea,
            'donate_SEO' => $donate_seo,
            'donate_checkout_url' => $chkouturl,
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/success');
    }

    public function ajaxDonate(Request $request)
    {
        $body = $request->all();
        // error_log($body['search']);
        $sel_query = "SELECT * from donate where donate_foc_Area LIKE   '%" . $body['focus'] . "%' and donate_state LIKE   '%" . $body['state'] . "%'";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['donate_approved'] == 1) {

                    $data = '
                        <div class="col-12 " style="margin-bottom:2rem;">

                        <div class="card content fell_search_item"  id="results">
                            <div class="card-body" id="results">
                                <div class="row " id="resultss">
                        <div class="col-md-2  results" style="text-align: center;">
                        <img  style="width:80%" src=' . asset($res['donate_logo']) . ' />
                        </div>
                        <div class="col-md-8">
                        <div class="results" style="font-weight: bold;font-size: 20px;">' . $res['donation_title'] . '</div>
                        <div id="results">
                        ' . $res['donate_org_name'] . '
                        </div>
                        <div id="results">
                            <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;font-size:16px;" >' . $res['donate_state'] . ' </span>

                        </div>
                        <div id="results">
                            <span style="font-weight: bold;color:#007bff;font-size:16px;" >' . $res['donate_foc_Area'] . ' </span>

                            </div>
                                
                                
                            </div>
                            <div class="col-md-2 my-auto " >
                                                    
                                                </div>
                                                </div>
                                                </div>
                                                </div>
                                                </div>
                                                ';

                    
                    $htmldata = $htmldata . $data;
                    //$mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));
                } 
                // else {
                //     $res['error'] = '<div class="col-md-2  results" style="text-align: center;">
                //     <img src=' . $img . ' />
                //     </div>
                //     <div class="col-md-8">
                // <div class="resultss" style="font-weight: bold;font-size: 20px;">you have donation</div>';
                //     return response()->json($res);
                // }
            }
            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }

    public function Donates(Request $request)
    {

        $sel_query = "SELECT * from donate where donate_approved = 1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['donate_years']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $donatesearch[] = array(
                    'donate_logo' => $res['donate_logo'],
                    'donate_solution' => $res['donate_solution'],
                    'donate_org_detail' => $res['donate_org_detail'],
                    'donate_state' => $res['donate_state'],
                    'donate_years' => $tempdate,
                    'donate_monthly_donors' => $res['donate_monthly_donors'],
                    'donate_foc_Area' => $res['donate_foc_Area'],
                    'donate_SEO' => $res['donate_SEO'],

                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $donatesearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 32;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('donate', compact(['donatesearch','seodata']));
    }

    public function update_donate(Request $request, $encid)
    {
        $summary = $request->input('summary');
        $totalgoals = $request->input('totalgoals');
        $title = $request->input('title');
        $org_name = $request->input('org_name');
        $remaining = $request->input('remaining');
        //$donors = $request->input('donors');
        //$monthlydonors = $request->input('monthlydonors');
        $fundraisers = $request->input('fundraisers');
        //$years = $request->input('years');
        $challenge = $request->input('challenge');
        $solution = $request->input('solution');
        $longterm = $request->input('longterm');
        $document = $request->file('document');
        $referenceurl = $request->input('referenceurl');
        $organisationlogo = $request->file('organisationlogo');
        $organisationdetail = $request->input('organisationdetail');
        $location = $request->input('location');
        $website = $request->input('website');
        $category = $request->input('category'); //state
        $focusarea = $request->input('focusarea');
        $banner = $request->file('banner');
        $chkouturl = $request->input('chkouturl');



        if($request->hasFile('banner')){
            $banner = $request->file('banner');
            error_log("--->>" . $banner->getClientOriginalExtension() . public_path() . $banner->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $banner->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $banner->move(public_path() . "/Images/", $src_file_logo);
            $banner = "public/Images/". $src_file_logo;

        }else{
            $banner = $request->input('old_banner'); 
        } 

     
        if($request->hasFile('organisationlogo')){
            $organisationlogo = $request->file('organisationlogo');
            error_log("--->>" . $organisationlogo->getClientOriginalExtension() . public_path() . $organisationlogo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $organisationlogo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $organisationlogo->move(public_path() . "/Images/", $src_file_logo);
            $organisationlogo = "public/Images/". $src_file_logo;

        }else{
            $organisationlogo = $request->input('old_organisationlogo'); 
        } 


        
        if($request->hasFile('document')){
            $document = $request->file('document');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = $request->input('old_document');
        }




        DB::beginTransaction();

        try {
            DB::table('donate')->where('donate_id', $encid)->update([
                'donate_summary' => $summary,
            'donate_total_goal' => $totalgoals,
            'donate_remaining' => $remaining,
            'donate_fundraiser' => $fundraisers,
            'donation_title' => $title,
            'donate_org_name' => $org_name,
            'donate_challenge' => $challenge,
            'donate_solution' => $solution,
            'donate_long_impact' => $longterm,
            'donate_additional_documentation' => $document,
            'donate_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            // 'donate_approved' => 0,
            'donate_ref_url' => $referenceurl,
            'donate_logo' => $organisationlogo,
            'donate_org_detail' => $organisationdetail,
            'donate_loc' => $location,
            'donate_website' => $website,
            'donation_banner' => $banner,
            'donate_state' => $category,
            'donate_foc_area' => $focusarea,
            // 'donate_SEO' => $donate_seo,
            'donate_checkout_url' => $chkouturl,

                //'fell_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                //'fell_cate' =>$cates,
                // 'evt_upload_banner' => $db_name_banner,
            ]);
            DB::commit();
            return \redirect('/admin/donation_list');
        } catch (\Exception $ex) {
            dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function show_donation_Detail(Request $request, $encid)
    {
        try {

            $sel_query = "SELECT * from donate where donate.donate_id  = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];


                $jp_obj = array(
                    'donate_id' => $res['donate_id'],
                    'donation_title' => $res['donation_title'],
                    'donation_banner' => $res['donation_banner'],
                    'donate_Summary' => $res['donate_Summary'],
                    // 'fell_end_date' => $tempdate,
                    'donate_total_goal' => $res['donate_total_goal'],

                    // 'fell_status' => $status,

                    'donate_remaining' => $res['donate_remaining'],
                    'donate_donors' => $res['donate_donors'],
                    'donate_monthly_donors' => $res['donate_monthly_donors'],
                
                    'donate_fundraiser' => $res['donate_fundraiser'],
                    'donate_years' => $res['donate_years'],
                
                    'donate_challenge' => $res['donate_challenge'],
                    'donate_solution' => $res['donate_solution'],
                
                    'donate_long_impact' => $res['donate_long_impact'],
                    'donate_additional_documentation' => $res['donate_additional_documentation'],
                
                    'donate_ref_url' => $res['donate_ref_url'],
                    'donate_logo' => $res['donate_logo'],
                
                
                    'donate_org_detail' => $res['donate_org_detail'],
                    'donate_org_name' => $res['donate_org_name'],
                
                    'donate_loc' => $res['donate_loc'],
                    'donate_website' => $res['donate_website'],
                
                    'donate_state' => $res['donate_state'],
                    'donate_foc_Area' => $res['donate_foc_Area'],
                
                    'donate_checkout_url' => $res['donate_checkout_url'],
                    // 'donate_website' => $res['donate_website'],
                


                );
                // $html = GeneralUtils::createHTML_for_selected_cate($res['donate_foc_Area']);
            } else {
                //  $csrlist = array();
                //errorView
            }

            return view('adm_donation_edit', compact(['jp_obj']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

}
