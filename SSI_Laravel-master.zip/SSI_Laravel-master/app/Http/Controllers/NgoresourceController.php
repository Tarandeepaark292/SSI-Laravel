<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class NgoresourceController extends Controller
{
    //

    public function getresources(Request $request){
        $sel_query = "SELECT * from NgoResource where ngo_r_id  = 1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $ngolist = array(
                    'ngo_r_img' => $res['ngo_r_img'],
                    'ngo_r_title' => $res['ngo_r_title'],
                    'ngo_r_id'=>$res['ngo_r_id'],
                    'ngo_r_data'=>json_decode($res['ngo_r_data'],true),
                );
                // dd($ngolist);

            }
        }
        else{
            $ngolist = array(); 

        }
        return view('adm_resource',compact(['ngolist']));


    }


    public function submitadminngo(Request $request){
        $ngo_id = $request->input("ngo_resource_id");
        $title = $request->input('title');
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $file = "/public/Images/" . $src_file_logo;
        } else {
            $file = $request->input('old_image');
        }

        try{
            DB::beginTransaction();
            DB::table('NgoResource')->where('ngo_r_id', $ngo_id)->update([
                'ngo_r_title' => $title,
                'ngo_r_img' => $file,
            ]);
            DB::commit();

        } catch (\Exception $ex) {
            dd($ex);
        }
        
        return \redirect('/admin/ngoresource');
    }

    public function adminngodocuments(Request $request){

        $title = $request->input('title');
        $ngodoc = $request->file('ngo_doc');
        $doc_uuid = uniqid("ID", true);
        $ngo_id = $request->input("ngo_resource_id");

        error_log("--->>" . $ngodoc->getClientOriginalExtension() . public_path() . $ngodoc->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $ngodoc->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $ngodoc->move(public_path() . "/Images/", $src_file_logo);
        $ngodoc = "/public/Images/" . $src_file_logo;

        

        $document_arr = GeneralUtils::getNGOdocs($ngo_id); //array();
        $document_arr[] = array("id"=>$doc_uuid, "doc"=>$ngodoc, "title"=>$title);
        // $document_arr[]['doc'] = $ngodoc;
        // $document_arr[]['title'] = $title;
       
        $document_json = json_encode($document_arr);
        
        try{
            DB::beginTransaction();
            // DB::table('NgoResource')->insert([
            //     'ngo_r_data' => $document_json,
            //     'ngo_r_img'=>$file,
            // ]);

            DB::table('NgoResource')->where('ngo_r_id', $ngo_id)->update([
                'ngo_r_data' => $document_json,
            ]);
            DB::commit();

        } catch (\Exception $ex) {
            dd($ex);
        }
        
        return \redirect('/admin/ngoresource');
     
    }
    
}
