<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Logincontroller extends Controller
{
     public function index(Request $req){

        // return $req->input();
$req->session()->put('data',$req->input());
if($req->session()->has('data')){
    return redirect('myaccount');
}


    }
}
?>
