<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SeoController extends Controller
{
    //


    public function js_enc_SEO(Request $request, $url)
    {

        try {
            $keyfordecode = $request->session()->get('ssiapp_rec_token');
            $js_obj = GeneralUtils::decrypt_id($url, $keyfordecode, SecurityDefines::MANAGEMENT_ID_CIPHER);
            //$js_obj = $url;

            $sel_query = "SELECT * from job_seeker where job_seeker.js_SEO = '" . $js_obj . "'";

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    'js_approved' => $res['js_approved'],
                    'js_photo' => (!isset($res['js_photo']) || empty($res['js_photo'])) ? "img/profile-avatar.png" : $res['js_photo'],
                    'js_number' => $res['js_number'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                    'js_sal' => is_null($res['js_salary']) ? "Not Set" : $res['js_salary'],
                    'js_totexp' => is_null($res['js_tot_exp']) ? "Not Set" : $res['js_tot_exp'],
                    'js_personal_info' => $res['js_personal_info'],
                );

                $js_loc_obj = json_decode($res['js_loc'], true);
                $js_edu_obj = json_decode($res['js_education'], true);
                $js_exp_obj = json_decode($res['js_experience'], true);
                if (!is_null($res['js_skills'])) {
                    $js_skill_list_obj = json_decode($res['js_skills'], true); //explode(',',$res['js_skills']);
                } else {
                    $js_skill_list_obj = [];
                }
                error_log($js_obj);
            } else {
                //dd('333');
                //return redirect('/404');
                abort(404);
            }
            return view('js_seo', compact(['jp_obj', 'js_loc_obj', 'js_exp_obj', 'js_edu_obj', 'js_skill_list_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }



    public function js_SEO(Request $request, $url)
    {

        try {
            $js_obj = $url;

            $sel_query = "SELECT * from job_seeker where job_seeker.js_SEO = '" . $js_obj . "' AND js_broadcast_resume = 1";

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    'js_approved' => $res['js_approved'],
                    'js_photo' => (!isset($res['js_photo']) || empty($res['js_photo'])) ? "img/profile-avatar.png" : $res['js_photo'],
                    'js_number' => $res['js_number'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                    'js_sal' => is_null($res['js_salary']) ? "Not Set" : $res['js_salary'],
                    'js_totexp' => is_null($res['js_tot_exp']) ? "Not Set" : $res['js_tot_exp'],
                    'js_personal_info' => $res['js_personal_info'],
                );

                $js_loc_obj = json_decode($res['js_loc'], true);
                $js_edu_obj = json_decode($res['js_education'], true);
                $js_exp_obj = json_decode($res['js_experience'], true);
                if (!is_null($res['js_skills'])) {
                    $js_skill_list_obj = json_decode($res['js_skills'], true); //explode(',',$res['js_skills']);
                } else {
                    $js_skill_list_obj = [];
                }
                error_log($js_obj);
            } else {
                //dd('333');
                //return redirect('/404');
                abort(404);
            }
            return view('js_seo', compact(['jp_obj', 'js_loc_obj', 'js_exp_obj', 'js_edu_obj', 'js_skill_list_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }


    public function donation_detail_seo(Request $request, $url)
    {

        $sel_query = "SELECT * from donate where donate_SEO ='$url' AND donate_approved = 1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['donate_years']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $datasearch = array(
                    'donate_Summary' => $res['donate_Summary'],
                    'donate_total_goal' => $res['donate_total_goal'],
                    //'donate_remaining' => $res['donate_remaining'],
                    //'donate_donors' => $res['donate_donors'],
                    //'donate_years' => $tempdate,
                    //'donate_monthly_donors' => $res['donate_monthly_donors'],
                    'donate_fundraiser' => $res['donate_fundraiser'],
                    'donate_challenge' => $res['donate_challenge'],
                    'donate_solution' => $res['donate_solution'],
                    'donate_long_impact' => $res['donate_long_impact'],
                    'donate_additional_documentation' => $res['donate_additional_documentation'],
                    'donate_ref_url' => $res['donate_ref_url'],
                    'donate_logo' => $res['donate_logo'],
                    'donate_org_detail' => $res['donate_org_detail'],
                    'donate_loc' => $res['donate_loc'],
                    'donate_website' => $res['donate_website'],
                    'donate_category' => $res['donate_state'],
                    'donate_title' => $res['donation_title'],
                    'donate_org_name' => $res['donate_org_name'],
                    'donate_banner' => $res['donation_banner'],
                    'donate_foc_Area' => $res['donate_foc_Area'],
                    'donate_checkout_url' => $res['donate_checkout_url'],


                );
            }
        } else {
            $datassearch = array();
        }

        return view('donate_seo', compact(['datasearch']));
    }


    public function news_detail_seo(Request $request, $url)
    {
        $sel_query = "SELECT * from news where news.news_SEO = '" . $url . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['news_create']);
            $tempdate = date("M d Y", $time);

            $DOR_time = strtotime($res['news_DOR']);
            $DOR_date = date("M d Y", $DOR_time);

            $news_obj = array(
                'news_id' => $res['news_id'],
                'news_body' => $res['news_body'],
                'news_image' => $res['news_image'],
                'news_links' => $res['news_links'],
                'news_videolink' => $res['news_videolink'],
                'news_head' => $res['news_head'],
                'news_DOR' => $DOR_date,
            );
        } else {
            //  $csrlist = array();
            //errorView
        }
        return view('news_SEO', compact(['news_obj']));
    }


    public function csr_funder_seo(Request $request, $url)
    {
        $sel_query = "SELECT * from CSR_funder_search where c_f_seo = '" . $url . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            // $time = strtotime($res['news_create']);
            // $tempdate = date("M d Y", $time);

            // $DOR_time = strtotime($res['news_DOR']);
            // $DOR_date = date("M d Y", $DOR_time);

            $c_f_obj = array(
                'c_f_id' => $res['c_f_id'],
                'c_f_org_name' => $res['c_f_org_name'],
                'c_f_org_detail' => $res['c_f_org_detail'],
                'c_f_focus_area' => GeneralUtils::getCateNames($res['c_f_focus_area']),
                'c_f_web' => $res['c_f_web'],
                'c_f_addr' => $res['c_f_addr'],
                'c_f_contact' => $res['c_f_contact'],
                'c_f_email' => $res['c_f_email'],
            );
        } else {
            //  $csrlist = array();
            //errorView
        }
        return view('csrfunder_SEO', compact(['c_f_obj']));
    }

    public function fcra_funder_seo(Request $request, $url)
    {
        $sel_query = "SELECT * from FCRA_funder_search where f_f_seo = '" . $url . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            // $time = strtotime($res['news_create']);
            // $tempdate = date("M d Y", $time);

            // $DOR_time = strtotime($res['news_DOR']);
            // $DOR_date = date("M d Y", $DOR_time);

            $f_f_obj = array(
                'f_f_id' => $res['f_f_id'],
                'f_f_org_name' => $res['f_f_org_name'],
                'f_f_org_detail' => $res['f_f_org_detail'],
                'f_f_focus_area' => GeneralUtils::getCateNames($res['f_f_focus_area']),
                'f_f_web' => $res['f_f_web'],
                'f_f_addr' => $res['f_f_addr'],
                'f_f_contact' => $res['f_f_contact'],
                'f_f_email' => $res['f_f_email'],
            );
        } else {
            //  $csrlist = array();
            //errorView
        }
        return view('fcrafunder_SEO', compact(['f_f_obj']));
    }



    public function rec_jobpost_SEO(Request $request, $url)
    {

        $sel_query = "SELECT * from job_post where job_post.jp_SEO = '" . $url . "' AND jp_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['jp_closing_date']);
            $tempdate = date("M d Y", $time);
            if ($res['jp_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'jp_id' => $res['jp_id'],
                'jp_title' => $res['jp_title'],
                'jp_loc' => $res['jp_loc'],
                'jp_job_type_str' => GeneralUtils::getJobType($res['jp_job_type']),
                'jp_job_type' => $res['jp_job_type'],
                'jp_ad_type_area_of_expertise' => $res['jp_ad_type_area_of_expertise'],
                'jp_desc' => $res['jp_desc'],
                'jp_app_email' => $res['jp_app_email'],
                'jp_email' => $res['jp_email'],
                'jp_org_name' => $res['jp_org_name'],
                'jp_org_logo' => $res['jp_org_logo'],
                'jp_org_twitter' => $res['jp_org_twitter'],
                'jp_org_video' => $res['jp_org_video'],
                'jp_closing_date' => $tempdate,
                'jp_org_web' => $res['jp_org_web'],
                'jp_status' => $status,
                'jp_approved' => $res['jp_approved'],
                'jp_files' => $res['jp_files'],

            );
        } else {
            //  $csrlist = array();
            //errorView
        }
        // return view('jobpost_preview', compact(['jp_obj']));
        return view('jobpost_SEO', compact(['jp_obj']));
    }

    public function publication_SEO(Request $request, $url)
    {


        $sel_query = "SELECT * from publication where publication.pub_SEO = '" . $url . "' AND 	pub_approved=1";
        // dd($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];

            if ($res['pub_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }
            $time = strtotime($res['pub_year'] . '-01');
            $tempdate = date("F, Y", $time);
            $jp_obj = array(
                'pub_id' => $res['pub_id'],
                'pub_title' => $res['pub_title'],
                'pub_name' => $res['pub_name'],
                'pub_upload_image' => $res['pub_upload_image'],
                'pub_type' => GeneralUtils::getpubCateNames($res['pub_type']),
                'pub_focusarea' => GeneralUtils::getpubFocus($res['pub_focusarea']),
                'pub_email' => $res['pub_email'],
                'pub_no' => $res['pub_no'],
                'pub_year' => $tempdate, //$res['pub_year'],
                'pub_website' => $res['pub_website'],
                'pub_upload_word' => $res['pub_upload_word'],
                'pub_media' => $res['pub_media'],
                'pub_desc' => $res['pub_desc'],

            );
        } else {

            //  $csrlist = array();
            //errorView
        }
        // return view('jobpost_preview', compact(['jp_obj']));
        return view('publication_seo', compact(['jp_obj']));
    }


    public function evt_SEO(Request $request, $url)
    {
        try {

            $sel_query = "SELECT * from events where events.evt_SEO = '" . $url . "' AND evt_approved=1";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("F d Y, l", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_loc' => $res['evt_loc'],
                    'evt_end_date' => $tempdate,
                    // 'csr_category' => $res['csr_category'],
                    'evt_status' => $status,
                    // 'csr_ref_url' => $res['csr_ref_url'],
                    // 'csr_logo' => $res['csr_logo'],
                    'evt_desc' => $res['evt_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'evt_approved' => $res['evt_approved'],
                    'evt_email' => $res['evt_email'],
                    // 'evt_upload_banner' => $res['evt_upload_banner'],
                    'evt_org_logo' => $res['evt_org_logo'],
                    'evt_upload_doc' => $res['evt_upload_doc'],
                    'evt_ref_url' => $res['evt_ref_url'],
                );
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('evt_seo', compact(['jp_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function awd_SEO(Request $request, $url)
    {
        try {

            $sel_query = "SELECT * from awards where awards.award_SEO = '" . $url . "' AND award_approved=1";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['award_end_date']);
                $tempdate = date("F d Y, l", $time);
                if ($res['award_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'award_id' => $res['award_id'],
                    'award_title' => $res['award_title'],
                    'award_org_name' => $res['award_org_name'],
                    'award_loc' => $res['award_loc'],
                    'award_end_date' => $tempdate,
                    // 'csr_category' => $res['csr_category'],
                    'award_status' => $status,
                    // 'csr_ref_url' => $res['csr_ref_url'],
                    // 'csr_logo' => $res['csr_logo'],
                    'award_desc' => $res['award_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'award_approved' => $res['award_approved'],
                    'award_email' => $res['award_email'],
                    'award_upload_banner' => $res['award_upload_banner'],
                    'award_org_logo' => $res['award_org_logo'],
                    'award_upload_doc' => $res['award_upload_doc'],
                    'award_ref_url' => $res['award_ref_url'],
                );
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('award_seo', compact(['jp_obj']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }


    public function rec_csr_SEO(Request $request, $url)
    {
        try {
            $sel_query = "SELECT * from csr where csr.csr_SEO = '" . $url . "' AND csr_approved=1";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['csr_close_date']);
                $tempdate = date("F d Y, l", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $csr_obj = array(
                    'csr_id' => $res['csr_id'],
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_org' => $res['csr_org'],
                    'csr_create_date' => $tempdate,
                    'csr_category' => $res['csr_category'],
                    'csr_status' => $status,
                    'csr_ref_url' => $res['csr_ref_url'],
                    'csr_logo' => $res['csr_logo'],
                    'csr_desc' => $res['csr_desc'],
                    // 'csr_close_date' => $res['csr_close_date'],
                    'csr_approved' => $res['csr_approved'],
                    'csr_email' => $res['csr_email'],
                    'csr_loc' => $res['csr_loc'],
                    'csr_upload_doc' => $res['csr_upload_doc'],
                    'csr_cates' => GeneralUtils::getCateNames($res['csr_category']),

                );
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('csr_seo', compact(['csr_obj']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    public function grant_SEO(Request $request, $url)
    {

        $sel_query = "SELECT * from register_grants where reg_SEO= '" . $url . "' AND reg_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['reg_valid_To']);
            $tempdate = date("M d Y", $time);
            if ($res['reg_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'reg_grant_id' => $res['reg_grant_id'],
                'reg_o_name' => $res['reg_o_name'],
                // 'reg_title' => $res['reg_title'],
                'reg_v_org' => $res['reg_v_org'],
                'reg_o_mission' => $res['reg_o_mission'],
                'reg_o_ach' => $res['reg_o_ach'],
                'reg_o_head' => $res['reg_o_head'],
                'reg_o_pan' => $res['reg_o_pan'],
                'reg_o_tan' => $res['reg_o_tan'],
                'reg_80g' => $res['reg_80g'],
                'reg_fcra' => $res['reg_fcra'],
                'reg_website' => $res['reg_website'],
                'reg_valid_from' => $res['reg_valid_from'],
                // 'reg_valid_To' => $res['reg_valid_To'],
                'reg_valid_To' => $tempdate,
                'reg_cates' => GeneralUtils::getCateNames($res['reg_category']),

                'reg_email' => $res['reg_email'],

                'reg_status' => $status,
                // 'reg_submitted_by' => $res['reg_submitted_by'],

            );
        } else {
        }
        // dd($jp_obj);
        return view('reg_seo', compact(['jp_obj']));
    }

    public function fell_SEO(Request $request, $url)
    {
        $sel_query = "SELECT * from fellowship where fell_SEO = '" . $url . "' AND fell_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['fell_end_date']);
            $tempdate = date("F d Y, l", $time);
            if ($res['fell_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'fell_id' => $res['fell_id'],
                'fell_o_name' => $res['fell_o_name'],
                'fell_title' => $res['fell_title'],
                // 'fell_job_type' => $res['fell_job_type'],
                // 'fell_ad_type_area_of_expertise' => $res['fell_ad_type_area_of_expertise'],
                // 'fell_end_date' => $res['fell_end_date'],
                'fell_end_date' => $tempdate,
                'fell_email' => $res['fell_email'],
                'fell_desc' => $res['fell_desc'],
                'fell_loc' => $res['fell_loc'],
                'fell_o_logo' => $res['fell_o_logo'],
                'fell_close_date' => $res['fell_end_date'],
                'fell_upload_doc' => $res['fell_upload_doc'],
                // 'fell_org_web' => $res['fell_org_web'],
                'fell_url' => $res['fell_url'],
                'fell_status' => $status,
                // 'fell_submitted_by' => $res['fell_submitted_by'],

            );
        } else {
        }
        // dd($jp_obj);
        return view('fell_seo', compact(['jp_obj']));
    }

    public function sc_SEO(Request $request, $url)
    {
        $sel_query = "SELECT * from scholarship where sc_SEO = '" . $url . "' AND sc_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['sc_end_date']);
            $tempdate = date("F d Y, l", $time);
            if ($res['sc_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }
            $jp_obj = array(
                'sc_id' => $res['sc_id'],
                'sc_o_name' => $res['sc_o_name'],
                'sc_title' => $res['sc_title'],

                'sc_end_date' => $tempdate,
                'sc_email' => $res['sc_email'],
                'sc_desc' => $res['sc_desc'],
                'sc_loc' => $res['sc_loc'],
                'sc_o_logo' => $res['sc_o_logo'],
                'sc_upload_doc' => $res['sc_upload_doc'],
                // 'fell_org_web' => $res['fell_org_web'],
                'sc_status' => $status,
                'sc_url' => $res['sc_url'],
                // 'fell_submitted_by' => $res['fell_submitted_by'],

            );
        } else {
            $jp_obj = array();
        }
        return view('scholarship_seo', compact(['jp_obj']));
    }

    public function rfp_SEO(Request $request, $url)
    {

        $sel_query = "SELECT * from rfp where rfp_SEO = '" . $url . "' and rfp_approved = 1;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $time = strtotime($res['rfp_close_date']);
            $tempdate = date("F d Y, l", $time);
            if ($res['rfp_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }

            $jp_obj = array(
                'rfp_id' => $res['rfp_id'],
                'rfp_title' => $res['rfp_title'],
                'rfp_loc' => $res['rfp_loc'],
                // 'rfp_job_type' => $res['rfp_job_type'],
                // 'rfp_ad_type_area_of_expertise' => $res['rfp_ad_type_area_of_expertise'],
                'rfp_desc' => $res['rfp_desc'],
                'rfp_o_ach' => $res['rfp_o_ach'],
                'rfp_email' => $res['rfp_email'],
                'rfp_logo' => $res['rfp_logo'],
                'rfp_g_amt' => $res['rfp_g_amt'],
                'rfp_org' => $res['rfp_org'],
                'rfp_close_date' => $tempdate,
                // 'rfp_close_date' => $res['rfp_close_date'],
                'rfp_upload_doc' => $res['rfp_upload_doc'],
                'rfp_status' => $status,
                'rfp_cates' => GeneralUtils::getCateNames($res['rfp_category']),

            );
        } else {
        }
        // dd($jp_obj);
        return view('rfp_seo', compact(['jp_obj']));
    }


    public function SEOlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));


        $sel_query = "SELECT * FROM SEO";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $seolist[] = array(
                    'seo_id' => $res['seo_id'],
                    'seo_page_name' => $res['seo_page_name'],
                    'seo_link' => $res['seo_link'],
                    'seo_data' => $res['seo_data'],


                );
                // dd($seolist);
            }
        } else {
            $seolist = array();
        }
        return view('adm_seo_list', compact(['seolist']));
    }


    public function show_seo_Detail(Request $request, $seoid)
    {
        try {
            // dd($request)
            //$html = GeneralUtils::Category();
            $sel_query = "SELECT * from SEO where seo_id = $seoid";
            // dd($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            // dd($res_query);
            if (count($res_query)) {
                foreach ($res_query as $res) {
                    $jp_obj = array(
                        'seo_id' => $res['seo_id'],
                        'seo_page_name' => $res['seo_page_name'],
                        'seo_link' => $res['seo_link'],
                        'seo_data' => json_decode($res['seo_data'],true),


                    );
                    // dd($jp_obj);

                }
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('adm_edit_seo', compact(['jp_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function admission_SEO(Request $request, $url)
    {
        $sel_query = "SELECT * from admission where adn_SEO = '" . $url . "' AND adn_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            // $time = strtotime($res['sc_end_date']);
            // $tempdate = date("M d Y", $time);
            if ($res['adn_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }
            $time = strtotime($res['adn_apply']);
            $tempdate = date("F d Y, l", $time);
            $adn_obj = array(
                'adn_id' => $res['adn_id'],
                'adn_inst_name' => $res['adn_inst_name'],
                'adn_title' => $res['adn_title'],
                'adn_email' => $res['adn_email'],
                'adn_display_page' => $res['adn_display_page'],
                'adn_org_logo' => $res['adn_org_logo'],
                'adn_pdf_document' => $res['adn_pdf_document'],
                'adn_website_url' => $res['adn_website_url'],
                'adn_apply' => $tempdate,
            );
        } else {
            $adn_obj = array();
            abort(404);
        }
        return view('admission_seo', compact(['adn_obj']));
    }

    public function onlinecourse_SEO(Request $request, $url)
    {
        $sel_query = "SELECT * from onlinecourse where on_SEO = '" . $url . "' AND on_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            // $time = strtotime($res['sc_end_date']);
            // $tempdate = date("M d Y", $time);
            if ($res['on_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }
            $time = strtotime($res['on_apply']);
            $tempdate = date("F d Y, l", $time);
            $on_obj = array(
                'on_id ' => $res['on_id'],
                'on_institute' => $res['on_institute'],
                'on_display' => $res['on_display'],
                'on_email' => $res['on_email'],
                'on_detail' => $res['on_detail'],
                'on_logo' => $res['on_logo'],
                'on_pdf_doc' => $res['on_pdf_doc'],
                'on_url' => $res['on_url'],
                'on_apply' => $tempdate,

            );
        } else {
            $on_obj = array();
            abort(404);
        }
        return view('online_seo', compact(['on_obj']));
    }

    public function callpaper_SEO(Request $request, $url)
    {
        $sel_query = "SELECT * from call_paper where paper_SEO = '" . $url . "' AND paper_approved=1";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            // $time = strtotime($res['sc_end_date']);
            // $tempdate = date("M d Y", $time);
            if ($res['paper_approved'] == 1) {
                $status = 'Approved';
            } else {
                $status = 'On Hold';
            }
            $time = strtotime($res['paper_apply_by']);
            $tempdate = date("F d Y, l", $time);
            $paper_obj = array(
                'paper_id ' => $res['paper_id'],
                'paper_o_name' => $res['paper_o_name'],
                'paper_title' => $res['paper_title'],
                'paper_email' => $res['paper_email'],
                'paper_loc'=>$res['paper_loc'],
                'paper_org_logo' => $res['paper_org_logo'],
                'paper_pdf_doc' => $res['paper_pdf_doc'],
                'paper_web_url' => $res['paper_web_url'],
                'paper_disp' => $res['paper_disp'],
                'paper_apply_by' => $tempdate,

            );
        } else {
            $paper_obj = array();
            abort(404);
        }
        return view('callpaper_seo', compact(['paper_obj']));
    }

    public function update_seo(Request $request, $encid)
    {
        // dd($request);
        $seotitle = $request->input('seotitle');
        $seoimg = $request->input('seoimg');
        $seokeywords = $request->input('seokeywords');
        $seo_desc = $request->input('seodesc');

        $seo_data = array('seotitle' => $seotitle, 'seodesc' => $seo_desc, 'seokeywords' => $seokeywords, 'seoimg' => $seoimg);
        $seo_data = json_encode($seo_data);
        DB::beginTransaction();

        try {
            DB::table('SEO')->where('seo_id', $encid)->update([
                
                'seo_data' => $seo_data,

                // 'evt_upload_banner' => $db_name_bannerh,
            ]);
            DB::commit();
            return \redirect('/admin/seo-list');
        } catch (\Exception $ex) {
            DB::rollback();
            return \redirect('/error-page');
        }
    }
}
