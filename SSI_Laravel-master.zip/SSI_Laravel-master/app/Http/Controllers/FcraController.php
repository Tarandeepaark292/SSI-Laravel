<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FcraController extends Controller
{
    //

    public function fcrafundlist(Request $request)
    {
        $sel_query = "SELECT * from FCRA_funder_search;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {

            foreach ($res_query as $res) {
                $f_f_obj[] = array(
                    'f_f_id' => $res['f_f_id'],
                    'f_f_org_name' => $res['f_f_org_name'],
                    'f_f_org_detail' => $res['f_f_org_detail'],
                    'f_f_focus_area' => GeneralUtils::getCateNames($res['f_f_focus_area']),
                    'f_f_web' => $res['f_f_web'],
                    'f_f_addr' => $res['f_f_addr'],
                    'f_f_contact' => $res['f_f_contact'],
                    'f_f_email' => $res['f_f_email'],
                    'f_f_seo' => $res['f_f_seo'],
                );
            }
        } else {
            $f_f_obj = null;
        }



        $sel_query = "SELECT * from category";
        //    dd($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $b_f_obj[] = array(

                    'cate_name' => $res['cate_name'],
                    'cate_id' => $res['cate_id'],
                    // 'gi_price' => $res['gi_price'],
                    // 'gi_create_date' => $tempdate,

                );
            }
        } else {
            $b_f_obj = array();
        }
        return view('fcra-fund-list', compact(['f_f_obj', 'b_f_obj']));
    }

    public function submitFCRAfunder(Request $request)
    {
        $org_name = $request->input('org_name');
        $Website = $request->input('Website');
        $org_detail = $request->input('org_detail');
        $cates = $request->input('cates');
        $address = $request->input('address');
        $Email = $request->input('Email');
        $contact = $request->input('contact');
        // $videolinks = $request->input('videolink');

        $csr_seo = str_replace(" ", "-", $org_name);
        $csr_seo = $csr_seo . "-" . time();


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('FCRA_funder_search')->insert([
            'f_f_org_name' => $org_name,
            'f_f_org_detail' => $org_detail,
            'f_f_focus_area' => $cates,
            'f_f_web' => $Website,
            'f_f_addr' => $address,
            'f_f_contact' => $contact,
            'f_f_email' => $Email,
            'f_f_seo' => GeneralUtils::CreateSEO($org_name),
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }



    // public function categoryfcra(Request $request)
    // {
    //     $body=$request->all();
    // //   dd($request);
    //     $sel_query = "SELECT * from category";

    //     $res_query = DBraw::select($sel_query);
    //     $res_query = json_decode(json_encode($res_query), true);

    //     if (count($res_query)) {
    //         foreach ($res_query as $res) {

    //             $b_f_obj[] = array(

    //                 'cate_name'=>$res['cate_name'],
    //                 'cate_id'=>$res['cate_id'],
    //                 // 'gi_price' => $res['gi_price'],
    //                 // 'gi_create_date' => $tempdate,

    //             );
    //         }
    //     } else {
    //         $b_f_obj = array();
    //     }
    //     return view('fcra-fund-list', compact(['b_f_obj']));
    // }



    public function ajaxfcrafunders(Request $request)
    {



        $body = $request->all();

        // dd($body);
        // dd($body['focus']);
        // $sel_query = "SELECT * from csr_funder_search where c_f_org_name LIKE   '%" .$body['focus']. "%' ";
        $sel_query = "SELECT * from FCRA_funder_search where f_f_org_name LIKE   '%" . $body['focus'] . "%'   and f_f_focus_area LIKE   '%" . $body['state'] . "%'";

        // error($sel_query);

        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        // $img = asset('img/ssi_logo.svg');
        $htmldata = "";
        $thead ='
        <div id="search_results" style="width: 100%;">
            <div class="container" style="margin-top:2rem;margin-bottom: 5rem;">

                <table class="table-responsive-md table-hover" id="searchtbl">
                    
                        <thead>
                            <tr>
                                <th scope="col">NO.</th>
                                <th scope="col">Organisation Name</th>
                                <th scope="col">Link</th>

                            </tr>
                        </thead>
                        <tbody>
                        ';

        $tfoot  ='</tbody>
            </table>

            </div>
            </div>';

        $count = 1;

        if (count($res_query)) {
            foreach ($res_query as $res) {

                // if ($res['donate_approved'] == 1) {

                $data = '
                                <tr>

                              
                                <td>
                                ' .$count . '

                                </td>
                               


                                    <td>
                                    ' . $res['f_f_org_name'] . '

                                    </td>
                                    
                                    <td>
                                   
                                <a href="'.url("/fcra-funder").'/' . $res['f_f_seo'] . '" target="_blank" style="font-weight: bold">Details</a>
                            </td>
                                </tr>
                              
                                                              ';


                $htmldata = $htmldata . $data;
                $count ++;
            }
            error_log($data);
            $htmldata = $thead . $htmldata . $tfoot;
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }



    public function show_fcra_Detail(Request $request, $encid)
    {
        try {
            $sel_query = "SELECT * from FCRA_funder_search where FCRA_funder_search.f_f_id = " . $encid;

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                // $time = strtotime($res['f_f_createdate']);
                // $tempdate = date("Y-m-d", $time);


                $jp_obj = array(
                    'f_f_id' => $res['f_f_id'],
                    'f_f_org_name' => $res['f_f_org_name'],
                    'f_f_org_detail' => $res['f_f_org_detail'],
                    'f_f_email' => $res['f_f_email'],
                    // 'f_f_createdate	' => $tempdate,
                    'f_f_web' => $res['f_f_web'],
                    'f_f_addr' => $res['f_f_addr'],
                    'f_f_contact' => $res['f_f_contact'],
                    'f_f_focus_area' => $res['f_f_focus_area'],

                  
                );
                // $html = GeneralUtils::createHTML_for_selected_cate($res['f_f_focus_area']);
                $html = GeneralUtils::createHTML_for_selected_cate($res['f_f_focus_area']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('edit_fcra', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            dd($ex);




            error_log('exception' . $ex->getMessage());
        }
    }

    public function update_fcra(Request $request, $encid)
    {
        // dd($request);
        $org_name = $request->input('org_name');
        $Website = $request->input('Website');
        $org_detail = $request->input('org_detail');
        $cates = $request->input('cates');
        $address = $request->input('address');
        $Email = $request->input('Email');
        $contact = $request->input('contact');





        DB::beginTransaction();

        try {
            DB::table('FCRA_funder_search')->where('f_f_id', $encid)->update([
                'f_f_org_name' => $org_name,
                'f_f_web' => $Website,
                'f_f_org_detail' => $org_detail,

                'f_f_email' => $Email,
                'f_f_addr' => $address,
                'f_f_contact' => $contact,
                'f_f_contact' => $contact,
                'f_f_focus_area' => $cates,


                // 'evt_upload_banner' => $db_name_bannerh,
            ]);
            DB::commit();
            return \redirect('/admin/fcra-list');
        } catch (\Exception $ex) {
            dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }


    public function FCRAList(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from FCRA_funder_search";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $time = strtotime($res['f_f_createdate']);
                // $tempdate = date("M d Y", $time);
                // if ($res['fell_approved'] == 1) {
                //     $status = 'Approved';
                // } else {
                //     $status = 'On Hold';
                // }
                $felllist[] = array(
                    'f_f_id' => $res['f_f_id'],
                    'f_f_org_name' => $res['f_f_org_name'],
                    'f_f_org_detail' => $res['f_f_org_detail'],
                    'f_f_email' => $res['f_f_email'],
                   // 'f_f_createdate' => $tempdate,

                );
            }
        } else {
            $felllist = array();
        }
        return view('adm_fcra_list', compact(['felllist']));
    }
}
