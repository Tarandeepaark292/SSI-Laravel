<?php

namespace App\Http\Controllers;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Utils\GeneralUtils;
class RfpController extends Controller
{

   

    public function getRFP1(Request $request)
    {
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        error_log($html);
        return view('post-proposal', compact(['html']));
    }

    public function submitRFP1(Request $request)
    {
        $email = $request->input('email');
        $org_name = $request->input('orgname');
        $grant_title = $request->input('grant_title');
        $rfp_seo = str_replace(" ","-",$grant_title);
        $rfp_seo = $rfp_seo . "-" . time();
        $location = $request->input('location');
        $total_amt = $request->input('total_amt');
        $closedate = $request->input('close_date');
        $descproposal = $request->input('proposal_desc');
        // $p=$request->input('document');
        //$orgachivement = $request->input('Description');
        $cates = $request->input('cates');
        $orgachivements = $request->input('organisation_ach');
        $file = $request->file('company_logo');
        $document = $request->file('document');
        $orgpan = $request->input('organisation_pan');

        if($request->hasFile('document')){
            $document = $request->file('document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('rfp')->insert([
            'rfp_org' => $org_name,
            'rfp_loc' => $location,
            'rfp_g_amt' => $total_amt,

            'rfp_close_date' => $closedate,
            'rfp_email' => $email,
            'rfp_upload_doc' => $document,
            'rfp_desc' => $descproposal,
            // 'csr_upload_doc' => $closingdate,
            'rfp_logo' => $file,

            'rfp_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'rfp_approved' => 0,

            'rfp_title' => $grant_title,
            'rfp_o_ach' => $orgachivements,
            'rfp_category' => $cates,
            'rfp_create_date' => $createdate,
            'rfp_SEO' => GeneralUtils::CreateSEO($grant_title),
            'rfp_is_submitted_by_admin' => 0,
            // 'rfp_o_ach' => $orgachivement,
            // 'rfp_o_achivements' => $orgachivements,
            // 'rfp_o_pan' => $orgpan,
            // rfp_document'=>$document,

            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,5)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function rfpads(Request $request)
    {

        //$sel_query = "SELECT * from rfp where rfp_approved = 1 order by rfp_id desc";
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from rfp where rfp_approved = 1 and rfp_close_date > '$today'  order by rfp_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $rfpsearch[] = array(
                    'rfp_logo' => $res['rfp_logo'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_close_date' => $tempdate,
                    'rfp_loc' => $res['rfp_loc'],
                    'rfp_seo' => $res['rfp_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $rfpsearch = array();
        }
        $cates = GeneralUtils::getDBCates();
        $sel_query = "SELECT seo_data from SEO where seo_id = 33;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-ads', compact(['rfpsearch','cates','seodata']));
    }

    public function ajaxrfp(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        //$sel_query = "SELECT * from rfp where rfp_org  LIKE   '%" . $body['search'] . "%' and rfp_category LIKE '%". $body['cate']."%';";
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from rfp where rfp_org  LIKE   '%" . $body['search'] . "%' and rfp_category LIKE '%". $body['cate']."%' and rfp_close_date > '$today';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['rfp_approved'] == 1) {
                    $time = strtotime($res['rfp_close_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">

                    <div class="card content fell_search_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">

                                <div class="col-md-2" style="text-align: center;">
                                    <img  style="width:80%" src="' . asset($res['rfp_logo']) . '" />
                                </div>
                                <div class="col-md-8">
                                    <div class="results" style="font-weight: bold;">
                                    ' .  $res['rfp_org']. '</div>
                                    <div id="results" class="limittext">
                                    ' . $res['rfp_title']. '
                                    </div>
                                    <div id="results">
                                        <i class="fa fa-map-marker" aria-hidden="true"
                                            style="color:#007bff;font-size: 18px;"></i> <span
                                            style="font-weight: bold;color:#007bff;">' . $res['rfp_loc']. '</span>

                                    </div>
                                    <div id="results">
                                        <i class="fa fa-calendar" aria-hidden="true"
                                            style="color:#00254d;font-size: 18px;"></i> Closing date: <span
                                            style="font-weight: bold;color:#00254d;">' . $tempdate . '
                                        </span>
                                    </div>
                                    <div id="results" style="color:#293e09;">
                                        <i class="fa fa-money" aria-hidden="true"></i> <span
                                            style="font-weight: bold;">' . $res['rfp_g_amt']. '</span>
                                    </div>
                                </div>
                                <div class="col-md-2 my-auto ">
                                   
                                    <a href="' .url('/rfp/') .'/'. $res['rfp_SEO']. '" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
                                </div>





                            </div>
                        </div>
                    </div>
                </div>


                                        ';

                                        $htmldata = $htmldata . $data;
                                    }
                    
                                }
                    
                                error_log($data);
                                return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
                            } else {
                                $res['res'] = 'fail';
                                return response()->json($res);
                            }
                                     
        //             error_log($data);

        //             // $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));

        //         } else {
        //             $res['error'] = '<div class="col-md-2  results" style="text-align: center;">
        //             <img src=' . $img . ' />
        //             </div>
        //             <div class="col-md-8">
        //         <div class="resultss" style="font-weight: bold;font-size: 20px;">you have no csr ads</div>';
        //             $mydata = response()->json($res);
        //         }

        //     }
        //     return $mydata;
        // } else {
        //     // $rfpsearch = array();
        //     $res['res'] = 'fail';
        //     return response()->json($res);
        // }

        // return view('all-ads',compact(['rfpsearch']));

    }
}
