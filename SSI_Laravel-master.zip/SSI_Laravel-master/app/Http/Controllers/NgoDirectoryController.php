<?php

namespace App\Http\Controllers;


use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;

class NgoDirectoryController extends Controller
{
    //

    public function post_ngodirectory(Request $request){
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }


        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }

        return view('adm_post_ngo_directory', compact(['html']));
    }

    public function submit_ngodirectory(Request $request){
        $org_name = $request->input('org_name');
        $Website = $request->input('Website');
        $cfunctionality = $request->input('cfunctionality');
        $cates = $request->input('cates');
        $address = $request->input('address');
        $Email = $request->input('Email');
        $contact = $request->input('contact');
        $ngo_type = $request->input('ngo_type');
        $fcra_avaliable = $request->input('fcra_avaliable');
        $regNo = $request->input('regNo');
        $stateReg = $request->input('stateReg');
        $country = $request->input('country');
        $Email = $request->input('Email');
        $city = $request->input('city');
        $dateReg = $request->input('dateReg');

        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('NGODirectory')->insert([
            'nd_org_name' => $org_name,
            'nd_chief_functionality' => $cfunctionality,
            'nd_focus_area' => $cates,
            'nd_ngo_type' => $ngo_type,
            'nd_reg_no' => $regNo,
            'nd_state' => $stateReg,
            'nd_date' => $dateReg,
            'nd_fcra_avaliable' => $fcra_avaliable,
            'nd_country' => $country,
            'nd_city' => $city,
            'nd_addr' => $address,
            'nd_mobile' => $contact,
            'nd_email' => $Email,
            'nd_website' => $Website,
            'nd_createdate' => $createdate, 
            'nd_seo' => GeneralUtils::CreateSEO($org_name),
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();

        return \redirect('/admin/dashboard');
    }

    public function showngodirectory(Request $request){
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from NGODirectory;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $time = strtotime($res['f_f_createdate']);
                // $tempdate = date("M d Y", $time);
                // if ($res['fell_approved'] == 1) {
                //     $status = 'Approved';
                // } else {
                //     $status = 'On Hold';
                // }
                $time = strtotime($res['nd_createdate']);
                $tempdate = date("M d Y", $time);
                $ngodirlist[] = array(
                    'nd_id' => $res['nd_id'],
                    'nd_org_name' => $res['nd_org_name'],
                    'nd_ngo_type' => $res['nd_ngo_type'],
                    'nd_seo' => $res['nd_seo'],
                    'nd_website' => $res['nd_website'],
                    'nd_createdate' => $tempdate,
                   // 'f_f_createdate' => $tempdate,

                );
            }
        } else {
            $felllist = array();
        }
        return view('adm_ngo_dir_list', compact(['ngodirlist']));
    }
}
