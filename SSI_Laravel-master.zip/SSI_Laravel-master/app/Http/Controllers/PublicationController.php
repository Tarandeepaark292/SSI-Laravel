<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PublicationController extends Controller
{
    public function submitpublication(Request $request)
    {
        $author = $request->input('authorname');

        $type = $request->input('cates');
        $focusarea = $request->input('farea2');
        $title = $request->input('documenttitle');
        $pub_seo = str_replace(" ","-",$title);
        $pub_seo = $pub_seo . "-" . time();
        $email = $request->input('email');
        $mobileno = $request->input('mobile');

        $year = $request->input('year');
        // $cates = $request->input('cates');
        $website = $request->input('website');
        $mediaurl = $request->input('media');
        $worddoc = $request->input('doc');
        $desc = $request->input('publication_desc');
        $image=$request->file('image');
        
      
        // $pdfdoc = $request->file('pdf');



        error_log("--->>" . $image->getClientOriginalExtension() . public_path() . $image->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $image->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $image->move(public_path() . "/Images/", $src_file_logo);
        $image = "/public/Images/" . $src_file_logo;


// dd($image);

        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('publication')->insert([
            'pub_name' => $author,
            'pub_type' =>  $type,
            'pub_focusarea' => $focusarea,
            'pub_title' => $title,
            'pub_email' => $email,
            'pub_no' => $mobileno,
            'pub_year' =>   $year,
            'pub_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'pub_approved' => 0,
            'pub_website' =>  $website,
            'pub_media' =>  $mediaurl,
            'pub_upload_word' =>  $worddoc,
            'pub_desc' => $desc,
            'pub_SEO' => GeneralUtils::CreateSEO($title),
            'pub_upload_image'=>$image
            // 'pub_upload_doc' =>   $pdfdoc,
            // 'evt_SEO' => $event_seo,
            // 'file_date'=>date("Y-m-d H:i:s"),
        
        ]); 

        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,16)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function searchpublication(Request $request)
    {

        // $today = date("Y-m-d") . " 00:00:00";
        // $sel_query = "SELECT * from publication where pub_approved = 1 and pub_year > '$today' ORDER BY pub_id DESC";
        $sel_query = "SELECT * from publication where pub_approved = 1 ORDER BY pub_id DESC";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                // $time = strtotime($res['sc_date']);
                // $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $time = strtotime($res['pub_year'] . '-01');
                $tempdate = date("F, Y", $time);
            
                $pubsearch[] = array(
                    'pub_title' => $res['pub_title'],
                    'pub_name' => $res['pub_name'],
                    'pub_email' => $res['pub_email'],
                    'pub_SEO' => $res['pub_SEO'],
                    'pub_desc' => $res['pub_desc'],
                    'pub_upload_image' => $res['pub_upload_image'],
                    'pub_year' => $tempdate,//$res['pub_year'],
                );
            }
        } else {
            $pubsearch = array();
        }

        $sel_query_cate = "SELECT * FROM publication_category;";
        $res_query_cate = DBraw::select($sel_query_cate);
        $res_query_cate = json_decode(json_encode($res_query_cate), true);
        if (count($res_query_cate)) {
            foreach ($res_query_cate as $res) {
                $catelist[] = array(
                    'pub_cate_id' => $res['p_cat_id'],
                    'pub_cate_name' => $res['p_cat_name'],
                );
            }
        }


        $sel_query = "SELECT seo_data from SEO where seo_id = 26;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-publication', compact(['pubsearch','seodata','catelist']));
    }


    public function ajaxpublication(Request $request)
    {
        $body = $request->all();
        // error_log(json_encode($body));
        // error_log($body['search']);
        // $sel_query = "SELECT * from donate wher/e donate_foc_Area LIKE   '%" . $body['focus'] . "%' and donate_category LIKE   '%" . $body['state'] . "%'";
    
        //$sel_query = "SELECT * from publication where pub_focusarea LIKE '%" . $body['state'] . "%' and pub_type  LIKE '%" . $body['focus'] . "%' ";
        $body = $request->all();
        error_log(json_encode($body));
        // error_log($body['search']);
        // error_log($body['location']);
        $notfound = false;
        if ($body['cate'] != '-1') {
            // error_log("qwe");
            $sel_query = "SELECT * from publication  where pub_name  LIKE '%" . $body['cate'] . "%' OR pub_title    LIKE   '%" . $body['cate'] . "%' ORDER BY pub_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }
        if ($body['focus']) {
            // error_log("asdf");
            $sel_query = "SELECT * from publication  where pub_focusarea    LIKE   '%" . $body['focus'] . "%'  ORDER BY pub_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }
        if ($body['state']) {
            // error_log("qwe");
            $sel_query = "SELECT * from publication  where pub_type      LIKE   '%" . $body['state'] . "%'  ORDER BY pub_id DESC";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
            $notfound = true;
        }

        if(!$notfound){
            $sel_query = "SELECT * from publication  ORDER BY pub_id DESC;";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            error_log(json_encode($res_query));
        }

        // error_log(json_encode($res['js_loc']));
        $img = asset('img/ssi_logo.svg');
        $data = '';
        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $loca = $res['jp_loc'];
                // error_log(json_decode(json_encode($res['js_loc']),true));
                // $loca = json_decode($res['js_loc'], true);
                $time = strtotime($res['pub_year'] . '-01');
                $tempdate = date("F, Y", $time);
                if ($res['pub_approved'] == 1) {
                    // $time = strtotime($res['jp_closing_date']);
                    // $tempdate = date("F d Y, l", $time);
                    $data = $data . '<div class="col-12" style="margin-bottom:2rem;">
                    <div class="card content joblist_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">

                                <div class="col-md-2" style="text-align: center;">

                                    <img style="width: 80%;" src="'.asset($res['pub_upload_image']).'" />
                                </div>
                                <div class="col-md-8">
                                    <div id="results" style="margin-bottom:2px;font-weight: bold;color:#004a99">
                                        '.$res['pub_name'].'
                                    </div>
                                    
                                    <div id="results" class="limittext" style="font-weight: bold;color:#004a99">'.$res['pub_title'].'</div>
                                    <div id="results" style="margin-bottom:2px;font-weight: bold;color:#004a99">
                                        '.$tempdate.'
                                    </div>
                                    

                               
                                            <div class="limittext_news" style="text-align: justify;">
                                            '.$res['pub_desc'].'
                                        </div>
                                </div>

                                <div class="col-md-2" style="align-self: center;justify-content: center;">
                                <a href="'.url('/publication_seo').'/'.$res['pub_SEO'].'" class="btn btn-primary">Detail  <i class="fa fa-chevron-right"></i></a>
                            </div>

                            </div>

                        </div>
                    </div>
                    </div>';

                    // error_log($data);

                    // $mydata = response()->json(array('res' => 'SUCCESS', 'data' => $data));
                }
            }
            $data = '<div class="items">' . $data . '</div>' . '<div class="pager">
            <div class="previousPage"><i class="fa fa-arrow-left"></i></div>
            <div class="pageNumbers"></div>
            <div class="nextPage"><i class="fa fa-arrow-right"></i></div>
        </div>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $data));
        } else {
            // $rfpsearch = array();
            $res['res'] = 'FAIL';
            $res['error'] = '
        <div class="col-md-12">
        <div class="resultss" style="font-weight: bold;font-size: 20px;">No Job found</div>
        </div>';
            return response()->json($res);
        }

    }


    public function publications(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from  publication";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        $sel_query_cate = "SELECT * FROM publication_category;";
        $res_query_cate = DBraw::select($sel_query_cate);
        $res_query_cate = json_decode(json_encode($res_query_cate), true);
        if (count($res_query_cate)) {
            foreach ($res_query_cate as $res) {
                $catelist[] = array(
                    'pub_id' => $res['pub_id'],
                    'pub_name' => $res['pub_name'],
                );
            }
        }

        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['rfp_close_date']);
                // $tempdate = date("M d Y", $time);
                if ($res['pub_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $publist[] = array(
                    'pub_id' => $res['pub_id'],
                    'pub_name' => $res['pub_name'],
                    'pub_focusarea' => $res['pub_focusarea'],
                    'pub_media' => $res['pub_media'],
                    'pub_title' => $res['pub_title'],
                    'pub_email' => $res['pub_email'],
                    'pub_approved' => $res['pub_approved'],
                    // 'rfp_close_date' => $tempdate,
                    'pub_submitted_by' => $res['pub_submitted_by'],
                    // 'rfp_status' => $status,
                    // 'rfp_approved' => $res['rfp_approved'],
                );
            }
        } else {
            $publist = array();
        }
        return view('publication_list', compact(['publist']));
    }
}
