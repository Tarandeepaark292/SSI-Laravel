<?php

namespace App\Http\Controllers;

use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Utils\EmailUtils;
class LoginController extends Controller
{
    //
    public function userlogin(Request $request)
    {
        $data = $request->validate([
            'password' => 'required',
            'email' => 'required|email',
        ]);
        $email = $request->input('email');
        $passwd = $request->input('password');
        $role_type = $request->input('role');
        error_log($role_type);
        if ($role_type == 'jobseek') {
            $sel_query = "SELECT * FROM job_seeker where js_pwd = '" . $passwd . "' AND js_email = '" . $email . "';";

        } else if ($role_type == 'recruiter') {
            $sel_query = "SELECT * FROM recruiter where r_pwd = '" . $passwd . "' AND r_email = '" . $email . "';";
        }
        //$sel_query = "SELECT * FROM job_seeker where js_pwd = '".$passwd."' AND js_email = '".$email."';";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            //update token
            $res = $res_query[0];
            if ($role_type == 'jobseek') {
                $token = GeneralUtils::gen_js_LoginToken();
                if (GeneralUtils::update_js_Token($token, $res['js_id'])) {
                   
                    $request->session()->forget(['ssiapp_rec', 'ssiapp_rec_id', 'ssiapp_rec_token','ssiapp_rec_name','ssiapp_rec_website','ssiapp_rec_contact_name']);
                    $request->session()->put('ssiapp_js', true);
                    $request->session()->put('ssiapp_js_id', $res['js_id']);
                    $request->session()->put('ssiapp_js_token', $token);
                    $request->session()->put('ssiapp_js_name',$res['js_name']);
                    return \redirect('/js/dashboard');
                    //return response()->json($result);
                }
            } else if ($role_type == 'recruiter') {
                $token = GeneralUtils::gen_recruiter_LoginToken();
                if (GeneralUtils::update_recruiter_Token($token, $res['r_id'])) {
                    
                    $request->session()->forget(['ssiapp_js', 'ssiapp_js_id', 'ssiapp_js_token','ssiapp_js_name']);
                    $request->session()->put('ssiapp_rec', true);
                    $request->session()->put('ssiapp_rec_id', $res['r_id']);
                    $request->session()->put('ssiapp_rec_token', $token);
                    $request->session()->put('ssiapp_rec_name',$res['r_org_name']);
                    $request->session()->put('ssiapp_rec_contact_name',$res['r_name']);
                    $request->session()->put('ssiapp_rec_website',$res['r_off_website']);
                    
                    
                    return \redirect('/recruiter/dashboard');
                    //return response()->json($result);
                }
            }

            $res['error'] = "Can't login to System";
            return \Redirect::back()->withErrors(['error_reason' => 'Can\'t login to System']);

        } else {
            $res['error'] = "Can't login to System";
            return \Redirect::back()->withErrors(['error_reason' => 'Wrong Email or Password']);
        }
    }

    public function userlogout(Request $request)
    {
        if ($request->session()->has('ssiapp_js')) {
            $request->session()->forget(['ssiapp_js', 'ssiapp_js_name','ssiapp_js_id', 'ssiapp_js_token']);
        } else if ($request->session()->has('ssiapp_rec')) {
            $request->session()->forget(['ssiapp_rec', 'ssiapp_rec_name', 'ssiapp_rec_id', 'ssiapp_rec_token','ssiapp_rec_website','ssiapp_rec_contact_name']);
        }

        return \redirect('/login');
    }

    public function organization_login(Request $request){
        return view('organization_loginpage');
    }

    public function organization_register(Request $request){
        return view('organization_registerpage');
    }

    public function organization_forgotpwd(Request $request){
        return view('organization_forgetpwd');
    }

    public function resetpwd(Request $request){
        $data = $request->validate([
            
            'email' => 'required|email',
        ]);
        $email = $request->input('email');

        $sel_query = "SELECT * FROM recruiter where r_email = '" . $email . "';";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];
            DB::beginTransaction();
            try {
                $pwd = uniqid();
                DB::table('recruiter')->where('r_id', $res['r_id'])->update([
                    'r_pwd' => $pwd,
                ]);
                DB::commit();
                $data = array("org_name"=>$res['r_name'], "org_email"=>$res['r_email'],"org_pwd"=>$pwd,'js_phone'=>$res['r_phone']);
                EmailUtils::ForgotPassword($data,'ORG',$email);
                return \redirect('/organization/login');
            } catch (\Exception $ex) {
                DB::rollback();
                error_log($ex->getMessage());
                $res['res'] = 'FAIL';
                $res['error'] = $ex->getMessage();

                return \Redirect::back()->withErrors(['error_reason' => 'Problem generating Password']);
            }  
        }
        return \Redirect::back()->withErrors(['error_reason' => 'Email Address not found in System']);
    }

    public function js_forgotpwd(Request $request){
        return view('jobseeker_forgetpwd');
    }

    public function jsresetpwd(Request $request){
        $data = $request->validate([
            
            'email' => 'required|email',
        ]);
        $email = $request->input('email');

        $sel_query = "SELECT * FROM job_seeker where js_email = '" . $email . "';";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];
            DB::beginTransaction();
            try {
                $pwd = uniqid();
                DB::table('job_seeker')->where('js_id', $res['js_id'])->update([
                    'js_pwd' => $pwd,
                ]);
                DB::commit();
                $data = array("js_name"=>$res['js_name'], "js_email"=>$res['js_email'],"js_pwd"=>$pwd,'js_phone'=>$res['js_number']);
                EmailUtils::ForgotPassword($data,'JS',$email);
                return \redirect('/login');
            } catch (\Exception $ex) {
                DB::rollback();
                error_log($ex->getMessage());

                $res['res'] = 'FAIL';
                $res['error'] = $ex->getMessage();

                return \Redirect::back()->withErrors(['error_reason' => 'Problem generating Password']);
            }  
        }
        return \Redirect::back()->withErrors(['error_reason' => 'Email Address not found in System']);
    }
}
