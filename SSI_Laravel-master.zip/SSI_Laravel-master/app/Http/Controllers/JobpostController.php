<?php

namespace App\Http\Controllers;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Utils\GeneralUtils;
class JobpostController extends Controller
{
    public function jobpost(Request $request)
    {
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        error_log($html);
        return view('recruiters', compact(['html']));

    }

    public function submitJB(Request $request)
    {
        $email = $request->input('email');
        $jobtitle = $request->input('jobtitle');
        $jp_seo = str_replace(" ","-",$jobtitle);
        $jp_seo = $jp_seo . "-" . time();
        $location = $request->input('location');

        $jobtype = $request->input('job_type');

        $description = $request->input('description');

        $applicationemail = $request->input('applicationemail');

        $closingdate = $request->input('closingdate');

        
        $orgname = $request->input('org_name');
        $website = $request->input('website');
        $video = $request->input('video');
        $twiiter = $request->input('twitterusername');
        // $logo = $request->file('logo');
        $areas = $request->input('area');
       
        if($request->hasFile('files')){
            $files = $request->file('files');
            $src_document = date('YmdHis') . $files->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $files->move(public_path() . "/document/", $src_document);
            $files = '/public/document/' . $src_document;
        }else{
            $files = '';
        }

        if($request->hasFile('logo')){
            $org_logo = $request->file('logo');
            error_log("--->>" . $org_logo->getClientOriginalExtension() . public_path() . $org_logo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $org_logo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $org_logo->move(public_path() . "/Images/", $src_file_logo);
            $image = "/public/Images/". $src_file_logo;

        }else{
            $image = $request->input('old_image'); 
        }

        // $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
        // $dest_file_logo = public_path() . "/Images/";
        // $logo->move(public_path() . "/Images/", $src_file_logo);
        // $logo = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('job_post')->insert([
            'jp_email' => $email,
            //'jp_by' => $request->session()->get('ssiapp_rec_id'),
            'jp_title' => $jobtitle,
            'jp_loc' => $location,
            'jp_job_type' => $jobtype,
            'jp_desc' => $description,
            'jp_app_email' => $applicationemail,
            // 'csr_upload_doc' => $closingdate,
            'jp_closing_date' => $closingdate,
            'jp_files' => $files,
            'jp_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'jp_approved' => 0,
            'jp_org_name' => $orgname,
            'jp_org_web' => $website,
            'jp_org_video' => $video,
            'jp_org_twitter' => $twiiter,
            'jp_org_logo' => $image,
            'jp_ad_type_area_of_expertise' => $areas,
            'jp_SEO' => GeneralUtils::CreateSEO($jobtitle),
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,6)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function enablejobpost(Request $request){
        $input = $request->all();
        DB::beginTransaction();
        try{
            DB::update('update job_post set jp_approved=1 where jp_id ='.$input['jp_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disablejobpost('.$input['jp_id'].')">Put on Hold</button>';
            return response()->json(array('res'=>'SUCCESS','data'=>$html));
        }catch(\Exception $ex){
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disablejobpost(Request $request){
        $input = $request->all();
       
        DB::beginTransaction();
        try{
            DB::update('update job_post set jp_approved=0 where jp_id ='.$input['jp_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enablejobpost('.$input['jp_id'].')">Approve</button>';
            return response()->json(array('res'=>'SUCCESS','data'=>$html));
        }catch(\Exception $ex){
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }
}
