<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdmissionController extends Controller
{
    public function submitAdmission(Request $request)
    {
        $title = $request->input('title');
        $inst_name = $request->input('name_institution');
        $apply_by = $request->input('apply');
        // $costdetails = str_replace(" ","-",$grant_title);
        // $csr_seo = $csr_seo . "-" . time();
        $costdetail = $request->input('costdetails');
        $thematic_area = $request->input('area');
        $displaypage = $request->input('display_page');
        $email = $request->input('email');
        $loc_state = $request->input('state');
        $academic_year = $request->input('year');
        $web_url = $request->input('website_url');
        $media_url = $request->input('url');
        // $terms_conditions = $request->input('terms');
        // $cates = $request->input('cates');
        $file = $request->file('org_logo');
        
        // $document_word = $request->file('document1');
        if($request->has('pdf_document')){
            $document = $request->file('pdf_document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        // error_log("--->>" . $document_word->getClientOriginalExtension() . public_path() . $document_word->getClientOriginalName());
        // $src_document = date('YmdHis') . $document_word->getClientOriginalName();
        // $dest_document = public_path() . "/document/";
        // $document_word->move(public_path() . "/document/", $src_document);
        // $document_word = "/public/document/" . $src_document;

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('admission')->insert([
            'adn_title' => $title,
            'adn_inst_name' => $inst_name,
            'adn_apply' => $apply_by,
            'adn_cost_details' => $costdetail,
            'adn_area' => $thematic_area,
            'adn_display_page' => $displaypage,
            'adn_email' => $email,
            'adn_state' => $loc_state,
            'adn_year' => $academic_year,
            'adn_website_url' => $web_url,
            'adn_mediaurl' => $media_url,
            'adn_pdf_document' => $document,
            // 'adn_word_document' => $document_word,
            'adn_org_logo' => $file,
            // 'csr_category' => $cates,
            'adn_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'adn_approved' => 0,
            'adn_SEO' => GeneralUtils::CreateSEO($title),
            // 'csr_g_title' => $grant_title,
            // 'csr_create_date' => $createdate,
            // 'csr_ref_url' => $ref_url,
            // 'csr_SEO' => $csr_seo,
            //'csr_document'=>$document,

            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,18)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function admissionads(Request $request)
    {
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from admission where adn_approved = 1 and adn_apply > '$today' order by adn_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                error_log(json_encode($res));
                $time = strtotime($res['adn_apply']);
                $tempdate = date("F d Y, l", $time);
                $adnsearch[] = array(
                    'adn_id' => $res['adn_id'],
                    'adn_title' => $res['adn_title'],
                    'adn_inst_name' => $res['adn_inst_name'],
                    'adn_state' => $res['adn_state'],
                    // 'csr_close_date' => $tempdate,
                    'adn_apply' => $tempdate,
                    'adn_org_logo' => $res['adn_org_logo'],
                    'adn_SEO' => $res['adn_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $adnsearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 29;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all_admission', compact(['adnsearch','seodata']));
    }
    public function ajax_search_admission(Request $request)
    {

        $body = $request->all();
        // error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from admission where adn_area  LIKE   '%" . $body['area'] . "%'and adn_state  LIKE   '%" . $body['state'] . "%' and adn_apply > '$today'";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);


        $img = asset('img/ssi_logo.svg');
        $htmldata = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['adn_apply']);
                $tempdate = date("F d Y, l", $time);
                if ($res['adn_approved'] == 1) {
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content joblist_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                <div class="col-md-2  results" style="text-align: center;">
                <img style="width:80%" src="' . asset($res['adn_org_logo']) . '" />
                </div>
                <div class="col-md-8">
                
                <div id="results" class="limittext" style="font-weight: bold;color:#004a99">
                ' . $res['adn_title'] . '
                </div>
                <div id="results">
                    <i class="" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;" >' . $res['adn_inst_name'] . '</span>

                </div>
                <div id="results">
                    <i class="fa fa-map-marker" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i>  <span style="font-weight: bold;color:#004a99">' . $res['adn_state'] . ' </span>
                    <div id="results" style="color:#293e09;"><i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <b>' . $tempdate . '</b></span>
                </div>
                    </div>
            </div>
            <div class="col-md-2 my-auto " >
            <a href="'.url('/admission/').'/'.$res['adn_SEO'].'" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>                
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        ';



                    $htmldata = $htmldata . $data;
                }
            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }
}
