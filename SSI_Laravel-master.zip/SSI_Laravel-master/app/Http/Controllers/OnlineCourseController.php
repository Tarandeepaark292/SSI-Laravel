<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OnlineCourseController extends Controller
{
    //
    public function submitonlinecourse(Request $request)
    {
        $title = $request->input('course');
        $name = $request->input('name');
        $apply = $request->input('apply');
        $category = $request->input('category');
        $area = $request->input('area');
        $display = $request->input('display');

        $email = $request->input('email');

        $media = $request->input('media');

        $location = $request->input('location');
        $year = $request->input('year');
        $url = $request->input('url');
        $logo = $request->file('logo');
        // $word = $request->file('word');
        if ($request->hasFile('pdf')) {
            $pdf = $request->file('pdf');

            // error_log("--->>" . $word->getClientOriginalExtension() . public_path() . $word->getClientOriginalName());
            // $src_document = date('YmdHis') . $word->getClientOriginalName();
            // $dest_document = public_path() . "/document/";
            // $word->move(public_path() . "/document/", $src_document);
            // $word = "/public/document/" . $src_document;

            error_log("--->>" . $pdf->getClientOriginalExtension() . public_path() . $pdf->getClientOriginalName());
            $src_document = date('YmdHis') . $pdf->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $pdf->move(public_path() . "/document/", $src_document);
            $pdf  = "/public/document/" . $src_document;
        }else{
            $pdf  = "";
        }
        error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
        $src_document = date('YmdHis') . $logo->getClientOriginalName();
        $dest_document = public_path() . "/Images/";
        $logo->move(public_path() . "/Images/", $src_document);
        $logo  = "/public/Images/" . $src_document;



        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('onlinecourse')->insert([
            'on_detail' => $title,
            'on_institute' =>   $name,
            'on_apply' =>   $apply,
            'on_radio' => $category,
            'on_area' => $area,
            'on_display' =>  $display,
            'on_email' =>   (isset($email) ? $email : ""),

            'on_media' =>   $media,
            'on_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'on_approved' => 0,
            'on_state' => $location,
            'on_year' =>   $year,
            'on_url' =>  $url,
            'on_pdf_doc' => $pdf,
            // 'on_document' => $word,
            'on_logo' =>   $logo,
            'on_SEO' => GeneralUtils::CreateSEO($title),

            // 'evt_SEO' => $event_seo,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,17)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }




    public function ajaxonlinecourse(Request $request)
    {
        $body = $request->all();
        // error_log($body['search']);
        // $sel_query = "SELECT * from publication where pub_focusarea LIKE '%" . $body['state'] . "%' and pub_type  LIKE '%" . $body['focus'] . "%' ";
      
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from onlinecourse where  on_area LIKE    '%" . $body['focus'] . "%' and  on_radio LIKE    '%" . $body['state'] . "%' and on_apply > '$today'";
        //$sel_query = "SELECT * from onlinecourse where  on_area LIKE    '%" . $body['focus'] . "%' and  on_radio LIKE    '%" . $body['state'] . "%'";
        // error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['on_approved'] == 1) {
                    $time = strtotime($res['on_apply']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '<div class="col-12 " style="margin-bottom:2rem;">
                    <div class="card content joblist_item" id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">

                                <div class="col-md-2" style="text-align: center;">
                                    <img style="width: 80%;" src="'.asset($res['on_logo']).'" />
                                </div>
                                <div class="col-md-8">
                                    <div id="results" class="limittext" style="font-weight: bold;color:#004a99;">
                                        '.($res['on_detail']) .'
                                    </div>
                                    <div id="results" style="font-weight: bold;color:#004a99;">
                                        '.$res['on_institute'] .'
                                    </div>
                                    <div id="results" style="color:#007bff;">
                                       Course Type: <b style="text-transform: capitalize;">'.$res['on_radio'] .'</b>
                                    </div>
                                    <div class="results" style="font-weight: bold;color:#007bff;">
                                    <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <b>'. $tempdate .'</b>
                                    </div>
                                </div>
                                <div class="col-md-2 my-auto " >
                                    <a href="'.url('/online-course/').'/'.$res['on_SEO'].'" class="btn btn-newprimary">Details  <i class="fa fa-chevron-right"></i></a>                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                                        ';

                    $htmldata = $htmldata . $data;
                }
            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }

    public function searchonline(Request $request)
    {

        $sel_query = "SELECT * from onlinecourse where on_approved = 1 order by on_id DESC";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['on_apply']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $onlinesearch[] = array(
                    'on_title' => $res['on_detail'],
                    'on_apply' => $tempdate,
                    'on_institute' => $res['on_institute'],
                    'on_logo' => $res['on_logo'],
                    'on_radio' => $res['on_radio'],
                    'on_SEO' => $res['on_SEO'],
                    // 'sc_email' => $res['sc_email'],
                    // 'sc_date' => $tempdate,
                    // 'sc_loc' => $res['sc_loc'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $onlinesearch = array();
        }
        $sel_query = "SELECT seo_data from SEO where seo_id = 28;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-online_course', compact(['onlinesearch','seodata']));
    }
}
