<?php

namespace App\Http\Controllers;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\GeneralEmail;
use App\Mail\JSGeneral;


class NewsController extends Controller
{
    //
    public function submitNEWS(Request $request)
    {
        $head = $request->input('heading');
        // $date = $request->input('dateofrelease');
        $body = $request->input('body');
        $image = $request->file('image');
        $links = $request->input('links');
        // $videolinks = $request->input('videolink');

        $news_seo = str_replace(" ", "-", $head);
        $news_seo = $news_seo . "-" . time();

        error_log("--->>" . $image->getClientOriginalExtension() . public_path() . $image->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $image->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $image->move(public_path() . "/Images/", $src_file_logo);
        $image = "public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('news')->insert([
            'news_head' => $head,
            
            'news_body' => $body,
            'news_image' => $image,
            'news_links' => $links,
            
            'news_create' => $createdate,
            'news_SEO' => $news_seo,
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/success');
    }

    public function show_news_Detail(Request $request, $encid)
    {
        try {
            $sel_query = "SELECT * from news where news.news_id = " . $encid;

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['news_create']);
                $tempdate = date("Y-m-d", $time);


                $jp_obj = array(
                    'news_id' => $res['news_id'],
                    'news_body' => $res['news_body'],
                    'news_DOR' => $res['news_DOR'],
                    'news_image' => $res['news_image'],
                    'news_create' => $tempdate,
                    'news_links' => $res['news_links'],
                    'news_videolink' => $res['news_videolink'],
                    'news_head' => $res['news_head'],

                );
            } else {
            }
            return view('edit_news', compact(['jp_obj']));
        } catch (\Exception $ex) {
            dd($ex);

            error_log('exception' . $ex->getMessage());
        }
    }

    public function update_news(Request $request, $encid)
    {
        // dd($request);
        $head = $request->input('heading');
        // $date = $request->input('dateofrelease');
        $body = $request->input('body');
        $image = $request->file('image');
        $links = $request->input('links');
        
        

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $file = "/public/Images/" . $src_file_logo;
        } else {
            $file = $request->input('old_image');
        }

        DB::beginTransaction();

        try {
            DB::table('news')->where('news_id', $encid)->update([
                'news_head' => $head,
               
                'news_body' => $body,
                'news_image' => $file,
                'news_links' => $links,
               

            ]);
            DB::commit();
            return \redirect('/admin/news_list');
        } catch (\Exception $ex) {
            dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function News(Request $request)
    {

        $sel_query = "SELECT * from news";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['news_create']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $newssearch[] = array(
                    'news_DOR' => $res['news_DOR'],
                    'news_body' => $res['news_body'],
                    'news_links' => $res['news_links'],
                    'news_videolink' => $res['news_videolink'],
                    'news_create' => $tempdate,
                    'news_head' => $res['news_head'],
                    'news_image' => $res['news_image'],
                    'news_SEO' => $res['news_SEO'],
                );
            }
        } else {
            $newssearch = array();
        }

        return view('news', compact(['newssearch']));
    }


    public function testmail(Request $request ){

        $today = date("Y-m-d") . " 00:00:00";
            $sel_query = "SELECT * FROM job_post where jp_approved=1 AND jp_closing_date > '$today' order by jp_id DESC limit 10;"; 
            error_log($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            $htmldata = "";

            if (count($res_query)) {
                $htmldata = $htmldata . "<h2>Latest Jobs</h2><hr>";
                foreach ($res_query as $res) {
                    $htmldata = $htmldata . '<table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                        <tr>
                            <td width="30%"><img src="'.asset($res['jp_org_logo']).'" alt="" style="width: 100%; max-width: 600px; height: auto; margin: auto; display: block;">
                            </td>
                            <td width="70%">
                                <table class="table-action" width="100%" cellspacing="0" cellspacing="0">
                                    <tr>
                                        <td>
                                            <b>Global Youth Participation Specialist</b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Johnson & Johnson
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="'.url("job-post/".$res['jp_SEO']).'" target="_blank">View Detail</a>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>';
                }
            }
        $data = array(
            'js_name' => "test Org",
            'js_pwd' => "test mail",
            'js_email' => 'test@socialservicesindia.org',
            'js_phone' => '3435647889',
            'org_name' => 'ddfdsf',
            'htmldata' => $htmldata
        );

        //Mail::to('pranay.aark@gmail.com')->send(new JSGeneral($data));
        // return view('email_template.general',compact(['data']));
        // return view('email_template.forgotpwd',compact(['data']));
        //return view('email_template.jsgeneral',compact(['data']));
        //return \redirect('/');

        return view('email_template.subscription',compact(['data']));
    }
}


