<?php

namespace App\Http\Controllers;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;

class AdminController extends Controller
{
    //

    public function JobseekerPaymentList(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT *,job_seeker.js_name as r_name FROM payments INNER JOIN job_seeker on payments.pay_user_id = job_seeker.js_id WHERE payments.pay_user_type = 1 ;";
        $res_query = DBraw::select($sel_query);
        error_log(json_encode($res_query));
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['pay_create_date']);
                $tempdate = date("M d Y", $time);
                $paylist[] = array(
                    'pay_id' => $res['pay_id'],
                    'pay_total' => $res['pay_total'],
                    'pay_provider_trans_id' => $res['pay_provider_trans_id'],
                    'pay_order_id' => $res['pay_order_id'],
                    'pay_create_date' => $tempdate,
                    'pay_by' => $res['r_name'],
                );
            }
        } else {
            $paylist = array();
        }
        return view('adm_js_payment_list', compact(['paylist']));
    }

    public function JobseekerPurchaseList(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT *,job_seeker.js_name as r_name, payments.pay_order_id AS pay_order_id from purchases inner JOIN job_seeker on purchases.pur_user = job_seeker.js_id INNER JOIN payments ON payments.pay_id=purchases.pur_payment_id WHERE pur_u_type= 1";
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['pur_used'] == 1) {
                    $status = 'Used';
                } else {
                    $status = 'Not Used';
                }
                $time = strtotime($res['pur_create_date']);
                $tempdate = date("M d Y", $time);
                $purchaselist[] = array(
                    'pur_id' => $res['pur_id'],
                    'pur_ser_name' => $res['pur_ser_name'],
                    'pur_ser_price' => $res['pur_ser_price'],
                    'status' => $status,
                    'order_id' => $res['pay_order_id'],
                    'pur_create_date' => $tempdate,
                    'pur_by' => $res['r_name'],
                );
            }
        } else {

            $purchaselist = array();
        }
        return view('adm_js_purchase_list', compact(['purchaselist']));
    }

    public function RecruiterPaymentList(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        error_log($request->session()->get('ssiapp_rec_token'));
        $sel_query = "SELECT *,recruiter.r_name as r_name FROM payments INNER JOIN recruiter on payments.pay_user_id = recruiter.r_id WHERE payments.pay_user_type = 2 ;";
        $res_query = DBraw::select($sel_query);
        error_log(json_encode($res_query));
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['pay_create_date']);
                $tempdate = date("M d Y", $time);
                $paylist[] = array(
                    'pay_id' => $res['pay_id'],
                    'pay_total' => $res['pay_total'],
                    'pay_provider_trans_id' => $res['pay_provider_trans_id'],
                    'pay_order_id' => $res['pay_order_id'],
                    'pay_create_date' => $tempdate,
                    'pay_by' => $res['r_name'],
                );
            }
        } else {
            $paylist = array();
        }
        return view('adm_rec_payment_list', compact(['paylist']));
    }

    public function RecruiterPurchaseList(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        error_log($request->session()->get('ssiapp_rec_token'));
        $sel_query = "SELECT *,recruiter.r_name as r_name, payments.pay_order_id AS pay_order_id from purchases inner JOIN recruiter on purchases.pur_user = recruiter.r_id INNER JOIN payments ON payments.pay_id=purchases.pur_payment_id WHERE pur_u_type= 2";
        $res_query = DBraw::select($sel_query);
        error_log($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['pur_used'] == 1) {
                    $status = 'Used';
                } else {
                    $status = 'Not Used';
                }
                $time = strtotime($res['pur_create_date']);
                $tempdate = date("M d Y", $time);
                $purchaselist[] = array(
                    'pur_id' => $res['pur_id'],
                    'pur_ser_name' => $res['pur_ser_name'],
                    'pur_ser_price' => $res['pur_ser_price'],
                    'status' => $status,
                    'order_id' => $res['pay_order_id'],
                    'pur_create_date' => $tempdate,
                    'pur_by' => $res['r_name'],
                );
            }
        } else {

            $purchaselist = array();
        }
        return view('adm_rec_purchase_list', compact(['purchaselist']));
    }


    public function Eventlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT *,recruiter.r_name as r_name from events inner join recruiter on events.evt_submitted_by = recruiter.r_id; ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                if ($today >= $time) {
                    $expevtlist[] = array(
                        'evt_id' => $res['evt_id'],
                        'evt_title' => $res['evt_title'],
                        'evt_email' => $res['evt_email'],
                        'evt_org_name' => $res['evt_org_name'],
                        'evt_end_date' => $tempdate,
                        'evt_submitted_by' => $res['r_name'],
                        'evt_status' => $status,
                        'evt_approved' => $res['evt_approved'],
                    );
                } else {
                    $evtlist[] = array(
                        'evt_id' => $res['evt_id'],
                        'evt_title' => $res['evt_title'],
                        'evt_email' => $res['evt_email'],
                        'evt_org_name' => $res['evt_org_name'],
                        'evt_end_date' => $tempdate,
                        'evt_submitted_by' => $res['r_name'],
                        'evt_status' => $status,
                        'evt_approved' => $res['evt_approved'],
                    );
                }

               
            }
        } else {
            $evtlist = array();
            $expevtlist = array();
        }
        if (!isset($evtlist)) {
            $evtlist = array();
        }
        if (!isset($expevtlist)) {
            $expevtlist = array();
        }
        return view('adm_event_list', compact(['evtlist','expevtlist']));
    }

    public function Awardlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT *,recruiter.r_name as r_name from awards inner join recruiter on awards.award_submitted_by = recruiter.r_id; ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['award_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['award_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                if ($today >= $time) {
                    $expevtlist[] = array(
                        'award_id' => $res['award_id'],
                        'award_title' => $res['award_title'],
                        'award_email' => $res['award_email'],
                        'award_org_name' => $res['award_org_name'],
                        'award_end_date' => $tempdate,
                        'award_create_date' => $res['award_create_date'],
                        'award_submitted_by' => $res['r_name'],
                        'award_status' => $status,
                        'award_approved' => $res['award_approved'],
                    );
                } else {
                    $evtlist[] = array(
                        'award_id' => $res['award_id'],
                        'award_title' => $res['award_title'],
                        'award_email' => $res['award_email'],
                        'award_org_name' => $res['award_org_name'],
                        'award_end_date' => $tempdate,
                        'award_create_date' => $res['award_create_date'],
                        'award_submitted_by' => $res['r_name'],
                        'award_status' => $status,
                        'award_approved' => $res['award_approved'],
                    );
                }
            }
        } else {
            $evtlist = array();
            $expevtlist = array();
        }
        return view('adm_award_list', compact(['evtlist','expevtlist']));
    }

    public function show_rfp_Detail(Request $request, $encid)
    {
        try {


            $sel_query = "SELECT * from rfp where rfp.rfp_id = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'rfp_id' => $res['rfp_id'],
                    'rfp_g_amt' => $res['rfp_g_amt'],
                    'rfp_title' => $res['rfp_title'],
                    'rfp_org' => $res['rfp_org'],
                    'rfp_email' => $res['rfp_email'],
                    'rfp_loc' => $res['rfp_loc'],
                    'rfp_close_date' => $tempdate,

                    'rfp_status' => $status,
                    'rfp_cates' => $res['rfp_category'],
                    'rfp_desc' => $res['rfp_desc'],
                    'rfp_o_ach' => $res['rfp_o_ach'],
                    'rfp_logo' => $res['rfp_logo'],
                    // 'evt_ref_url' => $res['evt_ref_url'],
                    'rfp_approved' => $res['rfp_approved'],
                    'rfp_upload_doc' => $res['rfp_upload_doc'],
                    // 'evt_upload_banner' => $res['evt_upload_banner'],
                    // 'evt_email' => $res['evt_email'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['rfp_category']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('edit_rfp', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    public function show_fell_Detail(Request $request, $encid)
    {
        try {

            $sel_query = "SELECT * from fellowship where fellowship.fell_id = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['fell_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'fell_id' => $res['fell_id'],
                    'fell_loc' => $res['fell_loc'],
                    'fell_title' => $res['fell_title'],
                    'fell_o_name' => $res['fell_o_name'],
                    'fell_end_date' => $tempdate,
                    'fell_email' => $res['fell_email'],

                    'fell_status' => $status,
                    'fell_cate' => $res['fell_cate'],
                    'fell_desc' => $res['fell_desc'],
                    'fell_o_logo' => $res['fell_o_logo'],
                    'fell_url' => $res['fell_url'],
                    'fell_approved' => $res['fell_approved'],
                    'fell_upload_doc' => $res['fell_upload_doc'],
                    // 'evt_upload_banner' => $res['evt_upload_banner'],
                    // 'evt_email' => $res['evt_email'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['fell_cate']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('edit_fell', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    public function scholarshiplist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;

        $sel_query = "SELECT *,recruiter.r_name as r_name from scholarship inner join recruiter on scholarship.sc_submitted_by = recruiter.r_id;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['sc_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['sc_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                if ($today >= $time) {
                    $expscholarshiplist[] = array(
                        'sc_id' => $res['sc_id'],
                        'sc_title' => $res['sc_title'],
                        'sc_loc' => $res['sc_loc'],
                        'sc_url' => $res['sc_url'],
                        'sc_date' => $tempdate,
                        'sc_submitted_by' => $res['r_name'],
    
                        'sc_approved' => $res['sc_approved'],
                    );
                } else {
                    $scholarshiplist[] = array(
                        'sc_id' => $res['sc_id'],
                        'sc_title' => $res['sc_title'],
                        'sc_loc' => $res['sc_loc'],
                        'sc_url' => $res['sc_url'],
                        'sc_date' => $tempdate,
                        'sc_submitted_by' => $res['r_name'],
    
                        'sc_approved' => $res['sc_approved'],
                    );
                }


                
            }
        } else {
            $scholarshiplist = array();
            $expscholarshiplist = array();

        }
        if (!isset($scholarshiplist)) {
            $scholarshiplist = array();
        }
        if (!isset($expscholarshiplist)) {
            $expscholarshiplist = array();
        }
        return view('adm_scholarship_list', compact(['scholarshiplist','expscholarshiplist']));
    }

    public function enablescholarship(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update scholarship set sc_approved=1 where sc_id =' . $input['sc_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disablescholarship(' . $input['sc_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disablescholarship(Request $request)
    {
        $input = $request->all();
        error_log(json_encode($input));
        DB::beginTransaction();
        try {
            DB::update('update scholarship set sc_approved=0 where sc_id =' . $input['sc_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enablescholarship(' . $input['sc_id'] . ')">Approve</button>';
            error_log($html);
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function CSRlist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT *,recruiter.r_name as r_name from csr inner join recruiter on csr.csr_submitted_by = recruiter.r_id;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['csr_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log("today " . $today . " -- time " . $time);
                if ($today >= $time) {
                    $expcsrlist[] = array(
                        'csr_id' => $res['csr_id'],
                        'csr_g_title' => $res['csr_g_title'],
                        'csr_g_amt' => $res['csr_g_amt'],
                        'csr_org' => $res['csr_org'],
                        'csr_close_date' => $tempdate,
                        'csr_submitted_by' => $res['r_name'],
                        'csr_status' => $status,
                        'csr_approved' => $res['csr_approved'],
                    );
                } else {
                    $csrlist[] = array(
                        'csr_id' => $res['csr_id'],
                        'csr_g_title' => $res['csr_g_title'],
                        'csr_g_amt' => $res['csr_g_amt'],
                        'csr_org' => $res['csr_org'],
                        'csr_close_date' => $tempdate,
                        'csr_submitted_by' => $res['r_name'],
                        'csr_status' => $status,
                        'csr_approved' => $res['csr_approved'],
                    );
                }

               
            }
        } else {
            $csrlist = array();
            $expcsrlist = array();
        }
        if (!isset($csrlist)) {
            $csrlist = array();
        }
        if (!isset($expcsrlist)) {
            $expcsrlist = array();
        }
        return view('adm_csr_list', compact(['csrlist','expcsrlist']));
    }

    public function FELLOWSHIP(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;

        $sel_query = "SELECT *,recruiter.r_name as r_name from fellowship inner join recruiter on fellowship.fell_submitted_by = recruiter.r_id;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['fell_end_date']);
                $tempdate = date("M d Y", $time);
                if ($res['fell_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                if ($today >= $time) {
                    $expfelllist[] = array(
                        'fell_id' => $res['fell_id'],
                        'fell_title' => $res['fell_title'],
                        'fell_email' => $res['fell_email'],
                        'fell_o_name' => $res['fell_o_name'],
                        'fell_end_date' => $tempdate,
                        'fell_submitted_by' => $res['r_name'],
                        'fell_status' => $status,
                        'fell_approved' => $res['fell_approved'],
                    );
                }else{
                    $felllist[] = array(
                        'fell_id' => $res['fell_id'],
                        'fell_title' => $res['fell_title'],
                        'fell_email' => $res['fell_email'],
                        'fell_o_name' => $res['fell_o_name'],
                        'fell_end_date' => $tempdate,
                        'fell_submitted_by' => $res['r_name'],
                        'fell_status' => $status,
                        'fell_approved' => $res['fell_approved'],
                    );
                }
               
            }
        } else {
            $felllist = array();
            $expfelllist = array();
        }
        if (!isset($felllist)) {
            $felllist = array();
        }
        if (!isset($expfelllist)) {
            $expfelllist = array();
        }
        return view('adm_fell_list', compact(['felllist','expfelllist']));
    }

    public function RECRUITER(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from recruiter ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $recruiterlist[] = array(
                    'r_org_name' => $res['r_org_name'],
                    'r_email' => $res['r_email'],
                    'r_phone' => $res['r_phone'],

                    'r_pwd' => $res['r_pwd'],
                    'r_comp_type' => $res['r_comp_type'],

                    'r_name' => $res['r_name'],

                    'r_org_name' => $res['r_org_name'],

                    'r_off_website' => $res['r_off_website'],
                );
            }
        } else {
            $reclist = array();
        }
        return view('adm_recruiter_list', compact(['recruiterlist']));
    }

    public function RFP(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT *,recruiter.r_name as r_name from rfp inner join recruiter on rfp.rfp_submitted_by = recruiter.r_id;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['rfp_close_date']);
                $tempdate = date("M d Y", $time);
                if ($res['rfp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                if ($today >= $time) {
                    $exprfplist[] = array(
                        'rfp_id' => $res['rfp_id'],
                        'rfp_title' => $res['rfp_title'],
                        'rfp_g_amt' => $res['rfp_g_amt'],
                        'rfp_org' => $res['rfp_org'],
                        'rfp_close_date' => $tempdate,
                        'rfp_submitted_by' => $res['r_name'],
                        'rfp_status' => $status,
                        'rfp_approved' => $res['rfp_approved'],
                    );
                }else{
                    $rfplist[] = array(
                        'rfp_id' => $res['rfp_id'],
                        'rfp_title' => $res['rfp_title'],
                        'rfp_g_amt' => $res['rfp_g_amt'],
                        'rfp_org' => $res['rfp_org'],
                        'rfp_close_date' => $tempdate,
                        'rfp_submitted_by' => $res['r_name'],
                        'rfp_status' => $status,
                        'rfp_approved' => $res['rfp_approved'],
                    );
                }
                
            }
        } else {
            $rfplist = array();
            $exprfplist = array();

        }

        if (!isset($exprfplist)) {
            $exprfplist = array();
        }
        if (!isset($rfplist)) {
            $rfplist = array();
        }
        return view('adm_rfp_list', compact(['rfplist','exprfplist']));
    }

    public function REG(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT *,recruiter.r_name as r_name from register_grants inner join recruiter on register_grants.reg_submitted_by = recruiter.r_id;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['reg_valid_To']);
                $tempdate = date("M d Y", $time);
                if ($res['reg_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $reglist[] = array(
                    'reg_grant_id' => $res['reg_grant_id'],
                    'reg_v_org' => $res['reg_v_org'],
                    'reg_email' => $res['reg_email'],
                    'reg_website' => $res['reg_website'],
                    'reg_valid_To' => $tempdate,
                    'reg_submitted_by' => $res['r_name'],
                    'reg_status' => $status,
                    'reg_approved' => $res['reg_approved'],
                );
            }
        } else {
            $reglist = array();
        }
        return view('adm_reg_list', compact(['reglist']));
    }

    public function REC(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from job_post";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $reclist[] = array(
                    'jp_title' => $res['jp_title'],
                    'jp_email' => $res['jp_email'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_close_date' => $tempdate,
                    'jp_submitted_by' => $res['jp_submitted_by'],
                    'jp_status' => $status,
                    'jp_approved' => $res['jp_approved'],
                );
            }
        } else {
            $reclist = array();
        }
        return view('adm_rec_list', compact(['reclist']));
    }




    public function enableCSR(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update csr set csr_approved=1 where csr_id =' . $input['csr_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableCSR(' . $input['csr_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableCSR(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update csr set csr_approved=0 where csr_id =' . $input['csr_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableCSR(' . $input['csr_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function enableEvent(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update events set evt_approved=1 where evt_id =' . $input['evt_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableEvt(' . $input['evt_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableEvent(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update events set evt_approved=0 where evt_id =' . $input['evt_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableEvt(' . $input['evt_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function enableAward(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update awards set award_approved=1 where award_id =' . $input['awd_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableAwd(' . $input['awd_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableAward(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update awards set award_approved=0 where award_id =' . $input['awd_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableAwd(' . $input['awd_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }


    public function enableFell(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update fellowship set fell_approved=1 where fell_id =' . $input['fell_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableFell(' . $input['fell_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableFell(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update fellowship set fell_approved=0 where fell_id =' . $input['fell_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableFell(' . $input['fell_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function enableRFP(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update rfp set rfp_approved=1 where rfp_id =' . $input['rfp_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableRfp(' . $input['rfp_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableRFP(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update rfp set rfp_approved=0 where rfp_id =' . $input['rfp_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableRfp(' . $input['rfp_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function enableRgrant(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update register_grants set reg_approved=1 where reg_grant_id =' . $input['reg_grant_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableRgrant(' . $input['reg_grant_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableRgrant(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update register_grants set reg_approved=0 where reg_grant_id =' . $input['reg_grant_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableRgrant(' . $input['reg_grant_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function JOB(Request $request)
    {
        $sel_query = "SELECT * from job_seeker where js_id =" . $request->session()->get('ssiapp_js_id');
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log(json_encode($res));
                $joblist[] = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    'js_status' => $status,
                    'js_approved' => $res['js_approved'],
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                );
            }
        } else {
            $joblist = array();
        }
        return view('js_job_list', compact(['joblist']));
    }

    public function admJobListEdit(Request $request, $jspid)
    {
        $id = $jspid;
        $sel_query = "SELECT * from job_seeker where js_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['js_createdate']);
                $tempdate = date("M d Y", $time);
                if ($res['js_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $joblist = array(
                    'js_id' => $res['js_id'],
                    'js_p_title' => $res['js_p_title'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_createdate' => $tempdate,
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_loc' => $res['js_loc'],
                    //  'js_adline' => $res['js_adline'],
                    //  'js_city' => $res['js_city'],
                    //  'js_state' => $res['js_state'],
                    //  'js_zip' => $res['js_zip'],
                    'js_vids' => $res['js_vids'],
                    'js_skills' => $res['js_skills'],
                );
            }
        } else {
            $joblist = array();
        }
        return view('jobeditpage', compact(['joblist']));
    }
    public function admJobListupdate(Request $request, $jspid)
    {


        $input = $request->all();
        $jspid = $jspid;

        \error_log(json_encode($input));
        DB::beginTransaction();
        try {
            $mgmtdate = date("Y-m-d H:i:s");
            // $time = strtotime($res['js_createdate']);
            //     $tempdate = date("M d Y", $time);
            DB::table('job_seeker')->where('js_id', $jspid)->update([
                'js_p_title' => $input['title'],
                'js_email' => $input['email'],
                'js_name' => $input['name'],
                'js_createdate' => $mgmtdate,
                'js_area_expertise' => $input['area'],
                'js_loc' => $input['location'],
                //  'js_city' => $input['city'],
                //  'js_state' => $input['state'],
                //  'js_zip' => $input['zip'],
                'js_vids' => $input['video'],

                'js_skills' => $input['skill'],
                // 'js_submitted_by' => $input['js_submitted_by'],
                // 'js_status' => $status,
                // 'js_approved' => $input['js_approved'],
                // 'site_loc' => $input['loc_id'],
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            $temp = array(
                'js_p_title' => $input['title'],
                'js_email' => $input['email'],
                'js_name' => $input['name'],
                'js_createdate' => $mgmtdate,
                'js_area_expertise' => $input['area'],
                'js_loc' => $input['location'],
                // 'js_adline' => $input['address'],
                // 'js_city' => $input['city'],
                // 'js_state' => $input['state'],
                // 'js_zip' => $input['zip'],
                'js_vids' => $input['video'],
                'js_skills' => $input['skill'],
                // 'js_submitted_by' => $input['js_submitted_by'],
                // 'js_status' => $status,
                // 'js_approved' => $input['js_approved'],
                'js_id' => $id,
            );
            return redirect('/js_job_list');
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function admin_donations(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from donate ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $donationlist[] = array(
                    'donate_id' => $res['donate_id'],
                    'donate_total_goal' => $res['donate_total_goal'],
                    'donation_title' => $res['donation_title'],
                    'donate_org_name' => $res['donate_org_name'],
                    'donate_foc_Area' => $res['donate_foc_Area'],
                    'donate_state' => $res['donate_state'],

                );
            }
        } else {
            $donationlist = array();
        }
        return view('adm_donation_list', compact(['donationlist']));
    }

    public function admin_news(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * from news ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $newlist[] = array(
                    'news_id' => $res['news_id'],
                    'news_DOR' => $res['news_DOR'],
                    'news_body' => $res['news_body'],
                    'news_image' => $res['news_image'],
                    'news_links' => $res['news_links'],
                    'news_videolink' => $res['news_videolink'],
                    'news_head' => $res['news_head'],
                );
            }
        } else {
            $newlist = array();
        }
        return view('adm_news_list', compact(['newlist']));
    }

    public function admin_show_news_view(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('adm_postnews');
    }

    public function admin_show_csrfunder_view(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }


        return view('adm_post_csrfunder', compact(['html']));
    }

    public function admin_show_fcrafunder_view(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }

        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }


        return view('adm_post_fcrafunder', compact(['html']));
    }

    public function admin_show_donate_detail_view(Request $request, $jspid)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $id = $jspid;
        $sel_query = "SELECT * from donate where donate_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                // $time = strtotime($res['js_createdate']);
                // $tempdate = date("Y-m-d", $time);



                $donation = array(
                    'donate_id' => $res['donate_id'],
                    'donation_title' => $res['donation_title'],
                    'donate_Summary' => $res['donate_Summary'],
                    'donation_banner' => $res['donation_banner'],
                    'donate_total_goal' => $res['donate_total_goal'],
                    'donate_fundraiser' => $res['donate_fundraiser'],
                    'donate_challenge' => $res['donate_challenge'],
                    'donate_solution' => $res['donate_solution'],
                    'donate_long_impact' => $res['donate_long_impact'],
                    'donate_additional_documentation' => $res['donate_additional_documentation'],
                    'donate_ref_url' => $res['donate_ref_url'],
                    'donate_logo' => $res['donate_logo'],
                    'donate_org_detail' => $res['donate_org_detail'],
                    'donate_org_name' => $res['donate_org_name'],
                    'donate_loc' => $res['donate_loc'],
                    'donate_website' => $res['donate_website'],
                    'donate_approved' => $res['donate_approved'],
                    'donate_submitted_by' => $res['donate_submitted_by'],
                    'donate_state' => $res['donate_state'],
                    'donate_foc_Area' => $res['donate_foc_Area'],
                    'donate_checkout_url' => $res['donate_checkout_url'],
                );
            }
        } else {
            $donation = array();
        }

        return view('adm_show_donate_detail', compact(['donation']));
    }

    public function show_csr_Detail(Request $request, $encid)
    {
        try {
            // dd($request)
            //$html = GeneralUtils::Category();
            $sel_query = "SELECT * from csr where csr_id = " . $encid;
            // dd($sel_query);
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            // dd($res_query);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['csr_close_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['csr_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                // dd($res['csr_desc']);

                $jp_obj = array(
                    'csr_id' => $res['csr_id'],
                    'csr_org' => $res['csr_org'],
                    'csr_loc' => $res['csr_loc'],
                    'csr_g_amt' => $res['csr_g_amt'],
                    'csr_close_date' => $res['csr_close_date'],
                    'csr_cates' => $res['csr_category'],
                    'csr_email' => $res['csr_email'],
                    'csr_desc' => $res['csr_desc'],
                    'csr_upload_doc' => $res['csr_upload_doc'],
                    'csr_logo' => $res['csr_logo'],
                    'csr_category' => $res['csr_category'],
                    'csr_submitted_by' => $res['csr_submitted_by'],
                    'csr_approved' => $res['csr_approved'],
                    'csr_g_title' => $res['csr_g_title'],
                    'csr_ref_url' => $res['csr_ref_url'],

                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['csr_category']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('edit_csr', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function enableonline(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update onlinecourse set on_approved=1 where on_id =' . $input['on_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableonline(' . $input['on_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableonline(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update onlinecourse set on_approved=0 where on_id =' . $input['on_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableonline(' . $input['on_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function showapplicant_view(Request $request)
    {
        try {

            $sel_query = "select * from job_apply inner join recruiter on recruiter.r_id = job_apply.ja_r_id inner join job_seeker on job_seeker.js_id = job_apply.ja_js_id inner join job_post on job_post.jp_id = job_apply.ja_job_id";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                foreach ($res_query as $res) {
                    $time = strtotime($res['ja_create_date']);
                    $tempdate = date("M d Y", $time);
                    $applicants[] = array(
                        'r_org_name' => $res['r_org_name'],
                        'r_comp_type' => $res['r_comp_type'],
                        'r_name' => $res['r_name'],
                        'js_name' => $res['js_name'],
                        'jp_title' => $res['jp_title'],
                        'jp_SEO' => $res['jp_SEO'],
                        'ja_create_date' => $tempdate,

                    );
                }
            }
            return view('/adm_applicant_list', compact(['applicants']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    public function show_online(Request $request, $pbcid)
    {
        try {

            $sel_query = "SELECT * from onlinecourse where onlinecourse.on_id = " . $pbcid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                if ($res['on_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'on_id' => $res['on_id'],

                    'on_detail' => $res['on_detail'],
                    'on_institute' => $res['on_institute'],
                    'on_apply' => $res['on_apply'],

                    'on_status' => $status,

                    'on_radio' => $res['on_radio'],
                    'on_display' => $res['on_display'],
                    'on_email' => $res['on_email'],
                    'on_area' => $res['on_area'],
                    'on_state' => $res['on_state'],
                    'on_year' => $res['on_year'],
                    'on_url' => $res['on_url'],
                    'on_logo' => $res['on_logo'],
                    'on_pdf_doc' => $res['on_pdf_doc'],

                    'on_document' => $res['on_document'],
                    'on_media' => $res['on_media'],


                );
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('/adm_online_edit', compact(['jp_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }

    public function update_fell(Request $request, $encid)
    {
        // dd($request);
        $fellowship_title = $request->input('title');
        // $event_seo = str_replace(" ","-",$event_title);
        // $event_seo = $event_seo . "-" . time();
        $org_name = $request->input('name');
        $email = $request->input('email');
        $location = $request->input('location');
        $desc = $request->input('desc');
        $dead_date = $request->input('deadlinedate');
        $cates = $request->input('cates');
        // dd($cates);


        $refurl = $request->input('url');

        if ($request->hasFile('org_logo')) {
            $org_logo = $request->file('org_logo');
            error_log("--->>" . $org_logo->getClientOriginalExtension() . public_path() . $org_logo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $org_logo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $org_logo->move(public_path() . "/Images/", $src_file_logo);
            $image = "/public/Images/" . $src_file_logo;
        } else {
            $image = $request->input('org_old_logo');
        }

        if ($request->hasFile('upload')) {
            $document = $request->file('upload');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('pdf_old_doc');
        }


        DB::beginTransaction();

        try {
            DB::table('fellowship')->where('fell_id', $encid)->update([
                'fell_title' => $fellowship_title,
                'fell_loc' => $location,
                'fell_o_name' => $org_name,
                'fell_end_date' => $dead_date,
                'fell_email' => $email,
                'fell_desc' => $desc,
                'fell_url' => $refurl,
                'fell_upload_doc' => (isset($document)) ? $document : "",
                'fell_o_logo' => $image,
                'fell_cate' => $cates,
                //'fell_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                //'fell_cate' =>$cates,
                // 'evt_upload_banner' => $db_name_banner,
            ]);
            DB::commit();
            return \redirect('/admin/fell-list');
        } catch (\Exception $ex) {
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function update_rfp(Request $request, $encid)
    {
        // dd($request);
        $grant_title = $request->input('grant_title');
        // $event_seo = str_replace(" ","-",$event_title);
        // $event_seo = $event_seo . "-" . time();
        $org_name = $request->input('orgname');
        $closedate = $request->input('close_date');
        $email = $request->input('email');
        $location = $request->input('location');
        $descproposal = $request->input('proposal_desc');
        $total_amt = $request->input('amt');
        // $orgpan = $request->input('organisation_pan');
        $orgachivements = $request->input('ach');
        $cates = $request->input('cates');
        //$cates = json_encode($cate);

        // $cates = $request->input('cates');

        if ($request->hasFile('org_logo')) {
            $file = $request->file('org_logo');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $db_name_logo = "/public/Images/" . $src_file_logo;
        } else {
            $db_name_logo = $request->input('old_logo');
        }
        // dd($request->file('pdf_doc'));
        if ($request->hasFile('pdf_doc')) {
            $document = $request->file('pdf_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('pdf_old');
        }


        DB::beginTransaction();

        try {
            DB::table('rfp')->where('rfp_id', $encid)->update([
                'rfp_title' => $grant_title,
                'rfp_org' => $org_name,
                'rfp_close_date' => $closedate,
                'rfp_desc' => $descproposal,
                'rfp_g_amt' => $total_amt,
                'rfp_email' => $email,
                'rfp_loc' => $location,
                'rfp_o_ach' => $orgachivements,
                'rfp_upload_doc' => (isset($document)) ? $document : "",
                'rfp_logo' => $db_name_logo,
                // 'rfp_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                'rfp_category' => $cates,
                // 'rfp_pan'=>
                // 'evt_upload_banner' => $db_name_banner,
            ]);

            DB::commit();
            return \redirect('/admin/rfp-list');
        } catch (\Exception $ex) {
            DB::rollback();

            return \redirect('/error-page');
        }
    }

    public function update_csr(Request $request, $encid)
    {
        // dd($request);
        $grant_title = $request->input('title');
        // $event_seo = str_replace(" ","-",$event_title);
        // $event_seo = $event_seo . "-" . time();
        $org_name = $request->input('org');
        $closingdate = $request->input('date');
        $email = $request->input('email');
        $location = $request->input('loc');
        $descproposal = $request->input('desc');
        $grant_amt = $request->input('amt');
        $cates = $request->input('cates');
        //$cates = json_encode($cate);
        // $cates = $request->input('cates');


        $ref_url = $request->input('url');

        if ($request->hasFile('company_logo')) {
            $file = $request->file('company_logo');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $db_name_logo = "/public/Images/" . $src_file_logo;
        } else {
            $db_name_logo = $request->input('old_company_logo');
        }

        if ($request->hasFile('document')) {
            $document = $request->file('document');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('old_document');
        }



        DB::beginTransaction();

        try {
            DB::table('csr')->where('csr_id', $encid)->update([
                'csr_org' => $org_name,
                'csr_loc' => $location,
                'csr_g_amt' => $grant_amt,
                'csr_close_date' => $closingdate,
                'csr_email' => $email,
                'csr_desc' => $descproposal,
                'csr_logo' => $db_name_logo,
                //'csr_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                'csr_ref_url' => $ref_url,
                'csr_upload_doc' => (isset($document)) ? $document : "",
                'csr_category' => $cates,
                // 'evt_upload_banner' => $db_name_bannerh,
            ]);
            DB::commit();
            return \redirect('/admin/csr-list');
        } catch (\Exception $ex) {
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function update_onlinecourse(Request $request, $pbcid)
    {


        $title = $request->input('course');
        $name = $request->input('name');
        $apply = $request->input('apply');
        $category = $request->input('category');
        $area = $request->input('area');
        $display = $request->input('display');

        $email = $request->input('email');
        $location = $request->input('location');
        $year = $request->input('year');
        $url = $request->input('url');


        $media = $request->input('media');
        //word
        if ($request->hasFile('word')) {
            $word = $request->file('word');
            error_log("--->>" . $word->getClientOriginalExtension() . public_path() . $word->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $word->getClientOriginalName();
            $dest_file_logo = public_path() . "/document/";
            $word->move(public_path() . "/document/", $src_file_logo);
            $word = "/public/document/" . $src_file_logo;
        } else {
            $word = $request->input('old_word');
            //dd($word);
        }
        //pdf
        if ($request->hasFile('pdf')) {
            $pdf = $request->file('pdf');
            $src_document = date('YmdHis') . $pdf->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $pdf->move(public_path() . "/document/", $src_document);
            $pdf = "/public/document/" . $src_document;
        } else {
            $pdf = $request->input('old_pdf');
        }


        //logo
        if ($request->hasFile('logo')) {
            $logo = $request->file('logo');
            $src_document = date('YmdHis') . $logo->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $logo->move(public_path() . "/Images/", $src_document);
            $dblogo = "/public/Images/" . $src_document;
        } else {
            $dblogo = $request->input('old_logo');
        }
        // dd($word);
        DB::beginTransaction();

        try {
            DB::table('onlinecourse')->where('on_id', $pbcid)->update([
                'on_detail' => $title,
                'on_institute' =>   $name,
                'on_apply' =>   $apply,
                'on_radio' => $category,
                'on_area' => $area,
                'on_display' => $display,
                'on_email' => $email,
                //'on_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                'on_year' => $year,
                'on_url' => $url,
                'on_state' => $location,
                'on_media' => $media,
                'on_pdf_doc' => (isset($pdf) ? $pdf : ""),

                'on_document' => $word,
                'on_logo' => $dblogo,
            ]);
            DB::commit();
            return \redirect('/admin/online-list');
        } catch (\Exception $ex) {
            dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function adm_call_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/adminlogin')->withErrors(['error_reason'=>'Session Don\'t exist']);
        }
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT * from call_paper";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['paper_apply_by']);
                $tempdate = date("M d Y", $time);

                if ($res['paper_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                error_log(json_encode($res));
                if ($today >= $time) {
                    $expcallsearch[] = array(
                        'paper_id' => $res['paper_id'],
                        'paper_title' => $res['paper_title'],
                        'paper_type' => $res['paper_type'],
                        'paper_o_name' => $res['paper_o_name'],
                        'paper_loc' => $res['paper_loc'],
                        'paper_org_logo' => $res['paper_org_logo'],
                        'paper_disp' => $res['paper_disp'],
                        'paper_email' => $res['paper_email'],
                        'paper_apply_by' => $tempdate,
                        'paper_web_url' => $res['paper_web_url'],
                        'paper_url' => $res['paper_url'],
                        'paper_pdf_doc' => $res['paper_pdf_doc'],
                        'paper_word_document' => $res['paper_word_document'],
                        'paper_approved' => $res['paper_approved'],

                    );
                }else{
                    $callsearch[] = array(
                        'paper_id' => $res['paper_id'],
                        'paper_title' => $res['paper_title'],
                        'paper_type' => $res['paper_type'],
                        'paper_o_name' => $res['paper_o_name'],
                        'paper_loc' => $res['paper_loc'],
                        'paper_org_logo' => $res['paper_org_logo'],
                        'paper_disp' => $res['paper_disp'],
                        'paper_email' => $res['paper_email'],
                        'paper_apply_by' => $tempdate,
                        'paper_web_url' => $res['paper_web_url'],
                        'paper_url' => $res['paper_url'],
                        'paper_pdf_doc' => $res['paper_pdf_doc'],
                        'paper_word_document' => $res['paper_word_document'],
                        'paper_approved' => $res['paper_approved'],

                    );
                }
            }
        } else {
            $callsearch = array();
            $expcallsearch = array();
        }
        if (!isset($callsearch)) {
            $callsearch = array();
        }
        if (!isset($expcallsearch)) {
            $expcallsearch = array();
        }
        return view('adm_call_list', compact(['callsearch','expcallsearch']));
    }

    public function adm_admission_list(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT * from admission";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['adn_apply']);
                $tempdate = date("M d Y", $time);

                if ($res['adn_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                error_log(json_encode($res));
                if ($today >= $time) {
                    $expadnsearch[] = array(
                        'adn_id' => $res['adn_id'],
                        'adn_title' => $res['adn_title'],
                        'adn_inst_name' => $res['adn_inst_name'],
                        'adn_apply' => $tempdate,
                        'adn_cost_details' => $res['adn_cost_details'],
                        // 'js_createdate' => $tempdate,
                        // 'js_submitted_by' => $res['js_submitted_by'],
                        'adn_area' => $res['adn_area'],
                        'adn_display_page' => $res['adn_display_page'],
                        'adn_email' => $res['adn_email'],
                        'adn_state' => $res['adn_state'],
                        'adn_year' => $res['adn_year'],
                        'adn_website_url' => $res['adn_website_url'],
                        'adn_mediaurl' => $res['adn_mediaurl'],
                        'adn_submitted_by' => $res['adn_submitted_by'],
                        'adn_approved' => $res['adn_approved'],
    
                    );
                }else{
                    $adnsearch[] = array(
                        'adn_id' => $res['adn_id'],
                        'adn_title' => $res['adn_title'],
                        'adn_inst_name' => $res['adn_inst_name'],
                        'adn_apply' => $tempdate,
                        'adn_cost_details' => $res['adn_cost_details'],
                        // 'js_createdate' => $tempdate,
                        // 'js_submitted_by' => $res['js_submitted_by'],
                        'adn_area' => $res['adn_area'],
                        'adn_display_page' => $res['adn_display_page'],
                        'adn_email' => $res['adn_email'],
                        'adn_state' => $res['adn_state'],
                        'adn_year' => $res['adn_year'],
                        'adn_website_url' => $res['adn_website_url'],
                        'adn_mediaurl' => $res['adn_mediaurl'],
                        'adn_submitted_by' => $res['adn_submitted_by'],
                        'adn_approved' => $res['adn_approved'],
    
                    );
                }
               
            }
        } else {
            $adnsearch = array();
            $expadnsearch = array();
        }
        if (!isset($adnsearch)) {
            $adnsearch = array();
        }
        if (!isset($expadnsearch)) {
            $expadnsearch = array();
        }
        return view('adm_admission_list', compact(['adnsearch','expadnsearch']));
    }


    public function adm_admission_edit(Request $request, $jspid)
    {

        $id = $jspid;
        $sel_query = "SELECT * from admission where adn_id=" . $jspid;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['adn_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $adnsearch = array(
                    'adn_id' => $res['adn_id'],
                    'adn_title' => $res['adn_title'],
                    'adn_inst_name' => $res['adn_inst_name'],
                    'adn_apply' => $res['adn_apply'],
                    'adn_cost_details' => $res['adn_cost_details'],
                    // 'js_createdate' => $tempdate,
                    // 'js_submitted_by' => $res['js_submitted_by'],
                    'adn_area' => $res['adn_area'],
                    'adn_display_page' => $res['adn_display_page'],
                    'adn_email' => $res['adn_email'],
                    'adn_state' => $res['adn_state'],
                    'adn_year' => $res['adn_year'],
                    'adn_website_url' => $res['adn_website_url'],
                    'adn_mediaurl' => $res['adn_mediaurl'],
                    'adn_submitted_by' => $res['adn_submitted_by'],
                    'adn_approved' => $res['adn_approved'],
                    'adn_org_logo' => $res['adn_org_logo'],
                    'adn_word_document' => $res['adn_word_document'],
                    'adn_pdf_document' => $res['adn_pdf_document'],


                );
            }
        } else {
            $adnsearch = array();
        }
        return view('adm_admission_detail', compact(['adnsearch']));
    }



    public function adm_admission_update(Request $request, $jspid)
    {

        $body = $request->all();
        // dd($body['word']);


        if ($request->hasFile('org_logo')) {
            $file = $request->file('org_logo');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $file = "/public/Images/" . $src_file_logo;
        } else {
            $file = $request->input('org_old_logo');
        }

        if ($request->hasFile('pdf_document')) {
            $document = $request->file('pdf_document');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('old_pdf');
        }
        if ($request->hasFile('word')) {
            $document_word = $request->file('word');
            $src_document = date('YmdHis') . $document_word->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document_word->move(public_path() . "/document/", $src_document);
            $document_word = "/public/document/" . $src_document;
        } else {
            $document_word = $request->input('old_word');
        }
        DB::beginTransaction();

        try {
            DB::table('admission')->where('adn_id', $jspid)->update([
                'adn_title' => $body['title'],
                // 'paper_type' => $papertype,
                'adn_inst_name' => $body['name'],
                'adn_apply' => $body['apply'],
                'adn_cost_details' => $body['cost'],
                'adn_area' => $body['area'],
                'adn_display_page' => $body['disp'],

                'adn_email' => $body['email'],
                'adn_website_url' => $body['url'],
                'adn_state' => $body['state'],
                'adn_year' => $body['year'],
                'adn_mediaurl' => $body['media_url'],
                'adn_pdf_document' => isset($document) ? $document : "",
                'adn_word_document' => $document_word,
                'adn_org_logo' => $file,


            ]);
            DB::commit();
            return redirect('/admin/adm_admission_list');
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }


    public function online_courselist(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));
        $today = time() - 86400;//- 86400000;
        $sel_query = "SELECT * from  onlinecourse";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                $time = strtotime($res['on_apply']);
                $tempdate = date("M d Y", $time);
                if ($res['on_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                if ($today >= $time) {
                    $exponlist[] = array(
                        'on_id' => $res['on_id'],
                        'on_media' => $res['on_media'],
                        'on_email' => $res['on_email'],
                        'on_institute' => $res['on_institute'],
                        'on_approved' => $res['on_approved'],
                        'on_apply' => $tempdate,
                    );
                } else {
                    $onlist[] = array(
                        'on_id' => $res['on_id'],
                        'on_media' => $res['on_media'],
                        'on_email' => $res['on_email'],
                        'on_institute' => $res['on_institute'],
                        'on_approved' => $res['on_approved'],
                        'on_apply' => $tempdate,
                    );
                }
            }
        } else {
            $onlist = array();
            $exponlist = array();
        }
        if (!isset($onlist)) {
            $onlist = array();
        }
        if (!isset($exponlist)) {
            $exponlist = array();
        }
        return view('adm_online_course_list', compact(['onlist','exponlist']));
    }

    public function enableadmission(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update admission set adn_approved=1 where adn_id =' . $input['adn_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disableadmission(' . $input['adn_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disableadmission(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update admission set adn_approved=0 where adn_id =' . $input['adn_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enableadmission(' . $input['adn_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }
    public function enablecallpaper(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update call_paper set paper_approved=1 where paper_id =' . $input['paper_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disablecallpaper(' . $input['paper_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disablecallpaper(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update call_paper set paper_approved=0 where paper_id =' . $input['paper_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enablecallpaper(' . $input['paper_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }
    public function enablepub(Request $request)
    {
        $input = $request->all();
        DB::beginTransaction();
        try {
            DB::update('update publication set pub_approved=1 where pub_id =' . $input['pub_id']);
            DB::commit();
            $html = '<button class="btn btn-danger" onclick="disablepub(' . $input['pub_id'] . ')">Put on Hold</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function disablepub(Request $request)
    {
        $input = $request->all();

        DB::beginTransaction();
        try {
            DB::update('update publication set pub_approved=0 where pub_id =' . $input['pub_id']);
            DB::commit();
            $html = '<button class="btn btn-primary" onclick="enablepub(' . $input['pub_id'] . ')">Approve</button>';
            return response()->json(array('res' => 'SUCCESS', 'data' => $html));
        } catch (\Exception $ex) {
            DB::rollback();
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    public function show_publication_Detail(Request $request, $pbcid)
    {
        try {

            $sel_query = "SELECT * from publication where publication.pub_id = " . $pbcid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                if ($res['pub_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'pub_id' => $res['pub_id'],

                    'pub_name' => $res['pub_name'],
                    'pub_type' => $res['pub_type'],
                    'pub_focusarea' => $res['pub_focusarea'],
                    'pub_title' => $res['pub_title'],

                    'pub_status' => $status,

                    'pub_email' => $res['pub_email'],
                    'pub_no' => $res['pub_no'],
                    'pub_year' => $res['pub_year'],
                    'pub_website' => $res['pub_website'],
                    'pub_desc' => $res['pub_desc'],
                    'pub_media' => $res['pub_media'],
                    'pub_approved' => $res['pub_approved'],
                    'pub_upload_word' => $res['pub_upload_word'],
                    //'pub_upload_doc' => $res['pub_upload_doc'],
                    'pub_upload_image' => $res['pub_upload_image']
                );
                $html = GeneralUtils::createHTML_for_selected_pub_cates($res['pub_type']);

                $html2 = GeneralUtils::createHTML_for_selected_pub_focus($res['pub_focusarea']);
                // dd($html2);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('show_publication_detail', compact(['jp_obj', 'html', 'html2']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }



    public function update_publication(Request $request, $pbcid)
    {
        $author = $request->input('authorname');
        $type = $request->input('cates');
        $focusarea = $request->input('focus');
        $title = $request->input('documenttitle');
        $email = $request->input('email');
        $mobileno = $request->input('mobile');
        $desc = $request->input('publication_desc');

        $year = $request->input('year');

        $website = $request->input('website');
        $mediaurl = $request->input('media');
        $worddoc = $request->input('doc');

        $image = $request->file('image');


        if ($request->hasFile('image')) {
            $image = $request->file('image');
            error_log("--->>" . $image->getClientOriginalExtension() . public_path() . $image->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $image->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $image->move(public_path() . "/Images/", $src_file_logo);
            $image = "/public/Images/" . $src_file_logo;
        } else {
            $image = $request->input('old_image');
        }


        DB::beginTransaction();

        try {
            DB::table('publication')->where('pub_id', $pbcid)->update([
                'pub_name' => $author,
                'pub_type' =>   $type,
                'pub_focusarea' =>  $focusarea,
                'pub_title' => $title,
                'pub_email' => $email,
                'pub_no' =>  $mobileno,
                'pub_desc' => $desc,
                'pub_upload_word' => $worddoc,
                // 'pub_submitted_by' => $request->session()->get('ssiapp_adm_id'),
                'pub_year' => $year,
                'pub_website' => $website,
                //  'pub_upload_doc' => $pdfdoc,
                'pub_media' => $mediaurl,
                'pub_upload_image' => $image

            ]);
            DB::commit();
            return \redirect('/admin/pub-list');
        } catch (\Exception $ex) {
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function publications(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $sel_query = "SELECT * from  publication";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // $time = strtotime($res['rfp_close_date']);
                // $tempdate = date("M d Y", $time);
                if ($res['pub_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }
                $publist[] = array(
                    'pub_id' => $res['pub_id'],
                    'pub_name' => $res['pub_name'],
                    'pub_focusarea' => $res['pub_focusarea'],
                    'pub_media' => $res['pub_media'],
                    'pub_title' => $res['pub_title'],
                    'pub_email' => $res['pub_email'],
                    'pub_approved' => $res['pub_approved'],
                    // 'rfp_close_date' => $tempdate,
                    'pub_submitted_by' => $res['pub_submitted_by'],
                    // 'rfp_status' => $status,
                    // 'rfp_approved' => $res['rfp_approved'],
                );
            }
        } else {
            $publist = array();
        }
        return view('adm_publication_list', compact(['publist']));
    }

    public function jobposts(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        error_log($request->session()->get('ssiapp_adm_token'));

        $today = time() - 86400;
        $sel_query = "SELECT * from job_post ";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        // dd($res_query);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['jp_closing_date']);
                $tempdate = date("M d Y", $time);
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                if ($today >= $time) {
                    error_log("unexp:-> " . $res['jp_id']);
                    // add in unexpired list$reclist   
                    $expreclist[] = array(
                        'jp_id' => $res['jp_id'],
                        'jp_title' => $res['jp_title'],
                        'jp_email' => $res['jp_email'],
                        'jp_org_name' => $res['jp_org_name'],
                        'jp_closing_date' => $tempdate,
                        'jp_submitted_by' => $res['jp_submitted_by'],
                        'jp_status' => $status,
                        'jp_approved' => $res['jp_approved'],
                    );
                } else if ($today < $time) {
                    //add in expired array
                    error_log("exp:-> " . $res['jp_id']);
                    $unexpreclist[] = array(
                        'jp_id' => $res['jp_id'],
                        'jp_title' => $res['jp_title'],
                        'jp_email' => $res['jp_email'],
                        'jp_org_name' => $res['jp_org_name'],
                        'jp_closing_date' => $tempdate,

                        'jp_submitted_by' => $res['jp_submitted_by'],
                        'jp_status' => $status,
                        'jp_approved' => $res['jp_approved'],
                    );
                }
            }
        } else {
            $expreclist = array();
            $unexpreclist = array();
        }

        if (!isset($expreclist)) {
            $expreclist = array();
        }
        return view('adm_jobpost_list', compact(['expreclist', 'unexpreclist']));
    }

    public function show_jobpost_Detail(Request $request, $encid)
    {
        try {
            // $body = $request->all();
            // dd($request);
            $sel_query = "SELECT * from job_post where job_post.jp_id = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            // dd($res_query);
            if (count($res_query)) {
                $res = $res_query[0];
                if ($res['jp_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'jp_id' => $res['jp_id'],
                    'jp_title' => $res['jp_title'],
                    'jp_job_type' => $res['jp_job_type'],
                    'jp_org_name' => $res['jp_org_name'],
                    'jp_loc' => $res['jp_loc'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    'jp_desc' => $res['jp_desc'],
                    'jp_app_email' => $res['jp_app_email'],
                    'jp_email' => $res['jp_email'],
                    'jp_files' => $res['jp_files'],
                    'jp_ad_type_area_of_expertise' => $res['jp_ad_type_area_of_expertise'],
                    'jp_org_web' => $res['jp_org_web'],
                    'jp_closing_date' => $res['jp_closing_date'],
                    'jp_org_logo' => $res['jp_org_logo'],
                    'jp_org_twitter' => $res['jp_org_twitter'],
                    'jp_org_video' => $res['jp_org_video'],
                    // 'paper_pdf_doc' => $res['jp_org_twitter'],                
                    'jp_approved' => $res['jp_approved'],

                );
            } else {
            }
            return view('edit_jobpost', compact(['jp_obj']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }


    public function update_jobpost(Request $request, $encid)
    {
        // dd($request);
        $body = $request->all();
        // dd($body);
        if ($request->hasFile('logo')) {
            $file = $request->file('logo');
            error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $file->move(public_path() . "/Images/", $src_file_logo);
            $file = "/public/Images/" . $src_file_logo;
        } else {
            $file = $request->input('old_org_logo');
        }

        if ($request->hasFile('pdf_document')) {
            $document = $request->file('pdf_document');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('old_pdf_document');
        }


        DB::beginTransaction();

        try {
            DB::table('job_post')->where('jp_id', $encid)->update([
                'jp_title' => $body['jobtitle'],
                'jp_email' => $body['email'],
                'jp_job_type' => $body['type'],
                'jp_org_name' => $body['org_name'],
                'jp_loc' => $body['location'],
                'jp_ad_type_area_of_expertise' => $body['area'],
                'jp_desc' => $body['description'],
                'jp_app_email' => $body['applicationemail'],
                'jp_closing_date' => $body['closingdate'],
                'jp_org_web' => $body['website'],
                'jp_org_video' => $body['video'],
                'jp_org_twitter' => $body['twitter'],
                'jp_org_logo' => $file,
                'jp_files' => isset($document) ? $document : "",

            ]);

            DB::commit();
            return \redirect('/admin/job-post-list');
        } catch (\Exception $ex) {
            //    dd($ex);
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function loadDashboard(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT (SELECT COUNT(*) FROM rfp ) AS totalrfps,
                    (SELECT COUNT(*) FROM csr ) AS totalcsr,
                    (SELECT COUNT(*) FROM fellowship ) AS totalfells,
                    (SELECT COUNT(*) FROM scholarship ) AS totalscholarships,
                    (SELECT COUNT(*) FROM events ) AS totalevts,
                    (SELECT COUNT(*) FROM awards ) AS totalawards,
                    (SELECT COUNT(*) FROM register_grants ) AS totalgrants,
                    (SELECT COUNT(*) FROM donate ) AS totaldonate,
                    (SELECT COUNT(*) FROM news ) AS totalnews,
                    (SELECT COUNT(*) FROM admission) AS totaladmissions,
                    (SELECT COUNT(*) FROM call_paper) AS totalpapers,
                    (SELECT COUNT(*) FROM onlinecourse) AS totalcourses,
                    (SELECT COUNT(*) FROM publication) AS totalpublications,
                    (SELECT COUNT(*) FROM job_post ) AS totaljps";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $res = $res_query[0];
            $dashObj = array(
                'totalrfps' => $res['totalrfps'],
                'totalcsr' => $res['totalcsr'],
                'totalfells' => $res['totalfells'],
                'totalscholarships' => $res['totalscholarships'],
                'totalevts' => $res['totalevts'],
                'totalawards' => $res['totalawards'],
                'totalgrants' => $res['totalgrants'],
                'totaldonate' => $res['totaldonate'],
                'totalnews' => $res['totalnews'],
                'totaladmissions' => $res['totaladmissions'],
                'totalpapers' => $res['totalpapers'],
                'totalcourses' => $res['totalcourses'],
                'totalpublications' => $res['totalpublications'],

                'totaljps' => $res['totaljps'],

            );
        }
        return view('adminDash', compact(['dashObj']));
    }

    public function post_donate(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        return view('post_donate');
    }


    public function adm_submit_fc_grant(Request $request)
    {
        $email = $request->input('email');
        $org_name = $request->input('orgname');
        $grant_title = $request->input('grant_title');
        $rfp_seo = str_replace(" ", "-", $grant_title);
        $rfp_seo = $rfp_seo . "-" . time();
        $location = $request->input('location');
        $total_amt = $request->input('total_amt');
        $closedate = $request->input('close_date');
        $descproposal = $request->input('proposal_desc');
        // $p=$request->input('document');
        //$orgachivement = $request->input('Description');
        $cates = $request->input('cates');
        $orgachivements = $request->input('organisation_ach');
        $file = $request->file('company_logo');
        $document = $request->file('document');
        $orgid = $request->input('org_id');

        if ($request->hasFile('document')) {
            $document = $request->file('document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('rfp')->insert([
            'rfp_org' => $org_name,
            'rfp_loc' => $location,
            'rfp_g_amt' => $total_amt,

            'rfp_close_date' => $closedate,
            'rfp_email' => $email,
            'rfp_upload_doc' => $document,
            'rfp_desc' => $descproposal,
            // 'csr_upload_doc' => $closingdate,
            'rfp_logo' => $file,

            'rfp_submitted_by' => $orgid,
            'rfp_approved' => 0,

            'rfp_title' => $grant_title,
            'rfp_o_ach' => $orgachivements,
            'rfp_category' => $cates,
            'rfp_create_date' => $createdate,
            'rfp_SEO' => GeneralUtils::CreateSEO($grant_title),
            'rfp_is_submitted_by_admin' => 1,
            // 'rfp_o_ach' => $orgachivement,
            // 'rfp_o_achivements' => $orgachivements,
            // 'rfp_o_pan' => $orgpan,
            // rfp_document'=>$document,

            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/recruiter/dashboard');
    }
    public function adm_post_fc_grant(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_fc_grant', compact(['html', 'organizationlist']));
    }
    //csr admin post//
    public function adm_post_csr(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                     <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_csr', compact(['html', 'organizationlist']));
    }
    public function adm_submit_csr(Request $request)
    {
        $email = $request->input('email');
        $org_name = $request->input('orgname');
        $grant_title = $request->input('grant_title');
        $csr_seo = str_replace(" ", "-", $grant_title);
        $csr_seo = $csr_seo . "-" . time();
        $location = $request->input('location');
        $grant_amt = $request->input('grant_amt');
        $closedate = $request->input('close_date');
        $descproposal = $request->input('proposal_desc');
        $closingdate = $request->input('close_date');
        $ref_url = $request->input('url');
        $cates = $request->input('cates');
        $file = $request->file('company_logo');
        $orgid = $request->input('org_id');


        if ($request->hasFile('document')) {
            $document = $request->file('document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('csr')->insert([
            'csr_org' => $org_name,
            'csr_loc' => $location,
            'csr_g_amt' => $grant_amt,
            'csr_close_date' => $closingdate,
            'csr_email' => $email,
            'csr_desc' => $descproposal,
            'csr_upload_doc' => $document,
            'csr_logo' => $db_name_logo,
            'csr_category' => $cates,
            'csr_submitted_by' => $orgid,
            'csr_approved' => 0,
            'csr_g_title' => $grant_title,
            'csr_create_date' => $createdate,
            'csr_ref_url' => $ref_url,
            'csr_SEO' => GeneralUtils::CreateSEO($grant_title),
            'csr_is_submitted_by_admin' => 1,
            //'csr_document'=>$document,

            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    //admin Fellowship
    public function adm_submit_fellowship(Request $request)
    {
        $body = $request->all();
        $fellowship_title = $request->input('title');
        $org_logo = $request->file('org_logo');
        $fell_seo = str_replace(" ", "-", $fellowship_title);
        $fell_seo = $fell_seo . "-" . time();

        $email = $request->input('email');
        $org_name = $request->input('name');

        $location = $request->input('location');
        $dead_date = $request->input('deadlinedate');
        $desc_textarea = $request->input('desc_textarea');
        $document = $request->file('upload');
        $url = $request->input('url');
        $cates = $request->input('cates');
        $orgid = $request->input('org_id');
        // $closingdate = $request->input('closingdate');
        // $ref_url = $request->input('url');
        // $cates = $request->input('cates');
        if ($request->has('upload')) {
            $document = $request->file('upload');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }


        error_log("--->>" . $org_logo->getClientOriginalExtension() . public_path() . $org_logo->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_logo->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_logo->move(public_path() . "/Images/", $src_file_logo);
        $image = "/public/Images/" . $src_file_logo;

        // $cate_text = "";
        // foreach ($body['cates'] as $cates) {
        //     $cate_text = $cate_text . ',';
        // }
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('fellowship')->insert([
            'fell_o_name' => $org_name,
            'fell_loc' => $location,
            'fell_title' => $fellowship_title,
            'fell_o_logo' => $image,
            'fell_email' => $email,
            'fell_end_date' => $dead_date,
            'fell_desc' => $desc_textarea,
            'fell_cate' => $cates,
            'fell_submitted_by' => $orgid,
            'fell_approved' => 0,
            'fell_upload_doc' => $document,
            'fell_url' => $url,
            'fell_SEO' => GeneralUtils::CreateSEO($fellowship_title),
            'fell_is_submitted_by_admin' => 1,

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }
    public function adm_post_fellowship(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                     <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_fell', compact(['html', 'organizationlist']));
    }

    //scholarship//
    public function adm_submit_scholarship(Request $request)
    {
        $name = $request->input('name');
        $sc_seo = str_replace(" ", "-", $name);
        $sc_seo = $sc_seo . "-" . time();
        $organisation_title = $request->input('title');
        $location = $request->input('location');
        $logo = $request->file('org_logo');
        $date = $request->input('deadlinedate');
        $email = $request->input('email');
        // $closedate = $request->input('close_date');
        //$descproposal = $request->input('proposal_desc');
        // $closingdate = $request->input('closingdate');
        $desc = $request->input('desc_textarea');
        $orgid = $request->input('org_id');
        // $cates = $request->input('cates');

        $url = $request->input('url');
        $cates = $request->input('cates');
        if ($request->hasFile('files')) {
            $upload = $request->file('upload');
            error_log("--->>" . $upload->getClientOriginalExtension() . public_path() . $upload->getClientOriginalName());
            $src_document = date('YmdHis') . $upload->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $upload->move(public_path() . "/document/", $src_document);
            $upload = "/public/document/" . $src_document;
        } else {
            $upload = "";
        }
        error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $logo->move(public_path() . "/Images/", $src_file_logo);
        $logo = "/public/Images/" . $src_file_logo;


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('scholarship')->insert([
            'sc_o_name' => $name,
            'sc_title' => $organisation_title,
            'sc_loc' => $location,
            'sc_end_date' => $date,
            'sc_email' => $email,
            'sc_desc' => $desc,
            'sc_o_logo' => $logo,
            'sc_upload_doc' => $upload,
            'sc_submitted_by' => $orgid,
            'sc_approved' => 0,
            'sc_url' => $url,
            'sc_cate' => $cates,
            // 'award_upload_doc' => $document,
            // 'award_upload_banner' => $db_name_banner,
            'sc_SEO' => GeneralUtils::CreateSEO($name),
            'sc_is_submitted_by_admin' => 1,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }
    public function adm_post_scholarship(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                     <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_scholarship', compact(['html', 'organizationlist']));
    }

    public function adm_submit_admission(Request $request)
    {
        $title = $request->input('title');
        $inst_name = $request->input('name_institution');
        $apply_by = $request->input('apply');
        // $costdetails = str_replace(" ","-",$grant_title);
        // $csr_seo = $csr_seo . "-" . time();
        $costdetail = $request->input('costdetails');
        $thematic_area = $request->input('area');
        $displaypage = $request->input('display_page');
        $email = $request->input('email');
        $loc_state = $request->input('state');
        $academic_year = $request->input('year');
        $web_url = $request->input('website_url');
        $media_url = $request->input('url');
        // $terms_conditions = $request->input('terms');
        // $cates = $request->input('cates');
        $file = $request->file('org_logo');
        $orgid = $request->input('org_id');

        // $document_word = $request->file('document1');
        if ($request->has('pdf_document')) {
            $document = $request->file('pdf_document');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }


        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('admission')->insert([
            'adn_title' => $title,
            'adn_inst_name' => $inst_name,
            'adn_apply' => $apply_by,
            'adn_cost_details' => $costdetail,
            'adn_area' => $thematic_area,
            'adn_display_page' => $displaypage,
            'adn_email' => $email,
            'adn_state' => $loc_state,
            'adn_year' => $academic_year,
            'adn_website_url' => $web_url,
            'adn_mediaurl' => $media_url,
            'adn_pdf_document' => $document,
            // 'adn_word_document' => $document_word,
            'adn_org_logo' => $file,
            // 'csr_category' => $cates,
            'adn_submitted_by' => $orgid,
            'adn_approved' => 0,
            'adn_SEO' => GeneralUtils::CreateSEO($title),
            'adn_is_submitted_by_admin' => 1,

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    public function adm_post_admission(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_admission', compact(['html', 'organizationlist']));
    }

    //Award//

    public function adm_submit_award(Request $request)
    {
        $award_title = $request->input('award_title');
        $award_seo = str_replace(" ", "-", $award_title);
        $award_seo = $award_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('award_desc');
        $ref_url = $request->input('url');
        $org_file = $request->file('org_logo');
        // $document = $request->file('upload_evt_doc');
        $banner = $request->file('upload_evt_banner');
        $cates = $request->input('cates');
        $orgid = $request->input('org_id');

        if ($request->has('upload_evt_doc')) {
            $document = $request->file('upload_evt_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }

        error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;

        // $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
        // $dest_file_banner = public_path() . "/Images/";
        // $banner->move(public_path() . "/Images/", $src_file_banner);
        // $db_name_banner = "/public/Images/" . $src_file_banner;
        $db_name_banner = '';

        /*
        	`award_id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`award_title` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_loc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_end_date` DATETIME NULL DEFAULT NULL,
	`award_desc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_email` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_upload_doc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_org_logo` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_org_name` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_ref_url` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_create_date` DATETIME NULL DEFAULT NULL,
	`award_approved` INT(11) NULL DEFAULT '0',
	`award_submitted_by` BIGINT(20) NULL DEFAULT '0',
	`award_SEO` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_upload_banner` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
        */


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('awards')->insert([
            'award_org_name' => $organisation_name,
            'award_loc' => $loc_name,
            'award_title' => $award_title,
            'award_end_date' => $proposal_close_date,
            'award_email' => $email,
            'award_desc' => $event_desc,
            'award_org_logo' => $db_name_logo,
            'award_submitted_by' => $orgid,
            'award_approved' => 0,
            'award_create_date' => $createdate,
            'award_ref_url' => $ref_url,
            'award_upload_doc' => $document,
            'award_upload_banner' => $db_name_banner,
            'award_SEO' => GeneralUtils::CreateSEO($award_title),
            'award_cates' => $cates,
            'award_is_submitted_by_admin' => 1,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }


    public function adm_post_award(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_award', compact(['html', 'organizationlist']));
    }


    //call paper

    public function adm_submit_callpaper(Request $request)
    {
        // dd($request->session()->get('ssiapp_adm')); 
        $title = $request->input('title');
        $papertype = $request->input('type');
        $org_name = $request->input('org');
        $apply_by = $request->input('apply');
        $location = $request->input('loc');

        $displaypage = $request->input('display_page');
        $email = $request->input('email');

        $web_url = $request->input('website_url');
        $media_url = $request->input('url');

        $file = $request->file('org_logo');
        $orgid = $request->input('org_id');
        // dd($file);
        if ($request->hasFile('pdf_document')) {
            $document = $request->file('pdf_document');
            // $document_word = $request->file('document1');

            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }
        // error_log("--->>" . $document_word->getClientOriginalExtension() . public_path() . $document_word->getClientOriginalName());
        // $src_document = date('YmdHis') . $document_word->getClientOriginalName();
        // $dest_document = public_path() . "/document/";
        // $document_word->move(public_path() . "/document/", $src_document);
        // $document_word = "/public/document/" . $src_document;

        error_log("--->>" . $file->getClientOriginalExtension() . public_path() . $file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $file->move(public_path() . "/Images/", $src_file_logo);
        $file = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('call_paper')->insert([
            'paper_title' => $title,
            'paper_type' => $papertype,
            'paper_o_name' => $org_name,
            'paper_apply_by' => $apply_by,

            'paper_loc' => $location,
            'paper_disp' => $displaypage,
            'paper_email' => (isset($email) ? $email : ""),

            'paper_web_url' => $web_url,
            'paper_url' => $media_url,
            'paper_pdf_doc' => $document,
            // 'paper_word_document' => $document_word,
            'paper_org_logo' => $file,

            'paper_submitted_by' => $orgid,
            'paper_approved' => 0,
            'paper_SEO' => GeneralUtils::CreateSEO($title),
            'paper_is_submitted_by_admin' => 1,


        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    public function adm_post_callpaper(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_callpaper', compact(['html', 'organizationlist']));
    }


    //Events
    public function adm_submit_events(Request $request)
    {
        $event_title = $request->input('event_title');
        $event_seo = str_replace(" ", "-", $event_title);
        $event_seo = $event_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('event_desc');
        // $closedate = $request->input('close_date');
        //$descproposal = $request->input('proposal_desc');
        // $closingdate = $request->input('closingdate');
        $ref_url = $request->input('url');
        // $cates = $request->input('cates');
        $org_file = $request->file('org_logo');

        $banner = $request->file('upload_evt_banner');
        $cates = $request->input('cates');
        $orgid = $request->input('org_id');

        if ($request->hasFile('upload_evt_doc')) {
            $document = $request->file('upload_evt_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = "";
        }

        error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;

        $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
        $dest_file_banner = public_path() . "/Images/";
        $banner->move(public_path() . "/Images/", $src_file_banner);
        $db_name_banner = "/public/Images/" . $src_file_banner;



        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('events')->insert([
            'evt_org_name' => $organisation_name,
            'evt_loc' => $loc_name,
            'evt_title' => $event_title,
            'evt_end_date' => $proposal_close_date,
            'evt_email' => $email,
            'evt_desc' => $event_desc,
            'evt_org_logo' => $db_name_logo,
            'evt_submitted_by' => $orgid,
            'evt_approved' => 0,
            'evt_create_date' => $createdate,
            'evt_ref_url' => $ref_url,
            'evt_upload_doc' => $document,
            'evt_upload_banner' => $db_name_banner,
            'evt_SEO' => GeneralUtils::CreateSEO($event_title),
            'evt_cate' => $cates,
            'evt_is_submitted_by_admin' => 1,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    public function adm_post_events(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_events', compact(['html', 'organizationlist']));
    }

    //publication//
    public function adm_submit_publication(Request $request)
    {
        $author = $request->input('authorname');

        $type = $request->input('cates');
        $focusarea = $request->input('farea2');
        $title = $request->input('documenttitle');
        $pub_seo = str_replace(" ", "-", $title);
        $pub_seo = $pub_seo . "-" . time();
        $email = $request->input('email');
        $mobileno = $request->input('mobile');

        $year = $request->input('year');
        // $cates = $request->input('cates');
        $website = $request->input('website');
        $mediaurl = $request->input('media');
        $worddoc = $request->input('doc');
        $desc = $request->input('publication_desc');
        $image = $request->file('image');
        $orgid = $request->input('org_id');

        // $pdfdoc = $request->file('pdf');



        error_log("--->>" . $image->getClientOriginalExtension() . public_path() . $image->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $image->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $image->move(public_path() . "/Images/", $src_file_logo);
        $image = "/public/Images/" . $src_file_logo;


        // dd($image);

        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('publication')->insert([
            'pub_name' => $author,
            'pub_type' =>  $type,
            'pub_focusarea' => $focusarea,
            'pub_title' => $title,
            'pub_email' => $email,
            'pub_no' => $mobileno,
            'pub_year' =>   $year,
            'pub_submitted_by' => $orgid,
            'pub_approved' => 0,
            'pub_website' =>  $website,
            'pub_media' =>  $mediaurl,
            'pub_upload_word' =>  $worddoc,
            'pub_desc' => $desc,
            'pub_SEO' => GeneralUtils::CreateSEO($title),
            'pub_upload_image' => $image,
            'pub_is_submitted_by_admin' => 1,
            // 'pub_upload_doc' =>   $pdfdoc,
            // 'evt_SEO' => $event_seo,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);

        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/pub-list');
    }

    public function adm_post_publication(Request $request)
    {
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                } else if ($total_count == 0) {

                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_publication', compact(['html', 'organizationlist']));
    }

    //JOBPOST//
    public function adm_submit_jobpost(Request $request)
    {
        $email = $request->input('email');
        $jobtitle = $request->input('jobtitle');
        $jp_seo = str_replace(" ","-",$jobtitle);
        $jp_seo = $jp_seo . "-" . time();
        $location = $request->input('location');

        $jobtype = $request->input('job_type');

        $description = $request->input('description');

        $applicationemail = $request->input('applicationemail');

        $closingdate = $request->input('closingdate');

        
        $orgname = $request->input('org_name');
        $website = $request->input('website');
        $video = $request->input('video');
        $twiiter = $request->input('twitterusername');
        // $logo = $request->file('logo');
        $areas = $request->input('area');
        $orgid = $request->input('org_id');
       
        if($request->hasFile('files')){
            $files = $request->file('files');
            $src_document = date('YmdHis') . $files->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $files->move(public_path() . "/document/", $src_document);
            $files = '/public/document/' . $src_document;
        }else{
            $files = '';
        }

        if($request->hasFile('logo')){
            $org_logo = $request->file('logo');
            error_log("--->>" . $org_logo->getClientOriginalExtension() . public_path() . $org_logo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $org_logo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $org_logo->move(public_path() . "/Images/", $src_file_logo);
            $image = "/public/Images/". $src_file_logo;

        }else{
            $image = $request->input('old_image'); 
        }

        // $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
        // $dest_file_logo = public_path() . "/Images/";
        // $logo->move(public_path() . "/Images/", $src_file_logo);
        // $logo = "/public/Images/" . $src_file_logo;
        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('job_post')->insert([
            'jp_email' => $email,
            //'jp_by' => $request->session()->get('ssiapp_rec_id'),
            'jp_title' => $jobtitle,
            'jp_loc' => $location,
            'jp_job_type' => $jobtype,
            'jp_desc' => $description,
            'jp_app_email' => $applicationemail,
            // 'csr_upload_doc' => $closingdate,
            'jp_closing_date' => $closingdate,
            'jp_files' => $files,
            'jp_submitted_by' => $orgid,
            'jp_approved' => 0,
            'jp_org_name' => $orgname,
            'jp_org_web' => $website,
            'jp_org_video' => $video,
            'jp_org_twitter' => $twiiter,
            'jp_org_logo' => $image,
            'jp_ad_type_area_of_expertise' => $areas,
            'jp_SEO' => GeneralUtils::CreateSEO($jobtitle),
            'jp_is_submitted_by_admin' => 1,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }
    public function adm_post_jobpost(Request $request){
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_jobpost', compact(['html','organizationlist']));
    }

    //online course//

    public function adm_submit_onlinecourse(Request $request)
    {
        $title = $request->input('course');
        $name = $request->input('name');
        $apply = $request->input('apply');
        $category = $request->input('category');
        $area = $request->input('area');
        $display = $request->input('display');

        $email = $request->input('email');

        $media = $request->input('media');

        $location = $request->input('location');
        $year = $request->input('year');
        $url = $request->input('url');
        $logo = $request->file('logo');
        $orgid = $request->input('org_id');
        // $word = $request->file('word');
        if ($request->hasFile('pdf')) {
            $pdf = $request->file('pdf');

            // error_log("--->>" . $word->getClientOriginalExtension() . public_path() . $word->getClientOriginalName());
            // $src_document = date('YmdHis') . $word->getClientOriginalName();
            // $dest_document = public_path() . "/document/";
            // $word->move(public_path() . "/document/", $src_document);
            // $word = "/public/document/" . $src_document;

            error_log("--->>" . $pdf->getClientOriginalExtension() . public_path() . $pdf->getClientOriginalName());
            $src_document = date('YmdHis') . $pdf->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $pdf->move(public_path() . "/document/", $src_document);
            $pdf  = "/public/document/" . $src_document;
        }else{
            $pdf  = "";
        }
        error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
        $src_document = date('YmdHis') . $logo->getClientOriginalName();
        $dest_document = public_path() . "/Images/";
        $logo->move(public_path() . "/Images/", $src_document);
        $logo  = "/public/Images/" . $src_document;



        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('onlinecourse')->insert([
            'on_detail' => $title,
            'on_institute' =>   $name,
            'on_apply' =>   $apply,
            'on_radio' => $category,
            'on_area' => $area,
            'on_display' =>  $display,
            'on_email' =>   (isset($email) ? $email : ""),

            'on_media' =>   $media,
            'on_submitted_by' => $orgid,
            'on_approved' => 0,
            'on_state' => $location,
            'on_year' =>   $year,
            'on_url' =>  $url,
            'on_pdf_doc' => $pdf,
            // 'on_document' => $word,
            'on_logo' =>   $logo,
            'on_SEO' => GeneralUtils::CreateSEO($title),
            'on_is_submitted_by_admin' => 1,
            // 'evt_SEO' => $event_seo,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/admin/dashboard');
    }


    public function adm_post_onlinecourse(Request $request){
        if (!$request->session()->has('ssiapp_adm_id')) {
            return \redirect('/admin/adminlogin')->withErrors(['error_reason' => 'Session Don\'t exist']);
        }
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);

        $organizationlist = GeneralUtils::getOrganizationList();

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                 <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                $count++;
                $total_count--;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
        }
        error_log($html);
        return view('adm_post_onlinecourse', compact(['html','organizationlist']));
    }

    public function admin_organisation_register(Request $request){
        return view('adm_organisation_register');
    }

    public function adm_organisation_submit(Request $request)
    {
        $data = $request->validate([
            'org_name' => 'required',
            'emailaddress' => 'required|email',
            'contactperson' => 'required',
            'mobile' => 'required|numeric',
            'passwd' => 'required',
            'company-type' => 'required',
            'pincode' => 'required',
        ]);
        $email = $request->input('emailaddress');
        $passwd = $request->input('passwd');
        $EmpPhone = $request->input('mobile');
        $name = $request->input('contactperson');
        $org_name = $request->input('contactperson');
        $pincode = $request->input('pincode');
        $website = $request->input('website');
        $org_pan = $request->input('org_pan');
        $officelandline = $request->input('officelandline');
        $company_type = $request->input('company-type');

        $from = $request->input('from');

        if (GeneralUtils::checkRecruiterExistEmail($email)) {
            $res['error'] = "Account already exist";
            return \Redirect::back()->withErrors(['error_reason' => 'Account already exist']);
        }
        try {

            $createdate = date("Y-m-d H:i:s");
            DB::table('recruiter')->insert([
                'r_name' => $name,
                'r_email' => $email,
                'r_phone' => $EmpPhone,
                'r_pwd' => $passwd,
                'r_createdate' => $createdate,
                'r_org_name' => $org_name,
                'r_org_pan' => $org_pan,
                'r_pin' => $pincode,
                'r_off_website' => $website,
                'r_off_lline_number' => $officelandline,
                'r_comp_type' => $company_type,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            $data = array("org_name"=>$name, "org_email"=>$email,"org_pwd"=>$passwd,'org_phone'=>$EmpPhone);
            //EmailUtils::NewAccountCreated($data,'ORG',$email);
             return \redirect('/admin/dashboard');
            
        } catch (\Exception $ex) {
            DB::rollback();
            $res['error'] = "Can't login to System";
            return \Redirect::back()->withErrors(['error_reason' => 'Problem in creating account']);
        }
    }
}
