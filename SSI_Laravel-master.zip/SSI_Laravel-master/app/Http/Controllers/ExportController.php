<?php

namespace App\Http\Controllers;

use App\Exports\RfpExport;
use App\Exports\OrganizerExport;
use App\Exports\JobSeekerExport;
use App\Exports\JobPostExport;
use App\Exports\RegisterGrantsExport;
use App\Exports\AdmissionExport;
use App\Exports\EventsExport;
use App\Exports\CallPaperExport;
use App\Exports\AwardExport;
use App\Exports\ScholarshipExport;
use App\Exports\OnlineCourseExport;



use Maatwebsite\Excel\Facades\Excel;

class ExportController extends Controller 
{
    public function rfpexport() 
    {
        return Excel::download(new RfpExport, 'rfp.xlsx');
    }

    public function organizerexport() 
    {
        return Excel::download(new OrganizerExport, 'Organizer.xlsx');
    }

    public function jobseekerexport() 
    {
        return Excel::download(new JobSeekerExport, 'Jobseeker.xlsx');
    }

    public function jobpostexport() 
    {
        return Excel::download(new JobPostExport, 'jobpost.xlsx');
    }
    public function regrantsexport() 
    {
        return Excel::download(new RegisterGrantsExport, 'regrants.xlsx');
    }
    public function admissionexport() 
    {
        return Excel::download(new AdmissionExport, 'admsn.xlsx');
    }
    public function eventexport() 
    {
        return Excel::download(new EventsExport, 'event.xlsx');
    }
    public function callpaperexport() 
    {
        return Excel::download(new CallPaperExport, 'callpaper.xlsx');
    }
    public function awardexport() 
    {
        return Excel::download(new AwardExport, 'callpaper.xlsx');
    }
    public function scholarshipexport() 
    {
        return Excel::download(new ScholarshipExport, 'callpaper.xlsx');
    }
    public function onlinecourseexport() 
    {
        return Excel::download(new OnlineCourseExport, 'callpaper.xlsx');
    }

}

?>