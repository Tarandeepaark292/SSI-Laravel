<?php

namespace App\Http\Controllers;
use App\Utils\GeneralUtils;

use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AwardController extends Controller
{
    //
    public function submitaward(Request $request)
    {
        $award_title = $request->input('award_title');
        $award_seo = str_replace(" ", "-", $award_title);
        $award_seo = $award_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('award_desc');
        $ref_url = $request->input('url');
        $org_file = $request->file('org_logo');
        // $document = $request->file('upload_evt_doc');
        $banner = $request->file('upload_evt_banner');
        $cates = $request->input('cates');

        if($request->has('upload_evt_doc')){
            $document = $request->file('upload_evt_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/" . $src_file_logo;

        // $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
        // $dest_file_banner = public_path() . "/Images/";
        // $banner->move(public_path() . "/Images/", $src_file_banner);
        // $db_name_banner = "/public/Images/" . $src_file_banner;
        $db_name_banner = '';

        /*
        	`award_id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`award_title` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_loc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_end_date` DATETIME NULL DEFAULT NULL,
	`award_desc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_email` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_upload_doc` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_org_logo` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_org_name` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_ref_url` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_create_date` DATETIME NULL DEFAULT NULL,
	`award_approved` INT(11) NULL DEFAULT '0',
	`award_submitted_by` BIGINT(20) NULL DEFAULT '0',
	`award_SEO` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
	`award_upload_banner` TEXT(65535) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
        */


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('awards')->insert([
            'award_org_name' => $organisation_name,
            'award_loc' => $loc_name,
            'award_title' => $award_title,
            'award_end_date' => $proposal_close_date,
            'award_email' => $email,
            'award_desc' => $event_desc,
            'award_org_logo' => $db_name_logo,
            'award_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'award_approved' => 0,
            'award_create_date' => $createdate,
            'award_ref_url' => $ref_url,
            'award_upload_doc' => $document,
            'award_upload_banner' => $db_name_banner,
            'award_SEO' => GeneralUtils::CreateSEO($award_title),
            'award_cates' => $cates,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,12)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function show_award_Detail(Request $request, $encid)
    {
        try {

            $sel_query = "SELECT * from awards where awards.award_id = " . $encid;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['award_end_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['award_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'award_id' => $res['award_id'],
                    'award_org_name' => $res['award_org_name'],
                    'award_loc' => $res['award_loc'],
                    'award_title' => $res['award_title'],
                    'award_end_date' => $tempdate,
                    'award_status' => $status,
                    'award_email' => $res['award_email'],
                    'award_desc' => $res['award_desc'],
                    'award_org_logo' => $res['award_org_logo'],
                    'award_approved' => $res['award_approved'],
                    'award_create_date' => $res['award_create_date'],
                    'award_ref_url' => $res['award_ref_url'],
                    'award_upload_doc' => $res['award_upload_doc'],
                    'award_cates' => $res['award_cates'],
                    'award_upload_banner' => $res['award_upload_banner'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['award_cates']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('rec_edit_award', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }

    // public function show_Donate_Detail(Request $request, $encid)
    // {
    //     try {

    //         $sel_query = "SELECT * from awards where awards.award_id = " . $encid;
    //         $res_query = DBraw::select($sel_query);
    //         $res_query = json_decode(json_encode($res_query), true);
    //         if (count($res_query)) {
    //             $res = $res_query[0];
    //             $time = strtotime($res['award_end_date']);
    //             $tempdate = date("Y-m-d", $time);
    //             if ($res['award_approved'] == 1) {
    //                 $status = 'Approved';
    //             } else {
    //                 $status = 'On Hold';
    //             }

    //             $jp_obj = array(
    //                 'award_id' => $res['award_id'],
    //                 'award_org_name' => $res['award_org_name'],
    //                 'award_loc' => $res['award_loc'],
    //                 'award_title' => $res['award_title'],
    //                 'award_end_date' => $tempdate,
    //                 'award_status' => $status,
    //                 'award_email' => $res['award_email'],
    //                 'award_desc' => $res['award_desc'],
    //                 'award_org_logo' => $res['award_org_logo'],
    //                 'award_approved' => $res['award_approved'],
    //                 'award_create_date' => $res['award_create_date'],
    //                 'award_ref_url' => $res['award_ref_url'],
    //                 'award_upload_doc' => $res['award_upload_doc'],
    //                 'award_upload_banner' => $res['award_upload_banner'],
    //             );
    //         } else {
    //             //  $csrlist = array();
    //             //errorView
    //         }
    //         return view('rec_edit_award', compact(['jp_obj']));
    //     } catch (\Exception $ex) {
    //         error_log('exception' . $ex->getMessage());
    //     }
    // }

    public function update_awards(Request $request, $encid)
    {

        $award_title = $request->input('award_title');
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('award_desc');
        $ref_url = $request->input('url');
        $cates = $request->input('cates');

        // $org_file = $request->file('org_logo');
        // $document = $request->file('upload_evt_doc');
        // $banner = $request->file('upload_evt_banner');

        if ($request->hasFile('org_logo')) {
            $org_file = $request->file('org_logo');
            error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $org_file->move(public_path() . "/Images/", $src_file_logo);
            $db_name_logo = "/public/Images/" . $src_file_logo;
        } else {
            $db_name_logo = $request->input('old_org_logo');
        }

        if ($request->hasFile('upload_evt_doc')) {
            $document = $request->file('upload_evt_doc');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        } else {
            $document = $request->input('old_upload_evt_doc');
        }

        if ($request->hasFile('upload_evt_banner')) {
            $banner = $request->file('upload_evt_banner');
            $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
            $dest_file_banner = public_path() . "/Images/";
            $banner->move(public_path() . "/Images/", $src_file_banner);
            $db_name_banner = "/public/Images/" . $src_file_banner;
        } else {
            $db_name_banner = $request->input('old_upload_evt_banner');
        }

        DB::beginTransaction();

        try {
            DB::table('awards')->where('award_id', $encid)->update([

                'award_title' => $award_title,
                'award_org_name' => $organisation_name,
                'award_end_date' => $proposal_close_date,
                'award_email' => $email,
                'award_loc' => $loc_name,
                'award_desc' => $event_desc,
                // 'award_submitted_by' => $request->session()->get('ssiapp_rec_id'),
                'award_ref_url' => $ref_url,
                'award_org_logo' => $db_name_logo,
                'award_upload_doc' => isset($document) ? $document : "",
                'award_upload_banner' => $db_name_banner,
                'award_cates'=>$cates,
            ]);
            DB::commit();
            return \redirect('/admin/award-list');
        } catch (\Exception $ex) {
            DB::rollback();
            dd($ex);
            return \redirect('/error-page');
        }
    }


    public function searchads(Request $request)
    {

        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from awards where award_approved = 1 and award_end_date > '$today' order by award_id DESC";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['award_create_date']);
                $tempdate = date("F d Y, l", $time);
                $time = strtotime($res['award_end_date']);
                $tempenddate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $awardsearch[] = array(
                    'award_org_logo' => $res['award_org_logo'],
                    'award_org_name' => $res['award_org_name'],
                    'award_title' => $res['award_title'],
                    'award_email' => $res['award_email'],
                    'award_create_date' => $tempdate,
                    'award_loc' => $res['award_loc'],
                    'award_seo' => $res['award_SEO'],
                    'award_end_date' => $tempenddate
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $awardsearch = array();
        }
        $cates = GeneralUtils::getDBCates();
        $sel_query = "SELECT seo_data from SEO where seo_id = 30;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-awards', compact(['awardsearch','cates','seodata']));
    }

    public function ajaxaward(Request $request)
    {
        try{
        $body = $request->all();
        error_log($body['search']);
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from awards where (award_title  LIKE   '%" . $body['search'] . "%' OR award_org_name  LIKE   '%" . $body['search'] . "%') and award_cates LIKE '%". $body['cate']."%' and award_end_date > '$today';";
        error_log($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['award_approved'] == 1) {
                    $time = strtotime($res['award_create_date']);
                    $tempdate = date("F d Y, l", $time);
                    $time = strtotime($res['award_end_date']);
                    $tempenddate = date("F d Y, l", $time);
                    $data = '
                    <div class="col-12 " style="margin-bottom:2rem;">
    
                    <div class="card content fell_search_item"  id="results">
                        <div class="card-body" id="results">
                            <div class="row " id="resultss">
                    <div class="col-md-2  results" style="text-align: center;">
                    <img  style="width:80%" src=' . asset($res['award_org_logo']) . ' />
                    </div>
                    <div class="col-md-8">
                    <div class="results limittext" style="font-weight: bold;">' . $res['award_title'] . '</div>
                    <div id="results" style="font-weight: bold;">
                    ' . $res['award_org_name'] . '
                    </div>
                    <div id="results" style="font-weight: bold;">
                        <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;" >' . $res['award_loc'] . ' </span>
    
                    </div>
                    <div id="results">
                        <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <span style="font-weight: bold;color:#00254d;">' . $tempenddate . ' </span>
                    </div>
                </div>
                <div class="col-md-2 my-auto ">
                                       
                <a href="' .url('/award/') .'/'. $res['award_SEO']. '" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
            </div>
                
                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            ';

                    $htmldata = $htmldata . $data;
                }
            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }catch (\Exception $ex){
        $res['res'] = 'fail';
        $res['data'] = $ex->getMessage();
        return response()->json($res);
    }
    }

    
}
