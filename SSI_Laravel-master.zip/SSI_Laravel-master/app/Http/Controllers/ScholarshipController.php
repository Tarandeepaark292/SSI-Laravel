<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ScholarshipController extends Controller
{
    public function submitscholarship(Request $request)
    {
        $name = $request->input('name');
        $sc_seo = str_replace(" ", "-", $name);
        $sc_seo = $sc_seo . "-" . time();
        $organisation_title = $request->input('title');
        $location = $request->input('location');
        $logo = $request->file('org_logo');
        $date = $request->input('deadlinedate');
        $email = $request->input('email');
        // $closedate = $request->input('close_date');
        //$descproposal = $request->input('proposal_desc');
        // $closingdate = $request->input('closingdate');
        $desc = $request->input('desc_textarea');
        // $cates = $request->input('cates');
        
        $url = $request->input('url');
        $cates = $request->input('cates');
        if($request->hasFile('files')){
            $upload = $request->file('upload');
            error_log("--->>" . $upload->getClientOriginalExtension() . public_path() . $upload->getClientOriginalName());
            $src_document = date('YmdHis') . $upload->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $upload->move(public_path() . "/document/", $src_document);
            $upload = "/public/document/" . $src_document;
        }else{
            $upload = "";
        }
        error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $logo->move(public_path() . "/Images/", $src_file_logo);
        $logo = "/public/Images/" . $src_file_logo;


        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('scholarship')->insert([
            'sc_o_name' => $name,
            'sc_title' => $organisation_title,
            'sc_loc' => $location,
            'sc_end_date' => $date,
            'sc_email' => $email,
            'sc_desc' => $desc,
            'sc_o_logo' => $logo,
            'sc_upload_doc' => $upload,
            'sc_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'sc_approved' => 0,
            'sc_url' => $url,
            'sc_cate' => $cates,
            // 'award_upload_doc' => $document,
            // 'award_upload_banner' => $db_name_banner,
            'sc_SEO' => GeneralUtils::CreateSEO($name),
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        if(GeneralUtils::addtoCartaftersubmit($request,13)){
            return \redirect('/organizer/showcart');
        }else{
            return \redirect('/recruiter/dashboard');    
        }
    }

    public function show_scholarship_Detail(Request $request, $scid)
    {
        try {

            $sel_query = "SELECT * from scholarship where scholarship.sc_id = " . $scid;

            $res_query = DBraw::select($sel_query);

            $res_query = json_decode(json_encode($res_query), true);

            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['sc_end_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['sc_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }


                $jp_obj = array(
                    'sc_id' => $res['sc_id'],
                    'sc_name' => $res['sc_o_name'],
                    'sc_loc' => $res['sc_loc'],
                    // 'sc_loc' => $res['sc_loc'],
                    'sc_date' => $tempdate,

                    'sc_status' => $status,


                    'sc_email' => $res['sc_email'],
                    'sc_description' => $res['sc_desc'],
                    'sc_upload' => $res['sc_upload_doc'],
                    'sc_url' => $res['sc_url'],
                    'sc_category' => $res['sc_cate'],
                    'sc_title' => $res['sc_title'],
                    'sc_logo' => $res['sc_o_logo'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['sc_cate']);
            } else {
                //  $csrlist = array();
                //errorView
            }

            return view('rec_edit_scholarship', compact(['jp_obj','html']));
        } catch (\Exception $ex) {
            dd($ex);
            error_log('exception' . $ex->getMessage());
        }
    }


    public function update_scholarship(Request $request, $encid)
    {

        $name = $request->input('name');
        $organisation_title = $request->input('title');
        $location = $request->input('location');
        $date = $request->input('deadlinedate');
        $email = $request->input('email');
        $desc = $request->input('desc_textarea');

        $url = $request->input('url');
        $cates = $request->input('cates');


        if ($request->hasFile('org_logo')) {
            $logo = $request->file('org_logo');
            error_log("--->>" . $logo->getClientOriginalExtension() . public_path() . $logo->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $logo->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $logo->move(public_path() . "/Images/", $src_file_logo);
            $db_name_logo = "/public/Images/" . $src_file_logo;
        } else {
            $db_name_logo = $request->input('old_org_logo');
        }


        if ($request->hasFile('upload')) {
            $upload = $request->file('upload');
            $src_file_banner = date('YmdHis') . $upload->getClientOriginalName();
            $dest_file_banner = public_path() . "/Images/";
            $upload->move(public_path() . "/Images/", $src_file_banner);
            $db_name_banner = "/public/Images/" . $src_file_banner;
        } else {
            $db_name_banner = $request->input('old_upload');
        }

        DB::beginTransaction();

        try {
            DB::table('scholarship')->where('sc_id', $encid)->update([

                'sc_o_name' => $name,
                'sc_title' => $organisation_title,
                'sc_cate' => $cates,
                'sc_loc' => $location,
                'sc_email' => $email,
                'sc_o_logo' => $db_name_logo,
                'sc_end_date' => $date,
               // 'sc_submitted_by' => $request->session()->get('ssiapp_rec_id'),
                'sc_desc' => $desc,
                'sc_upload_doc' => isset($db_name_banner) ? $db_name_banner : "",
                'sc_url' => $url,


            ]);
            DB::commit();
            return \redirect('/admin/sch-list');
        } catch (\Exception $ex) {
            DB::rollback();
            dd($ex);
            return \redirect('/error-page');
        }
    }

    public function searchscholarship(Request $request)
    {

        //$sel_query = "SELECT * from scholarship where sc_approved = 1 order by sc_id desc";
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from scholarship where sc_approved = 1 and sc_end_date > '$today'  order by sc_id desc";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {

                // error_log(GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER));
                $time = strtotime($res['sc_end_date']);
                $tempdate = date("F d Y, l", $time);
                error_log(json_encode($res));
                $scsearch[] = array(
                    'sc_logo' => $res['sc_o_logo'],
                    'sc_name' => $res['sc_o_name'],
                    'sc_title' => $res['sc_title'],
                    'sc_email' => $res['sc_email'],
                    'sc_date' => $tempdate,
                    'sc_loc' => $res['sc_loc'],
                    'sc_SEO' => $res['sc_SEO'],
                    // 'm_img_date'=>$res['m_img_date']

                    // 'm_img_id'=>GeneralUtils::encrypt_id($res['m_id'],AdminDefines::MANAGEMENT_SECRET_ID_KEY,AdminDefines::MANAGEMENT_ID_CIPHER)
                );
            }
        } else {
            $scsearch = array();
        }
        $cates = GeneralUtils::getDBCates();
        $sel_query = "SELECT seo_data from SEO where seo_id = 31;";

        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            $seodata = json_decode($res_query[0]['seo_data'],true);
        }else{
            $seodata = null;
        }
        return view('all-scholarship', compact(['scsearch','cates','seodata']));
    }

    public function ajaxscholarship(Request $request)
    {
        $body = $request->all();
        error_log($body['search']);
        //$sel_query = "SELECT * from scholarship where sc_title  LIKE   '%" . $body['search'] . "%' and sc_o_name  LIKE   '%" . $body['search'] . "%' and sc_cate LIKE '%". $body['cate']."%';";
        $today = date("Y-m-d") . " 00:00:00";
        $sel_query = "SELECT * from scholarship where sc_title  LIKE   '%" . $body['search'] . "%' and sc_o_name  LIKE   '%" . $body['search'] . "%' and sc_cate LIKE '%". $body['cate']."%' and sc_end_date > '$today';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        error_log(json_encode($res_query));

        $img = asset('img/ssi_logo.svg');
        $htmldata = "";

        if (count($res_query)) {
            foreach ($res_query as $res) {

                if ($res['sc_approved'] == 1) {
                    $time = strtotime($res['sc_end_date']);
                    $tempdate = date("F d Y, l", $time);
                    $data = '
                <div class="col-12 " style="margin-bottom:2rem;">

                <div class="card content fell_search_item"  id="results">
                    <div class="card-body" id="results">
                        <div class="row " id="resultss">
                <div class="col-md-2  results" style="text-align: center;">
                <img  style="width:80%" src=' . asset($res['sc_o_logo']) . ' />
                </div>
                <div class="col-md-8">
                <div class="results limittext" style="font-weight: bold;color:#004a99">' . $res['sc_title'] . '</div>
                <div id="results" style="font-weight: bold;color:#004a99">
                ' . $res['sc_o_name'] . '
                </div>
                <div id="results" style="font-weight: bold;">
                    <i class="fa fa-map-marker" aria-hidden="true" style="color:#007bff;font-size: 18px;"></i> <span style="font-weight: bold;color:#007bff;" >' . $res['sc_loc'] . ' </span>

                </div>
                <div id="results">
                    <i class="fa fa-calendar" aria-hidden="true" style="color:#00254d;font-size: 18px;"></i> Closing date: <span style="font-weight: bold;color:#00254d;">' . $tempdate . ' </span>
                </div>
            </div>
            <div class="col-md-2 my-auto ">
                                   
            <a href="' .url('/scholarship/') .'/'. $res['sc_SEO']. '" class="btn btn-newprimary">Details <i class="fa fa-chevron-right"></i></a>
        </div>
            
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        ';

                    $htmldata = $htmldata . $data;
                }
            }

            error_log($data);
            return  response()->json(array('res' => 'SUCCESS', 'data' => $htmldata));;
        } else {
            $res['res'] = 'fail';
            return response()->json($res);
        }
    }
}
