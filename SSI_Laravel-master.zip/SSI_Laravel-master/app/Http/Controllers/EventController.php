<?php

namespace App\Http\Controllers;

use App\Defines\SecurityDefines;
use App\Utils\GeneralUtils;
use DB as DBraw;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    //
    public function submitEVENT(Request $request)
    {
        $event_title = $request->input('event_title');
        $event_seo = str_replace(" ","-",$event_title);
        $event_seo = $event_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('event_desc');
        // $closedate = $request->input('close_date');
        //$descproposal = $request->input('proposal_desc');
        // $closingdate = $request->input('closingdate');
        $ref_url = $request->input('url');
        // $cates = $request->input('cates');
        $org_file = $request->file('org_logo');
        
        $banner = $request->file('upload_evt_banner');
        $cates = $request->input('cates');

        if($request->hasFile('upload_evt_doc')){
            $document = $request->file('upload_evt_doc');
            error_log("--->>" . $document->getClientOriginalExtension() . public_path() . $document->getClientOriginalName());
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = "";
        }

        error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
        $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
        $dest_file_logo = public_path() . "/Images/";
        $org_file->move(public_path() . "/Images/", $src_file_logo);
        $db_name_logo = "/public/Images/". $src_file_logo;

        $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
        $dest_file_banner = public_path() . "/Images/";
        $banner->move(public_path() . "/Images/", $src_file_banner);
        $db_name_banner = "/public/Images/". $src_file_banner;



        DB::beginTransaction();
        $createdate = date("Y-m-d H:i:s");
        DB::table('events')->insert([
            'evt_org_name' => $organisation_name,
            'evt_loc' => $loc_name,
            'evt_title' => $event_title,
            'evt_end_date' => $proposal_close_date,
            'evt_email' => $email,
            'evt_desc' => $event_desc,
            'evt_org_logo' => $db_name_logo,
            'evt_submitted_by' => $request->session()->get('ssiapp_rec_id'),
            'evt_approved' => 0,
            'evt_create_date' => $createdate,
            'evt_ref_url' => $ref_url,
            'evt_upload_doc' => $document,
            'evt_upload_banner' => $db_name_banner,
            'evt_SEO' => GeneralUtils::CreateSEO($event_title),
            'evt_cate' => $cates,
            // 'file_date'=>date("Y-m-d H:i:s"),

        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return \redirect('/recruiter/dashboard');
    }

    public function update_event(Request $request,$encid){
        $event_title = $request->input('event_title');
        // $event_seo = str_replace(" ","-",$event_title);
        // $event_seo = $event_seo . "-" . time();
        $organisation_name = $request->input('organisation_name');
        $proposal_close_date = $request->input('proposal_close_date');
        $email = $request->input('email');
        $loc_name = $request->input('loc_name');
        $event_desc = $request->input('event_desc');
        $cates = $request->input('cates');
        $ref_url = $request->input('url');
        
        if($request->hasFile('org_logo')){
            $org_file = $request->file('org_logo');
            error_log("--->>" . $org_file->getClientOriginalExtension() . public_path() . $org_file->getClientOriginalName());
            $src_file_logo = date('YmdHis') . $org_file->getClientOriginalName();
            $dest_file_logo = public_path() . "/Images/";
            $org_file->move(public_path() . "/Images/", $src_file_logo);
            $db_name_logo = "/public/Images/". $src_file_logo;

        }else{
            $db_name_logo = $request->input('old_org_logo'); 
        }
        
        if($request->hasFile('upload_evt_doc')){
            $document = $request->file('upload_evt_doc');
            $src_document = date('YmdHis') . $document->getClientOriginalName();
            $dest_document = public_path() . "/document/";
            $document->move(public_path() . "/document/", $src_document);
            $document = "/public/document/" . $src_document;
        }else{
            $document = $request->input('old_upload_evt_doc');
        }

        if($request->hasFile('upload_evt_banner')){
            $banner = $request->file('upload_evt_banner');
            $src_file_banner = date('YmdHis') . $banner->getClientOriginalName();
            $dest_file_banner = public_path() . "/Images/";
            $banner->move(public_path() . "/Images/", $src_file_banner);
            $db_name_banner = "/public/Images/". $src_file_banner;
        }else{
            $db_name_banner =$request->input('old_upload_evt_banner');
        }

        DB::beginTransaction();

        try{
            DB::table('events')->where('evt_id', $encid)->update([
                'evt_org_name' => $organisation_name,
                'evt_loc' => $loc_name,
                'evt_title' => $event_title,
                'evt_end_date' => $proposal_close_date,
                'evt_email' => $email,
                'evt_desc' => $event_desc,
                'evt_org_logo' => $db_name_logo,
                // 'evt_submitted_by' => $request->session()->get('ssiapp_rec_id'),
                'evt_ref_url' => $ref_url,
                'evt_upload_doc' => isset($document) ? $document : "",
                'evt_upload_banner' => $db_name_banner,
                'evt_cate'=>$cates,
                ]);
                DB::commit();
                return \redirect('/admin/event-list');
        }catch(\Exception $ex){
            DB::rollback();
            return \redirect('/error-page');
        }
    }

    public function show_event_Detail(Request $request,$encid){
        try {

            $sel_query = "SELECT * from events where events.evt_id = " . $encid ;
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            if (count($res_query)) {
                $res = $res_query[0];
                $time = strtotime($res['evt_end_date']);
                $tempdate = date("Y-m-d", $time);
                if ($res['evt_approved'] == 1) {
                    $status = 'Approved';
                } else {
                    $status = 'On Hold';
                }

                $jp_obj = array(
                    'evt_id' => $res['evt_id'],
                    'evt_title' => $res['evt_title'],
                    'evt_org_name' => $res['evt_org_name'],
                    'evt_loc' => $res['evt_loc'],
                    'evt_end_date' => $tempdate,
                    
                    'evt_status' => $status,
                    'evt_cates' => $res['evt_cate'],
                    'evt_desc' => $res['evt_desc'],
                    'evt_org_logo' => $res['evt_org_logo'],
                    'evt_ref_url' => $res['evt_ref_url'],
                    'evt_approved' => $res['evt_approved'],
                    'evt_upload_doc' => $res['evt_upload_doc'],
                    'evt_upload_banner' => $res['evt_upload_banner'],
                    'evt_email' => $res['evt_email'],
                );
                $html = GeneralUtils::createHTML_for_selected_cate($res['evt_cate']);
            } else {
                //  $csrlist = array();
                //errorView
            }
            return view('edit_event', compact(['jp_obj', 'html']));
        } catch (\Exception $ex) {
            error_log('exception' . $ex->getMessage());
        }
    }
}
