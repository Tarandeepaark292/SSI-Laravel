<?php
namespace App\Defines;

class CartDefines
{
    //MANAGEMENT
    public const CART_PREFIX = 'ssi-cart-';
    public const CART_STS_COMPLETE = 1;
    public const CART_STS_OPEN = 0;
    public const CART_USER_TYPE_JS = 1;
    public const CART_USER_TYPE_REC = 2;
    public const CART_USER_TYPE_ADMIN = 3;
    // public const MANAGEMENT_ID_CIPHER = "aes-128-gcm";
}
?>