<?php
namespace App\Defines;

class SecurityDefines
{
    //MANAGEMENT
    public const MANAGEMENT_SECRET_KEY = '86355678-444c-43b1-93d7-135635d7d15e';
    public const MANAGEMENT_SECRET_ID_KEY = '172dc9be-00fa-407b-9e3b-483aae3a9887'; //login-token for recruiter
    public const MANAGEMENT_ID_CIPHER = "aes-128-gcm";
}
?>