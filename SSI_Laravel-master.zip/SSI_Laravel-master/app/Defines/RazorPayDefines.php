<?php
namespace App\Defines;

class RazorPayDefines
{
    //RazorPay
    public const RP_KEY = 'rzp_test_NXFykFIljAZKEK';//"rzp_test_7cBj0zim1cYP7f"; //"rzp_test_U41ZNwllmGzTHS";//"rzp_test_7cBj0zim1cYP7f";
    public const RP_SECRET = 'kQoAO23xaLugnlFZyaly80b5';//"Vo7KM0B7RevpvAI7SKggNONM"; //"mzvHijBv7kDcqK5lqZvbLRWa";//"Vo7KM0B7RevpvAI7SKggNONM";
}
?>