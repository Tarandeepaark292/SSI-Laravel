<?php
namespace App\Defines;

class MiscDefines
{
    //Purchases
    //public const RP_KEY = 'rzp_test_7cBj0zim1cYP7f';//"rzp_test_7cBj0zim1cYP7f"; //"rzp_test_U41ZNwllmGzTHS";//"rzp_test_7cBj0zim1cYP7f";
    //public const RP_SECRET = 'Vo7KM0B7RevpvAI7SKggNONM';//"Vo7KM0B7RevpvAI7SKggNONM"; //"mzvHijBv7kDcqK5lqZvbLRWa";//"Vo7KM0B7RevpvAI7SKggNONM";

    public const MISC_PUR_USER_TYPE_RECURITER = 2;
    public const MISC_PUR_USER_TYPE_JOBSEEKER = 1;
    public const MISC_PUR_NOT_USED = 0;
    public const MISC_PUR_USED = 1;

    public const IMG_PATH = "/public/Images";
}
?>