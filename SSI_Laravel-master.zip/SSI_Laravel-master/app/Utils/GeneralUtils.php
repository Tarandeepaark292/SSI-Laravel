<?php
namespace App\Utils;

use App\Defines\CartDefines;
use App\Defines\MiscDefines;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;

?>
<?php

class GeneralUtils
{


    public static function testpdf(){
        
        $myfile = fopen(__DIR__."/pdfssi.html", "r") or die("Unable to open file!");
        $data = fread($myfile,filesize(__DIR__."/pdfssi.html"));
        fclose($myfile);

        $html2pdf = new Html2Pdf('P', 'A4', 'fr');
        $html2pdf->writeHTML($data);
        $html2pdf->output('File.pdf','D');
    }

    public static function getJobType($jtype){
        // <option class="level-0" value="3740">Contribution</option>
        //                     <option class="level-0" value="42">Freelance</option>
        //                     <option class="level-0" value="39" selected="selected">Full Time</option>
        //                     <option class="level-0" value="3649">Grant</option>
        //                     <option class="level-0" value="43">Internship</option>
        //                     <option class="level-0" value="40">Part Time</option>
        //                     <option class="level-0" value="41">Temporary</option>
        //                     <option class="level-0" value="3681">Work from Home</option>
        if($jtype == 3740 ){
           return  'Contribution';
        }
        if($jtype == 42 ){
            return  'Freelance';
        }
        if($jtype == 39 ){
            return  'Full Time';
        }
        if($jtype == 3649 ){
            return  'Grant';
        }
        if($jtype == 43 ){
            return  'Internship';
        }
        if($jtype == 40 ){
            return  'Part Time';
        }
        if($jtype == 41 ){
            return  'Temporary';
        }
        if($jtype == 3681 ){
            return  'Work from Home';
        }
    }

    public static function getDBCates(){
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('cate_name'=>$res['cate_name'] , 'cate_id'=>$res['cate_id']);
            }
        }
        return $res_array;
    }

    public static function createHTML_for_selected_cate($cates){
        $catesarr = explode(',',$cates);
        $sel_query = "SELECT * FROM category;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        if (count($res_query)) {
            foreach ($res_query as $res) {
                if(in_array($res['cate_id'],$catesarr)){
                    $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick(); " checked>
                    <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                    
                }else{
                    $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['cate_id'] . '" name="proposal_chk[]" value="' . $res['cate_id'] . '" onclick="onchkclick();">
                <label for="proposal_chk' . $res['cate_id'] . '"> ' . $res['cate_name'] . '</label><br>';
                
                }
                $count++;
                if ($count == $division) {
                    $html .= $div_beg . $temp_html . $div_end;
                    $temp_html = '';
                    $count = 0;
                }
            }
        }
        return $html;
    }

    public static function createHTML_for_selected_pub_cates($cates){
        $catesarr = explode(',',$cates);
        $sel_query = "SELECT * FROM publication_category;";
        // dd($sel_query);
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $total_cate = count($res_query) + 1;
        
        // dd($total_cate);
        //error_log(round($total_cate / 3));
        $division = round($total_cate / 3);
        $count = 0;
        $div_beg = '<div class="form-group col-lg-4">';
        $div_end = '</div>';
        $html = "";
        $temp_html = "";
        $total_count = count($res_query);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                if(in_array($res['p_cat_id'],$catesarr)){
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['p_cat_id'] . '" name="proposal_chk[]" value="' . $res['p_cat_id'] . '" onclick="onchkclick();" checked>
                <label for="proposal_chk' . $res['p_cat_id'] . '"> ' . $res['p_cat_name'] . '</label><br>';
                     
            }else{
                $temp_html .= '<input type="checkbox" class="proposal_chk" id="proposal_chk' . $res['p_cat_id'] . '" name="proposal_chk[]" value="' . $res['p_cat_id'] . '" onclick="onchkclick();">
            <label for="proposal_chk' . $res['p_cat_id'] . '"> ' . $res['p_cat_name'] . '</label><br>';
            
            }
                $count++;
                $total_count --;
                if ($count == $division) {
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                    $count = 0;
                }else if($total_count == 0){
                    
                    $html .= $div_beg . $temp_html . $div_end;
                    //error_log($html);
                    $temp_html = '';
                }
            }
            
        }
    
        return $html;

    }
    public static function createHTML_for_selected_pub_focus($cates){
        $catesarr = explode(',',$cates);
        $sel_query = "SELECT * FROM publication_focus;";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            $total_cate = count($res_query) + 1;
            error_log(round($total_cate / 3));
            $division = round($total_cate / 3);
            $count = 0;
            $div_beg = '<div class="form-group col-lg-4">';
            $div_end = '</div>';
            $html2 = "";
            $temp_html2 = "";
            $total_count = count($res_query);
            if (count($res_query)) {
                foreach ($res_query as $res) {

                    if(in_array($res['p_f_id'],$catesarr)){   
                    $temp_html2 .= '<input type="checkbox" class="proposal_focus_chk" id="proposal_focus_chk' . $res['p_f_id'] . '" name="proposal_focus_chk[]" value="' . $res['p_f_id'] . '" onclick="onchkclick2();" checked>
                    <label for="proposal_focus_chk' . $res['p_f_id'] . '"> ' . $res['p_f_name'] . '</label><br>';
                    }
                    else{
                        $temp_html2 .= '<input type="checkbox" class="proposal_focus_chk" id="proposal_focus_chk' . $res['p_f_id'] . '" name="proposal_focus_chk[]" value="' . $res['p_f_id'] . '" onclick="onchkclick2();" >
                        <label for="proposal_focus_chk' . $res['p_f_id'] . '"> ' . $res['p_f_name'] . '</label><br>';
                    }


                    $count++;
                    $total_count --;
                    if ($count == $division) {
                        $html2 .= $div_beg . $temp_html2 . $div_end;
                        $temp_html2 = '';
                        $count = 0;
                    }else if($total_count == 0){
                        
                        $html2 .= $div_beg . $temp_html2 . $div_end;
                        //error_log($html);
                        $temp_html2 = '';
                    }
                }
            }
            return $html2;
         
    }

    public static function createPaymentEntry($cart_id,$user_id,$user_type,$orderid,$rpay_id,$provider_order_id,$amt){
        /*
        	`pay_id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`pay_user_type` INT(11) NULL DEFAULT NULL,
	`pay_user_id` BIGINT(20) NULL DEFAULT NULL,
	`pay_service_id` BIGINT(20) NULL DEFAULT NULL,
	`pay_desc` TEXT NULL DEFAULT NULL,
	`pay_create_date` DATETIME NULL DEFAULT NULL,
	`pay_provider_trans_id` TEXT NULL DEFAULT NULL,
	`pay_cart_id` BIGINT(20) NULL DEFAULT NULL,
        */
        DB::beginTransaction();
        //create payment and mark cart as finished
        $createdate = date("Y-m-d H:i:s");
        try{
            DB::table('payments')->insert([
                'pay_cart_id' => $cart_id,
                'pay_user_id' => $user_id,
                'pay_user_type' => $user_type,
                'pay_provider_trans_id' => $rpay_id,
                'pay_order_id' => $orderid,
                'pay_provider_order_id' => $provider_order_id,
                'pay_create_date' => $createdate,  
                'pay_total' => $amt,
            ]);
            $pay_id = DB::getPdo()->lastInsertId();

            DB::update('update cart set cart_sts = ' . CartDefines::CART_STS_COMPLETE . ' where cart_id =' . $cart_id);
            DB::commit();
            return $pay_id;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return -1;
        }
    }



    public static function consumeBroadcastResume($js_id)
    {
        DB::beginTransaction();
        $createdate = date("Y-m-d");
        $updated = strtotime($createdate . ' + 30 days');
        $dbdate = date('Y-m-d',$updated);
        $dbdate = $dbdate . " 23:59:59";
        try{
            DB::update("update job_seeker set js_broadcast_resume = 1 ,js_bc_end_date='$dbdate' where js_id =" . $js_id);
            DB::commit();
            return true;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return false;
        }
    }

    public static function adminBroadcastResume($js_id)
    {
        DB::beginTransaction();
        $createdate = date("Y-m-d");
        $updated = strtotime($createdate . ' + 30 days');
        $dbdate = date('Y-m-d',$updated);
        $dbdate = $dbdate . " 23:59:59";
        try{
            DB::update("update job_seeker set js_broadcast_resume = 1 ,js_bc_end_date='$dbdate' where js_id =" . $js_id);
            DB::commit();
            return $dbdate;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return null;
        }
    }

    public static function adminDisableBroadcastResume($js_id)
    {
        DB::beginTransaction();
        $createdate = date("Y-m-d");
        $updated = strtotime($createdate . ' + 30 days');
        $dbdate = date('Y-m-d',$updated);
        $dbdate = $dbdate . " 23:59:59";
        try{
            DB::update("update job_seeker set js_broadcast_resume = 0 ,js_bc_end_date=NULL where js_id =" . $js_id);
            DB::commit();
            return true;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return false;
        }
    }


    public static function createPurchases($payment_id, $ser_array,$user_id,$user_type){
        //[{"itm_id":6,"itm_service":"Job Post","itm_qty":1,"itm_amt":999},{"itm_id":3,"itm_service":"Fellowship AD","itm_qty":1,"itm_amt":2499}]
        DB::beginTransaction();
        $res_array = array();
        error_log(json_encode($ser_array));
        try{
            
            $createdate = date("Y-m-d H:i:s");
            foreach($ser_array as $ser){
                DB::table('purchases')->insert([
                    'pur_service' => $ser['itm_id'],
                    'pur_user' => $user_id,
                    'pur_u_type' => $user_type,
                    'pur_ser_name' => $ser['itm_service'],
                    'pur_ser_price' => $ser['itm_amt'],
                    'pur_payment_id' => $payment_id,
                    'pur_create_date' => $createdate,
                    'pur_used'=> MiscDefines::MISC_PUR_NOT_USED,
                ]);
                if($ser['itm_id'] == 14){
                    //the user can only be recruiter

                }
                $res_array[] = DB::getPdo()->lastInsertId();
            }
            DB::commit();
            return $res_array;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return null;
        }
    }

    public static function getRecruiterDetail($rec_id)
    {
        $sel_query = "SELECT * FROM recruiter where r_id = " . $rec_id . ";";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return array(
                'r_id' => $res_query[0]['r_id'],
                'r_name' => $res_query[0]['r_name'],
                'r_email' => $res_query[0]['r_email'],
                'r_org_name' => $res_query[0]['r_org_name'],
                'r_phone' => $res_query[0]['r_phone'],
            );
        } else {
            return null;
        }
    }

    public static function getJobseekerDetail($js_id)
    {
        $sel_query = "SELECT * FROM job_seeker where js_id = " . $js_id . ";";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return array(
                'js_id' => $res_query[0]['js_id'],
                'js_name' => $res_query[0]['js_name'],
                'js_email' => $res_query[0]['js_email'],
                'js_resume_doc' => $res_query[0]['js_resume_doc'],
                'js_number' => $res_query[0]['js_number'],
                'js_photo' => $res_query[0]['js_photo'],
                'js_SEO' => $res_query[0]['js_SEO'], 
            );
        } else {
            return null;
        }
    }

    public static function getJobDetail($jp_id)
    {
        $sel_query = "SELECT * FROM job_post where jp_id = " . $jp_id . ";";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return array(
                'jp_id' => $res_query[0]['jp_id'],
                'jp_title' => $res_query[0]['jp_title'],
                'jp_job_type' => GeneralUtils::getJobType($res_query[0]['jp_job_type']),
                'jp_desc' => $res_query[0]['jp_desc'],
                'jp_SEO' => $res_query[0]['jp_SEO'],
            );
        } else {
            return null;
        }
    }

    public static function getServiceDetail($ser_id)
    {
        $sel_query = "SELECT * FROM services where ser_id = " . $ser_id . ";";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return array(
                'ser_id' => $res_query[0]['ser_id'],
                'ser_name' => $res_query[0]['ser_name'],
                'ser_price' => $res_query[0]['ser_price'],
            );
        } else {
            return null;
        }
    }

    public static function getCartDetails($cart_id)
    {
        $sel_query = "SELECT * FROM cart where cart_id = " . $cart_id . ";";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return array(
                'cart_id' => $res_query[0]['cart_id'],
                'cart_data' => $res_query[0]['cart_data'],
                'cart_total' => $res_query[0]['cart_total'],
                'cart_user_id' => $res_query[0]['cart_user_id'],
                'cart_user_type' => $res_query[0]['cart_user_type'],
                'cart_sts' => $res_query[0]['cart_sts'],
                'cart_uuid' => $res_query[0]['cart_uuid'],
            );
        } else {
            return null;
        }
    }

    public static function createcart($js_rec_id, $data,$resume_id = -1)
    {

        //check cart exists
error_log("resumeid -> ".$resume_id);
        DB::beginTransaction();
        try {
            $cart_uuid = uniqid("ssi-cart-", true);
            $createdate = date("Y-m-d H:i:s");

            // if ($data['utype'] == 'JS') {
            //     $utype = CartDefines::CART_USER_TYPE_JS;
            // } else if ($data['utype'] == 'REC') {
            //     $utype = CartDefines::CART_USER_TYPE_REC;
            // } else {
            //     $utype = CartDefines::CART_USER_TYPE_ADMIN;
            // }
            $utype = $data['utype'] ;   
            $arr = array();
            //error_log(json_encode($data));
            $total = 0;
            for ($i = 0; $i < count($data['items']); $i++) {
                # code...
                $obj = $data['items'][$i];
                $arr[] = array(
                    'itm_id' => $obj['ser_id'],
                    'itm_service' => $obj['ser_name'],
                    'itm_qty' => 1,
                    'itm_amt' => $obj['ser_price'],
                    'itm_resume_id' => $resume_id
                );
                $total = $total + $obj['ser_price'];
            }
            $itemdata = json_encode($arr);

            DB::table('cart')->insert([
                'cart_data' => $itemdata,
                'cart_user_id' => $js_rec_id,
                'cart_user_type' => $utype,
                'cart_sts' => CartDefines::CART_STS_OPEN,
                'cart_uuid' => $cart_uuid,
                'cart_total' => $total,
                'cart_create' => $createdate,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            return $id;
        } catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return -1;
        }
    }

    public static function updatecart($cart_id, $newdata,$resume_id = -1)
    {

        //check cart exists
        error_log('test');
        $cart_detail = GeneralUtils::getCartDetails($cart_id);

        $arr = json_decode($cart_detail['cart_data'], true);
        DB::beginTransaction();
        try {
            $total = $cart_detail['cart_total'];
            for ($i = 0; $i < count($newdata['items']); $i++) {
                # code...
                $obj = $newdata['items'][$i];
                $arr[] = array(
                    'itm_id' => $obj['ser_id'],
                    'itm_service' => $obj['ser_name'],
                    'itm_qty' => 1,
                    'itm_amt' => $obj['ser_price'],
                    'itm_resume_id' => $resume_id
                );
                $total = $total + $obj['ser_price'];
            }
            $itemdata = json_encode($arr);
            error_log($itemdata);
            error_log('update cart set cart_total = ' . $total . ',cart_data = \'' . $itemdata . '\' where cart_id =' . $cart_id);
            DB::update('update cart set cart_total = ' . $total . ',cart_data = \'' . $itemdata . '\' where cart_id =' . $cart_id);
            DB::commit();
            return $cart_id;
        } catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return -1;
        }        
    }

    public static function createPurchaseResumeEntry($resume_id,$rec_id){
        DB::beginTransaction();
        try {
            $resumecreatedate = date("Y-m-d H:i:s");
            $createdate = date("Y-m-d");
            $updated = strtotime($createdate . ' + 30 days');
            $dbdate = date('Y-m-d',$updated);
            $expresumedate = $dbdate . " 23:59:59";
            DB::table('purchased_resumes')->insert([
                'p_r_js_id' => $resume_id,
                'p_r_rec_id' => $rec_id,
                'p_r_create_date' => $resumecreatedate,
                'p_r_exp_date' => $expresumedate,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            return $id;
        }catch (\Exception $ex) {
            error_log($ex->getMessage());
            DB::rollback();
            return -1;
        }        
    }

    public static function update_adm_Token($token, $adm_id)
    {
        DB::beginTransaction();
        try {
            DB::update('update admin set adm_login_session = \'' . $token . '\' where adm_id =' . $adm_id);
            DB::commit();
            return true;
        } catch (\Exception $ex) {
            DB::rollback();
            return false;
        }
    }

    public static function gen_adm_LoginToken()
    {
        $prefix = 'adm-';
        return uniqid($prefix, true);
    }

    public static function update_js_Token($token, $js_id)
    {
        DB::beginTransaction();
        try {
            DB::update('update job_seeker set js_login_token = \'' . $token . '\' where js_id =' . $js_id);
            DB::commit();
            return true;
        } catch (\Exception $ex) {
            DB::rollback();
            return false;
        }
    }

    public static function gen_js_LoginToken()
    {
        $prefix = 'js-';
        return uniqid($prefix, true);
    }

    public static function update_recruiter_Token($token, $r_id)
    {
        DB::beginTransaction();
        try {
            DB::update('update recruiter set r_login_token = \'' . $token . '\' where r_id =' . $r_id);
            DB::commit();
            return true;
        } catch (\Exception $ex) {
            DB::rollback();
            return false;
        }
    }

    public static function gen_recruiter_LoginToken()
    {
        $prefix = 'rec-';
        return uniqid($prefix, true);
    }

    public static function checkJobseekerExistEmail($email)
    {
        $sel_query = "SELECT * FROM job_seeker where js_email = '" . $email . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return true;
        } else {
            return false;
        }
    }

    public static function checkRecruiterExistEmail($email)
    {
        $sel_query = "SELECT * FROM recruiter where r_email = '" . $email . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return true;
        } else {
            return false;
        }
    }

    // public static moveuploadfile($files){

    //     //get Client file name

    //     $files = $request->file('companylogo');
    //         $name = $request->file('companylogo')->getClientOriginalName();
    //         $img_link = 'public/uploaded_images/'.$name;
    //         $destinationPath = 'public/uploaded_images/'; // upload path
    //         $profileImage = date('YmdHis') . "." . $files->getClientOriginalExtension();
    //         $files->move($destinationPath, $profileImage);
    //         $insert['image'] = "$profileImage";
    // }

    public static function encrypt_id($id, $key, $algo)
    {
        if (in_array($algo, openssl_get_cipher_methods())) {
            $ivlen = openssl_cipher_iv_length($algo);
            $iv = openssl_random_pseudo_bytes($ivlen);
            $ciphertext = openssl_encrypt($id, $algo, $key, $options = 0, $iv, $tag);
            $encoded_tag = \base64_encode($tag);
            $encoded_iv = \base64_encode($iv);
            return \base64_encode($ciphertext . "|||" . $encoded_tag . "|||" . $encoded_iv);
        } else {
            return \base64_encode($id);
        }
    }

    public static function decrypt_id($enc_id, $key, $algo)
    {
        if (in_array($algo, openssl_get_cipher_methods())) {

            $dec_id = \base64_decode($enc_id);
            $dec_arr = explode("|||", $dec_id);
            $decoded_tag = \base64_decode($dec_arr[1]);
            $decoded_iv = \base64_decode($dec_arr[2]);
            return openssl_decrypt($dec_arr[0], $algo, $key, $options = 0, $decoded_iv, $decoded_tag);
        } else {
            return \base64_decode($enc_id);
        }
    }

    public static function getCateNames($listids){
        $sel_query = "SELECT GROUP_CONCAT(cate_name) as res FROM category where cate_id in ($listids)";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return $res_query[0]['res'];
        } else {
            return "";
        }
    }

    public static function getpubCateNames($listids){
        $sel_query = "SELECT GROUP_CONCAT(p_cat_name SEPARATOR ', ') as res FROM publication_category where p_cat_id in ($listids)";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return $res_query[0]['res'];
        } else {
            return "";
        }
    }

    public static function getpubFocus($listids){
        $sel_query = "SELECT GROUP_CONCAT(p_f_name SEPARATOR ', ') as res FROM publication_focus where p_f_id in ($listids)";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return $res_query[0]['res'];
        } else {
            return "";
        }
    }

    public static function getSEOData($id){
        try{
            $sel_query = "SELECT seo_data from SEO where seo_id = 1;";

            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);

            if (count($res_query)) {
                $seodata = json_decode($res_query[0]['seo_data'],true);
            }else{
                $seodata = null;
            }
            return $seodata;
        }catch(\Exception $ex){
            error_log($ex->getMessage());
            return null;
        }
    }

    public static function CreateSEO($string){
        $slug = preg_replace('/[^a-z0-9-]+/', '-', trim(strtolower($string))) . "-" . time();
        return $slug;
    }

    public static function saveMsgFromRecruiter($msgdata){
        //msg_data
        //msg_by
        //msg_to
        try{
            DB::beginTransaction();
            $createdate = date("Y-m-d H:i:s");
            DB::table('messages')->insert([
                'msg_data' => $msgdata['data'],
                'msg_by' => $msgdata['by'],
                'msg_to' => $msgdata['to'],
                'msg_date' => $createdate,
            ]);
            $id = DB::getPdo()->lastInsertId();
            DB::commit();
            return true;
        }catch(\Exception $ex){
            error_log($ex->getMessage());
            return false;
        }
    }

    public static function getJSMEssages($js_id){
        $sel_query = "SELECT * FROM messages INNER JOIN recruiter ON  msg_by = recruiter.r_id WHERE msg_to = " . $js_id;
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['msg_date']);
                $tempdate = date("M d Y", $time);
                $msglist[] = array(
                    "msg_id"=>$res['msg_id'],
                    "msg_data"=>$res['msg_data'],
                    "org_name"=>$res['r_org_name'],
                    "msg_date"=>$tempdate,
                );
            }
        } else {
            $msglist = array();
        }
        return $msglist;

    }


    
    public static function getOrganizationList(){
        $sel_query = "SELECT * from recruiter ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $recruiterlist[] = array(
                    'r_id' => $res['r_id'],
                    'r_org_name' => $res['r_org_name'],
                    'r_email' => $res['r_email'],
                    'r_phone' => $res['r_phone'],
                    'r_comp_type' => $res['r_comp_type'],
                    'r_name' => $res['r_name'],
                    'r_org_name' => $res['r_org_name'],
                    'r_off_website' => $res['r_off_website'],
                );
            }
        } else {
            $recruiterlist = array();
        }
        return $recruiterlist;
    }

    public static function getJSList(){
        $sel_query = "SELECT * from job_seeker ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {

                $jslist[] = array(
                    'js_id' => $res['js_id'],
                    'js_email' => $res['js_email'],
                    'js_name' => $res['js_name'],
                    'js_p_title' => $res['js_p_title'],
                    'js_pwd' => $res['js_pwd'],      
                    'js_area_expertise' => $res['js_area_expertise'],
                    'js_tot_exp' => $res['js_tot_exp'],
                );
            }
        } else {
            $jslist = array();
        }
        return $jslist;
    }

    public static function addtoCartaftersubmit($request, $service_id){
        if (!$request->session()->has('ssiapp_cart_id') ) {
            //generate cart
            $service_data = GeneralUtils::getServiceDetail($service_id);
            $data['items'][] = $service_data;

            $result = -1;
            if ($request->session()->has('ssiapp_rec_id') ) {
                $data['utype'] = CartDefines::CART_USER_TYPE_REC;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_rec_id'),$data);
            }else if( $request->session()->has('ssiapp_js_id') ){
                $data['utype'] = CartDefines::CART_USER_TYPE_JS;
                $result = GeneralUtils::createcart($request->session()->get('ssiapp_js_id'),$data);
            }
           
            error_log($result);
            if($result == -1){
                $res['res'] = 'FAIL';
                $res['error'] = "Cart not generated";
    
                return response()->json($res);
            }else{
                $request->session()->put('ssiapp_cart_id', $result);
                return response()->json(array('res'=>'SUCCESS','data'=>$result)); 
            }
            
        }else{
            //update cart
            error_log('UPDATE  dvdsvd CART ->>>' . $request->session()->get('ssiapp_cart_id'));
            $service_data = GeneralUtils::getServiceDetail($service_id);
            $data['items'][] = $service_data;
            $result = GeneralUtils::updatecart($request->session()->get('ssiapp_cart_id'),$data);
            if($result == -1){
                return false;
            }else{
                return true; 
            }
        }

    }

    public static function getNGOdocs($ngoid)
    {
        $sel_query = "SELECT * from NgoResource where ngo_r_id = $ngoid ";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            $res = $res_query[0];
            return json_decode($res['ngo_r_data'], true);
        }
        return array();
    }

}
