<?php
namespace App\Utils;

use App\Defines\CartDefines;
use App\Defines\MiscDefines;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\GeneralEmail;
use App\Mail\JSGeneral;
use App\Mail\ForgotPassword;
use App\Mail\JSForgotPassword;

?>

<?php

class EmailUtils
{
    public static function NewAccountCreated($data,$type,$email){
        if($type == "ORG"){
            Mail::to($email)->send(new GeneralEmail($data));
        }else{
            Mail::to($email)->send(new JSGeneral($data));
        }
        
    }

    public static function ForgotPassword($data,$type,$email){
        if($type == "ORG"){
            Mail::to($email)->send(new ForgotPassword($data));
        }else{
            Mail::to($email)->send(new JSForgotPassword($data));
        }
        
    }
}

?>