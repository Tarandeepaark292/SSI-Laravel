<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class ScholarshipExport implements FromCollection, WithHeadings, ShouldAutoSize
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT sc_title, sc_desc, sc_email, sc_loc, sc_o_name, sc_end_date,sc_cate,sc_approved, sc_SEO  FROM scholarship INNER JOIN recruiter ON recruiter.r_id = scholarship.sc_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['sc_end_date']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'sc_title' => $res['sc_title'],
                'sc_desc' => $res['sc_desc'],
                'sc_email' => $res['sc_email'],
                'sc_loc' => $res['sc_loc'],
                'sc_o_name' => $res['sc_o_name'],
                'sc_cate' => $res['sc_cate'],
                'sc_approved' => (($res['sc_approved'] == 1) ? 'YES' : 'NO'),
                'sc_end_date' => $tempcreatedate,
                'sc_SEO' => url('/scholarship') . '/'. $res['sc_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Title',
            'Description',
            'Email',
            'Location',
            'Organisation Name',
            'Scholarship Category',
            'Is Approved',
            'End Date',
            'Link',
        ];
    }
}

?>