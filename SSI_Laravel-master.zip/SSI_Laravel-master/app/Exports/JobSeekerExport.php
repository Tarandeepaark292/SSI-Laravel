<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class JobSeekerExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        $sql_select = "SELECT * FROM job_seeker;";
        $res_query = DBraw::select($sql_select);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
           
            $time = strtotime($res['js_createdate']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'js_email' => $res['js_email'],
                'js_name' => $res['js_name'],
                'js_p_title' => $res['js_p_title'],
                'js_pwd' => $res['js_pwd'],
                
                'js_area_expertise' => $res['js_area_expertise'],
                
                'js_tot_exp' => $res['js_tot_exp'],
                'js_create' => $tempcreatedate,
                

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Email',
            'Name',
            'Title',
            'Password',
         
            'Area of Expertise',
         
            'Total Experience',
            'Create Date',
        ];
    }
}

?>