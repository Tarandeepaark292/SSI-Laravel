<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class OnlineCourseExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT on_institute, 	on_detail, on_display, on_area, on_apply, on_email, on_state, on_year,	on_approved  FROM onlinecourse INNER JOIN recruiter ON recruiter.r_id = onlinecourse.on_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $data[] = array(
                'on_institute' => $res['on_institute'],
                'on_detail' => $res['on_detail'],
                'on_display' => $res['on_display'],
                'on_area' => $res['on_area'],
                'on_email' => $res['on_email'],
                'on_state' => $res['on_state'],
                'on_year' => $res['on_year'],
                //'rfp_category' => $res['rfp_category'],
                'on_approved' => (($res['on_approved'] == 1) ? 'YES' : 'NO'),
                'on_apply' => $res['on_apply'],
           

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Institute',
            'Institute Detail',
            'Display',
            'Area',
            'Email',
            'State',
            'Year',
            // 'Category',
            'Is Approved',
            'Apply By',
        ];
    }
}

?>