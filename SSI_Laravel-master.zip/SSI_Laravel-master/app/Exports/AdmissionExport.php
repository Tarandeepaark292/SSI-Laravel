<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class AdmissionExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT adn_inst_name, adn_area, adn_display_page, adn_title, adn_cost_details, adn_state,	adn_year, adn_email,adn_approved, adn_website_url  FROM admission INNER JOIN recruiter ON recruiter.r_id = admission.adn_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $data[] = array(
                'adn_inst_name' => $res['adn_inst_name'],
                'adn_area' => $res['adn_area'],
                'adn_display_page' => $res['adn_display_page'],
                'adn_title' => $res['adn_title'],
                'adn_cost_details' => $res['adn_cost_details'],
                'adn_state' => $res['adn_state'],
                'adn_year' => $res['adn_year'],
                'adn_email' => $res['adn_email'],
                'adn_approved' => (($res['adn_approved'] == 1) ? 'YES' : 'NO'),
                'adn_website_url' => $res['adn_website_url'],

                //'rfp_category' => $res['rfp_category'],
               
                // 'rfp_SEO' => url('/rfp') . '/'. $res['rfp_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Institute Name',
            'Area',
            'Display Page',
            'Title',
            'Cost  Detail',
            'State',
            'Year',
            'Email',
            //'RFP Category',
            'Is Approved',
            'Website URL',
            
        ];
    }
}

?>