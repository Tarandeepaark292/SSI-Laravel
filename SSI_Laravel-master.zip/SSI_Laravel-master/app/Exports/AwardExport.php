<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class AwardExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT award_title, award_loc, award_desc, award_email, award_end_date, award_create_date, award_org_name,award_approved,award_SEO  FROM awards INNER JOIN recruiter ON recruiter.r_id = awards.award_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['award_create_date']);
            $tempclosedate = date("M d Y", $time);
            $time = strtotime($res['award_end_date']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'award_title' => $res['award_title'],
                'award_loc' => $res['award_loc'],
                'award_desc' => $res['award_desc'],
                'award_email' => $res['award_email'],
                'award_org_name' => $res['award_org_name'],
                'award_create_date' => $tempclosedate,
                //'rfp_category' => $res['rfp_category'],
                'award_approved' => (($res['award_approved'] == 1) ? 'YES' : 'NO'),
                'award_end_date' => $tempcreatedate,
                'award_SEO' => url('/awards') . '/'. $res['award_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Title',
            'Location',
            'Description',
            'Email',
            'Organisation Name',
            'Award End Date',
            //'RFP Category',
            'Is Approved',
            'Create Date',
            'Link',
        ];
    }
}

?>