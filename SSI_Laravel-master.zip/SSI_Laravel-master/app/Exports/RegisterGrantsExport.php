<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class RegisterGrantsExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT reg_o_name, reg_v_org, reg_o_ach, reg_o_head, reg_website, reg_create, reg_email, reg_approved,  reg_SEO  FROM register_grants INNER JOIN recruiter ON recruiter.r_id = register_grants.reg_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['reg_create']);
            $tempclosedate = date("M d Y", $time);
            $data[] = array(
                'reg_o_name' => $res['reg_o_name'],
                'reg_v_org' => $res['reg_v_org'],
                'reg_o_ach' => $res['reg_o_ach'],
                'reg_o_head' => $res['reg_o_head'],
                'reg_website' => $res['reg_website'],
                'reg_email' => $res['reg_email'],
                //'rfp_category' => $res['rfp_category'],
                'reg_approved' => (($res['reg_approved'] == 1) ? 'YES' : 'NO'),
                'reg_create' => $tempclosedate,
                'reg_SEO' => url('/register_grants') . '/'. $res['reg_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Organizer Name',
            'Vision Organization',
            'Organisation Achievement',
            'Organisation Head',
            'Organisation Website',
            'Organization Email',
            //'RFP Category',
            'Is Approved',
            'Create Date',
            'Link',
        ];
    }
}

?>