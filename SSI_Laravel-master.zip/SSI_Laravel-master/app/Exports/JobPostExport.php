<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class JobPostExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT jp_org_name, jp_desc, jp_title, jp_loc, jp_ad_type_area_of_expertise, jp_closing_date, jp_email, jp_approved, jp_SEO  FROM job_post INNER JOIN recruiter ON recruiter.r_id = job_post.jp_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['jp_closing_date']);
            $tempclosedate = date("M d Y", $time);
            // $time = strtotime($res['rfp_create_date']);
            // $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'jp_title' => $res['jp_title'],
                'jp_org_name' => $res['jp_org_name'],
                'jp_desc' => $res['jp_desc'],
                'jp_loc' => $res['jp_loc'],
                'jp_ad_type_area_of_expertise' => $res['jp_ad_type_area_of_expertise'],
                'jp_closing_date' => $tempclosedate,
                'jp_email' => $res['jp_email'],
                'jp_approved' => (($res['jp_approved'] == 1) ? 'YES' : 'NO'),
                //'rfp_category' => $res['rfp_category'],
                
                'jp_SEO' => url('/job_post') . '/'. $res['jp_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Title',
            'Organizer Name',
            'Description',
            'Location',
            'Area Expertise',
            'Close Date',
            'Email',
            //'RFP Category',
            'Is Approved',
            'Link',
        ];
    }
}

?>