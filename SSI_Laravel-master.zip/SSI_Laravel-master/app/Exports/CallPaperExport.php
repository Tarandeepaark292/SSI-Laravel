<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CallPaperExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT paper_o_name, paper_title, paper_type, paper_loc, paper_disp,  paper_email,paper_approved, paper_apply_by  FROM call_paper INNER JOIN recruiter ON recruiter.r_id = call_paper.paper_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $data[] = array(
                'paper_o_name' => $res['paper_o_name'],
                'paper_title' => $res['paper_title'],
                'paper_type' => $res['paper_type'],
                'paper_loc' => $res['paper_loc'],
                'paper_disp' => $res['paper_disp'],
                'paper_email' => $res['paper_email'],
                //'rfp_category' => $res['rfp_category'],
                'paper_approved' => (($res['paper_approved'] == 1) ? 'YES' : 'NO'),
                'paper_apply_by' => $res['paper_apply_by'],
        

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Organizer Name',
            'Title',
            'Type',
            'Location',
            'Description',
            'Email',
            //'RFP Category',
            'Is Approved',
            'Apply By',
           
        ];
    }
}

?>