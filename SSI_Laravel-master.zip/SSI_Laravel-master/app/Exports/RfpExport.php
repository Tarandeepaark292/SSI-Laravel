<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class RfpExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        $sel_query = "SELECT rfp_org, r_name, rfp_title, rfp_loc, rfp_g_amt, rfp_close_date, rfp_email, rfp_category,rfp_approved, rfp_create_date, rfp_SEO  FROM rfp INNER JOIN recruiter ON recruiter.r_id = rfp.rfp_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['rfp_close_date']);
            $tempclosedate = date("M d Y", $time);
            $time = strtotime($res['rfp_create_date']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'rfp_title' => $res['rfp_title'],
                'r_name' => $res['r_name'],
                'rfp_org' => $res['rfp_org'],
                'rfp_loc' => $res['rfp_loc'],
                'rfp_g_amt' => $res['rfp_g_amt'],
                'rfp_close_date' => $tempclosedate,
                'rfp_email' => $res['rfp_email'],
                //'rfp_category' => $res['rfp_category'],
                'rfp_approved' => (($res['rfp_approved'] == 1) ? 'YES' : 'NO'),
                'rfp_create_date' => $tempcreatedate,
                'rfp_SEO' => url('/rfp') . '/'. $res['rfp_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Title',
            'Organizer Name',
            'Organization',
            'Location',
            'Grant Amount',
            'RFP Close Date',
            'Organization Email',
            //'RFP Category',
            'Is Approved',
            'RFP Create Date',
            'RFP Link',
        ];
    }
}

?>