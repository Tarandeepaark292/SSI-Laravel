<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class OrganizerExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        $sql_select = "SELECT * FROM recruiter;";
        $res_query = DBraw::select($sql_select);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
           
            $time = strtotime($res['r_createdate']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'r_email' => $res['r_email'],
                'r_name' => $res['r_name'],
                'r_pwd' => $res['r_pwd'],
                'r_phone' => $res['r_phone'],
                'r_org_name' => $res['r_org_name'],
                'r_comp_type' => $res['r_comp_type'],
                'r_create' => $tempcreatedate,
                'r_off_lline_number' => $res['r_off_lline_number'],
                //'rfp_category' => $res['rfp_category'],
                'r_off_website' => $res['r_off_website'],
                'r_org_pan' => $res['r_org_pan'],
                'r_pin' => $res['r_pin'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Email',
            'Name',
            'Password',
            'Phone',
            'Organisation Name',
            'Company Type',
            'Create Date',
            'Office Number',
            'Official Website',
            'Organisation Pan Number',
            'Organisation Pin ',
        ];
    }
}

?>