<?php

namespace App\Exports;

// use App\User;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class EventsExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        // $data = DB::table('rfp')->orderBy('rfp_id', 'ASC')->get();
        // return $data;
        // $sel_query = "SELECT evt_org_name, evt_desc, evt_title, evt_loc, evt_create_date, evt_end_date, evt_email,,evt_approved, evt_ref_url, evt_SEO FROM events INNER JOIN recruiter ON recruiter.r_id = events.evt_submitted_by;";
        
        $sel_query = "SELECT evt_org_name,evt_desc,evt_title,evt_loc,evt_email,evt_ref_url,evt_create_date,evt_end_date,evt_approved, evt_SEO FROM events INNER JOIN recruiter ON recruiter.r_id = events.evt_submitted_by;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $data = [];
        foreach ($res_query as $res) {
            $time = strtotime($res['evt_create_date']);
            $tempclosedate = date("M d Y", $time);
            $time = strtotime($res['evt_end_date']);
            $tempcreatedate = date("M d Y", $time);
            $data[] = array(
                'evt_org_name' => $res['evt_org_name'],
                'evt_desc' => $res['evt_desc'],
                'evt_title' => $res['evt_title'],
                'evt_loc' => $res['evt_loc'],
                'evt_create_date' => $tempclosedate,
                'evt_email' => $res['evt_email'],
                'evt_ref_url' => $res['evt_ref_url'],

                //'rfp_category' => $res['rfp_category'],
                'evt_approved' => (($res['evt_approved'] == 1) ? 'YES' : 'NO'),
                'evt_end_date' => $tempcreatedate,
                'evt_SEO' => url('/events') . '/'. $res['evt_SEO'],

            );
        }
        return collect($data);
    }

    public function headings(): array
    {
        return [
            'Organizer Name',
            'Description',
            'Title',
            'Location',
            'Create Date',
            'Email',
            'Reference URL',
            //'RFP Category',
            'Is Approved',
            'End Date',
            'Event Link',
        ];
    }
}

?>